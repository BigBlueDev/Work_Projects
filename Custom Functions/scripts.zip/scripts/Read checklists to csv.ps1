﻿#PURPOSE: Gather all VCodes from a list of checklists and record that data to a CSV

#CHANGELOG
#Version 1.0 - 03/01/24 - MDR - Initial Version

$ReportPath = "C:\Temp\All_VCodes.csv"
$ChecklistFiles = (gci $ChecklistPath).Name
$VCodeDataArray = @()

#If the report already exists then remove it
If (Test-Path $ReportPath) {
    Remove-Item $ReportPath
}

#Get a list of all checklists
$ChecklistPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Checklists"

#Clear console
Clear

#Loop through all checklists to record them to the report
ForEach ($FileName in $ChecklistFiles) {
    #Display the checklist being read
    Write-Host "`nReading checklist $FileName"

    #Create an XML object
    $Checklist_XMLObject = New-Object XML
    #This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
    $Checklist_XMLObject.PreserveWhitespace = $true
    #This is the name of the empty checklist template file
    $Checklist_XMLObject.Load("$ChecklistPath\$FileName")

    #Get just the vulnerability data from the checklist
    $VULN_DATA = $Checklist_XMLObject.CHECKLIST.STIGS.iSTIG.VULN

    #Loop through each vulnerability
    ForEach ($VULN in $VULN_DATA) {
        #Store information from each vulnerability
        $VULN_NUM = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Vuln_Num'}).ATTRIBUTE_DATA
        $SEVERITY = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA
        $TITLE = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Rule_Title'}).ATTRIBUTE_DATA
        $DISCUSSION = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Vuln_Discuss'}).ATTRIBUTE_DATA
        $CHECK = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Check_Content'}).ATTRIBUTE_DATA
        $FIX = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Fix_Text'}).ATTRIBUTE_DATA

        #Record the vulnerability information to an array
        $VCodeDataArray += [PSCustomObject]@{'ChecklistName'=$FileName;'Vuln_Num'=$VULN_NUM;'Severity'=$SEVERITY;'Title'=$TITLE;'Discussion'=$DISCUSSION;`
                                             'Check'=$CHECK;'Fix'=$FIX}
    }

    #Once the entire checklist of information has been gathered, append it to the report file
    $VCodeDataArray | Export-Csv $ReportPath -Append -NoTypeInformation

    #Report that the checklist data has completed being collected
    Write-Host "`nCompleted checklist $FileName" -ForegroundColor Cyan

    #Reset the array for the next checklist
    $VCodeDataArray = @()
}

#Notify that the script is complete
Write-Host "Script complete" -ForegroundColor Green
# SIG # Begin signature block
# MIILxQYJKoZIhvcNAQcCoIILtjCCC7ICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUcM/oGxLHeVUuryoXbAokpMks
# ypqgggktMIIEbDCCA1SgAwIBAgIDEjRvMA0GCSqGSIb3DQEBCwUAMFoxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMwHhcNMjMwNDEwMDAw
# MDAwWhcNMjcwNDA3MTM1NTU0WjBmMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5T
# LiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEMMAoGA1UE
# CxMDRExBMRMwEQYDVQQDEwpDUy5ETEEuMDA1MIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAjMaXJ2yQcMI0ZgW8qa3xkItp8L7VtB9FDtfdiQS6chAZC+V8
# RQO4iWMV87+bCdMIbHx/AgTepcuOwX/kAfxKVhb2msv3mHPzu7hhJpNTV9sGFR9S
# c62e4axw0i/O73B/ZsClZG0URlYFDb3X6rV1Qk27BUXdX++683Xgk5CspndiN1Zb
# fjZ69IDsvda5/gV6wyREcXlr5nlEXwn8SuA+J2xlFtkXbDNeLHo4Z88NlY61i13s
# 7C71giua12KEwy1g9saqw2mKlwfFfL4qipyRVrcPJNvc/lTh+wVq5P4WaBA06iKC
# 33IHndFd1cNor0sjp2zviZBYWcsFYngTFwKWCQIDAQABo4IBLTCCASkwHwYDVR0j
# BBgwFoAUF+ZLyBpLyaemcLRMTV7I9jbUMJgwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9ESURDQV82My5jcmwwDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdIAQPMA0wCwYJYIZIAWUCAQsqMB0GA1UdDgQWBBT4AbxTG6dDzp0i
# G4IfIlvBDYoM3TBlBggrBgEFBQcBAQRZMFcwMwYIKwYBBQUHMAKGJ2h0dHA6Ly9j
# cmwuZGlzYS5taWwvc2lnbi9ET0RJRENBXzYzLmNlcjAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwHwYDVR0lBBgwFgYKKwYBBAGCNwoDDQYIKwYBBQUH
# AwMwDQYJKoZIhvcNAQELBQADggEBAApQpCPdOGEWZ/CqUmxr7H/Jkj7CALR3OA6y
# b/vEO2v2QplFIyBiTFRoFs1G4pOt5njGzE8RtkXyO3PRD29RKKMBMwJwQtXLX9vD
# 0YVf/w5Wqtj3lptILtKM5elw+jehhn4KgyncMtp2yJwzToyRaoFdo3g/T5ddSYts
# 03i4XOuxEFnlJW/hozoMFaKFYitF5KMPwvnkLAynzmZLdhw17piUoo2ftPhh0i6y
# ZWwCObwfeti5yqNyUyof1XzD/4+h380+Zye68PeXdLNS/wIdAeKVImKxZB8s1+qq
# DAny4dogj0FU4PgdunbnwgACVTTmVswXUIlZOH6rS/K4iUkLdLYwggS5MIIDoaAD
# AgECAgIFDzANBgkqhkiG9w0BAQsFADBbMQswCQYDVQQGEwJVUzEYMBYGA1UEChMP
# VS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEWMBQG
# A1UEAxMNRG9EIFJvb3QgQ0EgMzAeFw0yMTA0MDYxMzU1NTRaFw0yNzA0MDcxMzU1
# NTRaMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAK
# BgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFEl3WgH6i1/u1Su87lcHX
# lB7dOsy17rfSlynPggESAK/rjElfavjrkmT6ooaq1bmV59HbSOVrN8wM7V2A5D5t
# rhMRCf9UC62PyU7/tqDcaFntnY11MAHs5yRfQud8WS2Wd1y3maLOOLwIgH+AYXCh
# 7KQUXs1dueJe53GE3M9e88GEFjfzJdPPM0fENk4ENeHKiBjHr290hoMu9cLBZMez
# DnAElqJMwZ0pwWwJRQviQ5jSG/rRViRx244X357taauwktYwzkhlLky8tBSnO+X9
# cOcl6TtohohTeW1mi3L/wuvpIE2vuFq/HrMvHETBn8RR9TfyAq5DE6ijnSjaxFyd
# AgMBAAGjggGGMIIBgjAfBgNVHSMEGDAWgBRsipSid7GAch2Behaq8tzOZu5FwDAd
# BgNVHQ4EFgQUF+ZLyBpLyaemcLRMTV7I9jbUMJgwDgYDVR0PAQH/BAQDAgGGMGcG
# A1UdIARgMF4wCwYJYIZIAWUCAQskMAsGCWCGSAFlAgELJzALBglghkgBZQIBCyow
# CwYJYIZIAWUCAQs7MAwGCmCGSAFlAwIBAw0wDAYKYIZIAWUDAgEDETAMBgpghkgB
# ZQMCAQMnMBIGA1UdEwEB/wQIMAYBAf8CAQAwDAYDVR0kBAUwA4ABADA3BgNVHR8E
# MDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RST09UQ0EzLmNy
# bDBsBggrBgEFBQcBAQRgMF4wOgYIKwYBBQUHMAKGLmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvaXNzdWVkdG8vRE9EUk9PVENBM19JVC5wN2MwIAYIKwYBBQUHMAGGFGh0dHA6
# Ly9vY3NwLmRpc2EubWlsMA0GCSqGSIb3DQEBCwUAA4IBAQAGG9UvVRw4kCnDGW7n
# RE7d0PtOn/xUx+sDBhK3u5wsFKl10fG7BSwmQRqQntbweiJFA9dIZbSOtkDF1cff
# fUMuHJE+2f/bOFWQuI9Tr7BS+Z6fS3ei1PrURrmgm5TxES6lznXqtL4M3IIkvlYM
# aaMxBLLGExy2t62aLZxv3EIa+2gPqVSCod0NA2Q8oboRgko/A01gbfMIcQ1FEqBl
# 3zbGhUIH2Hc2FnczW5L5hc61w62TB8EoocxDxbXg0lS8MvfGPIv7krViLom1/kbe
# kC/FlCB/+99HcPrPG07hDL+ryphbZ7LImdFr2+bWR+NR3ZHQ2ZPo1pSMOmLcRnSu
# IXsVMYICAjCCAf4CAQEwYTBaMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5TLiBH
# b3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMM
# RE9EIElEIENBLTYzAgMSNG8wCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFJ2q+r8Ls30KBgvc0jS4
# STW1mFYPMA0GCSqGSIb3DQEBAQUABIIBAHeLpyvUSCz2tcdkzzuZf4DZeZskMpnJ
# 81hCzgPfwxcZ3dOP/Ao3PwCQRn53bGJ2UVxuA/2cB+j7LNa3BTykfdipkwq+AJrB
# J4hnS0ZBJTyjGC2d2QxPe0r0jvB2QBtdwliZSVbguFXL6gC5jPUdiQ4oy09jkje7
# bAZZ1SKg8MWJJXnitq67w44nv2I9DaTdAOuo1SVWvlvvCOEPE1cN1suss1nhfgUX
# uFha6ay2MLeyAHP1DxrO3xykw0UUZJLmf+oQQGB915RE2Mos4zJ5QpZEvva+fY/N
# Bslsy/8lCmZMhWA7f/3foWum+fTSAmVGNsMeSL9c7vFdJhu41ntsgI8=
# SIG # End signature block
