﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2020 v5.7.174
	 Created on:   	1/20/2021 10:43 AM
	 Created by:   	Matthew Miller
	 Organization: 	INFO OPTERATIONS
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93949	   	Rule ID: SV-104035r1_rule	   	STIG ID: ESXI-65-000001
Severity: CAT II	   	Classification: Unclass
If Lockdown Mode is disabled, this is a finding.
Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Security Profile. Click edit on "Lockdown Mode" and set to Enabled (Normal or Strict).
Or
From a PowerCLI command prompt while connected to the ESXi host run the following commands:

$level = "lockdownNormal" OR "lockdownStrict"
$vmhost = Get-VMHost -Name <hostname> | Get-View
$lockdown = Get-View $vmhost.ConfigManager.HostAccessManager
$lockdown.ChangeLockdownMode($level)

Note: In strict lockdown mode the DCUI service is stopped. If the connection to vCenter Server is lost and the vSphere Web Client is no longer available, the ESXi host becomes inaccessible.
#>
Get-VMHost | Select Name, @{ N = "Lockdown"; E = { $_.Extensiondata.Config.LockdownMode } }


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93951	   	Rule ID: SV-104037r1_rule	   	STIG ID: ESXI-65-000002
Severity: CAT III	   	Classification: Unclass

If the DCUI.Access is not restricted to root, this is a finding.
Note: This list is only for local user accounts and should only contain the root user.
For environments that do not use vCenter server to manage ESXi, this is not applicable.
Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the DCUI.Access value and configure it to root.
or
From a PowerCLI command prompt while connected to the ESXi host run the following command:
Get-VMHost | Get-AdvancedSetting -Name DCUI.Access | Set-AdvancedSetting -Value "root"#>
Get-VMHost | Get-AdvancedSetting -Name DCUI.Access



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93953	   	Rule ID: SV-104039r1_rule	   	STIG ID: ESXI-65-000003
Severity: CAT III	   	Classification: Unclass

If the Exception users list contains accounts that do not require special permissions, this is a finding.

Note - This list is not intended for system administrator accounts but for special circumstances such as a service account.

For environments that do not use vCenter server to manage ESXi, this is not applicable.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Security Profile. Under lockdown mode click Edit and remove unnecessary users to the exceptions list.
#>


	$vmhost = Get-VMHost | Get-View
	$lockdown = Get-View $vmhost.ConfigManager.HostAccessManager
	$lockdown.QueryLockdownExceptions()


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93955	   	Rule ID: SV-104041r1_rule	   	STIG ID: ESXI-65-000004
Severity: CAT II	   	Classification: Unclass

If the Syslog.global.logHost setting is not set to a site specific syslog server, this is a finding.
Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Syslog.global.logHost value and configure it to a site specific syslog server.
or
From a PowerCLI command prompt while connected to the ESXi host run the following commands:
Get-VMHost | Get-AdvancedSetting -Name Syslog.global.logHost | Set-AdvancedSetting -Value "<syslog server hostname>"#>

Get-VMHost | Get-AdvancedSetting -Name Syslog.global.logHost


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93957	   	Rule ID: SV-104043r1_rule	   	STIG ID: ESXI-65-000005
Severity: CAT II	   	Classification: Unclass

If the Security.AccountLockFailures is set to a value other than 3, this is a finding.
Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Security.AccountLockFailures value and configure it to 3.
or
From a PowerCLI command prompt while connected to the ESXi host run the following command:
Get-VMHost | Get-AdvancedSetting -Name Security.AccountLockFailures | Set-AdvancedSetting -Value 3#>


Get-VMHost | Get-AdvancedSetting -Name Security.AccountLockFailures

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93959	   	Rule ID: SV-104045r1_rule	   	STIG ID: ESXI-65-000006
Severity: CAT II	   	Classification: Unclass

If the Security.AccountUnlockTime is set to a value other than 900, this is a finding.
Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Security.AccountUnlockTime value and configure it to 900.
or
From a PowerCLI command prompt while connected to the ESXi host run the following commands:
Get-VMHost | Get-AdvancedSetting -Name Security.AccountUnlockTime | Set-AdvancedSetting -Value 900#>

Get-VMHost | Get-AdvancedSetting -Name Security.AccountUnlockTime

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93961	   	Rule ID: SV-104047r1_rule	   	STIG ID: ESXI-65-000007
Severity: CAT II	   	Classification: Unclass

Check for either of the following login banners based on the character limitations imposed by the system. An exact match of the text is required. If one of these banners is not displayed, this is a finding.

You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only.

By using this IS (which includes any device attached to this IS), you consent to the following conditions:

-The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations.

-At any time, the USG may inspect and seize data stored on this IS.

-Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG-authorized purpose.

-This IS includes security measures (e.g., authentication and access controls) to protect USG interests- -not for your personal benefit or privacy.

-Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details.

OR

I've read & consent to terms in IS user agreem't.

If the DCUI logon screen does not display the DoD logon banner, this is a finding.

Fix Text: From a PowerCLI command prompt while connected to the ESXi host copy the following contents into a script(.ps1 file) and run to set the DCUI screen to display the DoD logon banner:

<script begin>

$value = @"
{bgcolor:black} {/color}{align:left}{bgcolor:black}{color:yellow}{hostname} , {ip}{/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:black}{color:yellow}{esxproduct} {esxversion}{/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:black}{color:yellow}{memory} RAM{/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:black}{color:white} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} using this IS (which includes any device attached to this IS), you consent to the following conditions: {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} - The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} enforcement (LE), and counterintelligence (CI) investigations. {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} - At any time, the USG may inspect and seize data stored on this IS. {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} - Communications using, or data stored on, this IS are not private, are subject to routine monitoring, {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} interception, and search, and may be disclosed or used for any USG-authorized purpose. {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} - This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} for your personal benefit or privacy. {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} - Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} or monitoring of the content of privileged communications, or work product, related to personal representation {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} product are private and confidential. See User Agreement for details. {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{align:left}{bgcolor:yellow}{color:black} {/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
{bgcolor:black} {/color}{align:left}{bgcolor:dark-grey}{color:white} <F2> Accept Conditions and Customize System / View Logs{/align}{align:right}<F12> Accept Conditions and Shut Down/Restart {bgcolor:black} {/color}{/color}{/bgcolor}{/align}
{bgcolor:black} {/color}{bgcolor:dark-grey}{color:black} {/color}{/bgcolor}
"@

Get-VMHost | Get-AdvancedSetting -Name Annotations.WelcomeMessage | Set-AdvancedSetting -Value $value

<script end>#>

Get-VMHost | Get-AdvancedSetting -Name Annotations.WelcomeMessage

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93963	   	Rule ID: SV-104049r1_rule	   	STIG ID: ESXI-65-000008
Severity: CAT II	   	Classification: Unclass

If the Config.Etc.issue setting (/etc/issue file) does not contain the logon banner exactly as shown below this is a finding.

"You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By using this IS (which includes any device attached to this IS), you consent to the following conditions: -The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations. -At any time, the USG may inspect and seize data stored on this IS. -Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG-authorized purpose. -This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not for your personal benefit or privacy. -Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details."

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Config.Etc.issue value and set it to the following.

"You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By using this IS (which includes any device attached to this IS), you consent to the following conditions: -The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations. -At any time, the USG may inspect and seize data stored on this IS. -Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG-authorized purpose. -This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not for your personal benefit or privacy. -Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details."

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Config.Etc.issue | Set-AdvancedSetting -Value "<insert logon banner>"
#>

Get-VMHost | Get-AdvancedSetting -Name Config.Etc.issue

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93965	   	Rule ID: SV-104051r1_rule	   	STIG ID: ESXI-65-000009
Severity: CAT II	   	Classification: Unclass

# grep -i "^Banner" /etc/ssh/sshd_config

If there is no output or the output is not exactly "Banner /etc/issue", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

Banner /etc/issue#>

grep -i "^Banner" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93967	   	Rule ID: SV-104053r1_rule	   	STIG ID: ESXI-65-000010
Severity: CAT II	   	Classification: Unclass

If there is no output or the output is not exactly "Ciphers aes128-ctr,aes192-ctr,aes256-ctr", this is a finding.

Fix Text: Limit the ciphers to those algorithms which are FIPS-approved. Counter (CTR) mode is also preferred over cipher-block chaining (CBC) mode.

From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

Ciphers aes128-ctr, aes192-ctr, aes256-ctr#>


grep -i "^Ciphers" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93969	   	Rule ID: SV-104055r1_rule	   	STIG ID: ESXI-65-000011
Severity: CAT I	   	Classification: Unclass

# grep -i "^Protocol" /etc/ssh/sshd_config

If there is no output or the output is not exactly "Protocol 2", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

Add or correct the following line in "/etc/ssh/sshd_config":

Protocol 2#>

grep -i "^Protocol" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93971	   	Rule ID: SV-104057r1_rule	   	STIG ID: ESXI-65-000012
Severity: CAT II	   	Classification: Unclass

# grep -i "^IgnoreRhosts" /etc/ssh/sshd_config

If there is no output or the output is not exactly "IgnoreRhosts yes", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

Add or correct the following line in "/etc/ssh/sshd_config":

IgnoreRhosts yes#>

grep -i "^IgnoreRhosts" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93973	   	Rule ID: SV-104059r1_rule	   	STIG ID: ESXI-65-000013
Severity: CAT II	   	Classification: Unclass

# grep -i "^HostbasedAuthentication" /etc/ssh/sshd_config

If there is no output or the output is not exactly "HostbasedAuthentication no", this is a finding.
Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":
Add or correct the following line in "/etc/ssh/sshd_config":
HostbasedAuthentication no#>

grep -i "^HostbasedAuthentication" /etc/ssh/sshd_config


VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93975	   	Rule ID: SV-104061r1_rule	   	STIG ID: ESXI-65-000014
Severity: CAT III	   	Classification: Unclass

# grep -i "^PermitRootLogin" /etc/ssh/sshd_config

If there is no output or the output is not exactly "PermitRootLogin no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

Add or correct the following line in "/etc/ssh/sshd_config":

PermitRootLogin no

grep -i "^PermitRootLogin" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93977	   	Rule ID: SV-104063r1_rule	   	STIG ID: ESXI-65-000015
Severity: CAT I	   	Classification: Unclass


# grep -i "^PermitEmptyPasswords" /etc/ssh/sshd_config

If there is no output or the output is not exactly "PermitEmptyPasswords no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

PermitEmptyPasswords no#>

grep -i "^PermitEmptyPasswords" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93979	   	Rule ID: SV-104065r1_rule	   	STIG ID: ESXI-65-000016
Severity: CAT II	   	Classification: Unclass

# grep -i "^PermitUserEnvironment" /etc/ssh/sshd_config

If there is no output or the output is not exactly "PermitUserEnvironment no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

PermitUserEnvironment no#>

grep -i "^PermitUserEnvironment" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93981	   	Rule ID: SV-104067r1_rule	   	STIG ID: ESXI-65-000017
Severity: CAT II	   	Classification: Unclass

# grep -i "^MACs" /etc/ssh/sshd_config

If there is no output or the output is not exactly "MACs hmac-sha1,hmac-sha2-256,hmac-sha2-512", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

MACs hmac-sha1, hmac-sha2-256, hmac-sha2-512#>

grep -i "^MACs" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93983	   	Rule ID: SV-104069r1_rule	   	STIG ID: ESXI-65-000018
Severity: CAT III	   	Classification: Unclass

# grep -i "^GSSAPIAuthentication" /etc/ssh/sshd_config

If there is no output or the output is not exactly "GSSAPIAuthentication no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

GSSAPIAuthentication no#>

grep -i "^GSSAPIAuthentication" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93985	   	Rule ID: SV-104071r1_rule	   	STIG ID: ESXI-65-000019
Severity: CAT III	   	Classification: Unclass

# grep -i "^KerberosAuthentication" /etc/ssh/sshd_config

If there is no output or the output is not exactly "KerberosAuthentication no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

KerberosAuthentication no#>

grep -i "^KerberosAuthentication" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93987	   	Rule ID: SV-104073r1_rule	   	STIG ID: ESXI-65-000020
Severity: CAT II	   	Classification: Unclass

# grep -i "^StrictModes" /etc/ssh/sshd_config

If there is no output or the output is not exactly "StrictModes yes", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

StrictModes yes#>

grep -i "^StrictModes" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93989	   	Rule ID: SV-104075r1_rule	   	STIG ID: ESXI-65-000021
Severity: CAT II	   	Classification: Unclass

# grep -i "^Compression" /etc/ssh/sshd_config

If there is no output or the output is not exactly "Compression no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

Compression no#>

grep -i "^Compression" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93991	   	Rule ID: SV-104077r1_rule	   	STIG ID: ESXI-65-000022
Severity: CAT III	   	Classification: Unclass

# grep -i "^GatewayPorts" /etc/ssh/sshd_config

If there is no output or the output is not exactly "GatewayPorts no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

GatewayPorts no#>


grep -i "^GatewayPorts" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93993	   	Rule ID: SV-104079r1_rule	   	STIG ID: ESXI-65-000023
Severity: CAT II	   	Classification: Unclass

# grep -i "^X11Forwarding" /etc/ssh/sshd_config

If there is no output or the output is not exactly "X11Forwarding no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

X11Forwarding no#>

grep -i "^X11Forwarding" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93995	   	Rule ID: SV-104081r1_rule	   	STIG ID: ESXI-65-000024
Severity: CAT II	   	Classification: Unclass

# grep -i "^AcceptEnv" /etc/ssh/sshd_config

If there is no output or the output is not exactly "AcceptEnv", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

AcceptEnv#>

grep -i "^AcceptEnv" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93997	   	Rule ID: SV-104083r1_rule	   	STIG ID: ESXI-65-000025
Severity: CAT II	   	Classification: Unclass

# grep -i "^PermitTunnel" /etc/ssh/sshd_config

If there is no output or the output is not exactly "PermitTunnel no", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

PermitTunnel no#>

grep -i "^PermitTunnel" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-93999	   	Rule ID: SV-104085r1_rule	   	STIG ID: ESXI-65-000026
Severity: CAT III	   	Classification: Unclass

# grep -i "^ClientAliveCountMax" /etc/ssh/sshd_config

If there is no output or the output is not exactly "ClientAliveCountMax 3", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

ClientAliveCountMax 3#>

grep -i "^ClientAliveCountMax" /etc/ssh/sshd_config


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94001	   	Rule ID: SV-104087r1_rule	   	STIG ID: ESXI-65-000027
Severity: CAT III	   	Classification: Unclass

# grep -i "^ClientAliveInterval" /etc/ssh/sshd_config

If there is no output or the output is not exactly "ClientAliveInterval 200", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

ClientAliveInterval 200#>

grep -i "^ClientAliveInterval" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94003	   	Rule ID: SV-104089r1_rule	   	STIG ID: ESXI-65-000028
Severity: CAT II	   	Classification: Unclass

# grep -i "^MaxSessions" /etc/ssh/sshd_config

If there is no output or the output is not exactly "MaxSessions 1", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/ssh/sshd_config":

MaxSessions 1#>

grep -i "^MaxSessions" /etc/ssh/sshd_config

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94005	   	Rule ID: SV-104091r1_rule	   	STIG ID: ESXI-65-000029
Severity: CAT II	   	Classification: Unclass

# ls -la /etc/ssh/keys-root/authorized_keys

or

# cat /etc/ssh/keys-root/authorized_keys

If the authorized_keys file exists and is not empty, this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, zero or remove the /etc/ssh/keys-root/authorized_keys file:

# >/etc/ssh/keys-root/authorized_keys

or

# rm /etc/ssh/keys-root/authorized_keys#>


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94007	   	Rule ID: SV-104093r1_rule	   	STIG ID: ESXI-65-000030
Severity: CAT III	   	Classification: Unclass

If the Config.HostAgent.log.level setting is not set to info, this is a finding.

Note: Verbose logging level is acceptable for troubleshooting purposes.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Config.HostAgent.log.level value and configure it to "info".

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Config.HostAgent.log.level | Set-AdvancedSetting -Value "info"#>

Get-VMHost | Get-AdvancedSetting -Name Config.HostAgent.log.level



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94009	   	Rule ID: SV-104095r1_rule	   	STIG ID: ESXI-65-000031
Severity: CAT II	   	Classification: Unclass

f the Security.PasswordQualityControl setting is not set to "similar=deny retry=3 min=disabled,disabled,disabled,disabled,15", this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Security.PasswordQualityControl value and configure it to "similar=deny retry=3 min=disabled,disabled,disabled,disabled,15".

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Security.PasswordQualityControl | Set-AdvancedSetting -Value "similar=deny retry=3 min=disabled,disabled,disabled,disabled,15"
#>
get-vmhost | Get-AdvancedSetting -Name Security.PasswordQualityControl


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94011	   	Rule ID: SV-104097r1_rule	   	STIG ID: ESXI-65-000032
Severity: CAT II	   	Classification: Unclass

# grep -i "^password" /etc/pam.d/passwd | grep sufficient

If the remember setting is not set or is not "remember=5", this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/pam.d/passwd":

password sufficient /lib/security/$ISA/pam_unix.so use_authtok nullok shadow sha512 remember=5
#>

grep -i "^password" /etc/pam.d/passwd | grep sufficient

<#
VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94013	   	Rule ID: SV-104099r1_rule	   	STIG ID: ESXI-65-000033
Severity: CAT II	   	Classification: Unclass

# grep -i "^password" /etc/pam.d/passwd | grep sufficient

If sha512 is not listed, this is a finding.

Fix Text: From an SSH session connected to the ESXi host, or from the ESXi shell, add or correct the following line in "/etc/pam.d/passwd":

password sufficient /lib/security/$ISA/pam_unix.so use_authtok nullok shadow sha512 remember=5#>

grep -i "^password" /etc/pam.d/passwd | grep sufficient


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94015	   	Rule ID: SV-104101r1_rule	   	STIG ID: ESXI-65-000034
Severity: CAT II	   	Classification: Unclass

If the Config.HostAgent.plugins.solo.enableMob setting is not set to false, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Config.HostAgent.plugins.solo.enableMob value and configure it to false.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Config.HostAgent.plugins.solo.enableMob | Set-AdvancedSetting -Value false

#>

Get-VMHost | Get-AdvancedSetting -Name Config.HostAgent.plugins.solo.enableMob



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94017	   	Rule ID: SV-104103r1_rule	   	STIG ID: ESXI-65-000035
Severity: CAT II	   	Classification: Unclass

If the ESXi SSH service is running, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Security Profile. Under Services select Edit then select the SSH service and click the Stop button to stop the service. Use the pull-down menu to change the Startup policy to "Start and stop manually" and click OK.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" } | Set-VMHostService -Policy Off
Get-VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" } | Stop-VMHostService#>



Get-VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" }

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94019	   	Rule ID: SV-104105r1_rule	   	STIG ID: ESXI-65-000036
Severity: CAT II	   	Classification: Unclass

If the ESXi Shell service is running, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Security Profile. Under Services select Edit then select the ESXi Shell service and click the Stop button to stop the service. Use the pull-down menu to change the Startup policy to "Start and stop manually" and click OK.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-VMHostService | Where { $_.Label -eq "ESXi Shell" } | Set-VMHostService -Policy Off
Get-VMHost | Get-VMHostService | Where { $_.Label -eq "ESXi Shell" } | Stop-VMHostService
#>


Get-VMHost | Get-VMHostService | Where { $_.Label -eq "ESXi Shell" }


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94021	   	Rule ID: SV-104107r1_rule	   	STIG ID: ESXI-65-000037
Severity: CAT III	   	Classification: Unclass

For systems that do not use Active Directory and have no local user accounts, other than root and/or vpxuser, this is not applicable.

For systems that do not use Active Directory and do have local user accounts, other than root and/or vpxuser, this is a finding.

If the Directory Services Type is not set to "Active Directory", this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Authentication Services. Click Join Domain and enter the AD domain to join, select the "Using credentials" radio button and enter the credentials of an account with permissions to join machines to AD (use UPN naming - user@domain) and then click OK.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VMHost | Get-VMHostAuthentication | Set-VMHostAuthentication -JoinDomain -Domain "domain name" -User "username" -Password "password"#>




Get-VMHost | Get-VMHostAuthentication


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94023	   	Rule ID: SV-104109r2_rule	   	STIG ID: ESXI-65-000038
Severity: CAT II	   	Classification: Unclass

Verify if JoinADEnabled is True then JoinDomainMethod should be "FixedCAMConfigOption".

If you are not using Host Profiles to join active directory, this is not a finding.

Fix Text: From the vSphere Web Client go to Home >> Host Profiles >> and select a Host Profile to edit. View the settings under Security and Services >> Security Settings >> Authentication Configuration >> Active Directory Configuration >> Join Domain Method. Set the method used to join hosts to a domain to "Use vSphere Authentication Proxy to add the host to domain" and provide the IP address of the vSphere Authentication Proxy server.

#>


Get-VMHost | Select Name, ` @{ N = "HostProfile"; E = { $_ | Get-VMHostProfile } }, ` @{ N = "JoinADEnabled"; E = { ($_ | Get-VmHostProfile).ExtensionData.Config.ApplyProfile.Authentication.ActiveDirectory.Enabled } }, ` @{ N = "JoinDomainMethod"; E = { (($_ | Get-VMHostProfile).ExtensionData.Config.ApplyProfile.Authentication.ActiveDirectory | Select -ExpandProperty Policy | Where { $_.Id -eq "JoinDomainMethodPolicy" }).Policyoption.Id } }



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94025	   	Rule ID: SV-104111r1_rule	   	STIG ID: ESXI-65-000039
Severity: CAT III	   	Classification: Unclass

For systems that do not use Active Directory and have no local user accounts, other than root and/or vpxuser, this is not applicable.

For systems that do not use Active Directory and do have local user accounts, other than root and/or vpxuser, this is a finding.

If the "Config.HostAgent.plugins.hostsvc.esxAdminsGroup" keyword is set to "ESX Admins", this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configuration >> System >> Advanced System Settings. Click Edit and select the Config.HostAgent.plugins.hostsvc.esxAdminsGroup value and configure it to an Active Directory group other than "ESX Admins".

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Config.HostAgent.plugins.hostsvc.esxAdminsGroup | Set-AdvancedSetting -Value <AD Group>#>


Get-VMHost | Get-AdvancedSetting -Name Config.HostAgent.plugins.hostsvc.esxAdminsGroup


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94029	   	Rule ID: SV-104115r1_rule	   	STIG ID: ESXI-65-000041
Severity: CAT II	   	Classification: Unclass

If the UserVars.ESXiShellInteractiveTimeOut setting is not set to 600, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the UserVars.ESXiShellInteractiveTimeOut value and configure it to 600.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name UserVars.ESXiShellInteractiveTimeOut | Set-AdvancedSetting -Value 600#>


Get-VMHost | Get-AdvancedSetting -Name UserVars.ESXiShellInteractiveTimeOut

<#
VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94031	   	Rule ID: SV-104117r1_rule	   	STIG ID: ESXI-65-000042
Severity: CAT II	   	Classification: Unclass

If the UserVars.ESXiShellTimeOut setting is not set to 600, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the UserVars.ESXiShellTimeOut value and configure it to 600.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name UserVars.ESXiShellTimeOut | Set-AdvancedSetting -Value 600
#>

Get-VMHost | Get-AdvancedSetting -Name UserVars.ESXiShellTimeOut

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94033	   	Rule ID: SV-104119r1_rule	   	STIG ID: ESXI-65-000043
Severity: CAT II	   	Classification: Unclass

If the UserVars.DcuiTimeOut setting is not set to 600, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the UserVars.DcuiTimeOut value and configure it to 600.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name UserVars.DcuiTimeOut | Set-AdvancedSetting -Value 600#>

Get-VMHost | Get-AdvancedSetting -Name UserVars.DcuiTimeOut

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94035	   	Rule ID: SV-104121r1_rule	   	STIG ID: ESXI-65-000044
Severity: CAT III	   	Classification: Unclass

The first command prepares for the other two. The second command shows whether there is an active core dump partition configured. The third command shows whether a network core dump collector is configured and enabled, via the "HostVNic", "NetworkServerIP", "NetworkServerPort", and "Enabled" variables.

If there is no active core dump partition or the network core dump collector is not configured and enabled, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and right click. Select the "Add Diagnostic Partition" option configure a core dump diagnostic partition.

or

From a PowerCLI command prompt while connected to the ESXi host run at least one of the following sets of commands:

To configure a core dump partition:

$esxcli = Get-EsxCli
#View available partitions to configure
$esxcli.system.coredump.partition.list()
$esxcli.system.coredump.partition.set($null, "PartitionName", $null, $null)

To configure a core dump collector:

$esxcli = Get-EsxCli
$esxcli.system.coredump.network.set($null, "vmkernel port to use", $null, "CollectorIP", "CollectorPort")
$esxcli.system.coredump.network.set($true)
#>



$esxcli = Get-EsxCli
$esxcli.system.coredump.partition.get()
$esxcli.system.coredump.network.get()



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94037	   	Rule ID: SV-104123r1_rule	   	STIG ID: ESXI-65-000045
Severity: CAT II	   	Classification: Unclass

$esxcli = Get-EsxCli
$esxcli.system.syslog.config.get() | Select LocalLogOutput, LocalLogOutputIsPersistent

If the Syslog.global.logDir or LocalLogOutput value is not on persistent storage, this is a finding.

If the LocalLogOutputIsPersistent value is not true, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Syslog.global.logDir value and set it to a known persistent location.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Syslog.global.logDir | Set-AdvancedSetting -Value "New Log Location"#>

Get-VMHost | Get-AdvancedSetting -Name Syslog.global.logDir



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94039	   	Rule ID: SV-104125r1_rule	   	STIG ID: ESXI-65-000046
Severity: CAT II	   	Classification: Unclass

If the NTP service is not configured with authoritative DoD time sources and the service is not configured to start and stop with the host and is running, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Time Configuration. Click Edit to configure the NTP service to start and stop with the host and with authoritative DoD time sources.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

$NTPServers = "ntpserver1", "ntpserver2"
Get-VMHost | Add-VMHostNTPServer $NTPServers
Get-VMHost | Get-VMHostService | Where { $_.Label -eq "NTP Daemon" } | Set-VMHostService -Policy On
Get-VMHost | Get-VMHostService | Where { $_.Label -eq "NTP Daemon" } | Start-VMHostService#>


Get-VMHost | Get-VMHostNTPServer
Get-VMHost | Get-VMHostService | Where { $_.Label -eq "NTP Daemon" }


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94041	   	Rule ID: SV-104127r1_rule	   	STIG ID: ESXI-65-000047
Severity: CAT I	   	Classification: Unclass

If the acceptance level is CommunitySupported, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Security Profile. Under "Host Image Profile Acceptance Level" click Edit… and use the pull-down selection, set the acceptance level to be VMwareCertified, VMwareAccepted, or PartnerSupported.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

$esxcli = Get-EsxCli
$esxcli.software.acceptance.Set("PartnerSupported")

Note: VMwareCertified or VMwareAccepted may be substituted for PartnerSupported, depending upon local requirements.#>

$esxcli = Get-EsxCli
$esxcli.software.acceptance.get()


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94053	   	Rule ID: SV-104139r1_rule	   	STIG ID: ESXI-65-000053
Severity: CAT II	   	Classification: Unclass

From a console or ssh session run the follow command:

esxcli system snmp get

If SNMP is not in use and is enabled, this is a finding.

If SNMP is enabled and read only communities is set to public, this is a finding.

If SNMP is enabled and is not using v3 targets, this is a finding.

Note: SNMP v3 targets can only be viewed and configured from the esxcli command.

Fix Text: To disable SNMP run the following command from a PowerCLI command prompt while connected to the ESXi Host:

Get-VMHostSnmp | Set-VMHostSnmp -Enabled $false

or

From a console or ssh session run the follow command:

esxcli system snmp set -e no

To configure SNMP for v3 targets use the "esxcli system snmp set" command set.#>

Get-VMHostSnmp | Select *

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94055	   	Rule ID: SV-104141r1_rule	   	STIG ID: ESXI-65-000054
Severity: CAT III	   	Classification: Unclass

If iSCSI is not used, this is not a finding.

If iSCSI is used and CHAP is not set to "Required" for both the target and host, this is a finding.

If iSCSI is used and unique CHAP secrets are not used for each host, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> Storage >> Storage Adapters >> Select the iSCSI adapter >> Properties >> Authentication and click the Edit button. Set Authentication method to "Use bidirectional CHAP" and enter a unique secret for each traffic flow direction.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VMHost | Get-VMHostHba | Where { $_.Type -eq "iscsi" } | Set-VMHostHba -ChapType Required -ChapName "chapname" -ChapPassword "password" -MutualChapEnabled $true -MutualChapName "mutualchapname" -MutualChapPassword "mutualpassword"#>

Get-VMHost | Get-VMHostHba | Where { $_.Type -eq "iscsi" } | Select AuthenticationProperties -ExpandProperty AuthenticationProperties



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94057	   	Rule ID: SV-104143r1_rule	   	STIG ID: ESXI-65-000055
Severity: CAT III	   	Classification: Unclass

If the Mem.ShareForceSalting setting is not set to 2, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Mem.ShareForceSalting value and configure it to 2.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Mem.ShareForceSalting | Set-AdvancedSetting -Value 2#>


Get-VMHost | Get-AdvancedSetting -Name Mem.ShareForceSalting

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94059	   	Rule ID: SV-104145r1_rule	   	STIG ID: ESXI-65-000056
Severity: CAT II	   	Classification: Unclass

If for an enabled service "Allow connections from any IP address" is selected, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Security Profile. Under the Firewall section click Edit and for each enabled service uncheck the check box to "Allow connections from any IP address," and input the site specific network(s) required.Configure this for Incoming and Outgoing connections.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

$esxcli = Get-EsxCli
#This disables the allow all rule for the target service
$esxcli.network.firewall.ruleset.set($false, $true, "sshServer")
$esxcli.network.firewall.ruleset.allowedip.add("192.168.0.0/24", "sshServer")

This must be done for each enabled service.#>


Get-VMHost | Get-VMHostFirewallException | Where { $_.Enabled -eq $true } | Select Name, Enabled, @{ N = "AllIPEnabled"; E = { $_.ExtensionData.AllowedHosts.AllIP } }


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94061	   	Rule ID: SV-104147r1_rule	   	STIG ID: ESXI-65-000057
Severity: CAT II	   	Classification: Unclass

If the Incoming or Outgoing policies are True, this is a finding.

Fix Text: From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VMHostFirewallDefaultPolicy | Set-VMHostFirewallDefaultPolicy -AllowIncoming $false -AllowOutgoing $false
#>

Get-VMHostFirewallDefaultPolicy



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94063	   	Rule ID: SV-104149r1_rule	   	STIG ID: ESXI-65-000058
Severity: CAT III	   	Classification: Unclass

If the Net.BlockGuestBPDU setting is not set to 1, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Net.BlockGuestBPDU value and configure it to 1.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VMHost | Get-AdvancedSetting -Name Net.BlockGuestBPDU | Set-AdvancedSetting -Value 1#>

Get-VMHost | Get-AdvancedSetting -Name Net.BlockGuestBPDU


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94065	   	Rule ID: SV-104151r1_rule	   	STIG ID: ESXI-65-000059
Severity: CAT II	   	Classification: Unclass

If the "Forged Transmits" policy is set to accept, this is a finding.

Fix Text: From the vSphere Web Client go to Configure >> Networking >> Virtual Switches. For each virtual switch and port group click Edit settings and change "Forged Transmits" to reject.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VirtualSwitch | Get-SecurityPolicy | Set-SecurityPolicy -ForgedTransmits $false
Get-VirtualPortGroup | Get-SecurityPolicy | Set-SecurityPolicy -ForgedTransmitsInherited $true#>

Get-VirtualSwitch | Get-SecurityPolicy
Get-VirtualPortGroup | Get-SecurityPolicy


<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94067	   	Rule ID: SV-104153r1_rule	   	STIG ID: ESXI-65-000060
Severity: CAT I	   	Classification: Unclass


If the "MAC Address Changes" policy is set to accept, this is a finding.

Fix Text: From the vSphere Web Client go to Configure >> Networking >> Virtual Switches. For each virtual switch and port group click Edit settings and change "MAC Address Changes" to reject.

or

From a PowerCLI command prompt while connected to the ESXi host run the following commands:

Get-VirtualSwitch | Get-SecurityPolicy | Set-SecurityPolicy -MacChanges $false
Get-VirtualPortGroup | Get-SecurityPolicy | Set-SecurityPolicy -MacChangesInherited $true#>


Get-VirtualSwitch | Get-SecurityPolicy
Get-VirtualPortGroup | Get-SecurityPolicy

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94071	   	Rule ID: SV-104157r1_rule	   	STIG ID: ESXI-65-000062
Severity: CAT II	   	Classification: Unclass

If the Net.DVFilterBindIpAddress is not blank and security appliances are not in use on the host, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> System >> Advanced System Settings. Click Edit and select the Net.DVFilterBindIpAddress value and remove any incorrect addresses.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VMHost | Get-AdvancedSetting -Name Net.DVFilterBindIpAddress | Set-AdvancedSetting -Value ""#>

Get-VMHost | Get-AdvancedSetting -Name Net.DVFilterBindIpAddress

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94073	   	Rule ID: SV-104159r1_rule	   	STIG ID: ESXI-65-000063
Severity: CAT II	   	Classification: Unclass

If any port group is configured with the native VLAN of the ESXi hosts attached physical switch, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> Networking >> Virtual switches. Highlight a port group (where VLAN ID set to native VLAN ID) and click Edit settings. Change the VLAN ID to a non-native VLAN and click OK.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VirtualPortGroup -Name "portgroup name" | Set-VirtualPortGroup -VLanId "New VLAN#"#>

Get-VirtualPortGroup | Select Name, VLanId

<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94075	   	Rule ID: SV-104161r1_rule	   	STIG ID: ESXI-65-000064
Severity: CAT II	   	Classification: Unclass

If any port group is configured with VLAN 4095 and is not documented as a needed exception, this is a finding.

Fix Text: From the vSphere Web Client select the ESXi Host and go to Configure >> Networking >> Virtual switches. Highlight a port group (where VLAN ID set to 4095) and click Edit settings. Change the VLAN ID to not be 4095 and click OK.

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VirtualPortGroup -Name "portgroup name" | Set-VirtualPortGroup -VLanId "New VLAN#"
#>


Get-VirtualPortGroup | Select Name, VLanID



<#VMware vSphere 6.5 ESXi Security Technical Implementation Guide :: Version 1, Release: 4 Benchmark Date: 24 Apr 2020
Vul ID: V-94505	   	Rule ID: SV-104335r2_rule	   	STIG ID: ESXI-65-100037
Severity: CAT III	   	Classification: Unclass

For systems that do not use Active Directory and do have local user accounts, other than "root" and/or "vpxuser"", this is a finding.

If the "Directory Services Type" is not set to "Active Directory", this is a finding.
If you are not using Host Profiles to join active directory, this is not a finding.

Fix Text: From the vSphere Client select the ESXi host and go to Configuration >> Authentication Services. Click "Properties" and change the "Directory Service Type" to "Active Directory", enter the domain to join, check "Use vSphere Authentication Proxy" and enter the proxy server address then click "Join Domain".

or

From a PowerCLI command prompt while connected to the ESXi host run the following command:

Get-VMHost | Get-VMHostAuthentication | Set-VMHostAuthentication -JoinDomain -Domain "domain name" -User "username" -Password "password"#>

Get-VMHost | Get-VMHostAuthentication