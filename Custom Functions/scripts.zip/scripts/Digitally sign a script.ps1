﻿#PURPOSE: Prompt the user for a script to digitally sign.  The script will then search for a signing certificate and attempt to use it to sign the script

#CHANGELOG
#Version 1.0 - MDR - 08/28/23 - Initial version
#Version 1.1 - MDR - 08/29/23 - Allow importing ScriptValidation.csv to digitally sign any scripts out of compliance
#Version 1.11 - MDR - 12/06/23 - Prompt to remove the validation report at the end when it is utilized to run the script
#Version 1.2 - MDR - 04/01/23 - Added ability to select multiple files for signing

#NOTE: The process for the script selecting a code signing certificate is NOT well tested.  I currently have the only code signing cert so I just wrote it to select my certificate

[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") 

$ScriptDirectory = "v:\scripts\miker"

#Clear any data in the CodeSigningCert variable since this may contain data from a previous run
Clear-Variable CodeSigningCert -ErrorAction SilentlyContinue

Clear

Write-Host "Select the script you want to sign or select ScriptValidation.csv to do many at a time" -ForegroundColor Cyan

#Display a file dialog box
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
    InitialDirectory = $ScriptDirectory
    Filter = "PS1|*.ps1|CSV|*.csv"
    #Version 1.2 - Can now select multiple files
    MultiSelect = $true
}
$FileBrowser.ShowDialog((New-Object System.Windows.Forms.Form -Property @{ TopMost = $true })) | Out-Null

#Version 1.2 - Switched from FileName to FileNames
#Store the selected file path
$ScriptPath = $FileBrowser.FileNames

Function SignScript {
    Param ( $FilePath )

    Write-Host "`nSigning $FilePath"

    Try {
        $Result = Set-AuthenticodeSignature -FilePath $FilePath -Certificate $CodeSigningCert -ErrorAction SilentlyContinue -ErrorVariable SigningError

        If ($Result.Status -eq "Valid") {
            Write-Host "`nSuccess!  The signed script was output to $FilePath" -ForegroundColor Green
        } Else {
            Write-Host "`nError signing $FilePath.  Exiting script" -ForegroundColor Red

            If ($SigningError) {
                Write-Host "`n$SigningError.  Exiting script" -ForegroundColor Red
            }

            Exit
        }
    } Catch {
        Write-Host "`nFailed to sign code" -ForegroundColor Red
    }
}

If ($ScriptPath) {
    Write-Host "`nGetting code signing certificate.  You may be prompted for your PIN"

    #Search the users certificates for a code signing cert
    $CodeSigningCert = Get-ChildItem Cert:\CurrentUser\My | Where-Object {$_.Subject -eq "CN=CS.DLA.005, OU=DLA, OU=PKI, OU=DoD, O=U.S. Government, C=US"}

    #If a code signing cert was selected
    If ($CodeSigningCert) {
        #If this is a normal run where a single script was selected and NOT ScriptValidation.csv
        If ($ScriptPath -notlike "*ScriptValidation.csv") {
            #Version 1.2 - Loop through all selected files
            ForEach ($ScriptItem in $ScriptPath) {
                #Sign the selected script
                SignScript $ScriptItem
            }
        } Else { #If this is using the ScriptValication.csv
            $ScriptValidationData = Import-Csv $ScriptPath
            #Record the script name of all files that need to be signed
            $FilesToSign = ($ScriptValidationData | Where { $_.DigitalStatus -ne "Valid" }).ScriptPath

            #Loop through each file and sign them
            ForEach ($IndividualPath in $FilesToSign) {
                SignScript $IndividualPath
            }
        }
    } Else {
        Write-Host "`nA code signing certificate was found.  Exiting" -ForegroundColor Red
    }
    
} Else {
    Write-Host "`nNo script was selected.  Exiting" -ForegroundColor Yellow
    Break
}

#Version 1.11 - Give option to remove Validation script if it was used in this run
If ($ScriptPath -like "*.csv") {
    $Response = Read-Host "`nType Y to delete $ScriptPath"

    If ($Response -eq "Y") {
        Remove-Item $ScriptPath
    }
}

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDn1OXL6LEfQwaF
# mWoYNbvIFj+8u9i4fJSchvtcv6kPyqCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDUpMbXEIylkAr2NXq++2i5vcpbrw4SYJtBsfHr/72ujjANBgkq
# hkiG9w0BAQEFAASCAQAWwGH2W2ijVTyyW6hjwMmNHOKdWeWlX8obBOOQITL9pCR9
# iiGuKOHmNKy5zHTqdAkeIz4WNEvFFHht1vx2gyN8aVtfvswr9iF8zHdgcB4xGTFz
# 0Y3sqUaZp7kjKUvaIgGMwlaTi3cIjLLCOByv4Kc/9AjPGY3SdYcxM+vzR3CQWY7T
# p3bgA7SSPn9o+MKRPTeZQL9BHmSmVmmiYdM8/b1RBPbet9gGEfFGIloKgQlzobQj
# GRVdZTR3/Jjc5HNxtSYAfgUOdoSwl4fY5owXH/c5jXJJmpD6FHrhY3RnRqf/zxcK
# FltaqIuFU8CAK+U7FTyoWrppIVQ8ntpI3dyg85TC
# SIG # End signature block
