﻿#PURPOSE: Perform a STIG check on a list of ESX Hosts and output CKL files with the results

#CHANGELOG
#Version 1.0 - 03/26/24 - MDR - Initial version
#Version 1.05 - 10/01/24 - MDR - Make this script compatible with running from Orchestrator
#Version 1.06 - 01/16/25 - MDR - If the patch version exceeds what is in the param check then have it be NF, not O
#Version 1.07 - 01/27/25 - MDR - Adding check for host profile

#Version 1.05 - Added the $RunFromOrchestrator parameter
Param ( $ChecklistFilePath, $CurrentSystemName, $STIGParams, $RunFromOrchestrator )

$SSHDConfig = (Invoke-SSHCommand -SessionId 0 -Command { /usr/lib/vmware/openssh/bin/sshd -T }).Output

#Create an XML object
$Checklist_XMLObject = New-Object XML
#This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
$Checklist_XMLObject.PreserveWhitespace = $true
#This is the name of the empty checklist template file
$Checklist_XMLObject.Load("$ChecklistFilePath")

#I'm not sure if this is a safe assumption to make, but for now we'll say that vmk0 is the ESX host's IP and MAC
$ESXHostIPMACInfo = Get-VMHostNetworkAdapter -VMHost $CurrentSystemName | Where { $_.DeviceName -eq "vmk0" } | Select 'IP', 'MAC'

$Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$($CurrentSystemName.Split("."))[0]
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$CurrentSystemName
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = [String]$ESXHostIPMACInfo.IP
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = [String]$ESXHostIPMACInfo.MAC

$Global:VULN_DATA = $Checklist_XMLObject.CHECKLIST.STIGS.iSTIG.VULN

$ESXCLI = Get-EsxCli -V2 -VMHost $CurrentSystemName
$Global:ESXVMHost = Get-VMHost $CurrentSystemName
$Global:ESXHostView = $ESXVMHost | Get-View

ForEach ($Global:VULN in $VULN_DATA) {
    [System.Windows.Forms.Application]::DoEvents()

    $Vuln_Num = ($VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq 'Vuln_Num' }).ATTRIBUTE_DATA
    #Version 1.03 - Collecting Severity for reporting purposes later in the script
    $Severity = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA
    #Version 1.03 - Changed from $STIGCheck to $VCodeObjectSTIGData
    $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $Vuln_Num }
    $AltCheck = "False"

    If ($VCodeObjectSTIGData.Expected_Value -like "AltCheck *") {
        $AltCheck = "True"
        $OrigExpectedValue = $VCodeObjectSTIGData.Expected_Value

        $parms = @{
            AltCheck = $VCodeObjectSTIGData.Expected_Value
            STIGParams = $STIGParams
            CurrentSystemName = $CurrentSystemName
            SystemType = "ESX"
            RunFromOrchestrator = $RunFromOrchestrator
        }

        #Version 1.05 - If this is run from Orchestrator then run the check script from a local copy rather than a network one
        If ($RunFromOrchestrator -eq "True") {
            #Run the RecordToChecklist.ps1 script from a local copy
            $VCodeObjectSTIGData.Expected_Value = Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\AltCheck.ps1"" @parms")
        } Else {
            #Run the RecordToChecklist.ps1 script from the network
            $VCodeObjectSTIGData.Expected_Value = Invoke-Expression -Command ("& '$FolderPathToSTIGScript\AltCheck.ps1' @parms")
        }
    }

    #If there is a line in $STIGParams for the V-Code in this checklist
    If (!($VCodeObjectSTIGData)) {
        $VULN.COMMENTS = "No entry existed in the STIG parameters file for this V-Code"

        If ($NoSTIGParamList -notcontains $Vuln_Num) {
            $NoSTIGParamList += $Vuln_Num
        }
    } Else {
        Clear-Variable CustomComment, FindingHint, SystemSettingValue -ErrorAction SilentlyContinue

        If ($VCodeObjectSTIGData.Check_Method -eq "LockdownMode") {
            $SystemSettingValue = $ESXVMHost.Extensiondata.Config.LockdownMode
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "LockdownExceptions") {
            $LockdownView = Get-View $ESXHostView.ConfigManager.HostAccessManager
            $LockdownExceptions = $LockdownView.QueryLockdownExceptions()

            If ($LockdownExceptions -ne $null) {
                #First check to see if the Lockdown exceptions match the required
                $LockdownComparison = (Compare-Object $LockdownExceptions @($VCodeObjectSTIGData.Expected_Value.AltCheckExpectedValue -split ",") | Where { $_.SideIndicator -eq "<=" }).InputObject
            }
            
            If ($LockdownComparison -ne $null) {
                #Then check to see if they match the optional
                $LockdownComparison = (Compare-Object $LockdownComparison @($VCodeObjectSTIGData.Expected_Value.Optional -split ",") | Where { $_.SideIndicator -eq "<=" }).InputObject
            }

            If ($LockdownComparison) {
                $CustomComment = "The following undocumented accounts are in Lockdown Exceptions:`n`n$($LockdownComparison -join ""`n"")"
            } Else {
                $FindingHint = "NF"
                $CustomComment = "The following accounts are documented as accepted Lockdown Exceptions:`n`n$($LockdownExceptions -join ""`n"")"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AdvancedSetting") {
            $SystemSettingValue = ($ESXVMHost | Get-AdvancedSetting -Name $VCodeObjectSTIGData.Check_Param).Value

            If ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Syslog.global.logHost") {
                $VCodeObjectSTIGData.Expected_Value = $VCodeObjectSTIGData.Expected_Value.AltCheckExpectedValue
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Syslog.global.logDir") {
                If ($SystemSettingValue -eq "[] /scratch/log") {
                    $ScratchLocation = ($ESXVMHost | Get-AdvancedSetting -Name "ScratchConfig.CurrentScratchLocation").Value

                    If ($ScratchLocation -ne "/tmp/scratch") {
                        $SystemSettingValue = "$SystemSettingValue`n`nScratchConfig.CurrentScratchLocation set to $ScratchLocation"
                        $FindingHint = "NF"
                    }
                } Else {
                    $DatastoreList = (Get-Datastore | Where { $_.Name -ne ($CurrentSystemName.Split("."))[0] }).Name
                    
                    ForEach ($DatastoreItem in $DatastoreList) {
                        If ($SystemSettingValue -like "``[$DatastoreItem``]*") {
                            $FindingHint = "NF"
                            Break
                        }
                    }
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting UserVars.ESXiVPsDisabledProtocols" -and $SystemSettingValue -ne $null) {
                If (!(Compare-Object @($SystemSettingValue -split ",") @($VCodeObjectSTIGData.Expected_Value -split ","))) {
                    $FindingHint = "NF"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Net.DVFilterBindIpAddress") {
                If ($SystemSettingValue -eq "") {
                    $FindingHint = "NF"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ESXCLI") {
            #Version 1.03 - Changed from looking at Check_Param to Check_Name
            If ($VCodeObjectSTIGData.Check_Name -eq "SSH must use FIPS 140") {
                $SystemSettingValue = ($ESXCLI.system.security.fips140.ssh.get.invoke()).Enabled
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "VIB Acceptance Level") {
                $SystemSettingValue = $ESXCLI.software.acceptance.get.Invoke()

                #If the value being used is in the entire list of acceptable answers
                If ($VCodeObjectSTIGData.Expected_Value -Split "," -contains $SystemSettingValue) {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Audit Logging Enabled") {
                #Note: Doing Select * converts this to a PSCustom object so it can be displayed in comments
                $SystemSettingValue = $ESXCLI.system.auditrecords.get.invoke() | Select *
                
                If ($SystemSettingValue.AuditRecordRemoteTransmissionActive -eq "true" -and $SystemSettingValue.AuditRecordStorageActive -eq "true" -and $SystemSettingValue.AuditRecordStorageCapacity -eq "100") {
                    $FindingHint = "NF"
                    $CustomComment = "Audit location is $($SystemSettingValue.AuditRecordStorageDirectory)"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "x509 Verification") {
                $SystemSettingValue = ($ESXCLI.system.syslog.config.get.invoke()).StrictX509Compliance
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "rhttpproxy Must Use FIPS") {
                $SystemSettingValue = ($ESXCLI.system.security.fips140.rhttpproxy.get.invoke()).Enabled
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "TPM Enabled") {
                $SystemSettingValue = ($ESXCLI.system.settings.encryption.get.invoke()).Mode
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Secure Boot Required") {
                $SystemSettingValue = ($ESXCLI.system.settings.encryption.get.invoke()).RequireSecureBoot
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable SNMP") {
                $SystemSettingValue = ($ESXCLI.system.snmp.get.invoke()).Enable
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "Service") {
            $ServiceRunning = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Running
            $ServicePolicy = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Policy

            If ($VCodeObjectSTIGData.Check_Name -eq "Enable NTP Dameon Service") {
                $NTPCheck = $ESXVMHost | Get-VMHostNtpServer

                #If NTP servers are configured
                If ($NTPCheck) {
                    $ServicePolicy += " - NTP Found"
                } Else {
                    $ServicePolicy += " - NTP Not Found"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable SSH Service") {
                $ServiceRunning = "False"
                $ServicePolicy = "Off"
            }

            $SystemSettingValue = "$ServiceRunning - $ServicePolicy"
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ServicePermissions") {
            $ServiceRunning = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Running
            $ServicePolicy = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Policy

            If ($ServiceRunning -eq $false -and $ServicePolicy -eq "off") {
                $SystemSettingValue = "$($VCodeObjectSTIGData.Check_Param) is not running"
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            } Else {
                #Version 1.03 - For STANDALONE, connect to host
                If ($ESXUsingvCenter -ne "STANDALONE") {
                    Connect-VIServer $CurrentSystemName -Credential $SystemCreds -ErrorAction SilentlyContinue -ErrorVariable ConnectError | Out-Null
                }

                #09/27/24 - If there is a connection error then report it and move onto the next system
                If ($ConnectError) {
                    Write-Host "`nESX STIG Check script cannot connect to $CurrentSystemName with error`n`n$ConnectError"
                    $SystemSettingValue = "ESX STIG Check script cannot connect to $CurrentSystemName with error`n`n$ConnectError"
                    $FindingHint = "NR"
                } Else {
                    $CIMRolePermissions = (Get-VIRole -Server $CurrentSystemName -Name CIMRole -ErrorAction SilentlyContinue | Get-VIPrivilege).Name

                    If ($CIMRolePermissions) {
                        $RolePermissionsComparison = Compare-Object $CIMRolePermissions @($VCodeObjectSTIGData.Expected_Value -split ",")

                        If ($RolePermissionsComparison -eq $null) {
                            $VerifyCIMServiceExists = Get-VMHostAccount -Server $CurrentSystemName -id CIMService -ErrorAction SilentlyContinue
                            $GetCIMServiceRole = (Get-VIPermission -Server $CurrentSystemName -Principal CIMService -ErrorAction SilentlyContinue).Role

                            If ($VerifyCIMServiceExists -ne $null -and $GetCIMServiceRole -eq "CIMRole") {
                                $SystemSettingValue = "CIMService account exists and is associated with a properly configured CIMRole"
                                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                                $FindingHint = "NF"
                            } Else {
                                $SystemSettingValue = "Either the CIM Service account doesn't exist or it isn't associated with CIMRole"
                            }
                        } Else {
                            $SystemSettingValue = "CIMRole permissions set incorrectly:`n$($CIMRolePermissions -join "`n")"
                        }
                    } Else {
                        $SystemSettingValue = "CIMRole is missing"
                    }
                }

                #09/27/24 - If this is NOT a standalone host and there is NOT a connection error then disconnect the host
                If ($ESXUsingvCenter -ne "STANDALONE" -and !($ConnectError)) {
                    Disconnect-VIServer $CurrentSystemName -Confirm:$false
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "sshd_config") {
            If ($VCodeObjectSTIGData.Check_Name -eq "SSHD Config Cipher Check") {
                $SystemSettingValue = $SSHDConfig | Where { $_ -like "Ciphers *" }
                
                $ExpectedCiphersList = $VCodeObjectSTIGData.Expected_Value -replace "Ciphers ",""
                $ActualCiphersList = $SystemSettingValue -replace "Ciphers ",""

                If (!(Compare-Object @($ActualCiphersList -split ",") @($ExpectedCiphersList -split ","))) {
                    $FindingHint = "NF"
                }
            } Else {
                $SystemSettingValue = $SSHDConfig | Where { $_ -eq $VCodeObjectSTIGData.Expected_Value }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "DomainJoin") {
            $SystemSettingValue = ($ESXVMHost | Get-VMHostAuthentication).DomainMembershipStatus
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "HostProfile") {
            #Version 1.08 - Adding check for host profile
            $SystemSettingValue = Get-VMHost $CurrentSystemName | Get-VMHostProfile
            
            If ($SystemSettingValue -eq $null) {
                $CustomComment = "No host profile configured"
                $FindingHint = "NA"
            } ElseIf ($SystemSettingValue.ExtensionData.Config.ApplyProfile.Authentication.ActiveDirectory.Enabled -eq $false) {
                $CustomComment = "$($SystemSettingValue.Name) is attached to this host but the host profile isn't used to join it to the domain"
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VMKernel") {
            $VMKernelData = $ESXVMHost | Get-VMHostNetworkAdapter -VMKernel | Select *Enabled

            $VMKernelToReview = $VMKernelData | Where { $_.($VCodeObjectSTIGData.Check_Param) -eq "True" }

            If ($VMKernelToReview) {
                If (($VMKernelToReview.psobject.Properties.Value | Where { $_ -eq "True" }).Count -eq 1) {
                    $SystemSettingValue = $VCodeObjectSTIGData.Expected_Value
                #If the only reason there are two items here is because of IPv6 being enabled then this still isn't a finding
                } ElseIf (($VMKernelToReview.psobject.Properties.Value | Where { $_ -eq "True" }).Count -eq 2 -and $VMKernelToReview.IPv6Enabled -eq "True") {
                    $SystemSettingValue = $VCodeObjectSTIGData.Expected_Value
                } Else {
                    $SystemSettingValue = "$($VCodeObjectSTIGData.Check_Param) NIC is NOT isolated"
                }
            } Else {
                If ($VCodeObjectSTIGData.Check_Name -eq "Isolate Provisioning Traffic") {
                    $FindingHint = "NA"
                } Else {
                    $FindingHint = "NA"
                    $SystemSettingValue = "$($VCodeObjectSTIGData.Check_Param) NIC not found"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "iSCSI CHAP") {
            #NOTE: This check is good enough for if iSCSI is disabled, but need to expand this if we run into cases where it is enabled
            If ((Get-VMHostStorage -VMHost $CurrentSystemName).SoftwareIScsiEnabled -eq $false) {
                $FindingHint = "NA"
                $CustomComment = "ISCSI is not enabled"
            } Else {
                $SystemSettingValue = (Get-VMHostStorage -VMHost $CurrentSystemName).SoftwareIScsiEnabled
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "FirewallAllowAll") {
            $AllIPAllowedList = ($ESXVMHost | Get-VMHostFirewallException | Where-Object { ($_.Enabled -eq $True) -and ($_.extensiondata.allowedhosts.allip -eq "enabled") }).Name

            If ($AllIPAllowedList -ne $null) {
                $CustomComment = "The following services allow connections from any IP`n`n$($AllIPAllowedList -join "`n")"
            } Else {
                $SystemSettingValue = "No firewall rules configured with Allow All"
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "FirewallDefaultPolicy") {
            $FirewallDefaultPolicy = Get-VMHostFirewallDefaultPolicy -VMHost $CurrentSystemName

            If ($FirewallDefaultPolicy.IncomingEnabled -eq $False -and $FirewallDefaultPolicy.OutgoingEnabled -eq $False) {
                $SystemSettingValue = $VCodeObjectSTIGData.Expected_Value
            } Else {
                $SystemSettingValue = "Incoming Enabled is set to $($FirewallDefaultPolicy.IncomingEnabled) and Outgoing Enabled is set to $($FirewallDefaultPolicy.OutgoingEnabled)"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "StandardSwitch") {
            $StandardSwitchList = Get-VirtualSwitch -VMHost $CurrentSystemName -Standard | Get-SecurityPolicy
            $StandardPortGroupList = Get-VirtualPortGroup -VMHost $CurrentSystemName -Standard | Get-SecurityPolicy

            $SwitchAcceptList = ($StandardSwitchList | Where { $_.($VCodeObjectSTIGData.Check_Param) -ne $False }).VirtualSwitch.Name
            $PortGroupAcceptList = ($StandardPortGroupList | Where { $_.($VCodeObjectSTIGData.Check_Param) -ne $False }).VirtualPortGroup.Name

            If ($StandardSwitchList) {
                If ($SwitchAcceptList -or $PortGroupAcceptList) {
                    $SystemSettingValue = "True"
                    $CustomComment = "The following Switches were set to accept:`n`n$SwitchAcceptList`n`nThe following Port Groups were set to accept:`n`n$PortGroupAcceptList"
                } Else {
                    $SystemSettingValue = $VCodeObjectSTIGData.Expected_Value
                }
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NA
                $FindingHint = "NA"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "StandardPortGroup") {
            #Version 1.03 - Collect Switch information since it is used in this check
            $StandardSwitchList = Get-VirtualSwitch -VMHost $CurrentSystemName -Standard | Get-SecurityPolicy
            $StandardPortGroupList = Get-VirtualPortGroup -VMHost $CurrentSystemName -Standard | Select Name, VLanId

            If ($VCodeObjectSTIGData.Check_Name -ne "Port Groups Don't Use Reserved Ips") {
                $VLANMatches = ($StandardPortGroupList | Where { $_.VLanID -eq $VCodeObjectSTIGData.Check_Param }).Name
            } Else {
                $VLANMatches = @()

                ForEach ($VLANItem in $VCodeObjectSTIGData.Check_Param.Split(",")) {
                    $VLANSplit = $VLANItem.Split("-")

                    If ($VLANSplit.Count -eq 2) {
                        $VLANsFound = ($StandardPortGroupList | Where { $_.VLanID -ge $VLANSplit[0] -and $_.VLanID -le $VLANSplit[1] }).Name
                    } Else {
                        $VLANsFound = ($StandardPortGroupList | Where { $_.VLanID -eq $VLANItem }).Name
                    }

                    #Version 1.03 - Only add $VLANMatches if there are VLANs found
                    If ($VLANsFound) {
                        $VLANMatches += $VLANsFound
                    }
                }
            }

            If ($StandardSwitchList) {
                #Version 1.03 - Check to see if there are any entries in $VLANMatches
                If ($VLANMatches.Count -ne 0) {
                    $SystemSettingValue = "The following Port Groups are assigned to VLAN $($VCodeObjectSTIGData.Check_Param):`n`n$VLANMatches"
                } Else {
                    $SystemSettingValue = $VCodeObjectSTIGData.Expected_Value
                }
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NA
                $FindingHint = "NA"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "Patches") {
            $SystemSettingValue = "Version - $($ESXVMHost.Version) - Build - $($ESXVMHost.Build)"

            #Version 1.06 - Check to see if the build exceeds the required version
            $ExepectedValueSplit = $VCodeObjectSTIGData.Expected_Value -Split " - "
            If ($ExepectedValueSplit[1] -eq $ESXVMHost.Version -and $ExepectedValueSplit[3] -lt $ESXVMHost.Build) {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SSHQuery") {
            If ($VCodeObjectSTIGData.Check_Name -eq "Secure Boot Enabled") {
                $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command { /usr/lib/vmware/secureboot/bin/secureBoot.py -s }).Output
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable ESX Override Config") {
                $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command { stat -c "%s" /etc/vmware/settings }).Output
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable ESX Override Log") {
                $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command { grep "^vmx\.log" /etc/vmware/config }).Output
                
                #First need to check to see if this is Null prior to checking if it is blank
                If ($SystemSettingValue -eq $null) {
                    $FindingHint = "NF"
                } ElseIf ($SystemSettingValue[0] -eq "") {
                    $FindingHint = "NF"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "DODCert") {
            $certMgr = Get-View -Id $ESXVMHost.ExtensionData.ConfigManager.CertificateManager
            
            If ([DateTime]$certMgr.CertificateInfo.NotAfter -gt (Get-Date) -and $certMgr.CertificateInfo.Issuer -like "*OU=DoD*") {
                $SystemSettingValue = $VCodeObjectSTIGData.Expected_Value
            } Else {
                $SystemSettingValue = "Issuer of $($certMgr.CertificateInfo.Issuer) and expiration of $([DateTime]$certMgr.CertificateInfo.NotAfter)"
            }
        }

        $parms = @{
            CorrectVal = $VCodeObjectSTIGData.Expected_Value
            ActualVal = $SystemSettingValue
            CustomComment = $CustomComment
            FindingHint = $FindingHint
            CurrentSystemName = $CurrentSystemName
        }

        #Version 1.05 - If this is run from Orchestrator then run the check script from a local copy rather than a network one
        If ($RunFromOrchestrator -eq "True") {
            #Run the RecordToChecklist.ps1 script from a local copy
            Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\RecordToChecklist.ps1"" @parms")
        } Else {
            #Run the RecordToChecklist.ps1 script from the network
            Invoke-Expression -Command ("& '$FolderPathToSTIGScript\RecordToChecklist.ps1' @parms")
        }

        If ($AltCheck -eq "True") {
            $VCodeObjectSTIGData.Expected_Value = $OrigExpectedValue
        }
    }
}

$Checklist_XMLObject.Save($ChecklistFilePath)

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBMWrhf7fpk1Cvx
# 6B52akoNKYcF6ljed2c1EHWKL7y6iaCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAinD1dMn/HBVxUGEfiVUt8F4i5tsSerqsAcaLt5+bW+TANBgkq
# hkiG9w0BAQEFAASCAQBu/BCo4As2DbvxhyEEfhzbjJng6u4Lypiylk/kwfTCuLUt
# ssO2/iO3P7fdECqPUk8yLq2in10sEAjdFRedAwBt74yB1tcMIOt/PZSD3WH0e1NE
# oi5v8N8xutn7A4QrBalEf02ek/wdEVDqk2yStoi1pQHyg9aSq1XfdXgcyfuoG9Gj
# /21H3ehwIcMzhD9/yoapLdC4aWcFzmN5EyVrq1HZjP7J1a8ZPMsRn6XOXCdeQqpi
# 3vkNbgTyfHYmQDTfpMGo8+3maK2h+8z7yqk5LnJNKEv9M97VvGzCyuGRsnwSTPaC
# C+AHVyQhJ0QGs7JvP8P9Firtc28Ml6G5xI4nDLtl
# SIG # End signature block
