#PURPOSE: Loop through all vCenter servers to find VMs that are Ballooning and then determine if increasing the Resource Pool memory limit would resolve this issue

#Future plan: Start including Get-VICredentialStoreItem to this script as well as a report

#CHANGELOG
#Version 1.0 - 02/29/24 - MDR - Initial version
#Version 1.01 - 03/01/24 - MDR - Add ability to loop through all vCenter servers

#Version 1.01 - Import the list of all vCenter Servers
$vCenterServerList = Import-Csv "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter-Servers.csv"

#Clear screen
Clear

#Version 1.01 - Loop through all of the vCenter Servers
ForEach ($vCenterServer in $vCenterServerList.ServerName) {
    #Version 1.01 - Declare the connection to the vCenter Server
    Write-Host "`nConnecting to vCenter Server $vCenterServer"

    #Connect to vCenter Server
    Connect-VIServer $vCenterServer -ErrorAction SilentlyContinue | Out-Null

    #Version 1.01 - Confirm that the connection worked
    If (!($global:DefaultVIServer | Where { $_.Name -eq $vCenterServer })) {
        #Version 1.01 - Output a failure to connect
        Write-Host "Failed to connect to the vCenter Server $vCenterServer" -ForegroundColor Red
        #Version 1.01 - Return to the top of the ForEach loop for the next vCenter Server
        Continue
    }

    #Keep a list of all Resource Pools that have been reviewed
    $ResourcePoolList = @()

    #Get a list of all VMs on the vCenter Server
    $vms = Get-VM

    #Report that script is collecting info from VMs
    Write-Host "`nDetermining which VMs are ballooning memory.  Please wait"

    #Determine which VMs are ballooning memory
    $BallooningVMs = Get-Stat -Entity $vms -Realtime -Stat mem.vmmemctl.average -MaxSamples 1 -ErrorAction SilentlyContinue | where {$_.Value -gt 5} | Select @{N="VM";E={$_.Entity.Name}},Value

    #Version 1.01 - If there are VMs that are ballooning
    If ($BallooningVMs) {
        #Report that script is about to start looping through Resource Pools
        Write-Host "`nLooping through $($BallooningVMs.Count) VMs to find which Resource Pools need to get reconfigured"
    } Else {
        #Version 1.01 - Report that no VMs are ballooning
        Write-Host "`nNo VMs found to be ballooning" -ForegroundColor Green
    }

    #Loop through each VM ballooning memory
    ForEach ($BalloonVM in $BallooningVMs) {
        #Get info about the VM that is ballooning memory
        $VMInfo = Get-VM $BalloonVM.VM | Select *

        #If the VM is in a Resource Pool that hasn't been reviewed yet AND the VM isn't sitting outside of any Resource Pool
        If ($ResourcePoolList -notcontains $VMInfo.ResourcePool.Name -and $VMInfo.ResourcePool.Name -ne "Resources") {
            #Record the name of the Resource Pool now that it has been reviewed so it doesn't get reported on again
            $ResourcePoolList += $VMInfo.ResourcePool.Name

            #Find out how much RAM is being used by VMs in this Resource Pool
            $TotalMemoryInVMsInRP = ((Get-VM | Where { $_.ResourcePool -eq $VMInfo.ResourcePool }).MemoryGB | measure-object -sum).sum

            #Get the limit for how much RAM is allowed in this Resource Pool
            $TotalMemoryInRP = (Get-ResourcePool $VMInfo.ResourcePool).MemLimitGB | Where { $_ -gt 0 }

            #If there is more than 1 instance of this Resource Pool
            If ($TotalMemoryInRP.Count -ne 1) {
                #If more than one instance is found then nothing can be done
                Write-Host "`nThere is more than one instance of $($VMInfo.ResourcePool) so no action could be taken" -ForegroundColor Yellow
            } Else {
                #Report the collected information
                Write-Host "`n$($VMInfo.ResourcePool) has $TotalMemoryInRP limit and VMs in it are using $TotalMemoryInVMsInRP"

                #If the Resource Pool limit is less than the amount of RAM being used by the VMs times 115% (Using 15% instead of 20% to ensure that once a RP is increased by 20% it doesn't trip here)
                If ($TotalMemoryInRP -lt ($TotalMemoryInVMsInRP * 1.15)) {
                    #Increase the Resource Pool memory limit to be 20% higher than the amount of RAM used by the VMs in the Resource Pool
                    Set-ResourcePool $VMInfo.ResourcePool -MemLimitGB ($TotalMemoryInVMsInRP * 1.2) | Out-Null

                    #Get the updated amount of memory for this Resource Pool
                    $NewTotalMemoryInRP = (Get-ResourcePool $VMInfo.ResourcePool).MemLimitGB | Where { $_ -gt 0 }

                    #Report the increase in RAM for the Resource Pool
                    Write-Host "Updated memory for $($VMInfo.ResourcePool) from $TotalMemoryInRP to $NewTotalMemoryInRP" -ForegroundColor Cyan
                } Else { #If there is enough memory in the Resource Pool already
                    #Report that no change needs to be made to this Resource Pool
                    Write-Host "$($VMInfo.ResourcePool) already has a high enough memory limit to support the VMs" -ForegroundColor Green
                }
            }
        } ElseIf ($VMInfo.ResourcePool.Name -eq "Resources") { #If the VM isn't in a Resource Pool
            #Report that the VM isn't in a Resource Pool
            Write-Host "`n$($BalloonVM.VM) isn't in a Resource Pool" -ForegroundColor Yellow
        }
    }

    #Version 1.10 - Declare that this vCenter server is complete
    Write-Host "`nFinished scanning $vCenterServer" -ForegroundColor Cyan

    #Version 1.01 - Disconnect from the vCenter Server
    Disconnect-VIServer -Server $vCenterServer -Confirm:$false
}

#Version 1.01 - Declare that script has completed
Write-Host "`nScript complete" -ForegroundColor Green
# SIG # Begin signature block
# MIILxQYJKoZIhvcNAQcCoIILtjCCC7ICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUzupwPcp+WIL7P9EZPMzdeHVd
# fVygggktMIIEbDCCA1SgAwIBAgIDEjRvMA0GCSqGSIb3DQEBCwUAMFoxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMwHhcNMjMwNDEwMDAw
# MDAwWhcNMjcwNDA3MTM1NTU0WjBmMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5T
# LiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEMMAoGA1UE
# CxMDRExBMRMwEQYDVQQDEwpDUy5ETEEuMDA1MIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAjMaXJ2yQcMI0ZgW8qa3xkItp8L7VtB9FDtfdiQS6chAZC+V8
# RQO4iWMV87+bCdMIbHx/AgTepcuOwX/kAfxKVhb2msv3mHPzu7hhJpNTV9sGFR9S
# c62e4axw0i/O73B/ZsClZG0URlYFDb3X6rV1Qk27BUXdX++683Xgk5CspndiN1Zb
# fjZ69IDsvda5/gV6wyREcXlr5nlEXwn8SuA+J2xlFtkXbDNeLHo4Z88NlY61i13s
# 7C71giua12KEwy1g9saqw2mKlwfFfL4qipyRVrcPJNvc/lTh+wVq5P4WaBA06iKC
# 33IHndFd1cNor0sjp2zviZBYWcsFYngTFwKWCQIDAQABo4IBLTCCASkwHwYDVR0j
# BBgwFoAUF+ZLyBpLyaemcLRMTV7I9jbUMJgwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9ESURDQV82My5jcmwwDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdIAQPMA0wCwYJYIZIAWUCAQsqMB0GA1UdDgQWBBT4AbxTG6dDzp0i
# G4IfIlvBDYoM3TBlBggrBgEFBQcBAQRZMFcwMwYIKwYBBQUHMAKGJ2h0dHA6Ly9j
# cmwuZGlzYS5taWwvc2lnbi9ET0RJRENBXzYzLmNlcjAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwHwYDVR0lBBgwFgYKKwYBBAGCNwoDDQYIKwYBBQUH
# AwMwDQYJKoZIhvcNAQELBQADggEBAApQpCPdOGEWZ/CqUmxr7H/Jkj7CALR3OA6y
# b/vEO2v2QplFIyBiTFRoFs1G4pOt5njGzE8RtkXyO3PRD29RKKMBMwJwQtXLX9vD
# 0YVf/w5Wqtj3lptILtKM5elw+jehhn4KgyncMtp2yJwzToyRaoFdo3g/T5ddSYts
# 03i4XOuxEFnlJW/hozoMFaKFYitF5KMPwvnkLAynzmZLdhw17piUoo2ftPhh0i6y
# ZWwCObwfeti5yqNyUyof1XzD/4+h380+Zye68PeXdLNS/wIdAeKVImKxZB8s1+qq
# DAny4dogj0FU4PgdunbnwgACVTTmVswXUIlZOH6rS/K4iUkLdLYwggS5MIIDoaAD
# AgECAgIFDzANBgkqhkiG9w0BAQsFADBbMQswCQYDVQQGEwJVUzEYMBYGA1UEChMP
# VS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEWMBQG
# A1UEAxMNRG9EIFJvb3QgQ0EgMzAeFw0yMTA0MDYxMzU1NTRaFw0yNzA0MDcxMzU1
# NTRaMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAK
# BgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFEl3WgH6i1/u1Su87lcHX
# lB7dOsy17rfSlynPggESAK/rjElfavjrkmT6ooaq1bmV59HbSOVrN8wM7V2A5D5t
# rhMRCf9UC62PyU7/tqDcaFntnY11MAHs5yRfQud8WS2Wd1y3maLOOLwIgH+AYXCh
# 7KQUXs1dueJe53GE3M9e88GEFjfzJdPPM0fENk4ENeHKiBjHr290hoMu9cLBZMez
# DnAElqJMwZ0pwWwJRQviQ5jSG/rRViRx244X357taauwktYwzkhlLky8tBSnO+X9
# cOcl6TtohohTeW1mi3L/wuvpIE2vuFq/HrMvHETBn8RR9TfyAq5DE6ijnSjaxFyd
# AgMBAAGjggGGMIIBgjAfBgNVHSMEGDAWgBRsipSid7GAch2Behaq8tzOZu5FwDAd
# BgNVHQ4EFgQUF+ZLyBpLyaemcLRMTV7I9jbUMJgwDgYDVR0PAQH/BAQDAgGGMGcG
# A1UdIARgMF4wCwYJYIZIAWUCAQskMAsGCWCGSAFlAgELJzALBglghkgBZQIBCyow
# CwYJYIZIAWUCAQs7MAwGCmCGSAFlAwIBAw0wDAYKYIZIAWUDAgEDETAMBgpghkgB
# ZQMCAQMnMBIGA1UdEwEB/wQIMAYBAf8CAQAwDAYDVR0kBAUwA4ABADA3BgNVHR8E
# MDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RST09UQ0EzLmNy
# bDBsBggrBgEFBQcBAQRgMF4wOgYIKwYBBQUHMAKGLmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvaXNzdWVkdG8vRE9EUk9PVENBM19JVC5wN2MwIAYIKwYBBQUHMAGGFGh0dHA6
# Ly9vY3NwLmRpc2EubWlsMA0GCSqGSIb3DQEBCwUAA4IBAQAGG9UvVRw4kCnDGW7n
# RE7d0PtOn/xUx+sDBhK3u5wsFKl10fG7BSwmQRqQntbweiJFA9dIZbSOtkDF1cff
# fUMuHJE+2f/bOFWQuI9Tr7BS+Z6fS3ei1PrURrmgm5TxES6lznXqtL4M3IIkvlYM
# aaMxBLLGExy2t62aLZxv3EIa+2gPqVSCod0NA2Q8oboRgko/A01gbfMIcQ1FEqBl
# 3zbGhUIH2Hc2FnczW5L5hc61w62TB8EoocxDxbXg0lS8MvfGPIv7krViLom1/kbe
# kC/FlCB/+99HcPrPG07hDL+ryphbZ7LImdFr2+bWR+NR3ZHQ2ZPo1pSMOmLcRnSu
# IXsVMYICAjCCAf4CAQEwYTBaMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5TLiBH
# b3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMM
# RE9EIElEIENBLTYzAgMSNG8wCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFK7h1yN8w6cJaeKSJuPC
# ZRdPE9oLMA0GCSqGSIb3DQEBAQUABIIBACjD1TqFQD8pEN5C3YHgukTRKX0Vqc9V
# tIPXBpbPe0rP2Jza2iDcFCzn1FelhxulBm0NPzRxH78dqGk7ck+HQnhU26Aa3/qz
# hc0ghy31MI9pEWAczC2X4NCu6dYE+UsXrW+OlXWovrcki8MpxHqF3Jwo7P9SFqAG
# oziviF2Lcmbrz07hL96NIFiseX44K7/olLXgeZYSe4LzMJJji1GhWkSMHx7mTLbC
# yLWqh3T1pKAlilnuAVhOFmr+yhsL24v8cGqVSm4V067Znqv/pi8YhIxVFgoxgQN4
# jWggNjV9UKdzEJvhtVNlZkIC5E58P4MSIbEdXGoqevwIptiOgAkS0vU=
# SIG # End signature block
