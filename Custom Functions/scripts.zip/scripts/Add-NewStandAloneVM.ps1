# AddNewStandAloneVM.ps1
# This script is expected to work with DPM 2010 Beta

# 1. Parameters supplied to the script
param([string] $ProductionServer = "", [string] $PGName = "")

# 2. Failures are registered in Application events on the DPM server
trap [Exception] { 
	$log = Get-EventLog -List | Where-Object { $_.Log -eq "Application" }
	$log.Source = "AddNewStandAloneVM"
	$log.WriteEntry("TRAPPED: $error[0]", [system.Diagnostics.EventLogEntryType]::Error,9911) 
	$Error[0] #show on console
	exit 
}

# 3. Prompt for missing parameters
if(!$ProductionServer)
{
	$ProductionServer = read-host "Enter the production server FQDN "
}
if(!$PGName)
{
	$PGName = read-host "Enter the name of your existing Hyper-V protection group "
}

$dpmservername = &"52zhtv-bs-676"
connect-dpmserver $dpmservername

# Do not modify this line
$tape = "Short-term using tape"

# Hyper-V Writer guid
$guid = "66841cd4-6ded-4f4b-8f17-fd23f8ddc3de"

# 4. Search for the protection group name passed as input and exit if it was not found
$PGList = @(Get-ProtectionGroup $dpmservername)
$PG = $PGlist | where { $_.FriendlyName -eq $PGName}
if (!$PG) { Throw "Specified protection group [$PGname] is not found!" }

# 5. Obtain the list of protected servers on this DPM server
$PSList=@(Get-ProductionServer $dpmservername)
$DsList = @()

# 6. Scan through the obtained list of protected servers
foreach ($PS in $PSList)
{
	# 6.1 Search for the protected server name passed as input
	if($PS.Name -eq $ProductionServer)
	{
		write-host "Running Inquiry on" $PS.Name

		# 6.1.1 Run inquiry on the protected server matched
		$DSlist += Get-Datasource -ProductionServer $PS -Inquire
		$PSFound=$true
	}
}

if(!$PSfound)
{
	"Production Server $PS does not exist"
	exit 1
}


# 7. If object is a data source and of type Hyper-V and is currently not protected add to list of unprotected VMs
$unprotectedDsList = @($DSlist | ? {$($_.Type.IsDatasource) -and ($($_.Type.Id) -match $guid) -and ! $($_.Protected)})

# 8. Exit if there are no unprotected VMs
if ($unprotectedDSList.count -lt 1) 
{
	write-host "No new datasources found!"
	exit 1
}

# 9. Obtain a modifiable protection group type
$MPG = Get-ModifiableProtectionGroup $PG

# 10. Perform the following for each new VM to add to protection
foreach ($ds in $unprotectedDsList)
{
	write-host "Adding data source"  $ds.Name "to" $MPG.FriendlyName
	$npg = Add-ChildDatasource -ProtectionGroup $MPG -ChildDatasource $ds

	# 10.1 Disk allocation is skipped if short term protection is to tape
	if($MPG.protectionmethod -eq $tape) { continue };
	$x = Get-DatasourceDiskAllocation -Datasource $ds
	Set-DatasourceDiskAllocation -Datasource $ds -ProtectionGroup $MPG
}

# 11. Note that replica is created immediately irrespective of the PG policy
Set-ReplicaCreationMethod -ProtectionGroup $MPG -Now

write-host "Adding new Hyper-V data sources to" $MPG.FriendlyName

# 12. Save the changes to the protection group. Replica creation will be triggered immediately.
Set-protectiongroup $MPG

disconnect-dpmserver $dpmservername
"Exiting from script"
