#PURPOSE: Create signed certificate requests for ESX hosts

#CHANGELOG
#Version 1.00 - 07/16/24 - MDR - Initial version
#Version 1.01 - 08/15/24 - MDR - Added a note at the end of the script to indicate what steps to take next
#Version 1.02 - 08/23/24 - MDR - Updated the prompt for inputting the vCenter password to specify it needs the PowerShell service account password
#Version 1.03 - 10/04/24 - MDR - Updating the script to TRIM the names provided by the user to prevent errors if spaces exist on the end of the names
#Version 1.04 - 10/25/24 - MDR - Add the cert request hash to the MassCert.csv output so that it is easier to submit PKI requests

#This list is built from the script "Build ESX List.ps1" and will have information in it that is necessary for generating signed cert requests
$ESXHostList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ESXHostList.csv"
#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"
#Set the path to output the PDF data to
$PDFOutputPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\Fillout PDFs\MassCert.csv"
#Create the variable for creating the PDFs after this process is over
$PDFData = New-Object System.Collections.Generic.List[System.Object]

Clear

#Create the Temp folder if necessary
If (!(Test-Path "C:\Temp")) {
    New-Item "C:\Temp" -ItemType Directory | Out-Null
}

#Verify that the ESX host list was imported
If ($ESXHostList -eq $null) {
    Write-Host "The ESX Host List file was not found" -ForegroundColor Red
    Break
}

#Ask if this is for a single host or a list
$ServerList = Read-Host "Enter the ESX host name or enter LIST if there is a list of them"

#If a list is being imported
If ($ServerList -eq "List") {
    #Load the .NET library for opening dialog windows
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null
    
    #Bring up a file browser to select the .txt file of the list
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
        InitialDirectory = "c:\temp"
        Filter = "(*.txt) | *.txt"
    }
    $FileBrowser.ShowDialog() | Out-Null

    #If a file was selected
    If ($FileBrowser -ne $null) {
        #Import the server list
        $ServerList = Get-Content $FileBrowser.FileName
    } Else { #If no file was selected then exit
        Write-Host "No file was selected" -ForegroundColor Red
        Break
    }
}

#Version 1.02 - Prompt for Powershell Password
$vCenterPass = Read-Host "`nInput the svc_VPM_Powershell password" -MaskInput

#Loop through each server on the list
ForEach ($ESXHostName in $ServerList) {
    #Version 1.03 - Trim the name of the ESX host to remove any spaces at the end of the name
    $ESXHostName = $ESXHostName.Trim()

    #Get the info for this server
    $ServerInfo = $ESXHostList | Where { $_.SystemName -eq $ESXHostName }

    If ($ServerInfo -eq $null) {
        Write-Host "`nNo ESX info was found for $ESXHostName" -ForegroundColor Red
        Continue
    } Else {
        Write-Host "`nCreating signed cert request for $ESXHostName" -ForegroundColor Cyan
    }

    #Store all of the variables for the ESX host being processed
    $vCenterServerName = $ServerInfo.vCenterServer
    $ESXHostShortName = ($ESXHostName.Split("."))[0]
    $ESXHostIPAddr = $ServerInfo.IPAddr
    $ESXHostCity = $ServerInfo.Location
    $ESXHostState = $ServerInfo.State
    $ESXHostLocation = "$ESXHostCity, $ESXHostState"

    #Only perform a connection attempt to vCenter if it isn't already connected
    If (($global:DefaultVIServers).Name -notcontains $vCenterServerName) {
        #Get the user name that will be used to connect to vCenter
        $vCenterUserName = ($vCenterServerList | Where { $_.ServerName -eq $vCenterServerName }).User

        #Generate the vCenter credentials to connect
        $SecurePassword = ConvertTo-SecureString $vCenterPass -AsPlainText -Force
        $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterUserName, $SecurePassword )

        Try {
            #Disconnected from all vCenter Servers
            Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
        } Catch {}

        #Connect to vCenter Server
        Connect-VIServer $vCenterServerName -Credential $vCenterSecureCreds | Out-Null
        
        #Confirm that the connection worked
        If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServerName })) {
            Write-Host "`nFailed to connect to vCenter Server $vCenterServerName" -ForegroundColor Red
            Break
        }

        #Get the certificate mode from the vCenter server
        $CertMode = (Get-AdvancedSetting "vpxd.certmgmt.mode" -Entity $vCenterServerName).Value

        #Confirm that it is set to Custom
        If ($CertMode -ne "custom") {
            Write-Host "The certificate mode must be set to custom on $vCenterServerName"
            Break
        }
    }

    #Get the ESX host info
    $VMHost = Get-VMHost $ESXHostName
    #Make a request for the signed certificate
    $esxRequest = New-VIMachineCertificateSigningRequest -VMHost $VMHost -CommonName $ESXHostName -Locality $ESXHostCity -StateOrProvince $ESXHostState -Country "US" -Organization "US Government" -OrganizationUnit "DLA"
    #Store the certificate request to the server
    $esxRequest.CertificateRequestPEM | Out-File "C:\Temp\$ESXHostName.pem" -Force

    #Store data that will be used to generate PDFs for the signed cert requests
    #Version 1.04 - Add the cert request hash to the MassCert.csv output so that it is easier to submit PKI requests
    $PDFData.add((New-Object "psobject" -Property @{"Common Name"=$ESXHostName;"Physical Location"=$ESXHostLocation;"IP"=$ESXHostIPAddr;"CertReq"=$esxRequest.CertificateRequestPEM}))
}

Write-Host "`nCompleted creating signed certificate requests" -ForegroundColor Green
#Version 1.01 - Added more details for what needs to be done next
Write-Host "`nThe next step in this process is to retrieve the signed certificate requests from C:\Temp and use them to submit signed cert requests with the PKI team" -ForegroundColor Green
Write-Host "`nA file has been created in \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\Fillout PDFs\MassCert.csv which can be used by the FillOutPDF.ps1 script to generate signed cert request PDFs.  If using this method then open this file and update it as signed cert requests are done with the PKI team" -ForegroundColor Green

#Prompt for the CA number that will be used
$CANumber = Read-Host "`nEnter the CA number you will use for requesting these certs"

#Version 1.04 - Added "CertReq" to the output
$PDFData | Select @{Name="CA";Expression={$CANumber}}, @{Name="Request";Expression={""}}, @{Name="Description";Expression={"ESX Host"}}, "Common Name", "Physical Location", "IP", `
                  @{Name="SAN1";Expression={""}}, @{Name="SAN2";Expression={""}}, @{Name="SAN3";Expression={""}}, "CertReq" | Export-CSV $PDFOutputPath -NoTypeInformation -Force
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAuOy5DjfMBtuk3
# u1KdnB04IaX9qd0VLjNP71Z0wPGNV6CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBzJRnTVoIfuY5QsmkiU4HzqFELzTR8pg+8IHnYB5R/MjANBgkq
# hkiG9w0BAQEFAASCAQACPAGX1ate+8Izj7fD3d6QKoIRiRTImD6oWJbHXV0KmMrI
# KW6YBHm1r4o62/Sek6ZdcMqZW1lSylB5NkgvIksAUJ1BbJpFjc44N7Rgg+frgMSh
# sEZGK6+QiTA01vZ5jTWQDq5b3dXf5wD57CFam+8G/xHljaQrbPnSXkHDkal3MhE5
# 1BsYYn7ia+aXEgVTmJw71DLj7CjyZgy6MYnySSUpcDj3xlTlQkwOd0MD0MOrXO7I
# pKj5Uyc10Wo7G25xforZe/KZsdYf2U3GZlkHnysSZeoKCzklSiBRyxSs036fDoXZ
# lRbPn3ZeYZ/6Q1ULu8VZjAVOKi3ZpOgxJcfStNRF
# SIG # End signature block
