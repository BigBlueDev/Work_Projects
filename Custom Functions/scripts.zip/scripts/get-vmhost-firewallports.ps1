

[CmdletBinding(DefaultParameterSetName = "userInput")]
param (
    [Parameter(ParameterSetName = "UserInput", ValueFromPipeline = $true)]
    [Parameter(ParameterSetName = "pipedcreds", ValueFromPipeline = $true)]
    [string]
    $VcenterName,
    [Parameter(ParameterSetName = "UserInput", ValueFromPipeline = $false)]
    [string] $username,
    [Parameter(ParameterSetName = "pipedcreds", ValueFromPipeline = $true, )]
    [System.Management.Automation.PSCredential] $credentials
)

function toolcheck ($m)
{

    # If module is imported say that and do nothing
    if (Get-Module | Where-Object { $_.Name -eq $m })
    {
        Write-Host "Module $m is already imported."
    }
    else
    {

        # If module is not imported, but available on disk then import
        if (Get-Module -ListAvailable | Where-Object { $_.Name -eq $m })
        {
            Import-Module $m -Verbose
        }
        else
        {

            # If module is not imported, not available on disk, but is in online gallery then install and import
            if (Find-Module -Name $m | Where-Object { $_.Name -eq $m })
            {
                Install-Module -Name $m -Force -Verbose -Scope CurrentUser
                Import-Module $m -Verbose
            }
            else
            {

                # If the module is not imported, not available and not in the online gallery then abort
                Write-Host "Module $m not imported, not available and not in an online gallery, exiting."
                EXIT 1
            }
        }
    }
}

toolcheck 'VMware.PowerCLI'


if ($credentials)
{

    Connect-VIServer -Server $VcenterName -Credential $credentials

}
else
{
    Connect-VIServer -Server $VcenterName -Credential (Get-Credential -UserName $username -Message 'Input SSO Admin Account')
}



$vmhost = Get-VMHost




$output = @()
foreach ($hostname in $vmhost)
{


    $hostname = $hostname.name
    $fw_query = Get-VMHostFirewallException -VMHost $hostname | Where-Object { $_.name -eq 'vSphere Web Client' }

    $ports = [PSCustomObject]@{
        hostname       = $hostname
        FWName         = $fw_query.name
        Enabled        = $fw_query.enabled
        IncomingPorts  = $fw_query.IncomingPorts
        OutgoingPorts  = $fw_query.OutgoingPorts
        Protocols      = $fw_query.Protocols
        ServiceRunning = $fw_query.ServiceRunning
    }
    $output += $ports
}
$output | Export-Csv "C:\temp\hostfirewallportconfig+_$vcentername+$((Get-Date).ToString('yyyymmdd_hhmmtt')).csv" -NoTypeInformation -Force






