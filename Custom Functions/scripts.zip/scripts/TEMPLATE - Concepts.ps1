﻿#PURPOSE: Notes for basic concepts and ideas to use in other scripts

#CHANGELOG
#Version ??? - MDR - Always updating!

#*****BASIC FOREACH*****
$ServerList = get-content "C:\Temp\Scripts\ServerList.txt"

foreach($ServerName in $ServerList)
{
    $Session = New-PSSession $ServerName

    Invoke-Command -Session $Session -ScriptBlock {
        hostname
    }

    Remove-PSSession $Session
}

#*****HIDE TEST-NETCONNECTION PROGRESS BAR*****
$OriginalProgressPreference = $Script:ProgressPreference
$Script:ProgressPreference = 'SilentlyContinue'
Test-NetConnection $ServerName -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
$Script:ProgressPreference = $OriginalProgressPreference

#*****LISTS - ARRAY*****
$ServerData = New-Object System.Collections.Generic.List[System.Object]
$ServerData.add((New-Object "psobject" -Property @{"Value"="Val3.1";"Date"=Get-Date;"Whatever"=15}))
$ServerData.add((New-Object "psobject" -Property @{"Value"="Val3.2";"Date"=(Get-Date).AddDays(1);"Whatever"=30}))

$SortedList = $ServerData | Sort-Object "Date" -Descending #Method for doing sorts
$ServerData.Clear()
$SortedList | ForEach-Object {$ServerData.Add($_)}

$ServerData.Removeat(0) #if thing ever need to be taken off the list

$ActiveJobList.RemoveAt($ActiveJobList.ServerName.IndexOf($ServerName))

#*****LIST - BASIC*****
$data = [PSCustomObject]@{'ServerName'="Hello"}
$data = $data + [PSCustomObject]@{'ServerName'="Bye"}

#*****LIST - VERY BASIC*****
$data = "Hello"
$data = $data,"Bye"

#*****ARRAYS - DEPRECATED*****
$ServerData = [System.Collections.ArrayList]@()

$obj = [PSCustomObject]@{"Text"="Hello";"Time"=Get-Date}
$ServerData.Add($obj) | Out-Null
$obj = [PSCustomObject]@{"Text"="Buh Bye";"Time"=(Get-Date).AddMinutes(-1)}
$ServerData.Add($obj) | Out-Null

$ServerData.Remove($ServerData[0])

$ServerData | Sort-Object "Time"

#*****CONDENSED PSSESSION*****
Function OpenPSSession ($PServerName, $PSPN) { #Where PServerName is server name and PSPN is either True-SPN or True-NoSPN
    if ($PSPN -eq "True-SPN") {
        $sessionOptions = New-PSSessionOption -IncludePortInSPN
        $Session = New-PSSession $PServerName -SessionOption $sessionOptions
    } else {
        $Session = New-PSSession $PServerName
    }

    $Session #Return session data
}

#*****FULL PSSESSION*****
Function OpenPSSession ([string]$PServerName) { #Where PServerName is server name
    $SplitServerName = $PServerName.Split(".") #If it is an FQDN, it will capture the short name
    $search = New-Object DirectoryServices.DirectorySearcher([ADSI]"")
    $search.filter = "(&(name=" + $SplitServerName[0] + ")(servicePrincipalName=*5985*))"
    $results = $search.Findall()

    if ($results -ne $null) { #If there is an SPN for port 5985 (only used for systems running IIS)
        $sessionOptions = New-PSSessionOption -IncludePortInSPN
        $RemoteSession = New-PSSession $PServerName -SessionOption $sessionOptions
        [PSCustomObject]@{'RemoteSession'=$RemoteSession;'PSSessionRequired'='True-SPN'}
    } Else {
        $RemoteSession = New-PSSession $PServerName
        [PSCustomObject]@{'RemoteSession'=$RemoteSession;'PSSessionRequired'='True-NoSPN'}
    }
}

#*****GENERATE STRONG PASSWORD*****
Add-Type -AssemblyName 'System.Web'
$Password = [System.Web.Security.Membership]::GeneratePassword(20,4)
$secPw = ConvertTo-SecureString -String $Password -AsPlainText -Force
set-localuser -Name $CredName -Password $secPw

#*****ALTERNATIVE MULTI-THREADING
#The way this works is by opening up many New-PSSessions at once and having them all execute the same script
[string[]]$arrayFromFile = Get-Content -Path 'C:\temp\scripts\ServerList.txt'
$Counter = 0 #This needs to start out at 0
$ThresholdCount = 10 #This is the number of servers to run at one time

Function ExecuteScript {
    $Session = New-PSSession $arrayFromFile[$Counter..$CounterHigh]
    $arrayFromFile[$Counter..$CounterHigh] #List the servers being scanned

    Invoke-Command -Session $Session -ScriptBlock {
        hostname
    }
    Remove-PSSession $Session
}

while ($true) {
    if ($Counter + $ThresholdCount -lt $arrayFromFile.Count) #If there are more servers left on the list than the ThresholdCount
    {
        $CounterHigh = $Counter + $ThresholdCount - 1
        ExecuteScript
    }
    else
    {
        $CounterHigh = $arrayFromFile.Count
        ExecuteScript
        break
    }
    $Counter = $Counter + $ThresholdCount
}

#*****GET-CONTENT WITHIN A COMMAND*****
Any-Command -ComputerName (Get-Content -Path 'C:\temp\Scripts\ServerList.txt')

#*****TEST IF FILE / FOLDER EXISTS*****
if (-not (test-path "\\$Server\C$\Program Files")) {
    Write-Output "Couldn't scan $Server"
} else {   
    get-childitem "\\$Server\C$\Program Files\HID Global\Credential Management Client\lib\log4j-core-2.13.3.jar"
}

#*****FILE SEARCH*****
get-childitem -recurse C:\ -ErrorAction SilentlyContinue | where {$_.Name -like "*.p12"}

#*****REMOVE OUTPUT HEADER FOR SINGLE COLUMN OUTPUT*****
#$VBS = Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard | foreach {$_.VirtualizationBasedSecurityStatus}
$VBS = (Get-CimInstance -ClassName Win32_DeviceGuard -Namespace root\Microsoft\Windows\DeviceGuard).VirtualizationBasedSecurityStatus

#*****Get Hostname*****
$FQDN = [System.Net.Dns]::GetHostByName($env:computerName).HostName
$FQDN = $env:ComputerName + "." + $env:UserDNSDomain

#*****Add column to output*****
$FQDN = [System.Net.Dns]::GetHostByName($env:computerName).HostName
$Test = "Need more data"
$Test | select @{Name="Hostname";Expression={hostname}}, @{Name="FQDN";Expression={$FQDN}}, length

#*****Rename an array column header*****
$data = [PSCustomObject]@{'ServerName'="Hello"}
$data | Select @{Name="NewName";Expression={$_.ServerName}}

#*****Certificate search*****
get-childitem -recurse Cert:\ | where {$_.Subject -like "*Silk Performer*"} | Select *

#*****Try Catch write error*****
try {
    #Something that fails
} catch {
    Write-Host $_
}

#*****For Loop*****
for (($i = 0); ($i -lt 6); ($i++)) {
    write-host $i
}

#*****Launch elevated window*****
$script:args = "& '" + $myinvocation.mycommand.definition + "'"
if(!([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")){ Start-Process powershell.exe "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" `"$args`"" -Verb RunAs}

#*****Array sort and return top item*****
$CertList | sort NotAfter -descending | select -first 1

#*****Convert date or time*****
$LatestExpirationDate.ToString("MM/dd/yyyy hh:mm")

#*****Math Round AND how to use Continue in a While or Foreach loop*****
$i = 0
while (1 -eq 1) {
    $i++
    if ($i / 2 -eq [math]::Round($i / 2)) {
        continue
    } else {
        write-host $i
    }
}

#*****Get a DC from domain*****
$dc = Get-ADDomainController -DomainName dev-test.dla.mil -Discover -NextClosestSite
Get-ADUser -Server $dc.HostName[0] -identity DMR0123M

#*****Test connectivity.  If fails then go onto the next system*****
if (-not (Resolve-DnsName $ServerName -ErrorAction SilentlyContinue) -or -not ((Test-NetConnection -ComputerName $ServerName -ErrorAction SilentlyContinue).PingSucceeded)) { #Check if server will ping before continuing
    write-host "Either can't resolve DNS or ping $ServerName"
    continue
}

#*****Get domain names*****
$env:UserDNSDomain #Gets DIR.AD.DLA.MIL
$env:UserDomain #Gets DIR

#*****PSSession with SSL and SkipCNCheck*****
$sessionOptions = New-PSSessionOption -SkipCNCheck
$Session = New-PSSession $PServerName -SessionOption $sessionOptions -UseSSL -ErrorAction SilentlyContinue

#*****Get Error Information after a Try / Catch failure*****
$Error[0].Exception.GetType().FullName

#*****Use the full error name to catch only those errors*****
try {Confirm-SecureBootUEFI}
catch [Microsoft.Secureboot.Commands.StatusException] {
"There was an error while checking, manual check necessary" | Out-File -Append $Outfile}

#*****Use to get left, mid, or right of a string where 0 is starting character and 5 is number of characters*****
$variable.SubString(0,5) #For left or mid
$variable.SubString($variable.length - 5, 5) #for right

#*****DoEvents*****
[System.Windows.Forms.Application]::DoEvents()

#*****Convert Time Difference to normal Time Format*****
Write-host ("{0:hh\:mm\:ss}" -f $TimeDiff)

#*****$Error can be used for any error*****
new-pssession -ComputerName Nonsense
$Error

#*****SCCM commands*****
Invoke-WMIMethod -namespace root\ccm -Class sms_client -Name TriggerSchedule "{00000000-0000-0000-0000-000000000021}" | Out-Null #Machine policy
Invoke-WMIMethod -namespace root\ccm -Class sms_client -Name TriggerSchedule "{00000000-0000-0000-0000-000000000113}" | Out-Null #Update scan cycle

#*****Output each character and the ASCII code*****
[char[]]"Save me" | %{ "$_ -> " + [int]$_ }

#*****Find a particular string in an array*****
$TestArray -eq "Yes" #This might be the best way to search an array
$MatchData = (0..($XCCDFData.Count-1)) | where {$XCCDFData.Version[$_] -eq "V-225012"} #This outputs the array line number
$LogData | Where {$_.Message -like "*SCC Tool install check*"} #This outputs whether it is found
$LogData.Message -like "*SCC Tool install check*" #This also outputs whether it is found

#*****Gather a value in multiple lines of an array with split*****
$CKLFileList | ForEach { ($_ -split "\\") | Select -Last 1 } #This will collect the file name from a folder path in an array

#*****Using to pass parameters*****
Invoke-Command -ComputerName ServerName -ScriptBlock { Get-ChildItem $Using:VariableWeWant }

#*****Expandable array*****
$array = @()
$obj = New-Object PSObject
$obj | Add-Member -MemberType NoteProperty -Name “ComputerName” -Value $computername
$obj | Add-Member -MemberType NoteProperty -Name “DisplayName” -Value $($thisSubKey.GetValue(“DisplayName”))
$array += $obj

#*****Format Timespan*****
(New-TimeSpan -Start $JobStartTime -End (Get-Date)).ToString("h\:mm\:ss")

#*****Get short date*****
(Get-Date).ToShortDateString()

#*****Split Notes*****
$Message.Split("$/(/)") #Will split by multiple characters!  $ and ( and ) will each be used to split
$CodeSegment -split "WriteOutput """ #This version of split will only split by one string, not multiple, and works better overall

#*****IndexOf*****
$GoldenChecklistFile.Substring(0,$GoldenChecklistFile.IndexOf("_STIG")) #IndexOf will report the character position where the start of the string provided is located

#*****Modify a SIMPLE array in a ForEach, this does NOT apply to LIST Arrays*****
$Array = 1,2
$Array = $Array | ForEach {
    $_ + 1
}
$Array

#*****Modify a LIST array in a ForEach.  I really have looked for better options, but this is all there is!*****
ForEach ($ActiveJob in $ActiveJobList) {
    If ($ActiveJob.ServerName -eq "Server1") {
        $ActiveJob.ServerName = "Server5"
    }
}

#*****Have a function call itself*****
Function CountToTen {
    If ($Script:Count -lt 10) {
        $Script:Count++
        Write-Host $Script:Count
        CountToTen
    }
}
$Count = 0
CountToTen

#*****Adds a line break using the Join command*****
Write-Host ($DataForThisRuleTitle.ServerName -join "`n")

#*****Remove a line break using the Join command*****
($POC1,$POC2,$POC3 | Where {$_ -ne ""} | Sort-Object) -join ''

#*****Search AD for e-mail address*****
Get-ADUser -Filter { Emailaddress -eq "michael.p.barnes@dla.mil" }

#*****Pointer or Reference Variables*****
$VariableName = "TestPointer"
Set-Variable -Name "$VariableName" -Value 1
$TestPointer

#*****Compare two arrays*****
$FilesNotFoundInGoldenArray = (Compare-Object $AllFilesArray $AllGoldenFilesArray | Where {$_.SideIndicator -eq "<="}).InputObject

#*****Wait for Write-Host to Output*****
#Piping to Out-Default will make it so PowerShell waits for a command to finish prior to moving onto the next line.  Without it the Get-PhysicalDisk output here wouldn't get displayed
Write-Host "List of disks:"
Get-PhysicalDisk | Out-Default
Read-Host "Please choose number from disks above"

#*****Get a list of values from a registry key*****
#You have to start one key prior to the one you are actually trying to get information for (WHICH IS DUMB) but this does work
$RegOutput = (gci -path "HKLM:\Software\Policies\Microsoft\Edge" | Where { $_.Name -like "*AutoplayAllowList" }).Property
$RegOutput | ForEach { #This portion outputs whatever is in the registry values
    Get-ItemPropertyValue -Path "HKLM:\Software\Policies\Microsoft\Edge\AutoplayAllowlist" -Name $_
}

#*****Compare two multi-dimensional arrays*****
$RegACLMatches = $DesiredACLs | % { #First need to gather all of the things that match
    $Permission = $_;
    $RegACLs | ? { $_ -like $($Permission) };
}

$RegACLNonMatches = $RegACLs | ? { $RegACLMatches -notcontains $_ } #From there, figure out which items didn't match

#*****Check if script is running from ISE*****
If ($psISE) { }

#*****Output unique items from a list along with a count*****
$FullPatchList.Name | Group-Object | Select Name, Count

#*****Combine two arrays that have some duplicate server names but different dates and output only the latest date for each server*****
$CombinedRecords = $ServerLastSuccessList + $ServerLastSuccessListUpdated #Combine the arrays
$GroupedRecords = $CombinedRecords | Group ServerName #Group by ServerName since we just want one of each server
$FinalOutput = ForEach ($GroupRecord in $GroupedRecords) { #Sort by Date then select just the top one for each grouped item
    $GroupRecord.Group | Sort -Property SuccessDate -Descending | Select -First 1
}

#*****Progress bar*****
$TotalEmailAddr = $EmailAddrList.Count
$CurrentEmailAddr = 1
Write-Progress -Activity "Checking email address $EmailAddr" -Status "$CurrentEmailAddr of $TotalEmailAddr" -PercentComplete ($CurrentEmailAddr / $TotalEmailAddr * 100)
Write-Progress -Activity "Checking email address $EmailAddr" -Completed

#*****Software Center Test*****
Get-CimInstance -ComputerName "beasvwpp005.dir.ad.dla.mil" -ClassName "CCM_SoftwareUpdate" -Filter "ComplianceState = 0" -NameSpace "ROOT\ccm\ClientSDK"
Get-CimInstance -ComputerName "beasvwpp005.dir.ad.dla.mil" -ClassName "CCM_Application" -Filter "InstallState <> 'Installed'" -NameSpace "ROOT\ccm\ClientSDK"

#*****Registry Key Commands*****
(Get-ItemProperty "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\RemoteRegistry").DisableIdleStop
Set-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\RemoteRegistry" -Name DisableIdleStop -Value 1
New-ItemProperty -Path "HKLM:\Software\Microsoft\Windows NT\CurrentVersion\RemoteRegistry" -Name DisableIdleStop -Value 1 -PropertyType DWord -Force | Out-Null

#*****Get data from List array based on column number of find the number of total columns*****
$DataItem[0].psobject.Properties.Value[0]
$DataItem[0].psobject.Properties.Value.Count

#*****Get name of a List array column header*****
$DataItem[0].psobject.Properties.Name[0]

#*****Sort by one column ascending and the other descending*****
$SectionData | Sort-Object -Property @{expression="LastSuccessDate";Descending=$true}, @{expression="ServerName";Descending=$false}

#*****Test if a registry value exists*****
If ((Get-ItemProperty -Path "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\operationalaccreditation").PSObject.Properties.Name -contains "DisplayName") {
    Write-Host "Yay"
}

#*****Check if something is NOT a number*****
$Test = "5A"
If ($Test -notmatch '^[0-9]+$') { Write-Host "Not a number" }

#*****Get list of users in group that includes SIDs*****
$GroupOutput = net localgroup "Remote Desktop Users"
$StartLine = $GroupOutput.IndexOf("-------------------------------------------------------------------------------") + 1
$EndLine = $GroupOutput.IndexOf("The command completed successfully.")
$UsersList = @()
For (($LineCount = $StartLine); ($LineCount -lt $EndLine); ($LineCount++)) {
    $UsersList += $GroupOutput[$LineCount]
}

#*****Convert array ($UnexpectedRebootList) to string ($UnexpectedReboots) for outputting to CSV*****
ForEach ($UnexpectedReboot in $UnexpectedRebootList) {
    $UnexpectedReboots += "$($UnexpectedReboot.TimeCreated.ToString("MM/dd/yy hh:mm"))`n"
}
If ($UnexpectedReboots -ne $null) { $UnexpectedReboots = $UnexpectedReboots.Trim() } #Removes the last line break

#*****Convert string to SHA Hash*****
$hasher = [System.Security.Cryptography.HashAlgorithm]::Create('sha256')
$hash = $hasher.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($DAASVWPP062))
$hashString = [System.BitConverter]::ToString($hash)
$hashString.Replace('-', '')

Write-Host "Checking for Administrator permission..."
If (-NOT ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Warning "Insufficient permissions to run this script. Open the PowerShell console as administrator and run this script again."
    Break
    #Also this can be done
    if ([int](Get-CimInstance -Class Win32_OperatingSystem | Select-Object -ExpandProperty BuildNumber) -ge 6000) {
     $CommandLine = "-File $($MyInvocation.MyCommand.Source)" + $MyInvocation.MyCommand.Path + "`" " + $MyInvocation.UnboundArguments
     Start-Process -FilePath (Get-Process -Name powershell_ise).path -Verb Runas -ArgumentList $CommandLine 
     Exit
    }
} Else {
    Write-Host "Running as administrator — continuing execution..." -ForegroundColor Green
}

#*****Alternative check for admin*****
($env:UserName).Length -eq 8

#*****Force run as administrator?*****
#Requires -RunAsAdministrator

#*****Run as smartcard*****
$runAsCommmand = "runas /smartcard `"powershell.exe -File `"$($script:MyInvocation.MyCommand.Path)`"`""
Start-Process cmd.exe -ArgumentList "/c $runAsCommmand" -Wait -ErrorAction Stop

#*****Regex to identify when two lines of text are used in the same string (ie COMPUTERNAME\COMPUTERNAME)*****
#.*? captures any text before the backslash and \1 matches the text captured in the first group
$ACASData | Where-Object { $_.'NetBIOS Name' -match '^(.*?)\\(\1)$' }

#*****Search an array for MULTIPLE values at the same time (ie AZC and CTX in this case)*****
$ACASData | Where { $_.'NetBIOS Name' -match "(AZC|CTX)" }

#*****Use match but with begins or ends with or even exact*****
@("1","22","313","051","23","3131") | Where { $_ -match "^1|2$|^313$|5" } #This line is saying that it wants things in the array that start with 1, end with 2, are exactly 313, or contains 5

#*****Excel filter multiple criteria*****
#Used the number 2 for XlOr or 1 for XlAnd
$WorkSheet.UsedRange.AutoFilter($NetBIOSNameColNum, "*AZC*", 2, "*CTX*") | Out-Null

#*****Excel clear filter*****
$WorkSheetFinalOutput.AutoFilter.ShowAllData() #This leaves the filter enabled but clears it
$WorkSheetFinalOutput.AutoFilterMode = $false #This disables the filter

#*****Convert standard date into Excel numerical date*****
$ExcelBaseDate = Get-Date -Year 1900 -Month 1 -Day 1
((Get-Date) - $ExcelBaseDate).Days

#*****Using xlUp to find last row in Excel*****
$xlUp = -4162 #The number -4162 is used in place of "xlUp" which is a VBA command
$WorkSheetFinalOutput.Cells($WorkSheetFinalOutput.rows.Count, 1).End($xlUp).Row

#*****Loop through each row in Taskord Master List****
:Outer For ($CurrentRow = 2; $CurrentRow -le 5; $CurrentRow++) {
    :Inner For ($CurrentRow2 = 2; $CurrentRow2 -le 5; $CurrentRow2++) {
        For ($CurrentRow3 = 2; $CurrentRow3 -le 5; $CurrentRow3++) {
            Break Outer
        }
    }
    Write-Host $CurrentRow
}

#*****Calculating a percentage*****
(5/21).tostring("P")

#*****Standard Hash*****
$EventFilter = @{
    LogName = "System"
    ID = 12,1074
    StartTime = [datetime]::Now.AddDays($PDaysToSearch)
}

#*****Hash array of arrays*****
$SeasonArray = @("Summer","Spring","Winter","Fall")
$WeatherArray = @("Hot","Mild","Cold","Crisp")
$RotationArray = @("Solstice","Equinox","Solstice","Equinox")
$Seasons = @{"Name" = $SeasonArray;"Weather" = $WeatherArray;"Rotation" = $RotationArray}
$Season = "Summer"
$FindValue = [array]::IndexOf($Seasons.Name,$Season)
Write-Host "$Season is $($Seasons.Weather[$FindValue]) and $($Seasons.Rotation[$FindValue])"

#*****Simple multidimensional array*****
$allRecords = @()
$allRecords += @{value="alkane1";text="solutions1";additional="this is some additional data for my record";enabled=$true}		
$allRecords += @{value="alkane2";text="solutions2";additional="this is some additional data for my record";enabled=$false}

#*****Send email*****
$smtpServer = "164.87.32.17"
$senderEmail = "No-Reply_Duplicate-IP-Address-PrintReports@dla.mil"
$recipientEmail = @("joseph.nicklous@dla.mil; carlton.parker.ctr@dla.mil; kenneth.smith.ctr@dla.mil")
$CCEmail = @("john.siegrist@dla.mil; casey.wyckoff@dla.mil; michael.d.russcher@dla.mil")
$subject = "Duplicate IP Address Report."
$body = "Duplicate IP Address on Print Server - Please Correct"
$attachment = "C:\Temp\Test.txt"
Send-MailMessage -To $recipientEmail -CC $CCEmail -From $senderEmail -Subject $subject -Body $body -SmtpServer $smtpServer -Port 25 -Attachments $attachment

#*****Port Communication Test*****
$TestCon9100 = New-Object Net.Sockets.TcpClient
Try {
    $TestCon9100.Connect("$PrinterIP", 9100)
} Catch {}
$TestCon9100.Close()

#*****Clear Visual Studio Code PowerShell Command History*****
#Delete the file in this folder path
(Get-PSReadlineOption).HistorySavePath

#*****Tee-Object - this can write to console and output at the same time*****
"Hello" | Tee-Object -FilePath "C:\temp\whatever.txt"

#*****Force a Try / Catch Failure*****
#Used -ErrorAction Stop instead of -ErrorAction SilentlyContinue

#*****Filter one array based on the contents of another array
$ExcelDataArray[$WorkSheetSelection] | ?{$IPAddrList -contains $_."IP Address"}

#*****Export from Excel and import as CSV*****
$excel = New-Object -ComObject Excel.Application
$workbook = $excel.Workbooks.Open('C:\temp\file.xlsx')
$workbook.SaveAs('C:\temp\file.csv', 6)
$workbook.Close($false)
$excel.Quit()
$csvData = Import-Csv -Path 'C:\temp\file.csv'

#*****Run script with a batch file*****
@ECHO OFF
Powershell.exe -executionpolicy bypass -File "\\orgwest\J6_INFO_OPS\J64\J64C\WinAdmin\Cloud\Printer\PrinterReports\Maint-Account\AzurePrintServerReportTool1.7.ps1"

#*****PowerShell Auto Format*****
Get-Process | Format-Table -Property Name,Path,WorkingSet -AutoSize -Wrap

#*****ARS Quest Powershell*****
#NOTE: This can only be used from Admin VDI, not servers or local workstations for some reason
Add-PSSnapin Quest.ActiveRoles.ADManagement
$QuestServer = "dadsvwpp001.dir.ad.dla.mil"
Connect-QADService -Proxy -Service $QuestServer
#*****Use commands like “Get-QADUser” or “Set-QADComputer”
Get-QADComputer to pull attributes

#*****Tail in Powershell*****
gc [file name] -tail 20 -wait

#*****Store from Excel into a two object array*****
$TestArray = $sheet.Cells[$StartRow,$StartColumn,$EndRow,$EndColumn].Value

#*****Get Encryption Information*****
$VM = get-vm NCDBVWNP050
$VM | Get-HardDisk | Select Parent,Name,Encrypted
($VM | Get-SpbmEntityConfiguration).StoragePolicy
$VM.ExtensionData.Config.KeyId

#*****Message box*****
[System.Windows.MessageBox]::Show('Would  you like to play a game?','Game input','YesNoCancel','Error')

#*****Modal message box*****
$PreFilledOutResponse = [Microsoft.VisualBasic.Interaction]::MsgBox('Are the supervisor and owner fields pre-filled out?', 'YesNo,SystemModal')

#*****Prompt for dialog box*****
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
    InitialDirectory = "c:\temp"
    Filter = "(*.ps1) | *.ps1"
}
$FileBrowser.ShowDialog() | Out-Null
$ScriptToSignName = $FileBrowser.FileName

#*****Folder dialog box*****
$FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{ 
    SelectedPath = "C:\Temp"
    Description = "Select the ImportExcel folder"
    RootFolder = "MyComputer"
}
If ($FolderBrowser.ShowDialog() -eq "OK") {
    $FolderPath = $FolderBrowser.SelectedPath
}

#*****Convert from JSON to XML and back to JSON*****
$xml = Get-Content "$OSChecklist" | ConvertFrom-Json
$xml | ConvertTo-Json -Depth 99 | Out-File $OSChecklist -Encoding ascii

#*****Call another script*****
Invoke-Expression -Command "& '$FolderPathToWizardScript\Finding Scripts\Shared - $SharedScriptName'"

#*****Find what can be run from an object you're unfamiliar with*****
$ObjFSO = New-Object -ComObject Scripting.FileSystemObject
$ObjFSO | get-member

#*****Reboot an ESX host and track it's progress*****
#Sees the Signed Cert Implementation code for this

#*****Reference a list column with a variable*****
$ColumnName = "Host Name"
$AzureHostInfoList[0].$ColumnName

#*****Start a process in PowerShell 7*****
$PS7Path = "C:\Program Files\PowerShell\7\pwsh.exe"
$ScriptPath = "EnablePS7Remoting.ps1"
Start-Process -FilePath $PS7Path -ArgumentList $ScriptPath -Wait

#*****Configure PowerShell 7 remoting*****
#First need to log onto remote system OR use Start-Process to launch a script to execute this
Enable-PSRemoting

#*****Outlook email object*****
$objOutlook = New-Object -comObject Outlook.Application
$Email = $objOutlook.CreateItem(0)
$Email.To = "joseph.nicklous@dla.mil; carlton.parker.ctr@dla.mil; kenneth.smith.ctr@dla.mil"
$Email.CC = "john.siegrist@dla.mil; casey.wyckoff@dla.mil; michael.d.russcher@dla.mil"
$Email.Subject = "vSphere STIG Report - $(Get-Date -Format MM/dd/yy)"
$Email.HTMLBody = $EmailHTMLBody
$Email.save()
$Inspector = $Email.GetInspector
$Inspector.Display()

#*****SMTP email****
Send-MailMessage -To "michael.d.russcher@dla.mil" -From "michael.d.russcher@dla.mil" -Subject "vSphere STIG Report - $(Get-Date -Format MM/dd/yy)" -Body $EmailHTMLBody -BodyAsHtml -SmtpServer "164.87.32.17" -Port 25

#*****Get-View****
$ServiceInstance = Get-View ServiceInstance #First store the base level of the view
$SettingsView = Get-View ($ServiceInstance).Content.Setting #Then request a view of a deeper object
$SettingsView.Setting | Where { $_.Key -like "config.vpxd*" }

#*****Invoke-SSHCommand*****
(Invoke-SSHCommand -SessionId 0 -Command { /opt/vmware/bin/sso-config.sh -print_logon_banner }).Output
(Invoke-SSHCommand -SessionId 0 -Command $VCodeObjectSTIGData.Check_Param).Output

#*****Default module path*****
$env:PSModulePath

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBRxJ7iq+m4NzwL
# Ua8oX6++KleYIcXMMDIqCL0cz6fsTKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBzoINuqzvOoJeNm0CA2A5qiNco32sQBQGePoHORUwXozANBgkq
# hkiG9w0BAQEFAASCAQBx8gEBJjW17hKgOz1OaxzEEBG6MrqQg7VMe0+U4j3+5D3/
# Z1q4rPuBApbk2oTnrC7Kfh7GRA74Q0lbHY3R28ycDARVZnWhF7LQGYQ/VqugSTNl
# xmq5B15cbsiV39HfdoJUF6F87klvPlNHZqag51Ctm3xgGW5pWI4+gJAc0neMWBKK
# RtaqW9mzP0AyTJcYRnLSyYZ7j1L8p5qkrsX8VRYrEHftvgABwCha3U7WEKOEUL4+
# tD/bxdGhD1y1gN5K4k/E6onij5WznlH5nAD3lX8vSSCMFjuGeE2S4RpKZuB+UYax
# tTXq715GfJ8gy2Owv90sLLT58sWFFl5ZuYniJBcu
# SIG # End signature block
