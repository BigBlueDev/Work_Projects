#PURPOSE: Provide a GUI for inputting information prior to kicking off an initial STIG scan or the mitigation of systems

#CHANGELOG
#Version 1.0 - 03/25/24 - MDR - Initial version
#Version 1.01 - 03/26/24 - MDR - Minor fixes for vCenter connection and message box display
#Version 1.02 - 03/26/24 - MDR - Added tabs to the main form
#Version 1.03 - 04/12/24 - MDR - Adding a place to input a user name for logins, changing so the ESX field can now also be Photon or anything else, and other fixes
#Version 1.04 - 04/15/24 - MDR - Added ability to copy multiple checklists for a STIG and pick the correct checklist for which version of Photon is being used
#Version 1.05 - 10/10/24 - MDR - Add POAM capabilities
#Version 1.06 - 10/17/24 - MDR - Fix POAM issue and make it so temp folders are made for each user
#Version 1.07 - 11/18/24 - MDR - Check whether SSH is started prior to script starting it.  If it is started already, then don't have the script start it or stop it later on
#Version 1.08 - 01/27/25 - MDR - Added a line to ensure VCodesWithFindings is always an array and never a string

#USE THIS FOR TESTING CHECK SCRIPTS
#$Script:STIGInfo = $STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }
#$CurrentSystemName = "TRISV0NP002.ics.dla.mil"
#$Script:ChecklistFilePath = "$($STIGInfo.TempPath)\$($ListBoxSTIGToRun.SelectedItem) STIG - $CurrentSystemName-$CurrDate.ckl"
#$Script:LocalBlankChecklistPath = "$($STIGInfo.TempPath)\$($BlankChecklist.Name)"
#$BlankChecklist | ForEach { Copy-Item $_.FullName "$($STIGInfo.TempPath)\$($_.Name)" }
#Copy-Item $LocalBlankChecklistPath $ChecklistFilePath
#$Script:STIGParams = Import-Excel $STIGInfo.ParmetersPath -WorksheetName *
#$SecureSystemPassword = ConvertTo-SecureString $MaskedTextBoxSystemPassword.Text -AsPlainText -Force
#$Global:SystemCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecureSystemPassword )
#$SSHConnection = New-SSHSession -HostName $CurrentSystemName -Credential $SystemCreds -AcceptKey -Force

<#
-----------Matts Notes-----------
1. Update resource files to central location and move code calling them to variables
2. need to export CKL files to format CLKB so new reader can open it
#>

#TYPES OF OBJECTS THAT CAN BE PLACED IN A GUI:

#CheckBox — used to list some options and select them before running script;
#RadioButton — lists some text options and allows to select only one of them;
#TextBox — user can write some text. It can be used to get the value of the PowerShell script parameter;
#CheckedListBox — shows a list of items;
#DataGridView — allows to view some tabular data;
#GroupBox — allows viewing and grouping a set of controls together;
#ListBox — can store several text items;
#TabControl — allows you to split your form into different areas (tabs);
#ListView — displays a list of items with text and (optionally) an icon;
#TreeView — hierarchical objects view;
#DateTimePicker — allows to select date and time;
#TrackBar — scrollable control;
#PictureBox — allows to show a picture on the form;
#ProgressBar — indicates the operation progress;
#HScrollBar — horizontal scroll bar;
#VScrollBar — vertical scroll bar;
#ContextMenu — right-click menus;
#Menu — top menu in your form.

#Store today's date
$CurrDate = Get-Date -Format "MMddyyyy"
#When performing mitigations, store a list of status changes that get made as the script runs
$Global:ListOfStatusUpdates = New-Object System.Collections.Generic.List[System.Object]
#List of STIG checks that were NOT on the Parameters list
$Global:NoSTIGParamList = @()
#Path to where all of the STIG scripts are stored
$FolderPathToSTIGScript = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR"

Clear

#Verify that the Import-Excel module exists
$VerifyImportExcelModule = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If Import-Excel doesn't exist then explain where to get it from and exit the script
If (!($VerifyImportExcelModule)) {
    Write-Host "`nImport-Excel module not found" -ForegroundColor Red
    #Version 1.04 - Updated this folder path
    Write-Host "`nImport-Excel can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\ImportExcel"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Version 1.04 - Verify PoshSSH module exists
$VerifyPoshSSHModule = Get-Command New-SSHSession -ErrorAction SilentlyContinue

#If Import-Excel doesn't exist then explain where to get it from and exit the script
If (!($VerifyPoshSSHModule)) {
    Write-Host "`nPoshSSH module not found" -ForegroundColor Red
    #Version 1.04 - Updated this folder path
    Write-Host "`nPoshSSH can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\Posh-SSH"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Set the command for allowing multiple connections to vCenter
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null
#Set parameter for ignoring invalid certificates
Set-PowerCLIConfiguration -InvalidCertificateAction Ignore -Confirm:$false | Out-Null

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#Get info for each type of STIG (ie info on the Parameters and script locations for VM, ESX, and Photon OS STIGs)
$STIGScriptInfo = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\STIG_Script_Info.csv"

#Add the Forms assembly that will allow for the creation of a GUI
Add-Type -AssemblyName System.Windows.Forms
#Add message box capabilities
Add-Type -AssemblyName PresentationCore,PresentationFramework
#Version 1.01 - Added this to support message box
[void][System.Windows.Forms.Application]::EnableVisualStyles()

###CREATE THE MAIN FORM###

#Create variables to define the Left value for different columns in the form
$Column1LeftValue = 10
$Column1Width = 175
$Column2LeftValue = 250
$Column2Width = 500

#Create an object for the primary form
$MainForm = New-Object System.Windows.Forms.Form
#Give a title to the form
$MainForm.Text ='STIG GUI - Version 1.07'
#Set the width and height
$MainForm.Width = 900
$MainForm.Height = 610

$FormTabControl = New-object System.Windows.Forms.TabControl
$FormTabControl.Size = "900,610"
$FormTabControl.Location = "0,0"
$TabMain = New-object System.Windows.Forms.Tabpage
$TabMain.DataBindings.DefaultDataSourceUpdateMode = 0
$TabMain.Name = "TabMain"
$TabMain.Text = "Main"
$TabMitigate = New-object System.Windows.Forms.Tabpage
$TabMitigate.DataBindings.DefaultDataSourceUpdateMode = 0
$TabMitigate.Name = "TabMitigate"
$TabMitigate.Text = "Mitigate"

#Add Controls
$MainForm.Controls.Add($FormTabControl)
$FormTabControl.Controls.Add($TabMain)
$FormTabControl.Controls.Add($TabMitigate)
$MainForm.Add_Shown({$MainForm.Activate()})

#Create variables for the CreateObject function which will contain information on all objects that get created in the GUI
$ObjectArray = @()
$ObjectCount = 0

#Creates all objects in the form
Function CreateObject {
    Param ( $ObjectType, $Text, $XValue, $YValue, $Width, $Height, $Visible, $TabName, $Bold )

    #Determine what type of object is being created
    If ($ObjectType -eq "Label") {
        $Script:ObjectArray += New-Object System.Windows.Forms.Label
        If ($Bold -ne "Standard") {
            $Script:ObjectArray[$ObjectCount].Font = New-Object System.Drawing.Font('Ariel',8,[System.Drawing.FontStyle]::Bold)
        }
    } ElseIf ($ObjectType -eq "TextBox") {
        $Script:ObjectArray += New-Object System.Windows.Forms.TextBox
    } ElseIf ($ObjectType -eq "ListBox") {
        $Script:ObjectArray += New-Object System.Windows.Forms.ListBox
    } ElseIf ($ObjectType -eq "Button") {
        $Script:ObjectArray += New-Object System.Windows.Forms.Button
    } ElseIf ($ObjectType -eq "ProgressBar") {
        $Script:ObjectArray += New-Object System.Windows.Forms.ProgressBar
    } ElseIf ($ObjectType -eq "MaskedTextBox") {
        $Script:ObjectArray += New-Object System.Windows.Forms.MaskedTextBox
        $Script:ObjectArray[$ObjectCount].PasswordChar = '*'
    }

    #Write the text to the object
    $Script:ObjectArray[$ObjectCount].Text = $Text
    #Set the location of the object
    $Script:ObjectArray[$ObjectCount].Location = New-Object System.Drawing.Point($XValue,$YValue)

    #Use $True to AutoSize the object
    If ($Width -eq "AutoSizeWidth") {
        $Script:ObjectArray[$ObjectCount].AutoSize = $true
    } Else { #Otherwise if a width is provided
        $Script:ObjectArray[$ObjectCount].Width = $Width
    }

    #If a value for Height is provided then set height
    If ($Height -ne "DefaultHeight") {
        $Script:ObjectArray[$ObjectCount].Height = $Height
    }

    #If a value for Visible is Invisible
    If ($Visible -eq "NotVisible") {
        $Script:ObjectArray[$ObjectCount].Visible = $false
    }

    If ($TabName -ne "Mitigate") {
        $TabMain.Controls.Add($ObjectArray[$ObjectCount])
    } Else {
        $TabMitigate.Controls.Add($ObjectArray[$ObjectCount])
    }

    #Return the current object.  This is useful when something like .Add_Click() needs to be done with the object.  Otherwise use " | Out-Null" to ignore this info
    $ObjectArray[$ObjectCount]
    
    #Increment the object counter
    $Script:ObjectCount++
}

###CREATE COLUMN 1 ITEMS###

###CREATE LABEL FOR STIG Type###
CreateObject "Label" "STIG Type" $Column1LeftValue 10 "AutoSizeWidth" "DefaultHeight" "Visible" | Out-Null

###CREATE LIST BOX FOR STIG Type of Check or Mitigate###
$ListBoxSTIGType = CreateObject "ListBox" "" $Column1LeftValue 30 $Column1Width 40 "Visible"
#Provide options for Check and Mitigate
$ListBoxSTIGType.Items.AddRange(@("Check","Mitigate"))

#Run this when either Check or Mitigate gets selected
$ListBoxSTIGType.Add_Click({
    If ($ListBoxSTIGToRun.Items.Count -eq 0) {
        #Provide STIG choices
        $ListBoxSTIGToRun.Items.AddRange(@("VM","ESX","PhotonOS"))
    }

    If ($ListBoxSTIGType.SelectedItem -eq "Check") {
        #Set anything Check related to visible
        $LabelSystemToScan.Visible = $true
        $ListBoxSystemToScan.Visible = $true

        #Set anything Mitigate related to invisible
        $LabelCompletedChecklistPath.Visible = $false
        $TextBoxCompletedChecklistPath.Visible = $false
        $ButtonCompletedChecklistPath.Visible = $false
    } ElseIf ($ListBoxSTIGType.SelectedItem -eq "Mitigate") {
        #Set anything Mitigate related to visible
        $LabelCompletedChecklistPath.Visible = $true
        $TextBoxCompletedChecklistPath.Visible = $true
        $ButtonCompletedChecklistPath.Visible = $true

        #Set anything Check related to invisible
        $LabelSystemToScan.Visible = $false
        $ListBoxSystemToScan.Visible = $false
        $LabelSingleOrList.Visible = $false
        $TextBoxSingleOrList.Visible = $false
        $ButtonListPath.Visible = $false
    }
})

###CREATE LABEL FOR STIG Type###
CreateObject "Label" "STIG to run" $Column1LeftValue 70 "AutoSizeWidth" "DefaultHeight" "Visible" | Out-Null

###CREATE LIST BOX FOR STIG to Run###
$ListBoxSTIGToRun = CreateObject "ListBox" "STIG to Run" $Column1LeftValue 90 $Column1Width 100 "Visible"
#Clear the list box
$ListBoxSTIGToRun.Items.Clear()

#Each time a STIG type is run then populate the System to Scan options
$ListBoxSTIGToRun.Add_Click({
    If ($ListBoxSTIGToRun.SelectedItem -eq "ESX") {
        $LabelSystemUser.Text = "ESX User"
        $TextBoxSystemUser.Text = "root"
        $LabelSystemPassword.Text = "ESX Password"
    } ElseIf ($ListBoxSTIGToRun.SelectedItem -eq "PhotonOS") {
        $LabelSystemUser.Text = "PhotonOS User"
        $TextBoxSystemUser.Text = "root"
        $LabelSystemPassword.Text = "PhotonOS Password"
    }

    If ($ListBoxSTIGType.SelectedItem -eq "Check") {
        #Clear System to Scan list
        $ListBoxSystemToScan.Items.Clear()

        $SystemScanOptions = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).ScanOptions

        #Provide options which types of systems can be scanned
        $ListBoxSystemToScan.Items.AddRange(@($SystemScanOptions.Split(",")))

        $TextBoxSTIGScriptPath.Text = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).CheckScriptPath
    } ElseIf ($ListBoxSTIGType.SelectedItem -eq "Mitigate") {
        $TextBoxCompletedChecklistPath.Text = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).NetworkPath
        $TextBoxSTIGScriptPath.Text = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).MitigateScriptPath
    }

    $Script:BlankChecklist = Get-ChildItem ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).BlankChecklistPath | Select Name, FullName

    $TextBoxSTIGParameterPath.Text = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).ParmetersPath
    $TextBoxSTIGReportPath.Text = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).ReportPath

    #Version 1.04 - If there is just one checklist
    If ($BlankChecklist.Count -eq 1) {
        $TextBoxSTIGBlankChecklistPath.Text = $BlankChecklist.FullName
    } Else {
        $TextBoxSTIGBlankChecklistPath.Text = "Multiple possibilities"
    }

    $LabelvCenterServers.Visible = $true
    $ListBoxvCenterServers.Visible = $true
})

###CREATE LABEL FOR Systems to Scan - CHECK STIGs ONLY - NOT VISIBLE AT FIRST###
$LabelSystemToScan = CreateObject "Label" "Systems to scan" $Column1LeftValue 190 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE LIST BOX FOR System to Scan - CHECK STIGs ONLY - NOT VISIBLE AT FIRST###
$ListBoxSystemToScan = CreateObject "ListBox" "Systems to Scan" $Column1LeftValue 210 $Column1Width 70 "NotVisible"

#Each time a System to Scan is selected - CHECK STIGs ONLY
$ListBoxSystemToScan.Add_Click({
    #Set default visibility
    $LabelSingleOrList.Visible = $true
    $TextBoxSingleOrList.Visible = $true
    $ButtonListPath.Visible = $false

    If ($ListBoxSystemToScan.SelectedItem -eq "Single") {
        $LabelSingleOrList.Text = "Enter $($ListBoxSystemToScan.SelectedItem) System Name"
    } ElseIf ($ListBoxSystemToScan.SelectedItem -eq "List") {
        $LabelSingleOrList.Text = "Path to List"
        $ButtonListPath.Visible = $true
    } Else { #If this isn't a Single / List
        #Set both to invisible
        $LabelSingleOrList.Visible = $false
        $TextBoxSingleOrList.Visible = $false
    }
})

###CREATE LABEL FOR Single System or List - CHECK STIGs ONLY - NOT VISIBLE AT FIRST###
$LabelSingleOrList = CreateObject "Label" "" $Column1LeftValue 290 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE TEXT BOX FOR Single System or List - CHECK STIGs ONLY - NOT VISIBLE AT FIRST###
$TextBoxSingleOrList = CreateObject "TextBox" "" $Column1LeftValue 310 $Column1Width "DefaultHeight" "NotVisible"

###CREATE BUTTON FOR Single System or List - CHECK STIGs ONLY - NOT VISIBLE AT FIRST###
$ButtonListPath = CreateObject "Button" "Browse for List" $Column1LeftValue 330 $Column1Width "DefaultHeight" "NotVisible"

#Browse for list of systems - CHECK STIGs ONLY
$ButtonListPath.Add_Click({
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    
    #Display a folder dialog box
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
        InitialDirectory = ($STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }).TempPath
        Filter = "TXT files (*.txt)|*.txt"
    }
    #Force the window to be on top
    $FileBrowser.ShowDialog((New-Object System.Windows.Forms.Form -Property @{ TopMost = $true })) | Out-Null
    
    Try {
        $TextBoxSingleOrList.Text = $FileBrowser.FileName
    } Catch {
        $TextBoxSingleOrList.Text = "Could not open $($FileBrowser.FileName)"
    }
})

###CREATE LABEL FOR Single System or List - MITIGATE STIGs ONLY - NOT VISIBLE AT FIRST###
$LabelCompletedChecklistPath = CreateObject "Label" "Completed Checklists Path" $Column1LeftValue 190 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE TEXT BOX FOR Single System or List - MITIGATE STIGs ONLY - NOT VISIBLE AT FIRST###
$TextBoxCompletedChecklistPath = CreateObject "TextBox" "" $Column1LeftValue 210 $Column1Width "DefaultHeight" "NotVisible"

###CREATE BUTTON FOR Single System or List - MITIGATE STIGs ONLY - NOT VISIBLE AT FIRST###
$ButtonCompletedChecklistPath = CreateObject "Button" "Browse for Checklists" $Column1LeftValue 230 $Column1Width "DefaultHeight" "NotVisible"

#Browse for list of systems - MITIGATE STIGs ONLY
$ButtonCompletedChecklistPath.Add_Click({
    [void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

    #Display a folder dialog box
    $FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{ 
        SelectedPath = $TextBoxCompletedChecklistPath.Text
        Description = "Select the Checklist folder"
        RootFolder = "MyComputer"
    }

    #Version 1.02 - Force the window to be on top
    #If OK is selected
    If ($FolderBrowser.ShowDialog((New-Object System.Windows.Forms.Form -Property @{ TopMost = $true })) -eq "OK") {
        $TextBoxCompletedChecklistPath.Text = $FolderBrowser.SelectedPath
    } Else {
        $TextBoxCompletedChecklistPath.Text =  "No folder path was selected"
    }
})

###CREATE LABEL FOR vCenter Lis - NOT VISIBLE AT FIRSTt###
$LabelvCenterServers = CreateObject "Label" "vCenter List (Hold CTRL to select multiple)" $Column1LeftValue 360 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE LIST BOX FOR vCenter Servers - NOT VISIBLE AT FIRST###
$ListBoxvCenterServers = CreateObject "ListBox" "STIG Type" $Column1LeftValue 380 $Column1Width 130 "NotVisible"
#Provide options for all vCenterServers
$ListBoxvCenterServers.Items.AddRange($vCenterServerList.Readable)
$ListBoxvCenterServers.SelectionMode = "MultiExtended"

#When a vCenter Server is selected than make the button to start the STIG visible
$ListBoxvCenterServers.Add_Click({
    If ($LabelvCenterSSOPassword.Visible -ne $true) {
        $LabelvCenterSSOPassword.Visible = $true
        $MaskedTextBoxvCenterSSOPassword.Visible = $true
        $LabelSystemUser.Visible = $true
        $LabelSystemPassword.Visible = $true
        $TextBoxSystemUser.Visible = $true
        $MaskedTextBoxSystemPassword.Visible = $true
        $LabelProgressBar.Visible = $true
        $ButtonStartSTIG.Visible = $true
        $ButtonCancel.Visible = $true
    }
})

###CREATE COLUMN 2 ITEMS###

###CREATE LABEL FOR STIG Parameter Path###
CreateObject "Label" "STIG Parameter Path" $Column2LeftValue 10 "AutoSizeWidth" "DefaultHeight" "Visible" | Out-Null

###CREATE TEXT BOX FOR STIG Parameter Path###
$TextBoxSTIGParameterPath = CreateObject "TextBox" "" $Column2LeftValue 30 $Column2Width "DefaultHeight" "Visible"

###CREATE LABEL FOR STIG Script Path###
CreateObject "Label" "STIG Script Path" $Column2LeftValue 60 "AutoSizeWidth" "DefaultHeight" "Visible" | Out-Null

###CREATE TEXT BOX FOR STIG Script Path###
$TextBoxSTIGScriptPath = CreateObject "TextBox" "" $Column2LeftValue 80 $Column2Width "DefaultHeight" "Visible"

###CREATE LABEL FOR STIG Report Path###
CreateObject "Label" "STIG Report Path" $Column2LeftValue 110 "AutoSizeWidth" "DefaultHeight" "Visible" | Out-Null

###CREATE TEXT BOX FOR STIG Script Path###
$TextBoxSTIGReportPath = CreateObject "TextBox" "" $Column2LeftValue 130 $Column2Width "DefaultHeight" "Visible"

###CREATE LABEL FOR Blank Checklist Path###
CreateObject "Label" "STIG Blank Checklist Path" $Column2LeftValue 160 "AutoSizeWidth" "DefaultHeight" "Visible" | Out-Null

###CREATE TEXT BOX FOR STIG Script Path###
$TextBoxSTIGBlankChecklistPath = CreateObject "TextBox" "" $Column2LeftValue 180 $Column2Width "DefaultHeight" "Visible"

###CREATE LABEL FOR vCenter SSO Password - NOT VISIBLE AT FIRST###
$LabelvCenterSSOPassword = CreateObject "Label" "vCenter SSO Password" $Column2LeftValue 210 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE MASKED TEXT BOX FOR vCenter SSO Password - NOT VISIBLE AT FIRST###
$MaskedTextBoxvCenterSSOPassword = CreateObject "MaskedTextBox" "" $Column2LeftValue 230 $Column2Width "DefaultHeight" "NotVisible"

###CREATE LABEL FOR SYSTEM User - NOT VISIBLE AT FIRST###
$LabelSystemUser = CreateObject "Label" "User Name" $Column2LeftValue 260 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE TEXT BOX FOR SYSTEM User - NOT VISIBLE AT FIRST###
$TextBoxSystemUser = CreateObject "TextBox" "" $Column2LeftValue 280 $Column2Width "DefaultHeight" "NotVisible"

###CREATE LABEL FOR SYSTEM Password - NOT VISIBLE AT FIRST###
$LabelSystemPassword = CreateObject "Label" "System Password" $Column2LeftValue 310 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE MASKED TEXT BOX FOR SYSTEM Password - NOT VISIBLE AT FIRST###
$MaskedTextBoxSystemPassword = CreateObject "MaskedTextBox" "" $Column2LeftValue 330 $Column2Width "DefaultHeight" "NotVisible"

###CREATE BUTTON TO Start STIG Process - NOT VISIBLE AT FIRST###
$ButtonStartSTIG = CreateObject "Button" "Start STIG" $Column2LeftValue 360 $Column1Width "DefaultHeight" "NotVisible"

Function VerifyUserInputs {
    $Script:ValidationError = ""

    If ("Single","List" -contains $ListBoxSystemToScan.SelectedItem) {
        If ($TextBoxSingleOrList.Text -eq "") {
            $Script:ValidationError = "No servers listed to scan"
        }
    } ElseIf ($ListBoxvCenterServers.SelectedItem.Count -eq 0) {
        $Script:ValidationError = "No vCenter Server selected"
    } ElseIf ($MaskedTextBoxvCenterSSOPassword.Text -eq "") {
        $Script:ValidationError = "No vCenter Server password entered"
    } ElseIf ($MaskedTextBoxSystemPassword.Text -eq "") {
        $Script:ValidationError = "No System password entered"
    }
}

Function ConnectTovCenterServers {
    ForEach ($vCenterServer in $ListBoxvCenterServers.SelectedItems) {
        $vCenterUser = ($vCenterServerList | Where { $_.Readable -eq $vCenterServer}).User
        $vCenterServerName = ($vCenterServerList | Where { $_.Readable -eq $vCenterServer}).ServerName

        #Version 1.01 - Only perform a connection attempt to vCenter if it isn't already connected
        If (($global:DefaultVIServers).Name -notcontains $vCenterServerName) {
            $SecurePassword = ConvertTo-SecureString $MaskedTextBoxvCenterSSOPassword.Text -AsPlainText -Force
            $vCenterCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterUser, $SecurePassword )

            Connect-VIServer $vCenterServerName -Credential $vCenterCreds | Out-Null

            #Confirm that the connection worked
            If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServerName })) {
                #Disconnect from all vCenter Servers
                Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
                Return
            }
        }
    }
}

#Version 1.01 - Created function for displaying message boxes
Function DisplayMessageBox {
    Param ( $ButtonPrompt, $MessageBoxTitle, $MessageBoxBody )

    $ButtonType = [System.Windows.MessageBoxButton]::$ButtonPrompt
    [System.Windows.Forms.MessageBox]::Show($MessageBoxBody,$MessageBoxTitle,$ButtonType)
}

Function PerformPreReqs {
    $Script:ValidationError = ""

    #Version 1.01 - Need to set this variable ahead of its use
    $Script:STIGInfo = $STIGScriptInfo | Where { $_.STIGType -eq $ListBoxSTIGToRun.SelectedItem }

    #Version 1.06 - Adjust the TempPath to include a folder for the specific user.  This is being done because there is sometimes a permissions issue where one user creates
    #               files in the TempPath and another user can't delete them.  Best to separate each user into their own folder
    $Script:STIGInfo.TempPath = $STIGInfo.TempPath + "\" + $env:UserName

    #Create the Temp Checklist folder
    If (!(Test-Path $STIGInfo.TempPath)) {
        New-Item $STIGInfo.TempPath -ItemType Directory | Out-Null
    } Else {
        Remove-Item "$($STIGInfo.TempPath)\*.ckl" | Out-Null
    }

    If ($ListBoxSTIGType.SelectedItem -eq "Check") {
        #Version 1.04 - Since Photon OS requires multiple checklists, making this into a ForEach
        $BlankChecklist | ForEach { Copy-Item $_.FullName "$($STIGInfo.TempPath)\$($_.Name)" }

        If ($ListBoxSystemToScan.SelectedItem -eq "Single") {
            $Script:SystemScanList = $TextBoxSingleOrList.Text
        } ElseIf ($ListBoxSystemToScan.SelectedItem -eq "List") {
            $Script:SystemScanList = Get-Content $TextBoxSingleOrList.Text
        } ElseIf ($ListBoxSystemToScan.SelectedItem -eq "All Systems") {
            If ($ListBoxSTIGToRun.SelectedItem -eq "VM") {
                $Script:SystemScanList = (Get-VM).Name
            } ElseIf ($ListBoxSTIGToRun.SelectedItem -eq "ESX") {
                #Version 1.04 - Get a list of all ESX hosts that are not disconnected or not responding
                $Script:SystemScanList = (Get-VMHost | Where { @('Connected','Maintenance') -contains $_.ConnectionState }).Name
            }
        }
    } ElseIf ($ListBoxSTIGType.SelectedItem -eq "Mitigate") {
        $Script:SystemChecklists = (Get-ChildItem $TextBoxCompletedChecklistPath.Text) | Where { $_.Name -like "$($ListBoxSTIGToRun.SelectedItem) STIG - *" } | Select Name, FullName, @{Name="SystemName";Expression={""}}, @{Name="TempPath";Expression={""}}

        If ($SystemChecklists -eq $null) {
            $ValidationError = "No checklist files found.  Exiting mitigation."
            Return
        }

        ForEach ($SystemChecklist in $SystemChecklists) {
            $CklName = ($SystemChecklist.Name -Split "$($ListBoxSTIGToRun.SelectedItem) STIG - ")[1]
            $NameSplit = $CklName -Split "-"
            $SystemChecklist.SystemName = ($NameSplit[0..($NameSplit.Count - 2)]) -join "-"
            $SystemChecklist.TempPath = "$($STIGInfo.TempPath)\$($SystemChecklist.SystemName).ckl"
        }

        $Script:SystemScanList = $SystemChecklists.SystemName
    }

    #Get a list of all systems that will be scanned
    If ($ListBoxSTIGToRun.SelectedItem -eq "ESX") {
        #Version 1.04 - Get a list of all ESX hosts that are not disconnected or not responding
        $Script:DiscoveredSystemList = (Get-VMHost | Where { @('Connected','Maintenance') -contains $_.ConnectionState }).Name
    } ElseIf ($ListBoxSTIGToRun.SelectedItem -eq "vCenter") {
        $Script:DiscoveredSystemList = ($global:DefaultVIServers).Name
    } Else {
        $Script:DiscoveredSystemList = (Get-VM).Name
    }

    $Script:SystemsFoundList = (Compare-Object $Script:SystemScanList $DiscoveredSystemList -IncludeEqual | Where { $_.SideIndicator -eq "==" }).InputObject
    $Script:SystemsNotFound = (Compare-Object $Script:SystemScanList $DiscoveredSystemList -IncludeEqual | Where { $_.SideIndicator -eq "<=" }).InputObject

    #Track any instances of VM names not matching the FQDN server names
    $Global:VMNameMismatches = @()

    #If a VM is not found then check to see if maybe the short name version of it exists on the system
    ForEach ($VMNameCheck in $SystemsNotFound) {
        $VMCheckResult = $DiscoveredSystemList | Where { $_ -like "$($VMNameCheck.Split(".")[0])*" }

        #If the VM is found then add the short name to the Found list and remove from FQDN from the Not Found
        If ($VMCheckResult -ne $null) {
            #If there is more than one VM matching this description
            If ($VMCheckResult.Count -gt 1) {
                #Loop through each VM
                ForEach ($VMCheck in $VMCheckResult) {
                    #If they are powered off then remove them from the list
                    If ((Get-VM $VMCheck).PowerState -eq "PoweredOff") {
                        $VMCheckResult = $VMCheckResult | Where { $_ -ne $VMCheck }
                    }
                }
            }

            #If there is only one VM found matching this description then update the Systems found and not found lists
            If ($VMCheckResult.Count -eq 1) {
                $Script:SystemsFoundList += $VMCheckResult
                $Script:SystemsNotFound = $SystemsNotFound | Where { $_ -ne $VMNameCheck }
            }
        }

        $Global:VMNameMismatches += [PSCustomObject]@{'ProvidedName'=$VMNameCheck;'ActualName'=$VMCheckResult}
    }

    #Version 1.01 - Added also checking that SystemsNotFound is not null
    If ($SystemsNotFound -ne $null) {
       $Response = DisplayMessageBox "YesNo" "The following systems were not found" "The following systems weren't found on the vCenter servers that were connected to:`n`n$SystemsNotFound`n`nDo you want to continue with the scan?"
       
        If ($Response -eq "Yes") {
            $Script:SystemScanList = $SystemsFoundList

            If ($ListBoxSTIGType.SelectedItem -eq "Mitigate") {
                ForEach ($SystemNotFound in $SystemsNotFound) {
                    #Remove checklists for any system that is not found
                    $Script:SystemChecklists = $SystemChecklists | Where { $_.SystemName -ne $SystemNotFound }
                }
            }
        } Else {
            $Script:ValidationError = "Some systems weren't found in vCenter"
            Return
        }
    }

    If ($SystemScanList.Count -eq 0) {
        $Script:ValidationError = "There are no systems to scan"
        Return
    }

    $Script:STIGParams = Import-Excel $STIGInfo.ParmetersPath -WorksheetName *
}

#Version 1.02 - Create a separate function for performing STIG checks
Function PerformSTIGChecks {
    #Store STIG results as the script runs
    $Global:STIGResultList = New-Object System.Collections.Generic.List[System.Object]

    If ($ValidationError -ne "") {
        $LabelProgressBar.Text = $ValidationError
        Return
    }
    
    $ProgressBar1.Visible = $true
    $Script:CancelClicked = "False"
    $SystemCount = $SystemScanList.Count
    $CurrentSystem = 1

    ForEach ($Script:CurrentSystemName in $SystemScanList) {
        If ($CancelClicked -eq "False") {
            $ProgressBar1.Value = ($CurrentSystem / $SystemCount) * 100
            $LabelProgressBar.Text = "$CurrentSystemName - $CurrentSystem out of $SystemCount"

            [System.Windows.Forms.Application]::DoEvents()

            Function CreateSSHConnection {
                $SecureSystemPassword = ConvertTo-SecureString $MaskedTextBoxSystemPassword.Text -AsPlainText -Force
                $Global:SystemCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $TextBoxSystemUser.Text, $SecureSystemPassword )

                $Global:SSHConnection = New-SSHSession -HostName $CurrentSystemName -Credential $SystemCreds -AcceptKey -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

                If ($SSHConnection -eq $null) {
                    #Only stop the SSH service if the script was the thing that started it
                    If ($ListBoxSTIGToRun.SelectedItem -eq "ESX" -and $SSHServiceRunStatus -eq $false) {
                        $ESXVMHostInfo | Get-VMHostService | Where { $_.Label -eq "SSH" } | Stop-VMHostService -Confirm:$false | Out-Null
                    }

                    DisplayMessageBox "Ok" "SSH Failed To Connect" "SSH failed to connect on $CurrentSystemName.  Skipping server" | Out-Null
                    Continue
                }
            }

            #Version 1.01 - Added some supporting code for ESX scans
            If ($ListBoxSTIGToRun.SelectedItem -eq "ESX") {
                $ESXVMHostInfo = Get-VMHost $CurrentSystemName

                If (($ESXVMHostInfo | Get-VMHostService | Where { $_.Label -eq "SSH" }).Running -eq $false) {
                    #Version 1.07 - Record that the script started the SSH service
                    $Script:SSHServiceRunStatus = $false

                    $ESXVMHostInfo | Get-VMHostService | Where { $_.Label -eq "SSH" } | Start-VMHostService -ErrorAction SilentlyContinue -ErrorVariable ServiceFailure | Out-Null

                    #If the SSH service fails to start then move onto the next ESX host
                    If ($ServiceFailure) {
                        DisplayMessageBox "Ok" "SSH Service Failed To Start" "SSH Service failed to start on $CurrentSystemName.  Skipping server" | Out-Null
                        Continue
                    }
                } Else {
                    #Version 1.07 - Record that the script did NOT start the SSH service
                    $Script:SSHServiceRunStatus = $true
                }

                CreateSSHConnection
            } ElseIf ($ListBoxSTIGToRun.SelectedItem -eq "PhotonOS") {
                CreateSSHConnection

                #Version 1.04 - Check which version of PhotonOS is being used
                #Check the PhotonOS version number
                $PhotonOSVersionInfo = (Invoke-SSHCommand -SessionId 0 -Command "cat /etc/photon-release" -Timeout 300).Output
                $PhotonOSVersionSplit = $PhotonOSVersionInfo[0].Split(" ")
                $PhotonOSVersion = $PhotonOSVersionSplit[$PhotonOSVersionSplit.Count - 1]
                #Increment the version by 4 since the VCSA 7.x STIG is based on Photon 3.x so any Photon 3.x needs to use that
                $TranslatedVersion = [int]$PhotonOSVersion + 4
                #Find the checklist name that has that version number in it
                $Script:BlankChecklist = $BlankChecklist | Where { $_.Name -like "*$TranslatedVersion*" }
            }

            #Version 1.04 - Moved the copy to here since Photon needs the SSH connection made first to determine which checklist to copy
            $Script:ChecklistFilePath = "$($STIGInfo.TempPath)\$($ListBoxSTIGToRun.SelectedItem) STIG - $CurrentSystemName-$CurrDate.ckl"
            $Script:LocalBlankChecklistPath = "$($STIGInfo.TempPath)\$($BlankChecklist.Name)"
            Copy-Item $LocalBlankChecklistPath $ChecklistFilePath
            
            $parms = @{
                ChecklistFilePath = $ChecklistFilePath
                CurrentSystemName = $CurrentSystemName
                STIGParams = $STIGParams
            }

            Invoke-Expression -Command ("& '$($TextBoxSTIGScriptPath.Text)' @parms")

            #Version 1.01 - Added some supporting code for ESX scans
            If ($ListBoxSTIGToRun.SelectedItem -eq "ESX" -or $ListBoxSTIGToRun.SelectedItem -eq "PhotonOS") {
                Get-SSHSession | Remove-SSHSession | Out-Null

                #Only stop the SSH service if the script was the thing that started it
                If ($ListBoxSTIGToRun.SelectedItem -eq "ESX" -and $SSHServiceRunStatus -eq $false) {
                    $ESXVMHostInfo | Get-VMHostService | Where { $_.Label -eq "SSH" } | Stop-VMHostService -Confirm:$false | Out-Null
                }
            }
        } Else {
            $ProgressBar1.Value = 0
            $LabelProgressBar.Text = "Canceled scan"
        }

        #Version 1.01 - Increment for the progress bar
        $CurrentSystem++
    }

    $ProgressBar1.Value = 0
    $LabelProgressBar.Text = "Complete"
}

Function PerformSTIGMitigations {
    #Store a list of all findings that can be mitigated
    $Script:MitigationFindingArray = New-Object System.Collections.Generic.List[System.Object]

    $SecureSystemPassword = ConvertTo-SecureString $MaskedTextBoxSystemPassword.Text -AsPlainText -Force
    $Global:ESXSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $TextBoxSystemUser.Text, $SecureSystemPassword )

    ForEach ($SystemChecklist in $SystemChecklists) {
        Copy-Item $SystemChecklist.FullName $STIGInfo.TempPath -Force

        $Checklist_XML = New-Object XML
        $Checklist_XML.PreserveWhitespace = $true #This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
        $Checklist_XML.Load("$($STIGInfo.TempPath)\$($SystemChecklist.Name)") #This is the name of the empty checklist template file

        $SystemName = $Checklist_XML.CHECKLIST.ASSET.HOST_FQDN
        $SystemShortName = $Checklist_XML.CHECKLIST.ASSET.HOST_NAME
        $VULN_DATA = $Checklist_XML.CHECKLIST.STIGS.iSTIG.VULN

        $VulnDataFiltered = $VULN_DATA | Where { $_.Status -eq "Not_Reviewed" -or $_.Status -eq "Open" }

        ForEach ($VULN in $VulnDataFiltered) { #Loop through the Checklist to see if there is data for each Vulnerability in the XCCDFData array
            $VulnArray = $VULN.STIG_DATA
            $VulnNumber = ($VulnArray | Where {$_.Vuln_Attribute -eq "Vuln_Num"}).ATTRIBUTE_DATA
            $VulnTitle = ($VulnArray | Where {$_.Vuln_Attribute -eq "Rule_Title"}).Attribute_Data
            $VulnFixText = ($VulnArray | Where {$_.Vuln_Attribute -eq "Fix_Text"}).Attribute_Data
            $VulnCheckContent = ($VulnArray | Where {$_.Vuln_Attribute -eq "Check_Content"}).Attribute_Data
            $VulnDiscuss = ($VulnArray | Where {$_.Vuln_Attribute -eq "Vuln_Discuss"}).Attribute_Data
            $VulnSeverity = $VulnArray | Where {$_.Vuln_Attribute -eq "Severity"}
            If ($Vuln.Comments.Length -gt 30000) { #If a comment is over about 32k then Excel lets it spill out into other fields
                $VulnComments = $Vuln.Comments.Substring(0,30000) 
            } Else {
                $VulnComments = $Vuln.Comments
            }

            #Version 1.05 - Check to see if this is a POAM item
            ForEach ($POAMItem in $STIGParams["POAMs"]) {
                #Version 1.05 - If this is a POAM item then mark it and exit the ForEach loop
                If ($VulnNumber -eq $POAMItem.Vuln_Num -and $SystemName -like "*$($POAMItem.Affected_Systems)*" ) {
                    $VULN.Status = "POAM"
                    $SystemName += " - POAM"
                    Break
                }
            }

            $Script:MitigationFindingArray.add((New-Object -TypeName "psobject" -property @{"SystemName"=$SystemName;"ShortName"=$SystemShortName;"VulnStatus"=$VULN.Status;"Severity"=$VulnSeverity.Attribute_Data;"VulnNumber"=$VulnNumber`
            ;"RuleTitle"=$VulnTitle;"Comments"=$VulnComments;"CKLFullPath"=$CKLFile.FullName;"CKLFileName"=$CKLFile.name})) 
        }
    }
    
    #Version 1.08 - Just in case there is only 1 finding, need to ensure this is created as an ARRAY and never can be just a STRING
    $Script:VCodesWithFindings = @()
    #Version 1.02 - Collect a list of only the VCode numbers that have findings
    $Script:VCodesWithFindings += $MitigationFindingArray.VulnNumber | Select -Unique

    $FormTabControl.SelectedIndex = 1
    $Script:CurrentMitigation = 0
    RunNextMitigation
}

Function RunNextMitigation {
    If ($CurrentMitigation -ge $VCodesWithFindings.Count) {
        CloseMitigationFindings
        GenerateReports
        DisconnectvCenter
        $FormTabControl.SelectedIndex = 0
        Return
    }

    $Script:STIGParam = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $VCodesWithFindings[$CurrentMitigation] }
    $Script:FindingsList = $MitigationFindingArray | Where { $_.VulnNumber -eq $VCodesWithFindings[$CurrentMitigation] }

    #Populate the list of affected VMs
    $ListBoxAffectedVMs.Items.Clear()
    $ListBoxAffectedVMs.Items.AddRange($FindingsList.SystemName)
    
    $LabelFindingInfo.Text = "There are $($FindingsList.Count) findings for this entry which are listed above"
    $LabelVCodeNumber.Text = $($FindingsList[0].VulnNumber)
    $LabelRuleTitle.Text = $($FindingsList[0].RuleTitle)
    $LabelFixText.Text = $($STIGParam.Fix_Text)

    $ButtonSkip.Visible = $true
    $ButtonMitigate.Text = "Mitigate"

    If ($STIGParam.Fix_Text -like "Manual fix:*") {
        $LabelMitigationInfo.Text = "This is a manual fix.  If you want to mark this as fixed then click Fixed"
        $ButtonMitigate.Text = "Fixed"
    } ElseIf ($STIGParam.Check_Method -eq "AutoClose") {
        $LabelMitigationInfo.Text = "These findings are closed automatically.  Click Mitigate to continue"
        $ButtonSkip.Visible = $false
    } Else {
        $LabelMitigationInfo.Text = "Click Mitigate to resolve this issue or click Skip"
    }

    $Script:CurrentMitigation++
}

Function CloseMitigationFindings {
    $parms = @{
        SystemChecklists = $SystemChecklists
        ListOfStatusUpdates = $ListOfStatusUpdates
    }

    Invoke-Expression -Command ("& '$FolderPathToSTIGScript\CloseSTIGFindings.ps1' @parms")
}

Function GenerateReports {
    #Store VCode results broken down by NR/NA/NF/O
    $VCodeReport = New-Object System.Collections.Generic.List[System.Object]
    #Store the number of findings per server broken down by NR/NA/NF/O and CAT I/II/III
    $ServerReport = New-Object System.Collections.Generic.List[System.Object]

    $VCodeList = $STIGResultList.VCode | Select -Unique
    $CATList = @("CAT I", "CAT II", "CAT III")
    $StatusList = @("O", "NF", "NA", "NR")
    $RecordCount = 0
        
    #Generate the VCode Report
    ForEach ($VCode in $VCodeList) {
        #Find all STIG checks that had this V-Code
        $VCodeResultList = $STIGResultList | Where { $_.VCode -eq $VCode }
        #Determine what CAT this finding is
        $CAT = ($VCodeResultList | Select -First 1).CAT
        #Get the Check_Name so the reports contains the check name and not just the V-Code ID
        $VCodeName = ($STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $VCode }).Check_Name
        #Store the results for this V-Code
        $VCodeReport.add((New-Object "psobject" -Property @{"VCode"=$VCode;"CAT"=$CAT;"Name"=$VCodeName;"O"=0;"NF"=0;"NA"=0;"NR"=0;"ServerList"=""}))

        #Loop through each type of finding ("O", "NF", "NA", "NR")
        ForEach ($Status in $StatusList) {
            #Update the count for this record for each type of finding
            $VCodeReport[$RecordCount].$Status = ($VCodeResultList | Where { $_.Status -eq $Status }).Count
        }
        
        #Move onto the next V-Code
        $RecordCount++
    }

    #Reset the count for the Server report
    $RecordCount = 0

    #Generate the Server Report
    ForEach ($SystemName in $SystemScanList) {
        #Find all STIG checks for this system
        $SystemResultList = $STIGResultList | Where { $_.SystemName -eq $SystemName }
        #Create a generic record for this finding
        $ServerReport.add((New-Object "psobject" -Property @{"SystemName"=$SystemName;"O"=0;"NF"=0;"NA"=0;"NR"=0;"CAT I"=0;"CAT II"=0;"CAT III"=0}))

        #Loop through each type of finding ("O", "NF", "NA", "NR")
        ForEach ($Status in $StatusList) {
            #Update the count for this record for each type of finding
            $ServerReport[$RecordCount].$Status = ($SystemResultList | Where { $_.Status -eq $Status }).Count
        }

        #Loop through each type of CAT finding ("CAT I", "CAT II", "CAT III")
        ForEach ($CAT in $CATList) {
            #For this system, gather the open findings for just this CAT type
            $VCodeFindingList = $SystemResultList | Where { $_.CAT -eq $CAT -and $_.Status -eq "O" }
            #Store the count of how many open findings there are for this CAT type
            $ServerReport[$RecordCount].$CAT = [String]$VCodeFindingList.Count

            #If there is more than one finding for this CAT type
            If ($VCodeFindingList.Count -ne 0) {
                #Build a string for this.  It will ultimately look like "2 - (V-256446, V-256447)" if there were two findings
                $ServerReport[$RecordCount].$CAT += " - ("

                #Loop through each finding
                ForEach ($VCodeFinding in $VCodeFindingList) {
                    #If there are more than two findings remaining then there will need to be a comma to separate the V-Codes
                    If ($ServerReport[$RecordCount].$CAT.Split("-").Count -gt 2) {
                        $ServerReport[$RecordCount].$CAT += ", " + $VCodeFinding.VCode
                    } Else { #Otherwise just add the V-Code
                        $ServerReport[$RecordCount].$CAT += $VCodeFinding.VCode
                    }
                }

                #Finish off the string with an end parenthasis
                $ServerReport[$RecordCount].$CAT += ")"
            }
        }

        #Move onto the next V-Code
        $RecordCount++
    }

    #Display if there were any STIG checks that were not on the Parameter spreadsheet
    If ($NoSTIGParamList) {
        Write-Host "`nThe following V-Codes had no STIG param item:"
        $NoSTIGParamList
    }

    #Output the VCode and Server reports
    $VCodeReport | Select "VCode","Name","O","NF","NA","NR" | Export-CSV "$($TextBoxSTIGReportPath.Text)\$($ListBoxSTIGToRun.SelectedItem) $($ListBoxSTIGType.SelectedItem) STIG VCode Report for $CurrDate.csv" -Force
    $ServerReport | Select "SystemName","O","NF","NA","NR","CAT I","CAT II","CAT III" | Export-CSV "$($TextBoxSTIGReportPath.Text)\$($ListBoxSTIGToRun.SelectedItem) $($ListBoxSTIGType.SelectedItem) STIG Server Report for $CurrDate.csv" -Force

    DisplayMessageBox "Ok" "Reports created" "Reports have been output to $($TextBoxSTIGReportPath.Text)" | Out-Null
    
    $Response = DisplayMessageBox "YesNo" "Do you want to copy files to network" "Do you want to move checklists from $($STIGInfo.TempPath) to $($STIGInfo.NetworkPath)"
    
    If ($Response -eq "Yes") {
        Get-ChildItem -Path "$($STIGInfo.TempPath)\$($ListBoxSTIGToRun.SelectedItem) STIG - *.ckl" | Move-Item -Destination $STIGInfo.NetworkPath -Force
    }
}

Function DisconnectvCenter {
    $Response = DisplayMessageBox "YesNo" "Script complete" "The STIG script has completed.  Do you want to disconnect from all vCenter servers?"

    If ($Response -eq "Yes") {
        Disconnect-VIServer -Server * -Confirm:$false
    }
}

#Button used to start the STIG scan
$ButtonStartSTIG.Add_Click({
    #Store STIG results as the script runs
    $Global:STIGResultList = New-Object System.Collections.Generic.List[System.Object]
    
    VerifyUserInputs
    
    ConnectTovCenterServers

    If ($global:DefaultVIServers.Count -ne 0) {
        PerformPreReqs
    } Else {
        $LabelProgressBar.Text = "Failed to connect to the vCenter Server $vCenterServerName"
        Return
    }

    If ($ListBoxSTIGType.SelectedItem -eq "Check") {
        PerformSTIGChecks
        
        If ($CancelClicked -eq "False") {
            GenerateReports
        }

        DisconnectvCenter
    } ElseIf ($ListBoxSTIGType.SelectedItem -eq "Mitigate") {
        PerformSTIGMitigations
    }
})

###CREATE BUTTON TO Start STIG Process - NOT VISIBLE AT FIRST###
$ButtonCancel = CreateObject "Button" "Cancel" 450 360 $Column1Width "DefaultHeight" "NotVisible"

#Button used to cancel the STIG scan
$ButtonCancel.Add_Click({
    $Script:CancelClicked = "True"
})

###CREATE LABEL FOR Blank Checklist Path - NOT VISIBLE AT FIRST###
$LabelProgressBar = CreateObject "Label" "" $Column2LeftValue 390 "AutoSizeWidth" "DefaultHeight" "NotVisible"

###CREATE PROGRESS BAR FOR entire STIG run - NOT VISIBLE AT FIRST###
$ProgressBar1 = CreateObject "ProgressBar" "" $Column2LeftValue 410 $Column2Width "DefaultHeight" "NotVisible"

###CREATE OBJECTS FOR GUI TAB###

###CREATE LABEL FOR Affected VMs###
CreateObject "Label" "Affected VMs" $Column1LeftValue 10 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate" | Out-Null

###CREATE LIST BOX FOR Affected VMs###
$ListBoxAffectedVMs = CreateObject "ListBox" "" $Column1LeftValue 30 225 500 "Visible" "Mitigate"

###CREATE LABEL FOR Finding Information###
CreateObject "Label" "Finding Information" $Column2LeftValue 10 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate" | Out-Null

###CREATE LABEL FOR Displaying Finding Information###
$LabelFindingInfo = CreateObject "Label" "" $Column2LeftValue 30 $Column2Width "DefaultHeight" "Visible" "Mitigate" "Standard"

###CREATE LABEL FOR VCode Number###
CreateObject "Label" "VCode Number" $Column2LeftValue 60 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate" | Out-Null

###CREATE LABEL FOR Displaying VCode Number###
$LabelVCodeNumber = CreateObject "Label" "" $Column2LeftValue 80 $Column2Width "DefaultHeight" "Visible" "Mitigate" "Standard"

###CREATE LABEL FOR Rule Title###
CreateObject "Label" "Rule Title" $Column2LeftValue 110 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate" | Out-Null

###CREATE LABEL FOR Displaying Rule Title###
$LabelRuleTitle = CreateObject "Label" "" $Column2LeftValue 130 $Column2Width 40 "Visible" "Mitigate" "Standard"

###CREATE LABEL FOR Fix Text###
CreateObject "Label" "Fix Text" $Column2LeftValue 180 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate" | Out-Null

###CREATE LABEL FOR Displaying Fix Text###
$LabelFixText = CreateObject "Label" "" $Column2LeftValue 200 $Column2Width 40 "Visible" "Mitigate" "Standard"

###CREATE LABEL FOR Mitigation Info###
CreateObject "Label" "Mitigation Info" $Column2LeftValue 250 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate" | Out-Null

###CREATE LABEL FOR Displaying Mitigation Info###
$LabelMitigationInfo = CreateObject "Label" "" $Column2LeftValue 270 $Column2Width "DefaultHeight" "Visible" "Mitigate" "Standard"

###CREATE BUTTON TO Mitigate finding###
$ButtonMitigate = CreateObject "Button" "Mitigate" $Column2LeftValue 300 $Column1Width "DefaultHeight" "Visible" "Mitigate"

###CREATE BUTTON TO Skip finding###
$ButtonSkip = CreateObject "Button" "Skip" 450 300 $Column1Width "DefaultHeight" "Visible" "Mitigate"

$ButtonMitigate.Add_Click({
    $ButtonMitigate.Enabled = $false
    $Script:MitigationType = $ButtonMitigate.Text

    $parms = @{
        FindingsList = $FindingsList
        STIGParam = $STIGParam
        MitigationType = $MitigationType
    }
    
    Invoke-Expression -Command ("& '$($TextBoxSTIGScriptPath.Text)' @parms")

    RunNextMitigation

    $ButtonMitigate.Enabled = $true
})

$ButtonSkip.Add_Click({
    RunNextMitigation
})

###CREATE LABEL FOR Mitigation###
$Global:LabelProgressBarMitigate = CreateObject "Label" "" $Column2LeftValue 330 "AutoSizeWidth" "DefaultHeight" "Visible" "Mitigate"

###CREATE PROGRESS BAR FOR Mitigation###
$Global:ProgressBarMitigate = CreateObject "ProgressBar" "" $Column2LeftValue 350 $Column2Width "DefaultHeight" "Visible" "Mitigate"

#Display the form
$MainForm.ShowDialog()
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDDKzCeNsMFj32v
# vLHnp+JM4m3uRcAedjg+9gFgy7a3DqCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDxD06lqbynwzrp2GXENY138WqRvHlCZ0vR/I1LAxn9rTANBgkq
# hkiG9w0BAQEFAASCAQCJCyhrUS2buHeIO57vQb4YxhGYtttg4yt8UNdQmxn18Gxu
# ZvPNkL7sQUaOBr2O+SjTPpvOK1UietVKSeN3KG2Ok3cSPrQZoj9BmbdkF/mNqVd9
# IoNdzxTgsaIVvAllCMM7Bs3IIL1yzSh7/ktl53O0uZjkKDgvBAYKYtGc/2q5MAKB
# VBKFJNdw4Y/hYvovUzAhUoHDxLzF14jc1WWVvQXUonwvURdSLf0/xPxfilYGo297
# vyq9af4aKfMCfrrtIL881I76z22xhVH9OMdB3KgHJ7hrfniZLSLJDnI5F9Mqmrh9
# ssn5OwYe8ogGffBDmLZdFn/kENUguelTXiIHg5ul
# SIG # End signature block
