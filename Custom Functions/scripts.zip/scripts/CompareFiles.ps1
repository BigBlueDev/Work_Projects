﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2019 v5.6.167
	 Created on:   	3/24/2020 9:56 AM
	 Created by:   	Matthew Miller
	 Organization: 	INFO OPTERATIONS
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$path = "c:\Temp"
$Inventory = Import-Csv -Path "$($path)\ServerInventory.csv"

$VMdata = Import-Csv -Path "$($path)\PowerOffVms.csv"


$computerdata = @()


foreach ($Line in $VMdata)
{
	$ojb =  New-Object System.Management.Automation.PSObject -Property @{
		Name = $Line.Name;
		Notes = $Line.notes;
		Decommission = ''
		
	}
	$ComputernameMatch = $Inventory | where {$_.Name -eq $Line.Asset_Name}
	
	If ($ComputernameMatch)
	{
		$obj | Add-Member -MemberType NoteProperty -Name Decommission -Value $ComputernameMatch.'Decommission_CRQ_#' -Force
		
		
		
	}
	$computerdata += $obj
}
$computerdata | Export-Csv -Path c:\Temp\DecommVM2.csv -NoTypeInformation

