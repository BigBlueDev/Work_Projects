﻿#PURPOSE: Perform a STIG check on a list of ESX Hosts and output CKL files with the results

#CHANGELOG
#Version 1.0 - 03/26/24 - MDR - Initial version

Param ( $ChecklistFilePath, $CurrentSystemName, $STIGParams )

$SSHDConfig = (Invoke-SSHCommand -SessionId 0 -Command { /usr/lib/vmware/openssh/bin/sshd -T }).Output

#Create an XML object
$Checklist_XMLObject = New-Object XML
#This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
$Checklist_XMLObject.PreserveWhitespace = $true
#This is the name of the empty checklist template file
$Checklist_XMLObject.Load("$ChecklistFilePath")

#Version 1.03 - Added VMHost parameter
#I'm not sure if this is a safe assumption to make, but for now we'll say that vmk0 is the ESX host's IP and MAC
$ESXHostIPMACInfo = Get-VMHostNetworkAdapter -VMHost $CurrentSystemName | Where { $_.DeviceName -eq "vmk0" } | Select 'IP', 'MAC'

#Version 1.03 - Get just the short name for the Host Name
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$($CurrentSystemName.Split("."))[0]
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$CurrentSystemName
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = [String]$ESXHostIPMACInfo.IP
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = [String]$ESXHostIPMACInfo.MAC

$VULN_DATA = $Checklist_XMLObject.CHECKLIST.STIGS.iSTIG.VULN

#Version 1.03 - Added VMHost parameter
$ESXCLI = Get-EsxCli -V2 -VMHost $CurrentSystemName
$ESXVMHost = Get-VMHost $CurrentSystemName
$ESXHostView = $ESXVMHost | Get-View

ForEach ($VULN in $VULN_DATA) {
    $Vuln_Num = ($VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq 'Vuln_Num' }).ATTRIBUTE_DATA
    #Version 1.03 - Collecting Severity for reporting purposes later in the script
    $Severity = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA
    #Version 1.03 - Changed from $STIGCheck to $VCodeObjectSTIGData
    $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $Vuln_Num }

    #If there is a line in $STIGParams for the V-Code in this checklist
    If (!($VCodeObjectSTIGData)) {
        $VULN.COMMENTS = "No entry existed in the STIG parameters file for this V-Code"

        If ($NoSTIGParamList -notcontains $Vuln_Num) {
            $NoSTIGParamList += $Vuln_Num
        }
    } Else {
        #Version 1.03 - Ensure these are all cleared ahead of each check
        Clear-Variable Comment, FindingHint, ESXSettingValue -ErrorAction SilentlyContinue

        If ($VCodeObjectSTIGData.Check_Method -eq "LockdownMode") {
            #Version 1.03 - Changed $ESXSettingValue to $ESXSettingValue
            $ESXSettingValue = (Get-VMHost -Name $CurrentSystemName).Extensiondata.Config.LockdownMode
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "LockdownExceptions") {
            $LockdownView = Get-View $ESXHostView.ConfigManager.HostAccessManager
            $LockdownExceptions = $LockdownView.QueryLockdownExceptions()
            $LockdownComparison = (Compare-Object $LockdownExceptions @($VCodeObjectSTIGData.Expected_Value -split ",") | Where { $_.SideIndicator -eq "<=" }).InputObject

            If ($LockdownComparison) {
                $Comment = "The following undocumented accounts are in Lockdown Exceptions:`n`n$($LockdownComparison -join ""`n"")"
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
                $Comment = "The following accounts are documented as accepted Lockdown Exceptions:`n`n$($LockdownExceptions -join ""`n"")"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AdvancedSetting") {
            $ESXSettingValue = ($ESXVMHost | Get-AdvancedSetting -Name $VCodeObjectSTIGData.Check_Param).Value

            #If ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Annotations.WelcomeMessage") {
            #    $VCodeObjectSTIGData.Expected_Value = $WelcomeBanner
            #}

            If ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Syslog.global.logHost" -and $ESXSettingValue -like "*ssl://*:1514*") {
                $Comment = "A valid Syslog address was found`n`n$ESXSettingValue"
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Syslog.global.logDir") {
                If ($ESXSettingValue -eq "[] /scratch/log") {
                    $ScratchLocation = ($ESXVMHost | Get-AdvancedSetting -Name "ScratchConfig.CurrentScratchLocation").Value

                    If ($ScratchLocation -ne "/tmp/scratch") {
                        $ESXSettingValue = "$ESXSettingValue`n`nScratchConfig.CurrentScratchLocation set to $ScratchLocation"
                        #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                        $FindingHint = "NF"
                    }
                } Else {
                    $DatastoreList = (Get-Datastore | Where { $_.Name -ne ($CurrentSystemName.Split("."))[0] }).Name
                    
                    ForEach ($DatastoreItem in $DatastoreList) {
                        If ($ESXSettingValue -like "``[$DatastoreItem``]*") {
                            #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                            $FindingHint = "NF"
                            Break
                        }
                    }
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting UserVars.ESXiVPsDisabledProtocols") {
                If (!(Compare-Object $ESXSettingValue.Split(",") $VCodeObjectSTIGData.Expected_Value.Split(","))) {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Annotations.WelcomeMessage" -and $ESXSettingValue -like "*You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only*") {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Advanced Setting Net.DVFilterBindIpAddress") {
                If ($ESXSettingValue -eq "") {
                    $FindingHint = "NF"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ESXCLI") {
            #Version 1.03 - Changed from looking at Check_Param to Check_Name
            If ($VCodeObjectSTIGData.Check_Name -eq "SSH must use FIPS 140") {
                $ESXSettingValue = ($ESXCLI.system.security.fips140.ssh.get.invoke()).Enabled
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "VIB Acceptance Level") {
                $ESXSettingValue = $ESXCLI.software.acceptance.get.Invoke()

                #If the value being used is in the entire list of acceptable answers
                If ($VCodeObjectSTIGData.Expected_Value -Split "," -contains $ESXSettingValue) {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Audit Logging Enabled") {
                #Note: Doing Select * converts this to a PSCustom object so it can be displayed in comments
                $ESXSettingValue = $ESXCLI.system.auditrecords.get.invoke() | Select *
                
                If ($ESXSettingValue.AuditRecordRemoteTransmissionActive -eq "true" -and $ESXSettingValue.AuditRecordStorageActive -eq "true" -and $ESXSettingValue.AuditRecordStorageCapacity -eq "100") {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                    $Comment = "Audit location is $($ESXSettingValue.AuditRecordStorageDirectory)"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "x509 Verification") {
                $ESXSettingValue = ($ESXCLI.system.syslog.config.get.invoke()).StrictX509Compliance
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "rhttpproxy Must Use FIPS") {
                $ESXSettingValue = ($ESXCLI.system.security.fips140.rhttpproxy.get.invoke()).Enabled
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "TPM Enabled") {
                $ESXSettingValue = ($ESXCLI.system.settings.encryption.get.invoke()).Mode
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Secure Boot Required") {
                $ESXSettingValue = ($ESXCLI.system.settings.encryption.get.invoke()).RequireSecureBoot
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable SNMP") {
                $ESXSettingValue = ($ESXCLI.system.snmp.get.invoke()).Enable
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "Service") {
            $ServiceRunning = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Running
            $ServicePolicy = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Policy

            If ($VCodeObjectSTIGData.Check_Name -eq "Enable NTP Dameon Service") {
                $NTPCheck = $ESXVMHost | Get-VMHostNtpServer

                #If NTP servers are configured
                If ($NTPCheck) {
                    $ServicePolicy += " - NTP Found"
                } Else {
                    $ServicePolicy += " - NTP Not Found"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable SSH Service") {
                $ServiceRunning = "False"
                $ServicePolicy = "Off"
            }

            $ESXSettingValue = "$ServiceRunning - $ServicePolicy"
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ServicePermissions") {
            $ServiceRunning = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Running
            $ServicePolicy = ($ESXVMHost | Get-VMHostService | Where { $_.Label -eq $VCodeObjectSTIGData.Check_Param }).Policy

            If ($ServiceRunning -eq $false -and $ServicePolicy -eq "off") {
                $ESXSettingValue = "$($VCodeObjectSTIGData.Check_Param) is not running"
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            } Else {
                #Version 1.03 - For STANDALONE, connect to host
                If ($ESXUsingvCenter -ne "STANDALONE") {
                    Connect-VIServer $CurrentSystemName -Credential $ESXCreds -ErrorAction SilentlyContinue -ErrorVariable ConnectError | Out-Null
                }

                $CIMRolePermissions = (Get-VIRole -Server $CurrentSystemName -Name CIMRole -ErrorAction SilentlyContinue | Get-VIPrivilege).Name

                If ($CIMRolePermissions) {
                    $RolePermissionsComparison = Compare-Object $CIMRolePermissions @($VCodeObjectSTIGData.Expected_Value -split ",")

                    If ($RolePermissionsComparison -eq $null) {
                        $VerifyCIMServiceExists = Get-VMHostAccount -Server $CurrentSystemName -id CIMService -ErrorAction SilentlyContinue
                        $GetCIMServiceRole = (Get-VIPermission -Server $CurrentSystemName -Principal CIMService -ErrorAction SilentlyContinue).Role

                        If ($VerifyCIMServiceExists -ne $null -and $GetCIMServiceRole -eq "CIMRole") {
                            $ESXSettingValue = "CIMService account exists and is associated with a properly configured CIMRole"
                            #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                            $FindingHint = "NF"
                        } Else {
                            $ESXSettingValue = "Either the CIM Service account doesn't exist or it isn't associated with CIMRole"
                        }
                    } Else {
                        $ESXSettingValue = "CIMRole permissions set incorrectly:`n$($CIMRolePermissions -join "`n")"
                    }
                } Else {
                    $ESXSettingValue = "CIMRole is missing"
                }

                #Version 1.03 - For STANDALONE, disconnect host
                If ($ESXUsingvCenter -ne "STANDALONE") {
                    Disconnect-VIServer $CurrentSystemName -Confirm:$false
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "sshd_config") {
            If ($VCodeObjectSTIGData.Check_Name -eq "SSHD Config Cipher Check") {
                $ESXSettingValue = $SSHDConfig | Where { $_ -like "Ciphers *" }
                
                $ExpectedCiphersList = $VCodeObjectSTIGData.Expected_Value -replace "Ciphers ",""
                $ActualCiphersList = $ESXSettingValue -replace "Ciphers ",""

                $ComparisonResults = (Compare-Object @($ActualCiphersList -split ",") @($ExpectedCiphersList -split ",")).InputObject

                If ($ComparisonResults -eq $null) {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                }
            } Else {
                $ESXSettingValue = $SSHDConfig | Where { $_ -eq $VCodeObjectSTIGData.Expected_Value }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "DomainJoin") {
            $ESXSettingValue = ($ESXVMHost | Get-VMHostAuthentication).DomainMembershipStatus
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "HostProfile") {
            #This needs to get checked from the vCenter server, but for now just close the finding out
            #Version 1.03 - Replaced expected and actual values with just setting hint to NF
            $FindingHint = "NF"
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VMKernel") {
            $VMKernelData = $ESXVMHost | Get-VMHostNetworkAdapter -VMKernel | Select *Enabled

            $VMKernelToReview = $VMKernelData | Where { $_.($VCodeObjectSTIGData.Check_Param) -eq "True" }

            If ($VMKernelToReview) {
                If (($VMKernelToReview.psobject.Properties.Value | Where { $_ -eq "True" }).Count -eq 1) {
                    $ESXSettingValue = $VCodeObjectSTIGData.Expected_Value
                } Else {
                    $ESXSettingValue = "$($VCodeObjectSTIGData.Check_Param) NIC is NOT isolated"
                }
            } Else {
                If ($VCodeObjectSTIGData.Check_Name -eq "Isolate Provisioning Traffic") {
                    $FindingHint = "NA"
                } Else {
                    $ESXSettingValue = "$($VCodeObjectSTIGData.Check_Param) NIC not found"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "iSCSI CHAP") {
            #NOTE: This check is good enough for if iSCSI is disabled, but need to expand this if we run into cases where it is enabled
            If ((Get-VMHostStorage -VMHost $CurrentSystemName).SoftwareIScsiEnabled -eq $false) {
                $FindingHint = "NA"
                $Comment = "ISCSI is not enabled"
            } Else {
                $ESXSettingValue = (Get-VMHostStorage -VMHost $CurrentSystemName).SoftwareIScsiEnabled
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "FirewallAllowAll") {
            $AllIPAllowedList = ($ESXVMHost | Get-VMHostFirewallException | Where-Object { ($_.Enabled -eq $True) -and ($_.extensiondata.allowedhosts.allip -eq "enabled") }).Name
        
            If ($AllIPAllowedList) {
                $Comment = "The following services allow connections from any IP`n`n$($AllIPAllowedList -join "`n")"
            } Else {
                $ESXSettingValue = $VCodeObjectSTIGData.Expected_Value
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "FirewallDefaultPolicy") {
            $FirewallDefaultPolicy = Get-VMHostFirewallDefaultPolicy -VMHost $CurrentSystemName

            If ($FirewallDefaultPolicy.IncomingEnabled -eq $False -and $FirewallDefaultPolicy.OutgoingEnabled -eq $False) {
                $ESXSettingValue = $VCodeObjectSTIGData.Expected_Value
            } Else {
                $ESXSettingValue = "Incoming Enabled is set to $($FirewallDefaultPolicy.IncomingEnabled) and Outgoing Enabled is set to $($FirewallDefaultPolicy.OutgoingEnabled)"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "StandardSwitch") {
            $StandardSwitchList = Get-VirtualSwitch -VMHost $CurrentSystemName -Standard | Get-SecurityPolicy
            $StandardPortGroupList = Get-VirtualPortGroup -VMHost $CurrentSystemName -Standard | Get-SecurityPolicy

            $SwitchAcceptList = ($StandardSwitchList | Where { $_.($VCodeObjectSTIGData.Check_Param) -ne $False }).VirtualSwitch.Name
            $PortGroupAcceptList = ($StandardPortGroupList | Where { $_.($VCodeObjectSTIGData.Check_Param) -ne $False }).VirtualPortGroup.Name

            If ($StandardSwitchList) {
                If ($SwitchAcceptList -or $PortGroupAcceptList) {
                    $ESXSettingValue = "True"
                    $Comment = "The following Switches were set to accept:`n`n$SwitchAcceptList`n`nThe following Port Groups were set to accept:`n`n$PortGroupAcceptList"
                } Else {
                    $ESXSettingValue = $VCodeObjectSTIGData.Expected_Value
                }
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NA
                $FindingHint = "NA"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "StandardPortGroup") {
            #Version 1.03 - Collect Switch information since it is used in this check
            $StandardSwitchList = Get-VirtualSwitch -VMHost $CurrentSystemName -Standard | Get-SecurityPolicy
            $StandardPortGroupList = Get-VirtualPortGroup -VMHost $CurrentSystemName -Standard | Select Name, VLanId

            If ($VCodeObjectSTIGData.Check_Name -ne "Port Groups Don't Use Reserved Ips") {
                $VLANMatches = ($StandardPortGroupList | Where { $_.VLanID -eq $VCodeObjectSTIGData.Check_Param }).Name
            } Else {
                $VLANMatches = @()

                ForEach ($VLANItem in $VCodeObjectSTIGData.Check_Param.Split(",")) {
                    $VLANSplit = $VLANItem.Split("-")

                    If ($VLANSplit.Count -eq 2) {
                        $VLANsFound = ($StandardPortGroupList | Where { $_.VLanID -ge $VLANSplit[0] -and $_.VLanID -le $VLANSplit[1] }).Name
                    } Else {
                        $VLANsFound = ($StandardPortGroupList | Where { $_.VLanID -eq $VLANItem }).Name
                    }

                    #Version 1.03 - Only add $VLANMatches if there are VLANs found
                    If ($VLANsFound) {
                        $VLANMatches += $VLANsFound
                    }
                }
            }

            If ($StandardSwitchList) {
                #Version 1.03 - Check to see if there are any entries in $VLANMatches
                If ($VLANMatches.Count -ne 0) {
                    $ESXSettingValue = "The following Port Groups are assigned to VLAN $($VCodeObjectSTIGData.Check_Param):`n`n$VLANMatches"
                } Else {
                    $ESXSettingValue = $VCodeObjectSTIGData.Expected_Value
                }
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NA
                $FindingHint = "NA"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "Patches") {
            #$ESXSettingValue = "Manual"
            $ESXSettingValue = "Manual check: Version - $($ESXVMHost.Version) - Build - $($ESXVMHost.Build)"
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SSHQuery") {
            If ($VCodeObjectSTIGData.Check_Name -eq "Secure Boot Enabled") {
                $ESXSettingValue = (Invoke-SSHCommand -SessionId 0 -Command { /usr/lib/vmware/secureboot/bin/secureBoot.py -s }).Output
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable ESX Override Config") {
                $ESXSettingValue = (Invoke-SSHCommand -SessionId 0 -Command { stat -c "%s" /etc/vmware/settings }).Output
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable ESX Override Log") {
                $ESXSettingValue = (Invoke-SSHCommand -SessionId 0 -Command { grep "^vmx\.log" /etc/vmware/config }).Output
                
                If ($ESXSettingValue[0] -eq "") {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "DODCert") {
            $certMgr = Get-View -Id $ESXVMHost.ExtensionData.ConfigManager.CertificateManager
            
            If ([DateTime]$certMgr.CertificateInfo.NotAfter -gt (Get-Date) -and $certMgr.CertificateInfo.Issuer -like "*OU=DoD*") {
                $ESXSettingValue = $VCodeObjectSTIGData.Expected_Value
            } Else {
                $ESXSettingValue = "Issuer of $($certMgr.CertificateInfo.Issuer) and expiration of $([DateTime]$certMgr.CertificateInfo.NotAfter)"
            }
        }

        $parms = @{
            CorrectVal = $VCodeObjectSTIGData.Expected_Value
            ActualVal = $VMSettingValue
            CustomComment = $Comment
            ResultHint = $FindingHint
            CurrentSystemName = $CurrentSystemName
        }

        Invoke-Expression -Command ("& '$FolderPathToSTIGScript\RecordToChecklist.ps1' @parms")
    }
}

$Checklist_XMLObject.Save($ChecklistFilePath)

# SIG # Begin signature block
# MIILxQYJKoZIhvcNAQcCoIILtjCCC7ICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUrd1VLbDYh3QHYNQ9NEtxN5aG
# ezOgggktMIIEbDCCA1SgAwIBAgIDEjRvMA0GCSqGSIb3DQEBCwUAMFoxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMwHhcNMjMwNDEwMDAw
# MDAwWhcNMjcwNDA3MTM1NTU0WjBmMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5T
# LiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEMMAoGA1UE
# CxMDRExBMRMwEQYDVQQDEwpDUy5ETEEuMDA1MIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAjMaXJ2yQcMI0ZgW8qa3xkItp8L7VtB9FDtfdiQS6chAZC+V8
# RQO4iWMV87+bCdMIbHx/AgTepcuOwX/kAfxKVhb2msv3mHPzu7hhJpNTV9sGFR9S
# c62e4axw0i/O73B/ZsClZG0URlYFDb3X6rV1Qk27BUXdX++683Xgk5CspndiN1Zb
# fjZ69IDsvda5/gV6wyREcXlr5nlEXwn8SuA+J2xlFtkXbDNeLHo4Z88NlY61i13s
# 7C71giua12KEwy1g9saqw2mKlwfFfL4qipyRVrcPJNvc/lTh+wVq5P4WaBA06iKC
# 33IHndFd1cNor0sjp2zviZBYWcsFYngTFwKWCQIDAQABo4IBLTCCASkwHwYDVR0j
# BBgwFoAUF+ZLyBpLyaemcLRMTV7I9jbUMJgwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9ESURDQV82My5jcmwwDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdIAQPMA0wCwYJYIZIAWUCAQsqMB0GA1UdDgQWBBT4AbxTG6dDzp0i
# G4IfIlvBDYoM3TBlBggrBgEFBQcBAQRZMFcwMwYIKwYBBQUHMAKGJ2h0dHA6Ly9j
# cmwuZGlzYS5taWwvc2lnbi9ET0RJRENBXzYzLmNlcjAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwHwYDVR0lBBgwFgYKKwYBBAGCNwoDDQYIKwYBBQUH
# AwMwDQYJKoZIhvcNAQELBQADggEBAApQpCPdOGEWZ/CqUmxr7H/Jkj7CALR3OA6y
# b/vEO2v2QplFIyBiTFRoFs1G4pOt5njGzE8RtkXyO3PRD29RKKMBMwJwQtXLX9vD
# 0YVf/w5Wqtj3lptILtKM5elw+jehhn4KgyncMtp2yJwzToyRaoFdo3g/T5ddSYts
# 03i4XOuxEFnlJW/hozoMFaKFYitF5KMPwvnkLAynzmZLdhw17piUoo2ftPhh0i6y
# ZWwCObwfeti5yqNyUyof1XzD/4+h380+Zye68PeXdLNS/wIdAeKVImKxZB8s1+qq
# DAny4dogj0FU4PgdunbnwgACVTTmVswXUIlZOH6rS/K4iUkLdLYwggS5MIIDoaAD
# AgECAgIFDzANBgkqhkiG9w0BAQsFADBbMQswCQYDVQQGEwJVUzEYMBYGA1UEChMP
# VS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEWMBQG
# A1UEAxMNRG9EIFJvb3QgQ0EgMzAeFw0yMTA0MDYxMzU1NTRaFw0yNzA0MDcxMzU1
# NTRaMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAK
# BgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFEl3WgH6i1/u1Su87lcHX
# lB7dOsy17rfSlynPggESAK/rjElfavjrkmT6ooaq1bmV59HbSOVrN8wM7V2A5D5t
# rhMRCf9UC62PyU7/tqDcaFntnY11MAHs5yRfQud8WS2Wd1y3maLOOLwIgH+AYXCh
# 7KQUXs1dueJe53GE3M9e88GEFjfzJdPPM0fENk4ENeHKiBjHr290hoMu9cLBZMez
# DnAElqJMwZ0pwWwJRQviQ5jSG/rRViRx244X357taauwktYwzkhlLky8tBSnO+X9
# cOcl6TtohohTeW1mi3L/wuvpIE2vuFq/HrMvHETBn8RR9TfyAq5DE6ijnSjaxFyd
# AgMBAAGjggGGMIIBgjAfBgNVHSMEGDAWgBRsipSid7GAch2Behaq8tzOZu5FwDAd
# BgNVHQ4EFgQUF+ZLyBpLyaemcLRMTV7I9jbUMJgwDgYDVR0PAQH/BAQDAgGGMGcG
# A1UdIARgMF4wCwYJYIZIAWUCAQskMAsGCWCGSAFlAgELJzALBglghkgBZQIBCyow
# CwYJYIZIAWUCAQs7MAwGCmCGSAFlAwIBAw0wDAYKYIZIAWUDAgEDETAMBgpghkgB
# ZQMCAQMnMBIGA1UdEwEB/wQIMAYBAf8CAQAwDAYDVR0kBAUwA4ABADA3BgNVHR8E
# MDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RST09UQ0EzLmNy
# bDBsBggrBgEFBQcBAQRgMF4wOgYIKwYBBQUHMAKGLmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvaXNzdWVkdG8vRE9EUk9PVENBM19JVC5wN2MwIAYIKwYBBQUHMAGGFGh0dHA6
# Ly9vY3NwLmRpc2EubWlsMA0GCSqGSIb3DQEBCwUAA4IBAQAGG9UvVRw4kCnDGW7n
# RE7d0PtOn/xUx+sDBhK3u5wsFKl10fG7BSwmQRqQntbweiJFA9dIZbSOtkDF1cff
# fUMuHJE+2f/bOFWQuI9Tr7BS+Z6fS3ei1PrURrmgm5TxES6lznXqtL4M3IIkvlYM
# aaMxBLLGExy2t62aLZxv3EIa+2gPqVSCod0NA2Q8oboRgko/A01gbfMIcQ1FEqBl
# 3zbGhUIH2Hc2FnczW5L5hc61w62TB8EoocxDxbXg0lS8MvfGPIv7krViLom1/kbe
# kC/FlCB/+99HcPrPG07hDL+ryphbZ7LImdFr2+bWR+NR3ZHQ2ZPo1pSMOmLcRnSu
# IXsVMYICAjCCAf4CAQEwYTBaMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5TLiBH
# b3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMM
# RE9EIElEIENBLTYzAgMSNG8wCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFBxTQ3MsRH3SMGilkPTe
# lY794A6yMA0GCSqGSIb3DQEBAQUABIIBAFkdj8+RwQDXg6Ce2CXUqYLnvDhFxX6i
# x7fZJh0pfjyIn8ayUbYC2ore89ca2Qaf7dw2gzx8SXPypvcmTH67lanGcXwgh7rd
# dgnqMIGki4hxKq0BPcXuFjsI+DyZX1SCBRm8q60XCp6XyXqxG9J8t6ikL/hrGoao
# 70BHkydJ+FqA3P+t1lSUgqwnKcUC41w6SkFlNqEIqOPfy41eQRFaeiBEBfowCrmv
# Hlf9EIpwK/o5NVWvpLnn/8q8m6jP8ra/nhEJhLQ4D/8rzcAqCU5lMMnoI+kcfMC7
# sRGiJfmKXL72fNrnap5jhi41qHOOLinqEf+ImDcFo+sEtzUz+Sp3vD4=
# SIG # End signature block
