#PURPOSE: This script can modify settings on ESX hosts in order to prepare them for patching.  It was requested by Scott Smith.

#CHANGELOG
#Version 1.00 - 07/16/24 - MDR - Initial version
#Version 1.01 - 11/14/24 - MDR - Change the post-patch Security.PasswordMaxDays to 99999 since right now we are not configuring that to the STIG setting of 90 

#Ensure that $ESXPass is clear at the start of the script
Clear-Variable ESXPass -ErrorAction SilentlyContinue

Clear

#Prompt for whether this is pre or post patch
Write-Host "1 = Configure ESX hosts in preparation for patches"
Write-Host "2 = Return ESX hosts back to original configuration"
$Selection = Read-Host "`nSelection"

#Verify that either 1 or 2 was selected
If (@("1","2") -notcontains $Selection) {
    Write-Host "`nInvalid selection" -ForegroundColor Red
    Break
}

#Ask if this is for a single host or a list
$ServerList = Read-Host "`nEnter the ESX host name or enter LIST if there is a list of them"

#If a list is being imported
If ($ServerList -eq "List") {
    #Load the .NET library for opening dialog windows
    [System.Reflection.Assembly]::LoadWithPartialName("System.windows.forms") | Out-Null

    #Bring up a file browser to select the .txt file of the list
    $FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
        InitialDirectory = "c:\temp"
        Filter = "(*.txt) | *.txt"
    }
    $FileBrowser.ShowDialog() | Out-Null

    #If a file was selected
    If ($FileBrowser -ne $null) {
        #Import the server list
        $ServerList = Get-Content $FileBrowser.FileName
    } Else { #If no file was selected then exit
        Write-Host "No file was selected" -ForegroundColor Red
        Break
    }
}

#Prompt for vCenter Password
$vCenterPass = Read-Host "`nInput the vCenter password" -MaskInput

#Exit if no password was entered
If ($vCenterPass -eq $null) {
    Write-Host "`nNo password was entered so exiting the script"
    Break
}

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#This list is built from the script "Build ESX List.ps1" and will have information in it that is necessary for generating signed cert requests
$ESXHostList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ESXHostList.csv"

#Loop through each ESX host
ForEach ($ESXHostName in $ServerList) {
    #If this is pre-patch
    If ($Selection -eq 1) {
        Write-Host "`nPreparing $ESXHostName for patches" -ForegroundColor Cyan
    } Else { #If this is post-patch
        Write-Host "`nSetting $ESXHostName config back to normal" -ForegroundColor Cyan
    }

    #Get the info for this server
    $ServerInfo = $ESXHostList | Where { $_.SystemName -eq $ESXHostName }

    If ($ServerInfo -eq $null) {
        Write-Host "`nNo ESX info was found for $ESXHostName" -ForegroundColor Red
        Continue
    }

    #Store all of the variables for the ESX host being processed
    $vCenterServerName = $ServerInfo.vCenterServer

    #Only perform a connection attempt to vCenter if it isn't already connected
    If (($global:DefaultVIServers).Name -notcontains $vCenterServerName) {
        #Get the user name that will be used to connect to vCenter
        $vCenterUserName = ($vCenterServerList | Where { $_.ServerName -eq $vCenterServerName }).User

        #Generate the vCenter credentials to connect
        $SecurePassword = ConvertTo-SecureString $vCenterPass -AsPlainText -Force
        $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterUserName, $SecurePassword )

        Try {
            #Disconnected from all vCenter Servers
            Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
        } Catch {}

        #Connect to vCenter Server
        Connect-VIServer $vCenterServerName -Credential $vCenterSecureCreds -ErrorAction SilentlyContinue | Out-Null
        
        #Confirm that the connection worked
        If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServerName })) {
            Write-Host "`nFailed to connect to vCenter Server $vCenterServerName" -ForegroundColor Red
            Break
        }
    }

    #Get ESX Host VMHost data
    $VMHostData = Get-VMHost $ESXHostName

    #Check to see if ESX host is connected in vCenter
    If (@("Connected","Maintenance") -notcontains $VMHostData.ConnectionState) {
        Write-Host "$ESXHostName is not connected in vCenter $vCenterServerName" -ForegroundColor Red
        Continue
    }

    #Get ESX Host Lockdown Data
    $VMHostView = Get-VMHost $ESXHostName | Get-View
    $LockdownView = Get-View $VMHostView.ConfigManager.HostAccessManager

    #If this is pre-patch
    If ($Selection -eq 1) {
        #Disable Lockdown mode
        $LockdownView.ChangeLockdownMode("lockdownDisable")
        #Set the ESX shell timeout to 0
        $VMHostData | Get-AdvancedSetting -Name "UserVars.ESXiShellTimeOut" | Set-AdvancedSetting -Value 0 -Confirm:$false | Out-Null
        #Set the Password Max Days to 99999
        $VMHostData | Get-AdvancedSetting -Name "Security.PasswordMaxDays" | Set-AdvancedSetting -Value 99999 -Confirm:$false | Out-Null
        #Set SSH to start with host
        $VMHostData | Get-VMHostService | Where { $_.Label -eq "SSH" } | Set-VMHostService -Policy On -Confirm:$false | Out-Null
        #Pause for a second to ensure everything is completed before starting the SSH service
        Sleep 1
        #Start the SSH service on the host
        $VMHostData | Get-VMHostService | Where { $_.Label -eq "SSH" } | Start-VMHostService -Confirm:$false | Out-Null

        #Check to see if the CIMService Lockdown exception is in place
        If ($LockdownView.QueryLockdownExceptions() -notcontains "CIMService") {
            $LockdownExceptions = $LockdownView.QueryLockdownExceptions()
            $LockdownExceptions += "CIMService"
            
            #If the exception is not in place then attempt to add it
            Try {
                $LockdownView.UpdateLockdownExceptions($LockdownExceptions)
            } Catch { #If it fails to add then this means that the CIMService account doesn't exist and needs to get added
                Write-Host "`nCIM Service account not found on $ESXHostName.  This script will now create and configure the account" -ForegroundColor Yellow

                #If the ESX password hasn't been entered yet then prompt for it
                If ($ESXPass -eq $null) {
                    #Prompt for ESX Password
                    $ESXPass = Read-Host "`nInput the ESX password" -MaskInput

                    #Generate the ESX credentials to connect
                    $SecurePassword = ConvertTo-SecureString $ESXPass -AsPlainText -Force
                    $ESXSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecurePassword )
                }

                #Connect to ESX Host
                Connect-VIServer $ESXHostName -Credential $ESXSecureCreds -ErrorAction SilentlyContinue -ErrorVariable ConnectError | Out-Null

                #Confirm that the host connected
                If ($global:DefaultVIServers | Where { $_.Name -eq $ESXHostName }) {
                    #Create the CIMRole and CIMService
                    New-VIRole -Server $ESXHostName -Name CIMRole | Out-Null
                    Set-VIRole -Server $ESXHostName -Role CIMRole -AddPrivilege (Get-VIPrivilege -Server $ESXHostName -id "Host.Cim.Ciminteraction") | Out-Null
                    New-VMHostAccount -Server $ESXHostName -Id CIMService -Password "Ms]:Q6qV)bdJL^Db5" -Description "CIM Service" | Out-Null
                    #Update Lockdown exceptions to include CIMService
                    $LockdownView.UpdateLockdownExceptions($LockdownExceptions)
                }

                #Disconnect from ESX Host
                Disconnect-VIServer -Server $ESXHostName -Confirm:$false
            }
        }
    } Else { #If this is post-patch
        #Enable Lockdown mode
        $LockdownView.ChangeLockdownMode("lockdownNormal")
        #Set the ESX shell timeout to 600
        $VMHostData | Get-AdvancedSetting -Name "UserVars.ESXiShellTimeOut" | Set-AdvancedSetting -Value 600 -Confirm:$false | Out-Null
        #Set the Password Max Days to 90
        $VMHostData | Get-AdvancedSetting -Name "Security.PasswordMaxDays" | Set-AdvancedSetting -Value 99999 -Confirm:$false | Out-Null
        #Set SSH to manual
        $VMHostData | Get-VMHostService | Where { $_.Label -eq "SSH" } | Set-VMHostService -Policy Off -Confirm:$false | Out-Null
        #Stop the SSH service on the host
        $VMHostData | Get-VMHostService | Where { $_.Label -eq "SSH" } | Stop-VMHostService -Confirm:$false | Out-Null
    }
}

Try {
    #Disconnected from all vCenter Servers
    Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
} Catch {}

#Notify that the script is completed
Write-Host "`nScript completed" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA5mZ2DxLhusG5Z
# FmF8zVb1RCvLX1OkGMCF68h7YRgFW6CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCA0lo6oJwU7OXhsXVS9L8sf7Sayl9cIqx9jUKoHHzKLzDANBgkq
# hkiG9w0BAQEFAASCAQAbjsu+B2EFoOgrQqEO8+NZr3Llp/Y2UKgY27z6e4Ndz2+f
# DiE22gajZOGbr+k1M59kJovuAKtJrSaClVDxHh+JH51OgbOaLYgU9GN6vAl0Ermd
# XlV6jtuNGquDJ8NzKHWlCSPZaH6NBNvn7NpgnGazJkO4gND3Uebc2Kct2mYr8NXI
# wxaX4EUz4Y83bwDm6VhY0Y+x7xKOCO/5XQTOoHM2yqwJfbdQG7DV6dAPmur4VuA/
# ugLp6CkkNmVlEr6zm73u+LQ9+LLXgfsXG7Rf8k0LGC7cmwX60nP1h6nPzoXHZkzN
# nZYiGOxg1qRu7QN6JRN42Z/cxx6swhpW5VXe93Gr
# SIG # End signature block
