<#
.SYNOPSIS
    Generates HTML Report to audit compliance against the vSphere 6.5 Version 1 Release 1 STIG.
.DESCRIPTION
    -This does not remediate any controls.
    -Not all controls can be checked programatically so this script does not cover those or policy type controls.
    -Controls and be disabled by updating the Vulnerability ID to $false   For example $V94569 = $false.  These are all listed out at the top of the script.
.NOTES
    File Name  : VMware_vSphere_6.5_STIG_Compliance_Report.ps1
    Author     : Ryan Lakey
    Version    : 1.0
    License    : Apache-2.0
    Tested against
    -PowerCLI 11.3
    -Powershell 5
    -ESXi 6.5
#>

[CmdletBinding()]
param (
	[Parameter(Mandatory = $false,
		HelpMessage = 'Enter the Active Directory Admins group to use for administrative access to ESXi')]
	[string]$esxAdminGroup = 'DIR\Enterprise VMware Admins',
	[Parameter(Mandatory = $false,
		HelpMessage = "Enter allowed IP ranges for the ESXi firewall in comma separated format.  For Example `"192.168.0.0/16`",`"10.0.0.0/8`" ")]
	[string[]]$allowedNetworks,
	[Parameter(Mandatory = $false,
		HelpMessage = "Enter allowed IP addresses for the ESXi firewall in comma separated format.  For Example `"192.168.0.1`",`"10.0.0.1`" ")]
	[string[]]$allowedIPs,
	[Parameter(Mandatory = $false,
		HelpMessage = 'Enter the syslog server for the ESXi server(s). Example tcp://log.domain.local:514')]
	$syslogServer = @(read-host -prompt "Syslog/Loginsight Server"),
	[Parameter(Mandatory = $false,
		HelpMessage = 'Specify the native VLAN Id configured on the ports going to the ESXi Hosts.  If none is specified the default of 1 will be used.')]
	[string]$nativeVLAN = '1'
)

#Get Current Date and Time
$date = Get-Date

#Report Name
$ReportName = 'vSphere 6.5 DISA STIG Version 2 Release 2 Compliance Report'

#Create log server address from servername
$logsvr = "ssl://" + $syslogServer + ":1514"

#Report Path - move to parameter later
$ReportOutputPath = 'C:\temp\Output'
$ReportFile = $ReportOutputPath + '\VMware_vSphere_6.5_STIG_Compliance_Report' + '_' + $Date.Month + '-' + $Date.Day + '-' + $Date.Year + '_' + $Date.Hour + '-' + $Date.Minute + '-' + $Date.Second + '.html'

#HTML Report Options
##Tabs to generate for report
$tabarray = @('Overview', 'ESXi')

#Logo Files
[String]$CompanyLogo = 'https://www.vmware.com/content/dam/digitalmarketing/vmware/en/files/images/wmrc/VMware_logo_gry_RGB_72dpi.jpg'
[String]$RightLogo = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQm32Zwz84atzMO6bpguQkTLwCEIrOoPUpfrptbkCGMkiMiCtav'
$ntpservers = 'ntp.ad.dla.mil'
#vSphere 6.5 STIG Settings   Created this up here to make it easier to update settings and values in the future without digging for them down in the code
$stigsettings = @{
        ##### Environment Specific STIG Values #####
        syslogHost            = @{ 'Syslog.global.logHost' = $logsvr }
        stigVibRE             = 'dod-stigvib-65-rd-1.0.0.9744467' #Update with STIG VIB version used
        stigVibRD             = 'dod-stigvib-65-rd-1.0.0.9744467' #Update with STIG VIB version used
        esxAdminsGroup        = @{ 'Config.HostAgent.plugins.hostsvc.esxAdminsGroup' = $esxAdminGroup }
        allowedNetworks       = $allowedNetworks #@("10.0.0.0/8","192.168.0.0/16")  #Allows IP ranges for the ESXi firewall.  These should be in the same order as seen in the UI.
        allowedIPs            = $allowedIPs #@()  #Allows IP addresses if any for the ESXi firewall.  These should be in the same order as seen in the UI.
        ntpServers            = $ntpservers
        esxiLatestBuild       = '19092475'
        nativeVLANid          = $nativeVLAN #"1"
        adDomain              = 'dir.ad.dla.mil'
        certAuthName          = 'OU=DoD,O=U.S. Government,C=US' #certificate authority issuer name  For example "O=U.S. Government"
        ## ESXi
        DCUIAccess            = @{ 'DCUI.Access' = 'root' }
        vibacceptlevel        = 'PartnerSupported' #VIB Acceptance level CommunitySupported,PartnerSupported,VMwareAccepted,VMwareCertified
        accountLockFailures   = @{ 'Security.AccountLockFailures' = '3' }
        accountUnlockTime     = @{ 'Security.AccountUnlockTime' = '900' }
        logLevel              = @{ 'Config.HostAgent.log.level' = 'info' }
        enableMob             = @{ 'Config.HostAgent.plugins.solo.enableMob' = $false }
        shellIntTimeout       = @{ 'UserVars.ESXiShellInteractiveTimeOut' = '120' }
        shellTimeout          = @{ 'UserVars.ESXiShellTimeOut' = '0' }
        DCUITImeout           = @{ 'UserVars.DcuiTimeOut' = '120' }
        ShareForceSalting     = @{ 'Mem.ShareForceSalting' = '2' }
        BlockGuestBPDU        = @{ 'Net.BlockGuestBPDU' = '1' }
        DVFilterBindIpAddress = @{ 'Net.DVFilterBindIpAddress' = '' }
        syslogScratch         = @{ 'Syslog.global.logDir' = '[] /scratch/log' }
        sslProtocols          = @{ 'UserVars.ESXiVPsDisabledProtocols' = 'sslv3,tlsv1,tlsv1.1' }
        passHistory           = @{ 'Security.PasswordHistory' = '5' }
        passComplexity        = @{ 'Security.PasswordQualityControl' = 'similar=deny retry=3 min=disabled,disabled,disabled,disabled,15' }
        banner                = @{ 'Config.Etc.issue' = 'You are accessing a U.S. Government (USG) Information System (IS) that is provided for USG-authorized use only. By using this IS (which includes any device attached to this IS), you consent to the following conditions: -The USG routinely intercepts and monitors communications on this IS for purposes including, but not limited to, penetration testing, COMSEC monitoring, network operations and defense, personnel misconduct (PM), law enforcement (LE), and counterintelligence (CI) investigations. -At any time, the USG may inspect and seize data stored on this IS. -Communications using, or data stored on, this IS are not private, are subject to routine monitoring, interception, and search, and may be disclosed or used for any USG-authorized purpose. -This IS includes security measures (e.g., authentication and access controls) to protect USG interests--not for your personal benefit or privacy. -Notwithstanding the above, using this IS does not constitute consent to PM, LE or CI investigative searching or monitoring of the content of privileged communications, or work product, related to personal representation or services by attorneys, psychotherapists, or clergy, and their assistants. Such communications and work product are private and confidential. See User Agreement for details.' }
        SuppressShellWarning  = @{ 'UserVars.SuppressShellWarning' = 0 }
}

#ESXi
$V239258 = $true #Lockdown Mode V93949 ESXI-65-000001
$V239259 = $true #DCUI.Access List V93951 ESXI-65-000002
$V239260 = $true #Lockdown Mode Exceptions V93953 ESXI-65-000003
$V239261 = $true #Syslog V93955 ESXI-65-000004
$V239262 = $true #Account Lock Failures V93957 ESXI-65-000005
$V239263 = $true #Account Unlock Timeout V93959 ESXI-65-000006
$V239264 = $true #Consent Banner Welcome V93961 ESXI-65-000007
$V239265 = $true #Consent Banner /etc/issue V93963 ESXI-65-000008
$V239266 = $true #SSH Banner V93965 ESXI-65-000009
$V239267 = $true #SSH Ciphers aes128-ctr,aes192-ctr,aes256-ctr V93967 ESXI-65-000010
#$V93969 = $true  #SSH Protocol 2 V93969 ESXI-65-000011 #Removed
$V239268 = $true #SSH IgnoreRhosts yes V93971 ESXI-65-000012
$V239269 = $true #SSH HostbasedAuthentication no V93973 ESXI-65-000013
$V239270 = $true #SSH PermitRootLogin no V93975 ESXI-65-000014
$V239271 = $true #SSH PermitEmptyPasswords no V93977 ESXI-65-000015
$V239272 = $true #SSH PermitUserEnvironment no V93979 ESXI-65-000016
#$V93981 = $true  #SSH MACs hmac-sha1,hmac-sha2-256,hmac-sha2-512 V93981 #Removed
$V239273 = $true #SSH GSSAPIAuthentication no V93983 ESXI-65-000018
$V239274 = $true #SSH KerberosAuthentication no V93985 ESXI-65-000019
$V239275 = $true #SSH StrictModes yes V93987 ESXI-65-000020
$V239276 = $true #SSH Compression no V93989 ESXI-65-000021
$V239277 = $true #SSH GatewayPorts no V93991 ESXI-65-000022
$V239278 = $true #SSH X11Forwarding no V93993 ESXI-65-000023
$V239279 = $true #SSH AcceptEnv no V93995 ESXI-65-000024
$V239280 = $true #SSH PermitTunnel no V93997 ESXI-65-000025
$V239281 = $true #SSH ClientAliveCountMax 3 V93999 ESXI-65-000026
$V239282 = $true #SSH ClientAliveInterval 200 V94001 ESXI-65-000027
$V239283 = $true #SSH MaxSessions 1 V94003 ESXI-65-000028
$V239284 = $true #Authorized Keys V94005 ESXI-65-000029
$V239285 = $true #Log Level V94007 ESXI-65-000030
$V239286 = $true #Password Complexity V94009 ESXI-65-000031
$V239287 = $true #Password Reuse V94011 ESXI-65-000032
$V239288 = $true #Password Hashes V94013 ESXI-65-000033
$V239289 = $true #Mob V94015 ESXI-65-000034
$V239290 = $true #SSH Running V94017 ESXI-65-000035
$V239291 = $true #disable ESXi Shell V94019 ESXI-65-000036
$V239292 = $true #Active Directory V94021 ESXI-65-000037
$V239293 = $true #Authentication Proxy V94023 ESXI-65-000038
$V239294 = $true #AD Admin Group V94025 ESXI-65-000039
$V239295 = $true #2FA multifactor authentication for local DCUI access V94027 ESXI-65-000040___
$V239296 = $true #Shell Interactive Timeout V94029 ESXI-65-000041
$V239297 = $true #Shell Timeout V94031 ESXI-65-000042
$V239298 = $true #DCUI Timeout V94033 ESXI-65-000043
$V239299 = $true #Core Dumps V94035 ESXI-65-000044
$V239300 = $true #Persistent Logs V94037 ESXI-65-000045
$V239301 = $true #NTP V94039 ESXI-65-000046
$V239302 = $true #Acceptance Level V94041 ESXI-65-000047
$V239303 = $true #Isolate vMotion V94043 ESXI-65-000048
$V239304 = $true #Protect Management V94045 ESXI-65-000049
$V239305 = $true #Protect Storage traffic V94047 ESXI-65-000050
$V94049 = $true  #VMK Separation #Removed from 6.5
$V239306 = $true #TCP/IP Stacks V94051 ESXI-65-000052
$V239307 = $true #SNMP V94053 ESXI-65-000053
$V239308 = $true #iSCSI CHAP V94055 ESXI-65-000054
$V239309 = $true #Memory Salting V94057 ESXI-65-000055
$V239310 = $False #Firewall Rules V94059 ESXI-65-000056
$V239311 = $False #Default Firewall V94061 ESXI-65-000057
$V239312 = $true #BPDU V94063 ESXI-65-000058
$V239313 = $true #Forged Transmits V94065 ESXI-65-000059
$V239314 = $true #MAC Changes V94067 ESXI-65-000060
$V239315 = $true #Prom Mode V94069 ESXI-65-000061
$V239316 = $true #dvFilter V94071 ESXI-65-000062
$V239317 = $true #Native VLAN V94073 ESXI-65-000063
$V239318 = $true #VLAN 4095 V94075 ESXI-65-000064
$V239319 = $true #Reserved VLANs V94077 ESXI-65-000065
$V239320 = $true #DTP V94079 ESXI-65-000066
$V239321 = $true #STP V94081 ESXI-65-000067
$V239322 = $true #Required VLANs V94083 ESXI-65-000068
$V239323 = $true #CIM Account V94349 ESXI-65-000070
$V239324 = $true #Checksum V94477 ESXI-65-000071
$V239325 = $true #Patch Level V94479 ESXI-65-000072
$V94481 = $true  #TLS 1.2 SFCB
$V239326 = $true #TLS 1.2 ipFilter vSAN V94483 ESXI-65-000074
$V94485 = $true  #TLS 1.2 authd
$V239327 = $true #Secureboot V94487 ESXI-65-000076
$V239328 = $true #DoD Cert V94489 ESXI-65-000078
$V239329 = $true #host must not suppress warnings ESXI-65-000079 NEW
$V239330 = $true #central log host ESXI-65-100004 NEW
$V239331 = $true #FIPS-approved ciphers ESXI-65-100010 NEW


#Modules needed to run script and load
$modules = @('VMware.PowerCLI', 'ReportHTMLV2.0.1')

#Check for correct modules
Function checkModule ($m) {
	if (Get-Module | Where-Object { $_.Name -eq $m }) {
		Write-ToConsole "...Module $m is already imported."
	}
	else {
		Write-ToConsole "...Trying to import module $m"
		Import-Module $m | out-null
	}
}

Function Test-WebServerSSL {
	[CmdletBinding()]
	param (
		[Parameter(Mandatory = $true, ValueFromPipeline = $true, Position = 0)]
		[string]$URL,
		[Parameter(Position = 1)]
		[ValidateRange(1, 65535)]
		[int]$Port = 443,
		[Parameter(Position = 2)]
		[Net.WebProxy]$Proxy,
		[Parameter(Position = 3)]
		[int]$Timeout = 15000,
		[switch]$UseUserContext
	)
	Add-Type @'
    using System;
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    namespace PKI {
        namespace Web {
            public class WebSSL {
                public Uri OriginalURi;
                public Uri ReturnedURi;
                public X509Certificate2 Certificate;
                //public X500DistinguishedName Issuer;
                //public X500DistinguishedName Subject;
                public string Issuer;
                public string Subject;
                public string[] SubjectAlternativeNames;
                public bool CertificateIsValid;
                //public X509ChainStatus[] ErrorInformation;
                public string[] ErrorInformation;
                public HttpWebResponse Response;
            }
        }
    }
'@
	$ConnectString = "https://$url`:$port"
	$WebRequest = [Net.WebRequest]::Create($ConnectString)
	$WebRequest.Proxy = $Proxy
	$WebRequest.Credentials = $null
	$WebRequest.Timeout = $Timeout
	$WebRequest.AllowAutoRedirect = $true
	[Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
	try { $Response = $WebRequest.GetResponse() }
	catch { }
	if ($WebRequest.ServicePoint.Certificate -ne $null) {
		$Cert = [Security.Cryptography.X509Certificates.X509Certificate2]$WebRequest.ServicePoint.Certificate.Handle
		try { $SAN = ($Cert.Extensions | Where-Object { $_.Oid.Value -eq '2.5.29.17' }).Format(0) -split ', ' }
		catch { $SAN = $null }
		$chain = New-Object Security.Cryptography.X509Certificates.X509Chain -ArgumentList (!$UseUserContext)
		[void]$chain.ChainPolicy.ApplicationPolicy.Add('1.3.6.1.5.5.7.3.1')
		$Status = $chain.Build($Cert)
		New-Object PKI.Web.WebSSL -Property @{
			OriginalUri             = $ConnectString;
			ReturnedUri             = $Response.ResponseUri;
			Certificate             = $WebRequest.ServicePoint.Certificate;
			Issuer                  = $WebRequest.ServicePoint.Certificate.Issuer;
			Subject                 = $WebRequest.ServicePoint.Certificate.Subject;
			SubjectAlternativeNames = $SAN;
			CertificateIsValid      = $Status;
			Response                = $Response;
			ErrorInformation        = $chain.ChainStatus | ForEach-Object { $_.Status }
		}
		$chain.Reset()
		[Net.ServicePointManager]::ServerCertificateValidationCallback = $null
	}
	else {
		Write-Error $Error[0]
	}
}
Function Write-ToConsole ($Details) {
	$LogDate = Get-Date -Format T
	Write-Host "$($LogDate) $Details"
}
Function Write-ToConsoleRed ($Details) {
	$LogDate = Get-Date -Format T
	Write-Host "$($LogDate) $Details" -ForegroundColor Red
}
Function Select-Vcenter {
	Add-Type -AssemblyName System.Windows.Forms
[System.Windows.Forms.Application]::EnableVisualStyles()

$Form                            = New-Object system.Windows.Forms.Form
$Form.ClientSize                 = New-Object System.Drawing.Point(400,400)
$Form.text                       = "Form"
$Form.TopMost                    = $false

$ListBox1                        = New-Object system.Windows.Forms.ListBox
$ListBox1.text                   = "listBox"
$ListBox1.width                  = 318
$ListBox1.height                 = 144
$ListBox1.location               = New-Object System.Drawing.Point(24,118)

$OK                              = New-Object system.Windows.Forms.Button
$OK.text                         = "OK"
$OK.width                        = 60
$OK.height                       = 30
$OK.location                     = New-Object System.Drawing.Point(85,286)
$OK.Font                         = New-Object System.Drawing.Font('Microsoft Sans Serif',10)

$Cancel                          = New-Object system.Windows.Forms.Button
$Cancel.text                     = "Cancel"
$Cancel.width                    = 60
$Cancel.height                   = 30
$Cancel.location                 = New-Object System.Drawing.Point(205,286)
$Cancel.Font                     = New-Object System.Drawing.Font('Microsoft Sans Serif',10)

$Label1                          = New-Object system.Windows.Forms.Label
$Label1.text                     = "Select a Vcenter Server"
$Label1.AutoSize                 = $true
$Label1.width                    = 25
$Label1.height                   = 10
$Label1.location                 = New-Object System.Drawing.Point(24,66)
$Label1.Font                     = New-Object System.Drawing.Font('Microsoft Sans Serif',10)

$Form.controls.AddRange(@($ListBox1,$OK,$Cancel,$Label1))

$OK.Add_Click({$global:x = $ListBox1.SelectedItem
    $form.Close()
    })
$Cancel.Add_Click({$Form.Close()})
$ListBox1.Add_AutoSizeChanged({  })
$ListBox1.Add_BackColorChanged({  })
$ListBox1.Add_ClientSizeChanged({  })
$ListBox1.Add_DoubleClick({$global:x = $ListBox1.SelectedItem
    $form.Close()
})
$ListBox1.Add_Enter({  })
$ListBox1.Add_KeyDown({  })
$Form.Add_Activated({  })
$Form.Add_Paint({  })
$Form.Add_Scroll({  })

#region Logic
	[void] $ListBox1.Items.Add('DAISV0PP212.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('TRISV0PP212.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('KLISV0PP212.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('DAISV0TP212.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('DAISV0PP202.ics.dla.mil')
	[void] $ListBox1.Items.Add('TRISV0PP202.ics.dla.mil')
	[void] $ListBox1.Items.Add('DAISV0PP222.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('DAISV0PP223.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('TRISV0PP222.dir.ad.dla.mil')
	[void] $ListBox1.Items.Add('TRISV0PP223.dir.ad.dla.mil')
#endregion

[void]$Form.ShowDialog()

$global:x
}



Function Write-ToConsoleGreen ($Details) {
	$LogDate = Get-Date -Format T
	Write-Host "$($LogDate) $Details" -ForegroundColor Green
}

#Add type to trust all certificates during checks otherwise some items will fail
If (-not [System.Net.ServicePointManager].DeclaredProperties | Where-Object { $_.name -eq 'CertificatePolicy' }) {
	Add-Type @'
    using System.Net;
    using System.Security.Cryptography.X509Certificates;
    public class TrustAllCertsPolicy : ICertificatePolicy {
        public bool CheckValidationResult(
            ServicePoint srvPoint, X509Certificate certificate,
            WebRequest request, int certificateProblem) {
            return true;
        }
    }
'@
	[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
}

#Load Modules
Try {
	ForEach ($module in $modules) {
		Write-ToConsole "...checking for $module"
		checkModule $module
	}
}
Catch {
	Write-Error 'Failed to load modules'
	Write-Error $_.Exception
}

#Test report path
Try {
	If (Test-Path -Path $ReportOutputPath) {
		Write-ToConsole "...Validated path for report at $ReportOutputPath"
	}
	Else {
		Write-ToConsole "...Report path $ReportOutputPath doesn't exist...attempting to create..."
		New-Item -ItemType Directory -Path $ReportOutputPath -Force -ErrorAction Stop
	}
}
Catch {
	Write-Error 'Failed to validate or create specified report directory'
	Write-Error $_.Exception
}

#Connect to vCenter
Try {

	$get_vcenter = Select-Vcenter
	Write-ToConsole "...Connecting to vCenter $get_vcenter"
    $vccred = get-credential -message 'Credentials for Vcenter'

	Connect-VIServer -Server $global:x -Credential $vccred -Protocol https
}
Catch {
	Write-Error "Failed to connect to $vcenter"
	Write-Error $_.Exception
    exit
}

#Initiate Variables
$report = @()

#Gather vCenter, ESXi, and VM Info
Try {
	Write-ToConsole "...Gathering info on target hosts in $vcenter"
	$vmhosts = Get-VMHost | Where-Object { $_.version -match '6.5' } | Where-Object { $_.connectionstate -ne 'Disconnected' } | Where-Object { $_.connectionstate -ne 'NotResponding' } | Sort-Object -Property Name -ErrorAction Stop
	$vmhostsv = $vmhosts | Get-View | Sort-Object -Property Name -ErrorAction Stop
	Write-ToConsole "...Gathering info on target virtual machines in $vcenter"
	$vms = Get-VM | Sort-Object -Property Name -ErrorAction Stop
	$vmsv = $vms | Get-View | Sort-Object -Property Name -ErrorAction Stop
	Write-ToConsole "...Gathering info on $vcenter"
	$datastores = Get-Datastore | Sort-Object -Property Name -ErrorAction Stop
	$clusters = Get-Cluster | Sort-Object -Property Name -ErrorAction Stop
	$vdswitches = Get-VDSwitch | Sort-Object -Property Name -ErrorAction Stop
	$dportgroups = Get-VDPortgroup | Where-Object { $_.IsUplink -eq $false } | Sort-Object -Property Name -ErrorAction Stop
}
Catch {
	Write-Error "Failed to gather info on environment in $vcenter"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}


#ESXi Processing
#Initialize array for all ESXi report data
$vmhostsarrayall = @()

## ESXI-65-000001
Try {
	$VULID = 'V-239258'
	$STIGID = 'ESXI-65-000001'
	$Title = 'The ESXi host must limit the number of concurrent sessions to ten for all accounts and/or account types by enabling lockdown mode.'
	$Severity = 'CAT II'
	If ($V239258) {
		$esxititle01 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			If ($vmhost.config.LockdownMode -eq 'lockdownDisabled') {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Lockdown Mode'
						'Value'     = $vmhost.config.LockdownMode
						'Expected'  = 'lockdownNormal or lockdownStrict'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Lockdown Mode'
						'Value'     = $vmhost.config.LockdownMode
						'Expected'  = 'lockdownNormal or lockdownStrict'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
		}
		$esxiarray01 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant01 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000002
Try {
	$VULID = 'V-239259'
	$STIGID = 'ESXI-65-000002'
	$Title = 'The ESXi host must verify the DCUI.Access list.'
	$Severity = 'CAT III'
	If ($V239259) {
		$esxititle02 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = [string]$stigSettings.DCUIAccess.Keys
		$settingvalue = [string]$stigsettings.DCUIAccess.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray02 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant02 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000003
Try {
	$VULID = 'V-239260'
	$STIGID = 'ESXI-65-000003'
	$Title = 'The ESXi host must verify the exception users list for lockdown mode.'
	$Severity = 'CAT III'
	If ($V239260) {
		$esxititle03 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$lockdown = Get-View $vmhost.ConfigManager.HostAccessManager
			$exceptions = $lockdown.QueryLockdownExceptions()
			If ($exceptions) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Lockdown Mode Exceptions'
						'Value'     = & { If ($exceptions) { ([String]::Join(',', $exceptions)) }
							else { 'No users found.' } }
						'Expected'  = 'No exception users found or are documented'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Lockdown Mode Exceptions'
						'Value'     = & { If ($exceptions) { ([String]::Join(',', $exceptions)) }
							else { 'No users found.' } }
						'Expected'  = 'No exception users found or are documented'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
		}
		$esxiarray03 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant03 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000004
Try {
	$VULID = 'V-239261'
	$STIGID = 'ESXI-65-000004'
	$Title = 'Remote logging for ESXi hosts must be configured.'
	$Severity = 'CAT II'
	If ($V239261) {
		$esxititle04 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = [string]$stigsettings.syslogHost.Keys
		$settingvalue = [string]$stigsettings.syslogHost.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Ojbect { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray04 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant03 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000005
Try {
	$VULID = 'V-239262'
	$STIGID = 'ESXI-65-000005'
	$Title = 'The ESXi host must enforce the limit of three consecutive invalid logon attempts by a user.'
	$Severity = 'CAT II'
	If ($V239262) {
		$esxititle05 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = [string]$stigsettings.accountLockFailures.Keys
		$settingvalue = [string]$stigsettings.accountLockFailures.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray05 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant05 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000006
Try {
	$VULID = 'V-239263'
	$STIGID = 'ESXI-65-000006'
	$Title = 'The ESXi host must enforce the unlock timeout of 15 minutes after a user account is locked out.'
	$Severity = 'CAT II'
	If ($V239263) {
		$esxititle06 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = [string]$stigsettings.accountUnlockTime.Keys
		$settingvalue = [string]$stigsettings.accountUnlockTime.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray06 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant06 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000007
Try {
	$VULID = 'V-239264'
	$STIGID = 'ESXI-65-000007'
	$Title = 'The ESXi host must display the Standard Mandatory DoD Notice and Consent Banner before granting access to the system.'
	$Severity = 'CAT II'
	If ($V239264) {
		$esxititle07 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Annotations.WelcomeMessage'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Annotations.WelcomeMessage'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray07 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant07 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000008
Try {
	$VULID = 'V-239265'
	$STIGID = 'ESXI-65-000008'
	$Title = 'The ESXi host must display the Standard Mandatory DoD Notice and Consent Banner before granting access to the system.'
	$Severity = 'CAT II'
	If ($V239265) {
		$esxititle08 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.banner.Keys
		$settingvalue = [string]$stigsettings.banner.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray08 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant08 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000009
Try {
	$VULID = 'V-239266'
	$STIGID = 'ESXI-65-000009'
	$Title = 'The ESXi host SSH daemon must be configured with the Department of Defense (DoD) login banner.'
	$Severity = 'CAT II'
	If ($V239266) {
		$esxititle09 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Banner /etc/issue'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Banner /etc/issue'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray09 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant09 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000010
Try {
	$VULID = 'V-239267'
	$STIGID = 'ESXI-65-000010'
	$Title = 'The ESXi host SSH daemon must use DoD-approved encryption to protect the confidentiality of remote access sessions.'
	$Severity = 'CAT II'
	If ($V239267) {
		$esxititle10 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Ciphers aes128-ctr,aes192-ctr,aes256-ctr'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Ciphers aes128-ctr,aes192-ctr,aes256-ctr'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray10 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant10 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000011
Try {
	$VULID = 'V-93969'
	$STIGID = 'ESXI-65-000011'
	$Title = 'The ESXi host SSH daemon must be configured to use only the SSHv2 protocol.'
	$Severity = 'CAT I'
	If ($V93969) {
		$esxititle11 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Protocol 2'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Protocol 2'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray11 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant11 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000012
Try {
	$VULID = 'V-239268'
	$STIGID = 'ESXI-65-000012'
	$Title = 'The ESXi host SSH daemon must ignore .rhosts files.'
	$Severity = 'CAT II'
	If ($V239268) {
		$esxititle12 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'IgnoreRhosts yes'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'IgnoreRhosts yes'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray12 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant12 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000013
Try {
	$VULID = 'V-239269'
	$STIGID = 'ESXI-65-000013'
	$Title = 'The ESXi host SSH daemon must not allow host-based authentication.'
	$Severity = 'CAT II'
	If ($V239269) {
		$esxititle13 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'HostbasedAuthentication no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'HostbasedAuthentication no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray13 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant13 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"
}

## ESXI-65-000014
Try {
	$VULID = 'V-239270'
	$STIGID = 'ESXI-65-000014'
	$Title = 'The ESXi host SSH daemon must not allow host-based authentication.'
	$Severity = 'CAT III'
	If ($V239270) {
		$esxititle14 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results.name -eq $stigsettings.stigVibRD) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitRootLogin no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB RD Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			ElseIf ($results.name -eq $stigsettings.stigVibRE) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitRootLogin no'
						'Value'     = "STIG VIB $($results.name) and root ssh logins are enabled!"
						'Expected'  = 'STIG VIB RD Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitRootLogin no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB RD Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray14 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant14 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000015
Try {
	$VULID = 'V-239271'
	$STIGID = 'ESXI-65-000015'
	$Title = 'The ESXi host SSH daemon must not allow authentication using an empty password.'
	$Severity = 'CAT I'
	If ($V239271) {
		$esxititle15 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitEmptyPasswords no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitEmptyPasswords no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray15 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant15 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000016
Try {
	$VULID = 'V-239272'
	$STIGID = 'ESXI-65-000016'
	$Title = 'The ESXi host SSH daemon must not permit user environment settings.'
	$Severity = 'CAT II'
	If ($V239272) {
		$esxititle16 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitUserEnvironment no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitUserEnvironment no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray16 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant02 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000017
Try {
	$VULID = 'V-93981'
	$STIGID = 'ESXI-65-000017'
	$Title = 'The ESXi host SSH daemon must be configured to only use Message Authentication Codes (MACs) employing FIPS 140-2 approved cryptographic hash algorithms.'
	$Severity = 'CAT II'
	If ($V93981) {
		$esxititle17 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'MACs hmac-sha1,hmac-sha2-256,hmac-sha2-512'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'MACs hmac-sha1,hmac-sha2-256,hmac-sha2-512'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray17 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant17 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000018
Try {
	$VULID = 'V-239273'
	$STIGID = 'ESXI-65-000018'
	$Title = 'The ESXi host SSH daemon must not permit GSSAPI authentication.'
	$Severity = 'CAT III'
	If ($V239273) {
		$esxititle18 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'GSSAPIAuthentication no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'GSSAPIAuthentication no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray18 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant18 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000019
Try {
	$VULID = 'V-239274'
	$STIGID = 'ESXI-65-000019'
	$Title = 'The ESXi host SSH daemon must not permit Kerberos authentication.'
	$Severity = 'CAT III'
	If ($V239274) {
		$esxititle19 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'KerberosAuthentication no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'KerberosAuthentication no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray19 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant19 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000020
Try {
	$VULID = 'V-239275'
	$STIGID = 'ESXI-65-000020'
	$Title = 'The ESXi host SSH daemon must perform strict mode checking of home directory configuration files.'
	$Severity = 'CAT II'
	If ($V239275) {
		$esxititle20 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'StrictModes yes'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'StrictModes yes'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray20 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant20 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000021
Try {
	$VULID = 'V-239276'
	$STIGID = 'ESXI-65-000021'
	$Title = 'The ESXi host SSH daemon must not allow compression or must only allow compression after successful authentication.'
	$Severity = 'CAT II'
	If ($V239276) {
		$esxititle21 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Compression no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Compression no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray21 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant21 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000022
Try {
	$VULID = 'V-239277'
	$STIGID = 'ESXI-65-000022'
	$Title = 'The ESXi host SSH daemon must be configured to not allow gateway ports.'
	$Severity = 'CAT III'
	If ($V239277) {
		$esxititle22 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'GatewayPorts no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'GatewayPorts no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray22 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant22 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000023
Try {
	$VULID = 'V-239278'
	$STIGID = 'ESXI-65-000023'
	$Title = 'The ESXi host SSH daemon must be configured to not allow X11 forwarding.'
	$Severity = 'CAT II'
	If ($V239278) {
		$esxititle23 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'X11Forwarding no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'X11Forwarding no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray23 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant23 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000024
Try {
	$VULID = 'V-239279'
	$STIGID = 'ESXI-65-000024'
	$Title = 'The ESXi host SSH daemon must not accept environment variables from the client.'
	$Severity = 'CAT II'
	If ($V239279) {
		$esxititle24 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'AcceptEnv'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'AcceptEnv'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray24 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant24 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000025
Try {
	$VULID = 'V-239280'
	$STIGID = 'ESXI-65-000025'
	$Title = 'The ESXi host SSH daemon must not permit tunnels.'
	$Severity = 'CAT II'
	If ($V239280) {
		$esxititle25 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitTunnel no'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'PermitTunnel no'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray25 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant25 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000026
Try {
	$VULID = 'V-239281'
	$STIGID = 'ESXI-65-000026'
	$Title = 'The ESXi host SSH daemon must set a timeout count on idle sessions.'
	$Severity = 'CAT III'
	If ($V239281) {
		$esxititle26 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'ClientAliveCountMax 3'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'ClientAliveCountMax 3'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray26 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant26 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000027
Try {
	$VULID = 'V-239282'
	$STIGID = 'ESXI-65-000027'
	$Title = 'The ESXi hostSSH daemon must set a timeout interval on idle sessions.'
	$Severity = 'CAT III'
	If ($V239282) {
		$esxititle27 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'ClientAliveInterval 200'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'ClientAliveInterval 200'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray27 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant27 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000028
Try {
	$VULID = 'V-239283'
	$STIGID = 'ESXI-65-000028'
	$Title = 'The ESXi host SSH daemon must limit connections to a single session.'
	$Severity = 'CAT II'
	If ($V239283) {
		$esxititle28 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'MaxSessions 1'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'MaxSessions 1'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray28 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant28 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000029
Try {
	$VULID = 'V-239284'
	$STIGID = 'ESXI-65-000029'
	$Title = 'The ESXi host must remove keys from the SSH authorized_keys file.'
	$Severity = 'CAT II'
	If ($V239284) {
		$esxititle29 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$results = Invoke-WebRequest -Uri "https://$($vmhost.name)/host/ssh_root_authorized_keys" -Method Get -Credential $esxicred
			If ($results.Content.length -gt 1) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'SSH Authorized Keys'
						'Value'     = $results.Content.substring(0, 20)
						'Expected'  = 'Empty File'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'SSH Authorized Keys'
						'Value'     = $results.Content
						'Expected'  = 'Empty File'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
		}
		$esxiarray29 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant29 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsole "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000030
Try {
	$VULID = 'V-239285'
	$STIGID = 'ESXI-65-000030'
	$Title = 'The ESXi host must produce audit records containing information to establish what type of events occurred.'
	$Severity = 'CAT III'
	If ($V239285) {
		$esxititle30 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.logLevel.Keys
		$settingvalue = [string]$stigsettings.logLevel.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray30 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant30 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000031
Try {
	$VULID = 'V-239286'
	$STIGID = 'ESXI-65-000031'
	$Title = 'The ESXi host must enforce password complexity by requiring that at least one upper-case character be used.'
	$Severity = 'CAT II'
	If ($V239286) {
		$esxititle31 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.passComplexity.Keys
		$settingvalue = [string]$stigsettings.passComplexity.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray31 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant31 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000032
Try {
	$VULID = 'V-239287'
	$STIGID = 'ESXI-65-000032'
	$Title = 'The ESXi host must prohibit the reuse of passwords within five iterations.'
	$Severity = 'CAT II'
	If ($V239287) {
		$esxititle32 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.passHistory.Keys
		$settingvalue = [string]$stigsettings.passHistory.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray32 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant32 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000033
Try {
	$VULID = 'V-239288'
	$STIGID = 'ESXI-65-000033'
	$Title = 'The password hashes stored on the ESXi host must have been generated using a FIPS 140-2 approved cryptographic hashing algorithm.'
	$Severity = 'CAT II'
	If ($V239288) {
		$esxititle33 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'sha512'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'sha512'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray33 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant33 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000034
Try {
	$VULID = 'V-239289'
	$STIGID = 'ESXI-65-000034'
	$Title = 'The ESXi host must disable the Managed Object Browser (MOB).'
	$Severity = 'CAT II'
	If ($V239289) {
		$esxititle34 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.enableMob.Keys
		$settingvalue = [string]$stigsettings.enableMob.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray34 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant34 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000035
Try {
	$VULID = 'V-239290'
	$STIGID = 'ESXI-65-000035'
	$Title = 'The ESXi host must be configured to disable non-essential capabilities by disabling SSH.'
	$Severity = 'CAT II'
	If ($V239290) {
		$esxititle35 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		$servicename = 'SSH'
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$vmhostservice = $vmhost | Get-VMHostService | Where-Object { $_.Label -eq $servicename }
			If ($vmhostservice.Running -eq $true) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'SSH Service Running'
						'Value'     = $vmhostservice.Running
						'Expected'  = $false
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'SSH Service Running'
						'Value'     = $vmhostservice.Running
						'Expected'  = $false
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
		}
		$esxiarray35 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant35 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000036
Try {
	$VULID = 'V-239291'
	$STIGID = 'ESXI-65-000036'
	$Title = 'The ESXi host must disable ESXi Shell unless needed for diagnostics or troubleshooting.'
	$Severity = 'CAT II'
	If ($V239291) {
		$esxititle36 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		$servicename = 'ESXi Shell'
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$vmhostservice = $vmhost | Get-VMHostService | Where-Object { $_.Label -eq $servicename }
			If ($vmhostservice.Running -eq $true) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'SSH Service Running'
						'Value'     = $vmhostservice.Running
						'Expected'  = $false
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'SSH Service Running'
						'Value'     = $vmhostservice.Running
						'Expected'  = $false
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
		}
		$esxiarray36 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant36 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000037
Try {
	$VULID = 'V-239292'
	$STIGID = 'ESXI-65-000037'
	$Title = 'The ESXi host must use Active Directory for local user authentication.'
	$Severity = 'CAT III'
	If ($V239292) {
		$esxititle37 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$adstatus = $vmhost | Get-VMHostAuthentication
			If ($adstatus.DomainMembershipStatus -ne 'Ok' -and $adstatus.Domain -ne $stigsettings.adDomain) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'                   = $vmhost.name
						'Domain'                 = $adstatus.Domain
						'DomainMembershipStatus' = $adstatus.DomainMembershipStatus
						'ExpectedStatus'         = 'Ok'
						'ExpectedDomain'         = $stigsettings.adDomain
						'Severity'               = $Severity
						'Compliant'              = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'                   = $vmhost.name
						'Domain'                 = $adstatus.Domain
						'DomainMembershipStatus' = $adstatus.DomainMembershipStatus
						'ExpectedStatus'         = 'Ok'
						'ExpectedDomain'         = $stigsettings.adDomain
						'Severity'               = $Severity
						'Compliant'              = $true
					})
			}
		}
		$esxiarray37 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant37 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsole "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000038
Try {
	$VULID = 'V-239293'
	$STIGID = 'ESXI-65-000038'
	$Title = 'The ESXi host must use the vSphere Authentication Proxy to protect passwords when adding ESXi hosts to Active Directory.'
	$Severity = 'CAT II'
	If ($V239293) {
		$esxititle38 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
		}
		$esxiarray38 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant38 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000039
Try {
	$VULID = 'V-239294'
	$STIGID = 'ESXI-65-000039'
	$Title = 'Active Directory ESX Admin group membership must not be used when adding ESXi hosts to Active Directory.'
	$Severity = 'CAT III'
	If ($V239294) {
		$esxititle39 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.esxAdminsGroup.Keys
		$settingvalue = [string]$stigsettings.esxAdminsGroup.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray39 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant39 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000041
Try {
	$VULID = 'V-239296'
	$STIGID = 'ESXI-65-000041'
	$Title = 'The ESXi host must set a timeout to automatically disable idle sessions after 10 minutes.'
	$Severity = 'CAT II'
	If ($V239296) {
		$esxititle41 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.shellIntTimeout.Keys
		$settingvalue = [string]$stigsettings.shellIntTimeout.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray41 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant41 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000042
Try {
	$VULID = 'V-239297'
	$STIGID = 'ESXI-65-000042'
	$Title = 'The ESXi host must terminate shell services after 10 minutes.'
	$Severity = 'CAT II'
	If ($V239297) {
		$esxititle42 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.shellTimeout.Keys
		$settingvalue = [string]$stigsettings.shellTimeout.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray42 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant42 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000043
Try {
	$VULID = 'V-239298'
	$STIGID = 'ESXI-65-000043'
	$Title = 'The ESXi host must logout of the console UI after 10 minutes.'
	$Severity = 'CAT II'
	If ($V239298) {
		$esxititle43 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.DcuiTimeOut.Keys
		$settingvalue = [string]$stigsettings.DcuiTimeOut.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray43 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant43 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000044
Try {
	$VULID = 'V-239299'
	$STIGID = 'ESXI-65-000044'
	$Title = 'The ESXi host must enable kernel core dumps.'
	$Severity = 'CAT III'
	If ($V239299) {
		$esxititle44 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.system.coredump.partition.list.Invoke() | Where-Object { $_.Active -eq 'true' }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Active Core Dump Partition'
						'Value'     = $results.Name
						'Expected'  = 'An Active Core Dump Partition'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Active Core Dump Partition'
						'Value'     = 'No Active Core Dump Partition found!'
						'Expected'  = 'An Active Core Dump Partition'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray44 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant44 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000045
Try {
	$VULID = 'V-239300'
	$STIGID = 'ESXI-65-000045'
	$Title = 'The ESXi host must enable a persistent log location for all locally stored logs.'
	$Severity = 'CAT II'
	If ($V239300) {
		$esxititle45 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.syslogScratch.Keys
		$settingvalue = [string]$stigsettings.syslogScratch.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray45 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant45 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000046
Try {
	$VULID = 'V-239301'
	$STIGID = 'ESXI-65-000046'
	$Title = 'The ESXi host must configure NTP time synchronization.'
	$Severity = 'CAT II'
	If ($V239301) {
		$esxititle46 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$currentntp = $vmhost.ExtensionData.Config.DateTimeInfo.ntpconfig.server
			If ($currentntp.count -eq '0') {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'NTP Servers'
						'Value'     = [String]::Join(',', $currentntp)
						'Expected'  = [String]::Join(',', $stigsettings.ntpServers)
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			else {
				If ($stigsettings.ntpServers[0] -ne $currentntp[0] -or $stigsettings.ntpServers[1] -ne $currentntp[1]) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = 'NTP Servers'
							'Value'     = [String]::Join(',', $currentntp)
							'Expected'  = [String]::Join(',', $stigsettings.ntpServers)
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = 'NTP Servers'
							'Value'     = [String]::Join(',', $currentntp)
							'Expected'  = [String]::Join(',', $stigsettings.ntpServers)
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
		}
		$esxiarray46 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant46 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000047
Try {
	$VULID = 'V-239302'
	$STIGID = 'ESXI-65-000047'
	$Title = 'The ESXi Image Profile and VIB Acceptance Levels must be verified.'
	$Severity = 'CAT I'
	If ($V239302) {
		$esxititle47 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.acceptance.get.Invoke()
			If ($results -eq 'CommunitySupported') {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'VIB Acceptance Level'
						'Value'     = $results
						'Expected'  = 'PartnerSupported or VMwareSupported or VMwareCertified'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
			else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'VIB Acceptance Level'
						'Value'     = $results
						'Expected'  = 'PartnerSupported or VMwareSupported or VMwareCertified'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
		}
		$esxiarray47 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant47 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000048
Try {
	$VULID = 'V-239303'
	$STIGID = 'ESXI-65-000048'
	$Title = 'The ESXi host must protect the confidentiality and integrity of transmitted information by isolating vMotion traffic.'
	$Severity = 'CAT II'
	If ($V239303) {
		$esxititle48 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$vmks = $vmhost | Get-VMHostNetworkAdapter -VMKernel
			ForEach ($vmk in $vmks) {
				If (($vmk.VMotionEnabled -eq 'True' -and $vmk.FaultToleranceLoggingEnabled -eq 'True') -xor ($vmk.VMotionEnabled -eq 'True' -and $vmk.ManagementTrafficEnabled -eq 'True') -xor ($vmk.VMotionEnabled -eq 'True' -and $vmk.VsanTrafficEnabled -eq 'True')) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = 'vMotion VMK Separation'
							'Value'     = "$($vmk.name) has more than 1 function enabled"
							'Expected'  = "vMotion is isolated on it's own VMkernel"
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				ElseIf ($vmk.VMotionEnabled -eq 'True') {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = 'vMotion VMK Separation'
							'Value'     = "$($vmk.name) has only vMotion enabled"
							'Expected'  = "vMotion is isolated on it's own VMkernel"
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
		}
		$esxiarray48 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant48 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000049
Try {
	$VULID = 'V-239304'
	$STIGID = 'ESXI-65-000049'
	$Title = 'The ESXi host must protect the confidentiality and integrity of transmitted information by protecting ESXi management traffic.'
	$Severity = 'CAT II'
	If ($V239304) {
		$esxititle49 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
		}
		$esxiarray49 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant49 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000050
Try {
	$VULID = 'V-239305'
	$STIGID = 'ESXI-65-000050'
	$Title = 'The ESXi host must protect the confidentiality and integrity of transmitted information by protecting IP based management traffic.'
	$Severity = 'CAT II'
	If ($V239305) {
		$esxititle50 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
		}
		$esxiarray50 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant50 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000052
Try {
	$VULID = 'V-239306'
	$STIGID = 'ESXI-65-000052'
	$Title = 'The ESXi host must protect the confidentiality and integrity of transmitted information by utilizing different TCP/IP stacks Where-Object possible.'
	$Severity = 'CAT III'
	If ($V239306) {
		$esxititle52 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
		}
		$esxiarray52 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant52 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000053
Try {
	$VULID = 'V-239307'
	$STIGID = 'ESXI-65-000053'
	$Title = 'SNMP must be configured properly on the ESXi host.'
	$Severity = 'CAT II'
	If ($V239307) {
		$esxititle53 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.system.snmp.get.Invoke() | Where-Object { $_.enable -eq 'true' }
			If ($results.communities) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'        = $vmhost.name
						'Enabled'     = $results.enable
						'communities' = $results.communities
						'v3targets'   = $results.v3targets
						'Expected'    = 'SNMP v1/2 is not in use'
						'Severity'    = $Severity
						'Compliant'   = $false
					})
			}
			ElseIf ($results.v3targets) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'        = $vmhost.name
						'Enabled'     = $results.enable
						'communities' = $results.communities
						'v3targets'   = $results.v3targets
						'Expected'    = 'SNMP v1/2 is not in use'
						'Severity'    = $Severity
						'Compliant'   = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'        = $vmhost.name
						'Enabled'     = $false
						'communities' = $results.communities
						'v3targets'   = $results.v3targets
						'Expected'    = 'SNMP v1/2 is not in use'
						'Severity'    = $Severity
						'Compliant'   = $true
					})
			}
		}
		$esxiarray53 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant53 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000054
Try {
	$VULID = 'V-239308'
	$STIGID = 'ESXI-65-000054'
	$Title = 'The ESXi host must enable bidirectional CHAP authentication for iSCSI traffic.'
	$Severity = 'CAT III'
	If ($V239308) {
		$esxititle54 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
		}
		$esxiarray54 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant54 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000055
Try {
	$VULID = 'V-239309'
	$STIGID = 'ESXI-65-000055'
	$Title = 'The ESXi host must disable Inter-VM transparent page sharing.'
	$Severity = 'CAT III'
	If ($V239309) {
		$esxititle55 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.ShareForceSalting.Keys
		$settingvalue = [string]$stigsettings.ShareForceSalting.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray55 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant55 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000056
Try {
	$VULID = 'V-239310'
	$STIGID = 'ESXI-65-000056'
	$Title = 'The ESXi host must configure the firewall to restrict access to services running on the host.'
	$Severity = 'CAT II'
	If ($V239310) {
		$esxititle56 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$fwservices = $vmhost | Get-VMHostFirewallException | Where-Object { $_.Enabled -eq $True }
			ForEach ($fwservice in $fwservices) {
				If ($fwservice.extensiondata.allowedhosts.IpNetwork) {
					#Extract allowed networks from configuration for comparison
					$allowedNetworks = @()
					$netcount = $fwservice.extensiondata.allowedhosts.IpNetwork.count
					For ($i = 0; $i -lt $netcount; $i++) {
						$newnet = $fwservice.extensiondata.allowedhosts.IpNetwork[$i].Network + '/' + $fwservice.extensiondata.allowedhosts.IpNetwork[$i].PrefixLength
						$allowedNetworks += $newnet
					}
					$allowedNetworksStr = [String]::Join(',', $allowedNetworks)
					$expectedNetworksStr = [String]::Join(',', $stigSettings.allowedNetworks)
				}
				Else {
					$allowedNetworks = $fwservice.extensiondata.allowedhosts.IpNetwork
					$allowedNetworksStr = ''
					If ($stigSettings.allowedNetworks) {
						$expectedNetworksStr = [String]::Join(',', $stigSettings.allowedNetworks)
					}
					Else {
						$expectedNetworksStr = ''
					}
				}
				If ($fwservice.extensiondata.allowedhosts.IpAddress) {
					$allowedIPs = $fwservice.extensiondata.allowedhosts.IpAddress
					$allowedIPsStr = [String]::Join(',', $fwservice.extensiondata.allowedhosts.IpAddress)
					#$expectedIPsStr = [String]::Join(',',$stigSettings.allowedIps)
					$expectedIPsStr = $stigSettings.allowedIps | Out-String
				}
				Else {
					$allowedIPs = $fwservice.extensiondata.allowedhosts.IpAddress
					$allowedIPsStr = ''
					If ($stigSettings.allowedIps) {
						$expectedIPsStr = [String]::Join(',', $stigSettings.allowedIps)
					}
					Else {
						$expectedIPsStr = ''
					}
				}
				If ($fwservice.extensiondata.allowedhosts.allip -eq $true -or $allowedNetworksStr -ne $expectedNetworksStr -or $allowedIPsStr -ne $expectedIPsStr) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'                       = $vmhost.name
							'Service'                    = $fwservice.name
							'AllIPsEnabled'              = $fwservice.extensiondata.allowedhosts.allip
							'AllowedIPNetworks'          = $allowedNetworksStr
							'AllowedIPs'                 = $allowedIPsStr
							'Expected'                   = 'All IPs allowed Disabled'
							'Expected Allowed IP Ranges' = $expectedNetworksStr
							'Expected Allowed IPs'       = $expectedIPsStr
							'Severity'                   = $Severity
							'Compliant'                  = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'                       = $vmhost.name
							'Service'                    = $fwservice.name
							'AllIPsEnabled'              = $fwservice.extensiondata.allowedhosts.allip
							'AllowedIPNetworks'          = $allowedNetworksStr
							'AllowedIPs'                 = $allowedIPsStr
							'Expected'                   = 'All IPs allowed Disabled'
							'Expected Allowed IP Ranges' = $expectedNetworksStr
							'Expected Allowed IPs'       = $expectedIPsStr
							'Severity'                   = $Severity
							'Compliant'                  = $true
						})
				}
			}
		}
		$esxiarray56 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant56 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000057
Try {
	$VULID = 'V-239311'
	$STIGID = 'ESXI-65-000057'
	$Title = 'The ESXi host must configure the firewall to block network traffic by default.'
	$Severity = 'CAT II'
	If ($V239311) {
		$esxititle57 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$results = $vmhost | Get-VMHostFirewallDefaultPolicy
			If ($results.IncomingEnabled -eq 'True' -xor $results.OutgoingEnabled -eq 'True') {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'            = $vmhost.name
						'Setting'         = 'Default Firewall Policy'
						'IncomingEnabled' = $results.IncomingEnabled
						'OutgoingEnabled' = $results.OutgoingEnabled
						'Expected'        = 'Incoming/Outgoing traffic blocked by default'
						'Severity'        = $Severity
						'Compliant'       = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'            = $vmhost.name
						'Setting'         = 'Default Firewall Policy'
						'IncomingEnabled' = $results.IncomingEnabled
						'OutgoingEnabled' = $results.OutgoingEnabled
						'Expected'        = 'Incoming/Outgoing traffic blocked by default'
						'Severity'        = $Severity
						'Compliant'       = $true
					})
			}
		}
		$esxiarray57 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$esxiCompliant57 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000058
Try {
	$VULID = 'V-239312'
	$STIGID = 'ESXI-65-000058'
	$Title = 'The ESXi host must enable BPDU filter on the host to prevent being locked out of physical switch ports with Portfast and BPDU Guard enabled.'
	$Severity = 'CAT III'
	If ($V239312) {
		$esxititle58 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.BlockGuestBPDU.Keys
		$settingvalue = [string]$stigsettings.BlockGuestBPDU.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray58 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant58 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000059
Try {
	$VULID = 'V-239313'
	$STIGID = 'ESXI-65-000059'
	$Title = 'The virtual switch Forged Transmits policy must be set to reject on the ESXi host.'
	$Severity = 'CAT II'
	If ($V239313) {
		$esxititle59 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$switches = Get-VirtualSwitch -VMHost $vmhost -Standard
			If ($switches.count -eq 0) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'                     = $vmhost.name
						'Switch'                   = 'N/A'
						'Port Group'               = 'N/A'
						'ForgedTransmits'          = 'N/A'
						'ForgedTransmitsInherited' = 'N/A'
						'Expected'                 = 'No vSwitches or Forged Transmits Disabled'
						'Severity'                 = $Severity
						'Compliant'                = $true
					})
			}
			Else {
				ForEach ($sw in $switches) {
					$secpol = $sw | Get-SecurityPolicy
					If ($secpol.ForgedTransmits -eq $true) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                     = $vmhost.name
								'Switch'                   = $sw.name
								'Port Group'               = 'N/A'
								'ForgedTransmits'          = $secpol.ForgedTransmits
								'ForgedTransmitsInherited' = 'N/A'
								'Expected'                 = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                 = $Severity
								'Compliant'                = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                     = $vmhost.name
								'Switch'                   = $sw.name
								'Port Group'               = 'N/A'
								'ForgedTransmits'          = $secpol.ForgedTransmits
								'ForgedTransmitsInherited' = 'N/A'
								'Expected'                 = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                 = $Severity
								'Compliant'                = $true
							})
					}
				}
				$portgroups = Get-VirtualPortGroup -VMHost $vmhost -Standard
				ForEach ($pg in $portgroups) {
					$secpol = $pg | Get-SecurityPolicy
					If ($secpol.ForgedTransmits -eq $true -or $secpol.ForgedTransmitsInherited -eq $false) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                     = $vmhost.name
								'Switch'                   = 'N/A'
								'Port Group'               = $pg.name
								'ForgedTransmits'          = $secpol.ForgedTransmits
								'ForgedTransmitsInherited' = $secpol.ForgedTransmitsInherited
								'Expected'                 = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                 = $Severity
								'Compliant'                = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                     = $vmhost.name
								'Switch'                   = 'N/A'
								'Port Group'               = $pg.name
								'ForgedTransmits'          = $secpol.ForgedTransmits
								'ForgedTransmitsInherited' = $secpol.ForgedTransmitsInherited
								'Expected'                 = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                 = $Severity
								'Compliant'                = $true
							})
					}
				}
			}
		}
		$esxiarray59 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant59 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000060
Try {
	$VULID = 'V-239314'
	$STIGID = 'ESXI-65-000060'
	$Title = 'The virtual switch MAC Address Change policy must be set to reject on the ESXi host.'
	$Severity = 'CAT I'
	If ($V239314) {
		$esxititle60 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$switches = Get-VirtualSwitch -VMHost $vmhost -Standard
			If ($switches.count -eq 0) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'                = $vmhost.name
						'Switch'              = 'N/A'
						'Port Group'          = 'N/A'
						'MacChanges'          = 'N/A'
						'MacChangesInherited' = 'N/A'
						'Expected'            = 'No vSwitches or Forged Transmits Disabled'
						'Severity'            = $Severity
						'Compliant'           = $true
					})
			}
			Else {
				ForEach ($sw in $switches) {
					$secpol = $sw | Get-SecurityPolicy
					If ($secpol.MacChanges -eq $true) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                = $vmhost.name
								'Switch'              = $sw.name
								'Port Group'          = 'N/A'
								'MacChanges'          = $secpol.MacChanges
								'MacChangesInherited' = 'N/A'
								'Expected'            = 'No vSwitches or Forged Transmits Disabled'
								'Severity'            = $Severity
								'Compliant'           = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                = $vmhost.name
								'Switch'              = $sw.name
								'Port Group'          = 'N/A'
								'MacChanges'          = $secpol.MacChanges
								'MacChangesInherited' = 'N/A'
								'Expected'            = 'No vSwitches or Forged Transmits Disabled'
								'Severity'            = $Severity
								'Compliant'           = $true
							})
					}
				}
				$portgroups = Get-VirtualPortGroup -VMHost $vmhost -Standard
				ForEach ($pg in $portgroups) {
					$secpol = $pg | Get-SecurityPolicy
					If ($secpol.MacChanges -eq $true -or $secpol.MacChangesInherited -eq $false) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                = $vmhost.name
								'Switch'              = 'N/A'
								'Port Group'          = $pg.name
								'MacChanges'          = $secpol.MacChanges
								'MacChangesInherited' = $secpol.MacChangesInherited
								'Expected'            = 'No vSwitches or Forged Transmits Disabled'
								'Severity'            = $Severity
								'Compliant'           = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                = $vmhost.name
								'Switch'              = 'N/A'
								'Port Group'          = $pg.name
								'MacChanges'          = $secpol.MacChanges
								'MacChangesInherited' = $secpol.MacChangesInherited
								'Expected'            = 'No vSwitches or Forged Transmits Disabled'
								'Severity'            = $Severity
								'Compliant'           = $true
							})
					}
				}
			}
		}
		$esxiarray60 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant60 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000061
Try {
	$VULID = 'V-239315'
	$STIGID = 'ESXI-65-000061'
	$Title = 'The virtual switch Promiscuous Mode policy must be set to reject on the ESXi host.'
	$Severity = 'CAT II'
	If ($V239315) {
		$esxititle61 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$switches = Get-VirtualSwitch -VMHost $vmhost -Standard
			If ($switches.count -eq 0) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'                      = $vmhost.name
						'Switch'                    = 'N/A'
						'Port Group'                = 'N/A'
						'AllowPromiscuous'          = 'N/A'
						'AllowPromiscuousInherited' = 'N/A'
						'Expected'                  = 'No vSwitches or Forged Transmits Disabled'
						'Severity'                  = $Severity
						'Compliant'                 = $true
					})
			}
			Else {
				ForEach ($sw in $switches) {
					$secpol = $sw | Get-SecurityPolicy
					If ($secpol.AllowPromiscuous -eq $true) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                      = $vmhost.name
								'Switch'                    = $sw.name
								'Port Group'                = 'N/A'
								'AllowPromiscuous'          = $secpol.AllowPromiscuous
								'AllowPromiscuousInherited' = 'N/A'
								'Expected'                  = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                  = $Severity
								'Compliant'                 = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                      = $vmhost.name
								'Switch'                    = $sw.name
								'Port Group'                = 'N/A'
								'AllowPromiscuous'          = $secpol.AllowPromiscuous
								'AllowPromiscuousInherited' = 'N/A'
								'Expected'                  = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                  = $Severity
								'Compliant'                 = $true
							})
					}
				}
				$portgroups = Get-VirtualPortGroup -VMHost $vmhost -Standard
				ForEach ($pg in $portgroups) {
					$secpol = $pg | Get-SecurityPolicy
					If ($secpol.AllowPromiscuous -eq $true -or $secpol.AllowPromiscuousInherited -eq $false) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                      = $vmhost.name
								'Switch'                    = 'N/A'
								'Port Group'                = $pg.name
								'AllowPromiscuous'          = $secpol.AllowPromiscuous
								'AllowPromiscuousInherited' = $secpol.AllowPromiscuousInherited
								'Expected'                  = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                  = $Severity
								'Compliant'                 = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'                      = $vmhost.name
								'Switch'                    = 'N/A'
								'Port Group'                = $pg.name
								'AllowPromiscuous'          = $secpol.AllowPromiscuous
								'AllowPromiscuousInherited' = $secpol.AllowPromiscuousInherited
								'Expected'                  = 'No vSwitches or Forged Transmits Disabled'
								'Severity'                  = $Severity
								'Compliant'                 = $true
							})
					}
				}
			}
		}
		$esxiarray61 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant61 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000062
Try {
	$VULID = 'V-239316'
	$STIGID = 'ESXI-65-000062'
	$Title = 'The ESXi host must prevent unintended use of the dvFilter network APIs.'
	$Severity = 'CAT II'
	If ($V239316) {
		$esxititle62 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.DVFilterBindIpAddress.Keys
		$settingvalue = [string]$stigsettings.DVFilterBindIpAddress.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray62 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant62 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000063
Try {
	$VULID = 'V-239317'
	$STIGID = 'ESXI-65-000063'
	$Title = 'For the ESXi host all port groups must be configured to a value other than that of the native VLAN.'
	$Severity = 'CAT II'
	If ($V239317) {
		$esxititle63 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$switches = Get-VirtualSwitch -VMHost $vmhost -Standard
			If ($switches.count -eq 0) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'       = $vmhost.name
						'Port Group' = 'N/A'
						'VLAN ID'    = 'N/A'
						'Expected'   = "No vSwitches or native vlan id: $($stigsettings.nativeVLANid)"
						'Severity'   = $Severity
						'Compliant'  = $true
					})
			}
			Else {
				$portgroups = Get-VirtualPortGroup -VMHost $vmhost -Standard
				ForEach ($pg in $portgroups) {
					If ($pg.VlanId -eq $stigsettings.nativeVLANid) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'       = $vmhost.name
								'Port Group' = $pg.name
								'VLAN ID'    = $pg.vlanid
								'Expected'   = "No vSwitches or native vlan id: $($stigsettings.nativeVLANid)"
								'Severity'   = $Severity
								'Compliant'  = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'       = $vmhost.name
								'Port Group' = $pg.name
								'VLAN ID'    = $pg.vlanid
								'Expected'   = "No vSwitches or native vlan id: $($stigsettings.nativeVLANid)"
								'Severity'   = $Severity
								'Compliant'  = $true
							})
					}
				}
			}
		}
		$esxiarray63 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant63 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000064
Try {
	$VULID = 'V-239318'
	$STIGID = 'ESXI-65-000064'
	$Title = 'For the ESXi host all port groups must not be configured to VLAN 4095 unless Virtual Guest Tagging (VGT) is required.'
	$Severity = 'CAT II'
	If ($V239318) {
		$esxititle64 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$switches = Get-VirtualSwitch -VMHost $vmhost -Standard
			If ($switches.count -eq 0) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'       = $vmhost.name
						'Port Group' = 'N/A'
						'VLAN ID'    = 'N/A'
						'Expected'   = 'No vSwitches or trunk vlan id: 4095'
						'Severity'   = $Severity
						'Compliant'  = $true
					})
			}
			Else {
				$portgroups = Get-VirtualPortGroup -VMHost $vmhost -Standard
				ForEach ($pg in $portgroups) {
					If ($pg.VlanId -eq '4095') {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'       = $vmhost.name
								'Port Group' = $pg.name
								'VLAN ID'    = $pg.vlanid
								'Expected'   = 'No vSwitches or trunk vlan id: 4095'
								'Severity'   = $Severity
								'Compliant'  = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'       = $vmhost.name
								'Port Group' = $pg.name
								'VLAN ID'    = $pg.vlanid
								'Expected'   = 'No vSwitches or trunk vlan id: 4095'
								'Severity'   = $Severity
								'Compliant'  = $true
							})
					}
				}
			}
		}
		$esxiarray64 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant64 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000065
Try {
	$VULID = 'V-239319'
	$STIGID = 'ESXI-65-000065'
	$Title = 'For the ESXi host all port groups must not be configured to VLAN values reserved by upstream physical switches.'
	$Severity = 'CAT II'
	If ($V239319) {
		$esxititle65 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$switches = Get-VirtualSwitch -VMHost $vmhost -Standard
			If ($switches.count -eq 0) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'       = $vmhost.name
						'Port Group' = 'N/A'
						'VLAN ID'    = 'N/A'
						'Expected'   = 'No vSwitches or reserved vlan ids'
						'Severity'   = $Severity
						'Compliant'  = $true
					})
			}
			Else {
				$portgroups = Get-VirtualPortGroup -VMHost $vmhost -Standard
				ForEach ($pg in $portgroups) {
					If ($pg.VlanId -In 1001 .. 1024 -or $pg.VlanId -In 3968 .. 4047 -or $pg.VlanId -In 4094) {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'       = $vmhost.name
								'Port Group' = $pg.name
								'VLAN ID'    = $pg.vlanid
								'Expected'   = 'No vSwitches or reserved vlan ids'
								'Severity'   = $Severity
								'Compliant'  = $false
							})
					}
					Else {
						$esxiarray += New-Object PSObject -Property ([ordered]@{
								'Name'       = $vmhost.name
								'Port Group' = $pg.name
								'VLAN ID'    = $pg.vlanid
								'Expected'   = 'No vSwitches or reserved vlan ids'
								'Severity'   = $Severity
								'Compliant'  = $true
							})
					}
				}
			}
		}
		$esxiarray65 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant65 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000072
Try {
	$VULID = 'V-239325'
	$STIGID = 'ESXI-65-000072'
	$Title = 'The ESXi host must have all security patches and updates installed.'
	$Severity = 'CAT I'
	If ($V239325) {
		$esxititle72 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$build = $vmhost.ExtensionData.Config.Product.build
			If ($build -ne $stigsettings.esxiLatestBuild) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'           = $vmhost.name
						'Current Build'  = $build
						'Expected Build' = $stigsettings.esxiLatestBuild
						'Severity'       = $Severity
						'Compliant'      = $false
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'           = $vmhost.name
						'Current Build'  = $build
						'Expected Build' = $stigsettings.esxiLatestBuild
						'Severity'       = $Severity
						'Compliant'      = $true
					})
			}
		}
		$esxiarray72 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant72 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

## ESXI-65-000074
Try {
	$VULID = 'V-239326'
	$STIGID = 'ESXI-65-000074'
	$Title = 'The ESXi host must exclusively enable TLS 1.2 for all endpoints.'
	$Severity = 'CAT II'
	If ($V239326) {
		$esxititle74 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		$settingname = $stigsettings.sslProtocols.Keys
		$settingvalue = [string]$stigsettings.sslProtocols.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray74 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant74 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000076
Try {
	$VULID = 'V-239327'
	$STIGID = 'ESXI-65-000076'
	$Title = 'The ESXi host must enable Secure Boot.'
	$Severity = 'CAT II'
	If ($V239327) {
		$esxititle76 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
		}
		$esxiarray76 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant76 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000078
Try {
	$VULID = 'V-239328'
	$STIGID = 'ESXI-65-000078'
	$Title = 'The ESXi host must use DoD-approved certificates.'
	$Severity = 'CAT II'
	If ($V239328) {
		$esxititle78 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$result = Test-WebServerSSL -URL $vmhost.name
			If ($result.Certificate.Issuer -match $stigsettings.certAuthName) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'            = $vmhost.name
						'Cert Issuer'     = $result.Certificate.Issuer
						'Cert Expires'    = $result.Certificate.NotAfter
						'Cert Serial'     = $result.Certificate.SerialNumber
						'Cert Thumbprint' = $result.Certificate.Thumbprint
						'Expected'        = 'Certificate issued from a DoD CA and valid'
						'Severity'        = $Severity
						'Compliant'       = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'            = $vmhost.name
						'Cert Issuer'     = $result.Certificate.Issuer
						'Cert Expires'    = $result.Certificate.NotAfter
						'Cert Serial'     = $result.Certificate.SerialNumber
						'Cert Thumbprint' = $result.Certificate.Thumbprint
						'Expected'        = 'Certificate issued from a DoD CA and valid'
						'Severity'        = $Severity
						'Compliant'       = $false
					})
			}

		}
		$esxiarray78 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant78 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsole "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-000079
Try {
	$VULID = 'V-239329'
	$STIGID = 'ESXI-65-000079'
	$Title = 'The ESXi host must not suppress warnings that the local or remote shell sessions are enabled.'
	$Severity = 'CAT II'
	If ($V239329) {
		$esxititle79 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		$settingname = [string]$stigsettings.SuppressShellWarning.Keys
		$settingvalue = [string]$stigsettings.SuppressShellWarning.Values
		Write-ToConsoleRed "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray79 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant79 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsole "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-100004
Try {
	$VULID = 'V-239330'
	$STIGID = 'ESXI-65-100004'
	$Title = 'The ESXi host must centrally review and analyze audit records from multiple components within the system by configuring remote logging.'
	$Severity = 'CAT II'
	If ($V239330) {
		$esxititle100004 = "Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity Title: $Title"
		$settingname = [string]$stigsettings.syslogHost.Keys
		$settingvalue = [string]$stigsettings.syslogHost.Values
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhostsv) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $settingname"
			If ($vmhost.Config.option.key -contains "$settingname") {
				$currentvalue = $vmhost.Config.option | Where-Object { $_.key -eq "$settingname" }
				If ($currentvalue.value -ne $settingvalue) {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $false
						})
				}
				Else {
					$esxiarray += New-Object PSObject -Property ([ordered]@{
							'Name'      = $vmhost.name
							'Setting'   = $currentvalue.key
							'Value'     = $currentvalue.value
							'Expected'  = $settingvalue
							'Severity'  = $Severity
							'Compliant' = $true
						})
				}
			}
			If ($vmhost.Config.option.key -notcontains "$settingname") {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = $settingname
						'Value'     = 'Setting does not exist on ESXi Host'
						'Expected'  = $settingvalue
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray100004 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant100004 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsole "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID Severity:$Severity with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

# ESXI-65-100010
Try {
	$VULID = 'V-239331'
	$STIGID = 'ESXI-65-100010'
	$Title = 'The ESXi host SSH daemon must be configured to only use FIPS 140-2 approved ciphers.'
	$Severity = 'CAT II'
	If ($V239331) {
		$esxititle100010 = "Vulnerability ID:$VULID STIG ID:$STIGID Title: $Title"
		Write-ToConsole "...Checking STIG Control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
		$esxiarray = @()
		ForEach ($vmhost in $vmhosts) {
			Write-ToConsole "...Checking ESXi Host $($vmhost.Name) for $title"
			$esxcli = Get-EsxCli -VMHost $vmhost -V2
			$results = $esxcli.software.vib.list.Invoke() | Where-Object { $_.Name -eq $stigsettings.stigVibRE -or $_.Name -eq $stigsettings.stigVibRD }
			If ($results) {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Ciphers aes128-ctr,aes192-ctr,aes256-ctr'
						'Value'     = "Set by STIG VIB $($results.name)"
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $true
					})
			}
			Else {
				$esxiarray += New-Object PSObject -Property ([ordered]@{
						'Name'      = $vmhost.name
						'Setting'   = 'Ciphers aes128-ctr,aes192-ctr,aes256-ctr'
						'Value'     = 'STIG VIB NOT installed'
						'Expected'  = 'STIG VIB Installed'
						'Severity'  = $Severity
						'Compliant' = $false
					})
			}
		}
		$esxiarray100010 = Set-TableRowColor -ArrayOfObjects $esxiarray -Red '$this.Compliant -eq $false' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name
		$esxiCompliant100010 = Set-TableRowColor -ArrayOfObjects $esxiarray -Green '$this.Compliant -eq $true' | Sort-Object -Property @{ Expression = { $_.RowColor }; Ascending = $false }, Name

		$vmhostsarrayall += $esxiarray
	}
	Else {
		Write-ToConsoleRed "...Skipping disabled control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title"
	}
}
Catch {
	Write-Error "Failed to check control with Vulnerability ID:$VULID STIG ID:$STIGID with Title: $Title on $($vmhost.name)"
	Write-Error $_.Exception
	Write-ToConsole "...Disconnecting from vCenter Server $vcenter"


}

#End ESXi Processing


##Build Overview Data
Write-ToConsole '...Building HTML Report...'


##ESXi Compliance Overall
$vmhostsarrayallcompliantcount = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $true }).count
$vmhostsarrayallnoncompliantcount = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $false }).count

##ESXi Compliance By Severity
$vmhostscompliantcountcat1 = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $true -and $_.Severity -eq 'CAT I' }).count
$vmhostsnoncompliantcountcat1 = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $false -and $_.Severity -eq 'CAT I' }).count
$vmhostscompliantcountcat2 = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $true -and $_.Severity -eq 'CAT II' }).count
$vmhostsnoncompliantcountcat2 = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $false -and $_.Severity -eq 'CAT II' }).count
$vmhostscompliantcountcat3 = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $true -and $_.Severity -eq 'CAT III' }).count
$vmhostsnoncompliantcountcat3 = @($vmhostsarrayall | Where-Object { $_.Compliant -eq $false -and $_.Severity -eq 'CAT III' }).count

#Generate ESXi Compliance table
$vmhostcomptable = New-Object 'System.Collections.Generic.List[System.Object]'

$obj1 = [PSCustomObject]@{
	'Name'  = 'Non-Compliant' + ": $vmhostsarrayallnoncompliantcount"
	'Count' = $vmhostsarrayallnoncompliantcount
}
$vmhostcomptable.Add($obj1)

$obj1 = [PSCustomObject]@{
	'Name'  = 'Compliant' + ": $vmhostsarrayallcompliantcount"
	'Count' = $vmhostsarrayallcompliantcount
}
$vmhostcomptable.Add($obj1)

#Generate ESXi Severity Compliance table
$vmhostcomptablesev = New-Object 'System.Collections.Generic.List[System.Object]'

$obj1 = [PSCustomObject]@{
	'Name'  = 'Non-Compliant CAT I' + ": $vmhostsnoncompliantcountcat1"
	'Count' = $vmhostsnoncompliantcountcat1
}
$vmhostcomptablesev.Add($obj1)

$obj1 = [PSCustomObject]@{
	'Name'  = 'Compliant CAT I' + ": $vmhostscompliantcountcat1"
	'Count' = $vmhostscompliantcountcat1
}
$vmhostcomptablesev.Add($obj1)

$obj1 = [PSCustomObject]@{
	'Name'  = 'Non-Compliant CAT II' + ": $vmhostsnoncompliantcountcat2"
	'Count' = $vmhostsnoncompliantcountcat2
}
$vmhostcomptablesev.Add($obj1)

$obj1 = [PSCustomObject]@{
	'Name'  = 'Compliant CAT II' + ": $vmhostscompliantcountcat2"
	'Count' = $vmhostscompliantcountcat2
}
$vmhostcomptablesev.Add($obj1)

$obj1 = [PSCustomObject]@{
	'Name'  = 'Non-Compliant CAT III' + ": $vmhostsnoncompliantcountcat3"
	'Count' = $vmhostsnoncompliantcountcat3
}
$vmhostcomptablesev.Add($obj1)

$obj1 = [PSCustomObject]@{
	'Name'  = 'Compliant CAT III' + ": $vmhostscompliantcountcat3"
	'Count' = $vmhostscompliantcountcat3
}
$vmhostcomptablesev.Add($obj1)

##ESXi Compliance Pie Chart
$PieObjectVMHostCompliance = Get-HTMLPieChartObject
$PieObjectVMHostCompliance.Title = 'ESXi Overall Compliance'
$PieObjectVMHostCompliance.Size.Height = 250
$PieObjectVMHostCompliance.Size.Width = 250
$PieObjectVMHostCompliance.ChartStyle.ChartType = 'doughnut'
#These file exist in the module directoy, There are 4 schemes by default
$PieObjectVMHostCompliance.ChartStyle.ColorSchemeName = 'ColorScheme4'
#Data defintion you can reference any column from name and value from the  dataset.
#Name and Count are the default to work with the Group function.
$PieObjectVMHostCompliance.DataDefinition.DataNameColumnName = 'Name'
$PieObjectVMHostCompliance.DataDefinition.DataValueColumnName = 'Count'

##ESXi Severity Compliance Pie Chart
$PieObjectVMHostComplianceSev = Get-HTMLPieChartObject
$PieObjectVMHostComplianceSev.Title = 'ESXi Overall Compliance by Severity'
$PieObjectVMHostComplianceSev.Size.Height = 250
$PieObjectVMHostComplianceSev.Size.Width = 250
$PieObjectVMHostComplianceSev.ChartStyle.ChartType = 'doughnut'
#These file exist in the module directoy, There are 4 schemes by default
$PieObjectVMHostComplianceSev.ChartStyle.ColorSchemeName = 'ColorScheme4'
#Data defintion you can reference any column from name and value from the  dataset.
#Name and Count are the default to work with the Group function.
$PieObjectVMHostComplianceSev.DataDefinition.DataNameColumnName = 'Name'
$PieObjectVMHostComplianceSev.DataDefinition.DataValueColumnName = 'Count'

##Environment Data Table
$envDataTable = New-Object 'System.Collections.Generic.List[System.Object]'
$envData = [PSCustomObject]@{
	'vCenter Server'       = $vcenter
	'ESXi Hosts'           = ($vmhosts).count
	'Virtual Machines'     = ($vms).count
	'Datastores'           = ($datastores).count
	'Clusters'             = ($clusters).count
	'Disitrbuted Switches' = ($vdswitches).count
}
$envDataTable.Add($envData)


#Generate Report Structure
$report += Get-HTMLOpenPage -TitleText $ReportName -LeftLogoString $CompanyLogo -RightLogoString $RightLogo
$report += Get-HTMLTabHeader -TabNames $tabarray

#Overview Tab
$report += Get-HTMLColumnOpen -ColumnNumber 3 -ColumnCount 6
$report += Get-HTMLPieChart -ChartObject $PieObjectVMHostCompliance -DataSet $vmhostcomptable
$report += Get-HTMLColumnClose
$report += Get-HTMLColumnOpen -ColumnNumber 4 -ColumnCount 6
$report += Get-HTMLPieChart -ChartObject $PieObjectVMHostComplianceSev -DataSet $vmhostcomptablesev
$report += Get-HTMLColumnClose
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText 'Environment Overview'
$report += Get-HTMLContentDataTable $envDataTable -HideFooter
$report += Get-HTMLContentClose
$report += Get-HTMLTabContentClose

#ESXi Tab
$report += Get-HTMLTabContentOpen -TabName $tabarray[1] -TabHeading 'vSphere 6.5 ESXi STIG (Version 2 Release 2)'
$report += Get-HTMLContentOpen -HeaderText $esxititle01
$report += Get-HTMLContentTable $esxiarray01
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle02
$report += Get-HTMLContentTable $esxiarray02
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle03
$report += Get-HTMLContentTable $esxiarray03
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle04
$report += Get-HTMLContentTable $esxiarray04
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle05
$report += Get-HTMLContentTable $esxiarray05
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle06
$report += Get-HTMLContentTable $esxiarray06
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle07
$report += Get-HTMLContentTable $esxiarray07
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle08
$report += Get-HTMLContentTable $esxiarray08
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle09
$report += Get-HTMLContentTable $esxiarray09
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle10
$report += Get-HTMLContentTable $esxiarray10
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle11
$report += Get-HTMLContentTable $esxiarray11
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle12
$report += Get-HTMLContentTable $esxiarray12
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle13
$report += Get-HTMLContentTable $esxiarray13
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle14
$report += Get-HTMLContentTable $esxiarray14
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle15
$report += Get-HTMLContentTable $esxiarray15
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle16
$report += Get-HTMLContentTable $esxiarray16
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle17
$report += Get-HTMLContentTable $esxiarray17
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle18
$report += Get-HTMLContentTable $esxiarray18
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle19
$report += Get-HTMLContentTable $esxiarray19
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle20
$report += Get-HTMLContentTable $esxiarray20
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle21
$report += Get-HTMLContentTable $esxiarray21
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle22
$report += Get-HTMLContentTable $esxiarray22
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle23
$report += Get-HTMLContentTable $esxiarray23
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle24
$report += Get-HTMLContentTable $esxiarray24
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle25
$report += Get-HTMLContentTable $esxiarray25
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle26
$report += Get-HTMLContentTable $esxiarray26
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle27
$report += Get-HTMLContentTable $esxiarray27
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle28
$report += Get-HTMLContentTable $esxiarray28
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle29
$report += Get-HTMLContentTable $esxiarray29
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle30
$report += Get-HTMLContentTable $esxiarray30
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle31
$report += Get-HTMLContentTable $esxiarray31
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle32
$report += Get-HTMLContentTable $esxiarray32
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle33
$report += Get-HTMLContentTable $esxiarray33
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle34
$report += Get-HTMLContentTable $esxiarray34
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle35
$report += Get-HTMLContentTable $esxiarray35
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle36
$report += Get-HTMLContentTable $esxiarray36
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle37
$report += Get-HTMLContentTable $esxiarray37
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle38
$report += Get-HTMLContentTable $esxiarray38
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle39
$report += Get-HTMLContentTable $esxiarray39
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle41
$report += Get-HTMLContentTable $esxiarray41
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle42
$report += Get-HTMLContentTable $esxiarray42
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle43
$report += Get-HTMLContentTable $esxiarray43
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle44
$report += Get-HTMLContentTable $esxiarray44
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle45
$report += Get-HTMLContentTable $esxiarray45
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle46
$report += Get-HTMLContentTable $esxiarray46
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle47
$report += Get-HTMLContentTable $esxiarray47
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle48
$report += Get-HTMLContentTable $esxiarray48
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle49
$report += Get-HTMLContentTable $esxiarray49
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle50
$report += Get-HTMLContentTable $esxiarray50
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle51
$report += Get-HTMLContentTable $esxiarray51
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle52
$report += Get-HTMLContentTable $esxiarray52
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle53
$report += Get-HTMLContentTable $esxiarray53
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle54
$report += Get-HTMLContentTable $esxiarray54
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle55
$report += Get-HTMLContentTable $esxiarray55
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle56
$report += Get-HTMLContentTable $esxiarray56
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle57
$report += Get-HTMLContentTable $esxiarray57
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle58
$report += Get-HTMLContentTable $esxiarray58
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle59
$report += Get-HTMLContentTable $esxiarray59
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle60
$report += Get-HTMLContentTable $esxiarray60
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle61
$report += Get-HTMLContentTable $esxiarray61
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle62
$report += Get-HTMLContentTable $esxiarray62
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle63
$report += Get-HTMLContentTable $esxiarray63
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle64
$report += Get-HTMLContentTable $esxiarray64
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle65
$report += Get-HTMLContentTable $esxiarray65
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle72
$report += Get-HTMLContentTable $esxiarray72
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle74
$report += Get-HTMLContentTable $esxiarray74
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle76
$report += Get-HTMLContentTable $esxiarray76
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle78
$report += Get-HTMLContentTable $esxiarray78
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle79
$report += Get-HTMLContentTable $esxiarray79
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle100004
$report += Get-HTMLContentTable $esxiarray100004
$report += Get-HTMLContentClose
$report += Get-HTMLContentOpen -HeaderText $esxititle100010
$report += Get-HTMLContentTable $esxiarray100010
$report += Get-HTMLContentClose
$report += Get-HTMLTabContentClose

#Generate Report
$report | Set-Content -Path $ReportFile -Force
Invoke-Item $ReportFile