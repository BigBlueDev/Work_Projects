#PURPOSE: Backup my scripts to OneDrive

#CHANGELOG
#Version 1.00 - 01/02/25 - MDR - Initial version

Clear-Host

$BackupFilesPath = "C:\Users\DMR0123\OneDrive - Defense Logistics Agency\Virtualization - New\Scripts"
$BackupSTIGScriptFilesPath = "C:\Users\DMR0123\OneDrive - Defense Logistics Agency\Virtualization - New\Scripts\STIG Scripts"
$ParameterFilesPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7"
$ScriptsFilePath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR"

#Retrieve backup files
$BackupScriptFiles = Get-ChildItem -File -Path $BackupFilesPath
$BackupSTIGScriptFiles = Get-ChildItem -File -Path $BackupSTIGScriptFilesPath

#Check whether files need to be backed up and back them up
Function BackupFiles {
    Param ( $FileList, $ComparisonFiles )

    #Loop through all files being checked
    ForEach ($FileData in $FileList) {
        #Find the file that is being back up
        $ComparisonFileData = $ComparisonFiles | Where { $_.Name -eq $FileData.Name }
    
        #If the last write times don't align
        If ($FileData.LastWriteTime -ne $ComparisonFileData.LastWriteTime) {
            #If there is no matching file in the other folder
            If ($ComparisonFileData.LastWriteTime -eq $null) {
                [PSCustomObject]@{'FileName'=$FileData.Name;'Old write time'="None";'New write time'=$FileData.LastWriteTime}
                #Copy the new item over using the directory path from the first file in the $ComparisonFiles list
                Copy-Item -Path $FileData -Destination $ComparisonFiles[0].Directory -Force
            } ElseIf ($FileData.LastWriteTime -gt $ComparisonFileData.LastWriteTime) { #If the file being checked is newer than the current backup
                [PSCustomObject]@{'FileName'=$FileData.Name;'Old write time'=$ComparisonFileData.LastWriteTime;'New write time'=$FileData.LastWriteTime}
                #Copy the new item over
                Copy-Item -Path $FileData -Destination $ComparisonFileData.Directory -Force
            } Else {
                Write-Host "`nThe copy of $($FileData.Name) has a NEWER date than the file in the comparison folder" -ForegroundColor Yellow
            }
        }
    }
}

Write-Host "Backing up parameter files`n" -ForegroundColor Cyan
#Get a list of parameter files
$FileList = Get-ChildItem -File -Path $ParameterFilesPath | Where { $_.Name -like "*.csv" -or $_.Name -like "*.xlsx" }
#Backup parameter files
BackupFiles $FileList $BackupSTIGScriptFiles

Write-Host "`nBacking up STIG scripts`n" -ForegroundColor Cyan
#Get a list of STIG scripts
$FileList = Get-ChildItem -File -Path $ScriptsFilePath | Where { $_.Name -like "*STIG*" -or $_.Name -like "AltCheck*" -or $_.Name -like "Digitally sign a script*" -or $_.Name -like "RecordToChecklist*" }
#Backup parameter files
BackupFiles $FileList $BackupSTIGScriptFiles

Write-Host "`nBacking up non-STIG scripts`n" -ForegroundColor Cyan
#Get a list of STIG scripts
$FileList = Get-ChildItem -File -Path $ScriptsFilePath | Where { $_.Name -notlike "*STIG*" -and $_.Name -notlike "AltCheck*" -and $_.Name -notlike "Digitally sign a script*" -and $_.Name -notlike "RecordToChecklist*" }
#Backup parameter files
BackupFiles $FileList $BackupScriptFiles

Write-Host "`nScript completed" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCClak/S3Amu5m/T
# f5Si4viM/WyJ8dzuA10qSqe7fO8H+qCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBfTARX8bn7YfGV1kRXgA2uJVHh/N0nSj3RnLR2sSJAFDANBgkq
# hkiG9w0BAQEFAASCAQAAu7M0Md3c/4XiOGuTeb0itss3onlW0SzKAQzxy0cwcLFO
# G2bSr3FF63fYqXXOswyLcRGXobcU2FjDl6rUHw5RqI8fLiSbOgGCHMvvohfeSpNe
# otzTWSZFXG58db8kXEjDqKpJO3aB1MTCqX2H41iS4sJLBP3LnnXaR3HGgNFrnP31
# E1Vf6g1XsT4gf0xicXobtr8deLtExBUk/tMGCZuakcmq8yi9YPKHa44a5A3UdgAy
# Hw/1StNzI2P6R0IViAmmRJlLGYkaVm73EZdpvNy1cCksLijEm5HNMUTw4AUtrA47
# i67kTw2lJrz3aArJCawtdAquLdqFbBppbuAEqol7
# SIG # End signature block
