﻿#PURPOSE: Generate an email based on the patch status of ESX and vCenter servers compared to what ACAS expects

#CHANGELOG:
#Version 1.00 - 10/08/24 - MDR - Initial version  
#Version 1.01 - 10/09/24 - MDR - Switching VMwareBuildInfo to import a .xlsx instead of .csv
#Version 1.02 - 12/31/24 - MDR - Adding support for non-ESX/vCenter patching findings

#Phase 1 - **** INITIALIZATION / IMPORT DATA****

#Script should be run with user account. Check to see if an admin account is being used. If so, break out of the script. If not continue.
If (($env:UserName).Length -eq 8) { #If this is an elevated account
    Write-Warning "You need to run this with your non-elevated account."
    Read-Host "`nHit enter to close this window."
    Break
}

#Variable initialization
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports"
$Tab = [char]9 #This will be used to tab over HTML data so that it is readable within the variable $EmailHTMLBody
$EmailHTMLBody = "<br><br><br>" #Start the email off with empty lines so text can be input there

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Check to see if ImportExcel is installed
$CheckForImportExcel = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If ImportExcel is not found then prompt for folder Where it is located
If (!$CheckForImportExcel) {
    Write-Host "The ImportExcel module is required for this script to run" -ForegroundColor Red
    Write-Host "`nA copy of this module is located in \\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\Software\ImportExcel"
    Write-Host "`nPlace a copy of this module in C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Phase 0.1 - *Load Functions*
#AddDataToTableFunction takes in two variables, the $DataToAdd in variable and the explaination for that $DataToAdd variable. This function will be called each time to add data and explainations to a table that will later be used to generate an email.
Function AddDataToTable {
    Param ( $DataToAdd, $TableExplanation )
    #If this is the first time calling this function, $DataUpon the first run create
    If ($DataToAdd -ne $null) {
        
        #Get the number of columns in the dataset
        $DataColumnCount = $DataToAdd[0].psobject.Properties.Value.Count

        #Add the explanation for the table
        $Script:EmailHTMLBody += "<font size=3 color=blue>$TableExplanation</font><br><br>`n"

        #Create the table
        $Script:EmailHTMLBody += "<Table border='1' cellspacing='0' cellpadding='7' style='border-collapse:collapse;border:none'><font size='2' face='Calibri' color='black'>`n"

    ###Create the headers###
        $Script:EmailHTMLBody += "$Tab<tr align='Center'; style='height:13.00pt'>`n" #Create a new row

        #If ($DataToAdd.Count -ge 100) {
        #    $Script:EmailHTMLBody += "$Tab$Tab<font size=3 color=red><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'><b>Not displaying full output of this table due to this finding having over 100 line items.  Actual finding count is $($DataToAdd.Count).  See full report to view data on this finding.</b></td></font>`n"
        #    $Script:EmailHTMLBody += "$Tab</tr>`n" #End the row
        #} Else {
            ForEach ($HeaderName in $DataToAdd[0].psobject.Properties.Name) { #For each cell in the row
                $Script:EmailHTMLBody += "$Tab$Tab<font size=3><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'><b>" + $HeaderName + "</b></td></font>`n"
            }
        

            $Script:EmailHTMLBody += "$Tab</tr>`n" #End the row

        ###Add data###
            ForEach ($DataItem in $DataToAdd) { #For each row of data
                $Script:EmailHTMLBody += "$Tab<tr align='Center'; style='height:13.00pt'>`n" #Create a new row
        
                For ($Count = 0; $Count -lt $DataColumnCount; $Count++) { #For each cell in the row
                    If ($DataColumnCount -ne 1) { #If there are multiple columns
                        $Script:EmailHTMLBody += "$Tab$Tab<font size=3><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'>" + $DataItem.psobject.Properties.Value[$Count] + "</td></font>`n"
                    } Else { #Do this if there is just 1 column because otherwise it'll only output one character at a time
                        $Script:EmailHTMLBody += "$Tab$Tab<font size=3><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'>" + $DataItem.psobject.Properties.Value + "</td></font>`n"
                    }
                }

                $Script:EmailHTMLBody += "$Tab</tr>`n" #End the row
            }
        #}
        
        $Script:EmailHTMLBody += "</font></table><br><br>`n`n" #End the table
    }
}

Clear-Host

#Get a list of all VMware Build reports
$VMWareBuildFileList = Get-ChildItem -Path $ReportPath -Filter "VMwareBuildInfo*" | Sort LastWriteTime -Descending

#Get the latest VMware Build file name
$LatestVMwareBuildFileName = ($VMWareBuildFileList | Select -First 1).FullName
Write-Host "Importing report data from $LatestVMwareBuildFileName"

#Version 1.01 - Import the latest version of the VMware Build report
$LatestVMwareBuildInfo = Import-Excel $LatestVMwareBuildFileName

#Get a list of all DLA ACAS report
$ACASFileList = Get-ChildItem -Path "C:\Temp" -Filter "DLA - *" | Sort LastWriteTime -Descending

#If no ACAS file is found then exit
If ($ACASFileList -eq $null) {
    Write-Host "No ACAS file located.  Exiting" -ForegroundColor Red
    Break
} Else {
    #Get the latest ACAS file name
    $LatestACASFileName = ($ACASFileList | Select -First 1).FullName
    Write-Host "`nImporting ACAS data from $LatestACASFileName"
}

#Function used to turn a number into a letter
Function GetColumnLetter {
    Param ( $ColumnNum )

    #This variable is incremented if the number is over 26
    $OverflowCount = 0

    #Version 1.21 - Switched from -ge to -gt
    #For each time $LastColNum is more than 26, add one to $OverflowCount
    While ( $ColumnNum -gt 26 ) {
        $ColumnNum = $ColumnNum - 26
        $OverflowCount++
    }

    #If the number provided was over 26 then OverflowCount will be greater than 0
    If ($OverflowCount -gt 0) {
        #Determine which two letters will make up the combination of letters
        $LastColFirstLetter = [char](64 + $OverflowCount)
        $LastColSecondLetter = [char](64 + $ColumnNum)

        $FinalLetter = $LastColFirstLetter + $LastColSecondLetter
    } Else { #If the number provided was 26 or less then just a single letter will be provided
        $FinalLetter = [char](64 + $ColumnNum)
    }

    #Return the final letter(s)
    $FinalLetter
}

#Create an Excel object
$objExcel = New-Object -ComObject Excel.Application
#Open the selected file
$WorkBook = $objExcel.Workbooks.Open($LatestACASFileName)
#Open up the specified worksheet
$DataWorkSheet = $WorkBook.worksheets.Item("All")
#Focus the spreadsheet to the selected worksheet
$DataWorkSheet.Activate()

#Create variable to contain the total number of rows in the Worksheet
$TotalRows = ($DataWorkSheet.UsedRange.Rows).Count
#Determine how many columns are in the spreadsheet
$LastColNum = ($DataWorkSheet.UsedRange.Columns).Count
#Get the last column letter
$LastColLetter = GetColumnLetter $LastColNum

#Create variable to combine the Starting and Ending column letters along with the Total Rows to create a data range
$StartingRange = "A1:" + $LastColLetter + $TotalRows
#Filter the finding name so it only finds VMware related items
$DataWorkSheet.Range($StartingRange).AutoFilter(2, "=*VMware*", $True) | Out-Null

#Create a new workbook to house the final output
$WorkBookFinalOutput = $objExcel.Workbooks.Add()
#Store the worksheet data so it can be closed later on
$WorkSheetFinalOutput = $WorkBookFinalOutput.Worksheets.Item(1)

#Identifies visible cells
$xlCellTypeVisible = 12
#Filter only visible cells so we can copy only Windows Server data
$FilteredData = $DataWorkSheet.Range($StartingRange).SpecialCells($xlCellTypeVisible)
#Copy the VMware findings
$FilteredData.Copy() | Out-Null
#Paste the Windows Server data into the final output
$WorkSheetFinalOutput.Paste()
#Release the range
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($FilteredData) | Out-Null

#When doing a SaveAs, using a 6 will tell Excel to save as a CSV file
$SaveAsCSV = 6
#Create a path to store the VMware findings to
$CSVFilePath = "C:\Temp\VMwareFindings.csv"
#Save the new workbook as a CSV
$WorkBookFinalOutput.SaveAs("$CSVFilePath", $SaveAsCSV)

#Close the final output
$WorkBookFinalOutput.Close($false)
Try {
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($WorkSheetFinalOutput) | Out-Null
} Catch { }
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($WorkBookFinalOutput) | Out-Null

#Close the ACAS report
$WorkBook.Close($false)
Try {
    [System.Runtime.InteropServices.Marshal]::ReleaseComObject($DataWorkSheet) | Out-Null
} Catch { }
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($WorkBook) | Out-Null

#Close Excel
$objExcel.Quit()
[System.Runtime.InteropServices.Marshal]::ReleaseComObject($objExcel) | Out-Null
[System.GC]::Collect()
[System.GC]::WaitForPendingFinalizers()

#Verison 1.02 - Notify whether the temporary findings file was created or not
If (Test-Path "C:\Temp\VMwareFindings.csv") {
    Write-Host "`nTemporary file C:\Temp\VMwareFindings.csv has been created" -ForegroundColor Cyan
} Else {
    Write-Host "`nFailed to create temporary file C:\Temp\VMwareFindings.csv" -ForegroundColor Red
    Break
}

Write-Host "`nCompiling list of findings"

#Import the VMware ACAS data
$VMwareACASData = Import-CSV $CSVFilePath
#Once the data is imported, this file can be deleted
Remove-Item $CSVFilePath

#Get a list of all sytems that have findings
$FindingSystemNames = $VMwareACASData.'DNS Name'
#Get a list of all of our systems that have findings
$OurFindingList = ((Compare-Object -ReferenceObject $LatestVMwareBuildInfo.SystemName -DifferenceObject $FindingSystemNames -IncludeEqual) | Where { $_.SideIndicator -eq "=="}).InputObject | Sort

#Store data to be outputted later
$FinalFindingList = New-Object System.Collections.Generic.List[System.Object]

#Loop through each system that ACAS says has a finding
ForEach ($SystemName in $OurFindingList) {
    #Get our data for this system
    $BuildData = $LatestVMwareBuildInfo | Where { $_.'SystemName' -eq $SystemName }
    #Get the ACAS data for this system
    $ACASData = $VMwareACASData | Where { $_.'DNS Name' -eq $SystemName }

    #If there is more than one ACAS finding for this host
    If ($ACASData.Count -gt 1) {
        #Select the one with the oldest patch date
        $OldestACASData = $ACASData | Sort 'Patch Publication Date' | Select -First 1
        #Determine how old the finding is
        $Age = ((Get-Date) - [DateTime](($OldestACASData.'Patch Publication Date' -split " ")[0])).Days

        #Select the one with the newest patch date
        $ACASData = $ACASData | Sort 'Patch Publication Date' -Descending | Select -First 1
    } Else {
        #Determine how old the finding is
        $Age = ((Get-Date) - [DateTime](($ACASData.'Patch Publication Date' -split " ")[0])).Days
    }

    #Find ACAS's proposed fixed build number
    If ($ACASData.'Plugin Output' -like "*Fixed build*") {
        #Get the string that includes the build number
        $FixedBuildSplit = $ACASData.'Plugin Output' -Split "Fixed build     : "
        #Sometimes the Plugin Output has MULTIPLE instance of Fixed Build so need to get the LAST one that is provided
        $FixedBuild = $FixedBuildSplit[$FixedBuildSplit.Count - 1]
        #Get just the build number
        $FixedBuildNumber = ($FixedBuild -split " ")[1]
    } Else {
        #Get the string that includes the build number
        $FixedBuild = ($ACASData.'Plugin Output' -Split "Fixed version     : ")[1]
        #Get just the build number
        $FixedBuildNumber = ($FixedBuild -split " ")[2]
    }

    #If the ACAS proposed fix is equal to or less than our confirmed build number
    If ($FixedBuildNumber -le $BuildData.Build) {
        $FalsePositive = "True"
        #Write-Host "$FixedBuildNumber is less then $($BuildData.Build)"
    } Else {
        $FalsePositive = "False"
    }

    $FinalFindingList.add((New-Object "psobject" -Property @{"SystemType"=$BuildData.SystemType;"SystemName"=$BuildData.SystemName;"CurrentVersion"=$BuildData.Version;"CurrentBuild"=$BuildData.Build;
                                                             "PluginName"=$ACASData.'Plugin Name';"FixedBuild"=$FixedBuild;"FixedBuildNumber"=$FixedBuildNumber;"FalsePositive"=$FalsePositive;"Age"=$Age}))
}

#Phase 2: ***Data analysis to create email****

#All Sections contain the following parts:
#$SectionData = New-Object System.Collections.Generic.List[System.Object] #$SectionData gets created/cleared in each section.
#$SectionExplaination is the text that describes the information being presented
#SortedList - always contains the ServerNames and data to add to the email
#A call to the AddDataToTable function which require the parameters of $SortedList and $SectionExplaination

###Version 1.02 - Store any Aria findings###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "Aria findings:"

$AriaACASData = $VMwareACASData | Where { $_.'Plugin Name' -like "*Aria*" -and $_.'DNS Name' -ne "" }

ForEach ($DataItem in $AriaACASData) {
    $FindingDataSplit = $DataItem.'Plugin Output' -Split "`n"
    $InstalledVersion = ($FindingDataSplit[2] -Split " : ")[1]
    $FixedVersion = ($FindingDataSplit[3] -Split " : ")[1]
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"ServerName"=$DataItem.'DNS Name';"Installed Version"=$InstalledVersion;"Fixed Version"=$FixedVersion}))
}

$SortedList = $SectionData | Select "ServerName","Installed Version", "Fixed Version" | Sort 'Installed Version', ServerName

If ($SortedList -ne $null) {
    AddDataToTable $SortedList $SectionExplanation
}

###Our vCenter build numbers###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "vCenter Build Numbers sorted by version:"

$Dataset = $LatestVMwareBuildInfo | Where { $_.SystemType -eq "vCenter" } | Group-Object Version, Build | Select Name, Count | Sort Name -Descending

ForEach ($DataItem in $Dataset) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"Name"=$DataItem.Name;"Count"=$DataItem.Count}))
}

$SortedList = $SectionData | Select "Name","Count"

AddDataToTable $SortedList $SectionExplanation

###Our ESX build numbers###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "ESX Build Numbers sorted by version:"

$Dataset = $LatestVMwareBuildInfo | Where { $_.SystemType -eq "ESX" -and $_.Version -ne "" } | Group-Object Version, Build | Select Name, Count | Sort Name -Descending

ForEach ($DataItem in $Dataset) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"Name"=$DataItem.Name;"Count"=$DataItem.Count}))
}

$SortedList = $SectionData | Select "Name","Count"

AddDataToTable $SortedList $SectionExplanation

###Display vCenter Servers with findings###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$Dataset = $FinalFindingList | Where { $_.SystemType -eq "vCenter" } | Sort "SystemName"

ForEach ($DataItem in $Dataset) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"SystemName"=$DataItem.SystemName;"Version"=$DataItem.CurrentVersion;"CurrentBuild"=$DataItem.CurrentBuild;"FixedBuildNumber"=$DataItem.FixedBuildNumber;"Age"=$DataItem.Age}))
}

$SectionExplanation = "$($SectionData.Count) vCenter Servers with findings:"

$SortedList = $SectionData | Select "SystemName","Version","CurrentBuild","FixedBuildNumber","Age" | Sort "CurrentBuild" -Descending

AddDataToTable $SortedList $SectionExplanation

###Display ESX hosts with findings###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$Dataset = $FinalFindingList | Where { $_.SystemType -eq "ESX" } | Sort "SystemName"

ForEach ($DataItem in $Dataset) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"SystemName"=$DataItem.SystemName;"Version"=$DataItem.CurrentVersion;"CurrentBuild"=$DataItem.CurrentBuild;"FixedBuildNumber"=$DataItem.FixedBuildNumber;"Age"=$DataItem.Age}))
}

$SectionExplanation = "$($SectionData.Count) ESX hosts with findings:"

$SortedList = $SectionData | Select "SystemName","Version","CurrentBuild","FixedBuildNumber","Age" | Sort-Object -Property @{Expression = "CurrentBuild"; Descending = $true}, @{Expression = "SystemName"; Ascending = $true}

AddDataToTable $SortedList $SectionExplanation

#Report any false positives

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "ACAS false positives:"

$Dataset = $FinalFindingList | Where { $_.FalsePositive -eq "True" }

#If there are any false positives to report
If ($Dataset -ne "" -and $Dataset -ne $null) {
    ForEach ($DataItem in $Dataset) {
        $SectionData.add((New-Object -TypeName "psobject" -Property  @{"SystemName"=$DataItem.SystemName;"CurrentBuild"=$DataItem.CurrentBuild;"RequiredBuild"=$DataItem.FixedBuild}))
    }

    $SortedList = $SectionData | Select "SystemName","CurrentBuild","RequiredBuild"

    AddDataToTable $SortedList $SectionExplanation

    #Remove all false positives
    $FinalFindingList = $FinalFindingList | Where { $_.FalsePositive -ne "True" }
}

###ESX Hosts with out of date patches that ACAS missed###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$ListOfAllESXBuilds = ($FinalFindingList | Where { $_.SystemType -eq "ESX" }).CurrentBuild | Select -Unique

$OutOfDateESXHosts = ($LatestVMwareBuildInfo | Where { $ListOfAllESXBuilds -contains $_.Build }).SystemName
$FoundOutOfDateHosts = ($FinalFindingList | Where { $ListOfAllESXBuilds -contains $_.CurrentBuild }).SystemName

$SortedList = Compare-Object -ReferenceObject $OutOfDateESXHosts -DifferenceObject $FoundOutOfDateHosts | Where { $_.SideIndicator -eq "<=" } | Sort InputObject | Select @{Name="SystemName";Expression={$_.InputObject}}

If ($SortedList -ne $null) {
    $SectionExplanation = "$($SortedList.Count) ESX hosts missing patches that didn't appear in ACAS:"

    AddDataToTable $SortedList $SectionExplanation
}

#Phase 3 ***Create Email*****

Write-Host "`nGenerating email"

#Add link to Server Problem Report at the bottom of the email
$EmailHTMLBody += "<br>Data generated from $LatestACASFileName and $LatestVMwareBuildFileName<br>"

###Construct the email###
$objOutlook = New-Object -comObject Outlook.Application

$Email = $objOutlook.CreateItem(0)
$Email.To = "matthew.2.miller@dla.mil;scott.r.smith@dla.mil;kenneth.smith.ctr@dla.mil;carlton.parker.ctr@dla.mil;joseph.nicklous@dla.mil;dawn.gordon@dla.mil;rajesh.singh@dla.mil"
$Email.CC = "john.siegrist@dla.mil;casey.wyckoff@dla.mil;michael.d.russcher@dla.mil"
$Email.Subject = "VMware ACAS findings - $(Get-Date -Format MM/dd/yy)"

$Email.HTMLBody = $EmailHTMLBody

$Email.save()

$Inspector = $Email.GetInspector
$Inspector.Display()

Write-Host "`nScript complete" -ForegroundColor Green

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBCpP+AkaTk25Hm
# J+/lGV2V+nfkrH9CQmO1rEDlX5xSY6CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAvAkwyNw4DF2wZerTQM0iu4m21JwkMBBO4KJy2OJtxPzANBgkq
# hkiG9w0BAQEFAASCAQBeF1J07KIjsN66P0Y5dMOHtsqJS/TREkNtwJ42tTrFYAIl
# ni6e82qfXS6FYZd4BebOeym7H2S37z6nIZe2PGA3Ynnn0FZyFnY0Z1z+RsrS78l4
# rN0l+EM1g3gZdRctZTNaudCuF3J+R2sDl4hyKgMCmj/ojj4HHM8hLb5NVk4+m4wr
# r92z3hJ46RCiew+AhlFzCeriRFTYaGU9/8k3G2WWfjjQSmHRCWUseUT+KYcBZP9+
# F9LAv71DnVwSaJb+yVA5tN420Rpbv/MUYKPTThJlVr820ObfFpl7P82n4hH10k9y
# 1/kClERBk1x37tnT9dKl8ZTEeZr1hpABOcZ/ypa8
# SIG # End signature block
