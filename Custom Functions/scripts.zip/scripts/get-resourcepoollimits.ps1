﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2020 v5.7.174
	 Created on:   	6/12/2020 9:49 AM
	 Created by:   	Matthew Miller
	 Organization: 	INFO OPTERATIONS
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

$report = @()

foreach ($cluster in Get-Cluster)
{
	
	foreach ($rp in Get-ResourcePool -Location $cluster)
	{
		
		foreach ($vm in (Get-VM -Location $rp))
		{
			
			$report += Get-HardDisk -VM $vm |
			
			Select @{ N = 'Cluster'; E = { $cluster.Name } },
			
				   @{ N = 'ResourcePool'; E = { $rp.Name } },
			
				   @{ N = 'VM'; E = { $vm.Name } },
			
				   @{ N = 'HD'; E = { $_.Name } },
			
				   @{ N = 'Datastore'; E = { ($_.Filename.Split(']')[0]).TrimStart('[') } },
			
				   @{ N = 'Filename'; E = { ($_.Filename.Split(' ')[1]).Split('/')[0] } },
			
				   @{ N = 'VMDK Path'; E = { $_.Filename } },
			
				   @{ N = 'Format'; E = { $_.StorageFormat } },
			
				   @{ N = 'Type'; E = { $_.DiskType } },
			
				   @{ N = 'VM Tools Status'; E = { $vm.ExtensionData.Guest.ToolsStatus } },
			
				   @{ N = 'CapacityGB'; E = { $_.CapacityGB } }
			
		}
		
		$report | Export-Csv C:\temp\report.csv -NoTypeInformation -UseCulture
		
	}
	
}

