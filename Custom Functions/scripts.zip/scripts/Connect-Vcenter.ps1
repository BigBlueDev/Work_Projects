﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2020 v5.7.174
	 Created on:   	10/14/2020 12:32 PM
	 Created by:   	Matthew Miller
	 Organization: 	INFO OPTERATIONS
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>


param (
	[Parameter(Mandatory = $true)]
	[String]$VIServer,
	[Parameter(Mandatory = $true)]
	[string]$username,
	[Parameter(Mandatory = $true)]
	[security.securestring]$password
)





connect-viserver -server $VIServer -user $username -password $password

$ArrayVM = get-vm | sort -Property name

$ArrayVM | out-host













