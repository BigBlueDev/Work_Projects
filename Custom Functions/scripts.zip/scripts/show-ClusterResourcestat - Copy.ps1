﻿
$VIServer = "DAISV0TP212.dir.ad.dla.mil"

#Connect-VIServer -Server $viserver | out-null

$ClusterCol = Get-cluster
$data = @()
Foreach ($cluster in $clustercol) 
{
    foreach($Pool in (Get-ResourcePool)){
    $vmlist = $pool | get-vm
            $vmCol = @()
                 foreach ($vm in $vmlist) {
                 

                    $VMobj = new-object -TypeName psobject
                    $vmobj | add-member -MemberType NoteProperty -Name VMName -Value $vm.name
                    $vmobj | add-member -MemberType NoteProperty -Name VMCPU -Value $vm.NumCpu
                    $vmobj | add-member -MemberType NoteProperty -Name VMMemory -Value $vm.MemoryGB
                    $vmobj | add-member -MemberType NoteProperty -Name VMPower -Value $vm.PowerState
                    $vmobj | add-member -MemberType NoteProperty -Name VMHost -Value $vm.vmhost.name

                    
                    $VMCol += $VMobj
                  }
            $RPVMcpucount = @($vmcol | Measure-Object -Property VMCPU -Sum).sum
            $RPVMmemcount = @($vmcol | Measure-Object -Property VMMemory -Sum).sum
            $RPVMPoweredOn = @($vmcol | Select * | where{$_.VMPower -eq "PoweredOn"}).count
            $RPVMPoweredoff = @($vmcol| where{$_.VMPower -eq "PoweredOff"}).Count
            $RPVMHostCpuMhz = (get-vmhost -name $vmcol.vmhost -ErrorAction SilentlyContinue).CpuTotalMhz | Measure-Object -Sum 
            $RPvmhostCPuType = (get-vmhost -name $vmcol.vmhost -ErrorAction SilentlyContinue).ProcessorType
            

            $Results = New-Object PSObject -Property ([ordered]@{

                vCenter = $VIServer
                
                Cluster = $cluster.Name

                'Resource Pool Name' = $pool.name

                'VMs running in Resource Pool' = $RPVMPoweredOn 

                'VMs Assigned but not running' = $RPVMPoweredoff

                'Resource Pool CPU Limit (MHz)' =    $pool.CpuLimitMHz

                'Resource Pool Memory Limit (GB' = $pool.MemLimitGB

                'CPUs Assigned to VMs from RP' = $RPVMcpucount
                
                'Memory Azzigned to VMs from RP' = $RPVMmemcount

                'Total CPU Mhz available' = $RPVMHostCpuMhz.sum

                'Host Processor' = $RPvmhostCPuType | select -first 1

                })
            $data += $results
                }                  
}

$data  | export-csv c:\temp\RP_Overcommit.csv -NoTypeInformation -force