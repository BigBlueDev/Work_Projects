#PURPOSE: find all VMs that need to get updated to the latest version of Network Watcher Agent

#CHANGELOG
#Version 1.0 - 07/22/24 - MDR - Initial version

#Configure variables
[Version]$MinVersion = "1.4.3320.1"
$TodaysDate = Get-Date -Format "MMddyy"
$ReportPath = "/home/azureuser/clouddrive/NetworkWatcherExtensionUpdate-$TodaysDate.csv"

#Get a list of all subscriptions
$SubscriptionList = Get-AzSubscription

#Loop through each subscription
ForEach ($CurrSubscription in $SubscriptionList) {
    #Display which subscription is being looked at
    Write-Host "`nChecking subscription $($CurrSubscription.Name)" -ForegroundColor Cyan

    #Connect to current subscription
    Set-AzContext -SubscriptionId $CurrSubscription | Out-Null

    #Get list of all VMs in that subscription
    $VMList = Get-AzVM

    #Get the number of VMs
    $VMCount = $VMList.Count
    #Set the counter to 1
    $CurrentVM = 1

    #Loop through all VMs
    ForEach ($VMName in $VMList) {
        #Update process bar
        Write-Progress -Activity "Checking VMs" -Status "$CurrentVM of $VMCount - $($VMName.Name)" -PercentComplete ($CurrentVM / $VMCount * 100)

        #Get the data for this VM
        $VMData = Get-AzVM -ResourceGroupName $VMName.ResourceGroupName -Name $VMName.name -Status

        #Determine if Azure Network Watcher Extension is on this VM
        $ExtensionCheck = $VMData.Extensions | Where { $_.Name -eq "AzureNetworkWatcherExtension" }
        
        #If the extension was found
        If ($ExtensionCheck -ne $null) {
            #If the extension is found but there is no version data for it then skip it
            If ($ExtensionCheck.TypeHandlerVersion -eq $null) {
                Write-Host "`nExtension found on $($VMName.Name) but no version data.  Skipping" -ForegroundColor Yellow
                [PSCustomObject]@{"ServerName"=$VMName.Name;"Subscription"=$CurrSubscription.Name;"PreviousVersion"="Not found";"NewVersion"="Skipped"} | Export-CSV $ReportPath -NoTypeInformation -Append
                Continue
            }

            #If this is a Windows System
            If ($VMData.OsName -like "*Windows*") {
                $ExtName = "NetworkWatcherAgentWindows"
            } Else { #If this is not a Windows system 
                $ExtName = "NetworkWatcherAgentLinux"
            }

            #If the current version is older than the expected version then upgrade it
            If ([Version]$ExtensionCheck.TypeHandlerVersion -lt $MinVersion) {
                Write-Host "`nUpgrading $($VMName.Name) from $($ExtensionCheck.TypeHandlerVersion) to the latest version"
                Set-AzVMExtension -ResourceGroupName $VMName.ResourceGroupName -Location $VMName.Location -VMName $VMName.Name -Name "AzureNetworkWatcherExtension" -Publisher "Microsoft.Azure.NetworkWatcher" -Type $ExtName | Out-Null
                [PSCustomObject]@{"ServerName"=$VMName.Name;"Subscription"=$CurrSubscription.Name;"PreviousVersion"=$ExtensionCheck.TypeHandlerVersion;"NewVersion"=$MinVersion} | Export-CSV $ReportPath -NoTypeInformation -Append
            }
        }

        #Update progress bar counter
        $CurrentVM++
    }

    #Close out the progress bar
    Write-Progress -Activity "Checking VMs" -Completed
}

#Script completed
Write-Host "Script complete" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCoXS2r1eyOJil+
# 4MpoLpvP042Ga0izWNwkHOn7AavwD6CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDfh0mv5F2bpKPZsYsR6ta9dtscUQCn7UNFRUiscHzx8jANBgkq
# hkiG9w0BAQEFAASCAQBNO/91ycgSS/FgUv2wDZIEweoUCVdcyM2w/7qwA5Jz8B/k
# 8Hkd0l0r1UrG5uaaHaKysJQqRF5p67KyO84zqutAsJm8XtOScrIZil72OHrJFfMD
# RVOi/NXJckrtua2fXjZqWnongrf/tMKMu7ta8hbMMbYRizheHaSZkB/qECmNtL/c
# cxX8U9pl34Nsu70SORRE8KanHDqqXz1fegxyX/Rfeksua2+Agg3G3ZEk1FPj051R
# EFrywdSEdzqSZChXwN2Ld9e3gwf4bcqPZ5soxQLxrlmizWl2cADrcdn4QMc6kjx2
# GsjpiRvJhjgV/atoRkJqMaaD2t/lA4TOwsQ7pXCY
# SIG # End signature block
