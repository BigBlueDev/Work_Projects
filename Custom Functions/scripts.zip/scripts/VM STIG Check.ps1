﻿#PURPOSE: Perform a STIG check on a list of VMs and output CKL files with the results

#CHANGELOG
#Version 1.0 - 03/25/24 - MDR - Initial version
#Version 1.04 - 06/20/24 - MDR - Never record the FQDN for the VM since the VM should just go by the VM name
#Version 1.05 - 10/01/24 - MDR - Make this script compatible with running from Orchestrator
#Version 1.06 - 11/21/24 - MDR - Add AutoClose to automatically close certain findings
#Version 1.07 - 01/30/25 - MDR - Adding code for POAMs and Documentables
#Version 1.08 - 02/03/25 - MDR - Added a check to confirm there are any POAMs / Documentables

#Version 1.05 - Added the $RunFromOrchestrator parameter
Param ( $ChecklistFilePath, $CurrentSystemName, $STIGParams, $RunFromOrchestrator )

#Create an XML object
$Checklist_XMLObject = New-Object XML
#This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
$Checklist_XMLObject.PreserveWhitespace = $true
#This is the name of the empty checklist template file
$Checklist_XMLObject.Load("$ChecklistFilePath")

#Version 1.03 - Attempt to get the FQDN and IP from VMware Tools
$VMGuestView = (Get-VM $CurrentSystemName | Get-View).Guest

#Depending on whether VMware Tools has info then add the best info available
If ($VMGuestView.HostName) {
    $VMHostName = $VMGuestView.HostName
    $VMMacAddr = (Get-VM $CurrentSystemName | Get-NetworkAdapter).MacAddress
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$CurrentSystemName
    #Version 1.04 - The FQDN should never get recorded for the VM rather than $($VMHostName.Split("."))[0]
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$CurrentSystemName
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = [String]$($VMGuestView.IPAddress)
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = [String]$VMMacAddr
} Else { #Only use this if VMware Tools can't pull the proper information
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$CurrentSystemName
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$CurrentSystemName
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = ""
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = ""
}

$Global:VULN_DATA = $Checklist_XMLObject.CHECKLIST.STIGS.iSTIG.VULN

ForEach ($Global:VULN in $VULN_DATA) {
    [System.Windows.Forms.Application]::DoEvents()
    
    $Vuln_Num = ($VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq 'Vuln_Num' }).ATTRIBUTE_DATA
    #Version 1.03 - Collecting Severity for reporting purposes later in the script
    $Severity = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA
    #Version 1.03 - Changed from $STIGCheck to $VCodeObjectSTIGData
    $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $Vuln_Num }
    #Version 1.07 - Get whether there are POAMs or Documentables for this finding
    $POAMDocumentableData = $STIGParams["POAM-Documentable"] | Where { $_.Vuln_Num -eq $Vuln_Num }

    #If there is a line in $STIGParams for the V-Code in this checklist
    If (!($VCodeObjectSTIGData)) {
        $VULN.COMMENTS = "No entry existed in the STIG parameters file for this V-Code"

        If ($NoSTIGParamList -notcontains $Vuln_Num) {
            $NoSTIGParamList += $Vuln_Num
        }
    } Else {
        #Version 1.03 - Ensure these are all cleared ahead of each check
        Clear-Variable CustomComment, FindingHint, ESXSettingValue -ErrorAction SilentlyContinue

        If ($VCodeObjectSTIGData.Check_Method -eq "Configuration") {
            #Version 1.03 - Changed $SettingValue to $SystemSettingValue
            $SystemSettingValue = (Get-VM $CurrentSystemName | Get-AdvancedSetting -Name $VCodeObjectSTIGData.Check_Param).Value

            If ($VCodeObjectSTIGData.Check_Name -eq "Disable Shared Salt Values" -and $SystemSettingValue -eq $null) {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
                $SystemSettingValue = "Does not exist"
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Disable 3D Support" -or $VCodeObjectSTIGData.Check_Name -eq "Retain Old Logs") {
                If ($SystemSettingValue -eq $null) {
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                    $SystemSettingValue = "Does not exist"
                } Else {
                    If ($VCodeObjectSTIGData.Check_Name -eq "Disable 3D Support") {
                        $VCodeObjectSTIGData.Expected_Value = "False"
                    } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Retain Old Logs") {
                        $VCodeObjectSTIGData.Expected_Value = "10"
                    }
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Auto Lock Console") {
                If (((Get-VM $CurrentSystemName).Guest).OSFullName -like "*Windows*") {
                    $VCodeObjectSTIGData.Expected_Value = "True"
                } Else { #If this is NOT a Windows base VM then this check weirdly isn't NA, but instead NF
                    #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                    $FindingHint = "NF"
                    If ($SystemSettingValue -eq $null) {
                        $SystemSettingValue = "Non-Windows VM therefore check doesn't apply"
                    } Else {
                        $SystemSettingValue = "$SystemSettingValue - Non-Windows VM therefore check doesn't apply"
                    }
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ConfigurationWildcard") {
            $SystemSettingValue = (Get-VM $CurrentSystemName | Get-AdvancedSetting | Where { $_.Name -like $VCodeObjectSTIGData.Check_Param }).Value

            If ($SystemSettingValue -eq $null) {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
                $SystemSettingValue = "Does not exist"
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "Manual"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VMConfig") {
            $AllowedValues = $VCodeObjectSTIGData.Expected_Value.Split(",")
            $CheckParam = $VCodeObjectSTIGData.Check_Param
            $SystemSettingValue = (Get-VM $CurrentSystemName).ExtensionData.Config.$CheckParam
            
            If ($AllowedValues -contains $SystemSettingValue) {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VMFlag") {
            $CheckParam = $VCodeObjectSTIGData.Check_Param
            $SystemSettingValue = (Get-VM $CurrentSystemName).ExtensionData.Config.Flags.$CheckParam
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "HardDisk") {
            $AllowedValues = $VCodeObjectSTIGData.Expected_Value.Split(",")
            $HardDiskInfo = Get-VM $CurrentSystemName | Get-HardDisk | Select Filename, Persistence
            $NonpersistentHardDisks = ($HardDiskInfo | Where { $AllowedValues -notcontains $_.Persistence }).Filename

            If ($NonpersistentHardDisks) {
                $CustomComment = "The following hard disks are non-persistent:`n`n$($NonpersistentHardDisks.Filename -join ""`n"")"
            } Else {
                $CustomComment = "All hard disks are persistent`n`n$($HardDiskInfo.Filename -join ""`n"")"
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "FloppyDisk") {
            $FloppyDiskInfo = Get-VM $CurrentSystemName | Get-FloppyDrive | Select Name

            If ($FloppyDiskInfo) {
                $CustomComment = "The following floppy disks were found:`n`n$($FloppyDiskInfo -join ""`n"")"
            } Else {
                $CustomComment = "No floppy disks found"
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "CDDrive") {
            $CDROMInfo = Get-VM $CurrentSystemName | Get-CDDrive | Where {$_.extensiondata.connectable.connected -eq $true} | Select Name, IsoPath

            If ($CDROMInfo) {
                $CustomComment = "The following CD-ROMs have something connected to them:`n`n$($CDROMInfo.Name) - $($CDROMInfo.IsoPath)" -join "`n"
            } Else {
                $CustomComment = "No CD-ROMs connected"
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "Hardware") {
            $SystemSettingValue = (Get-VM $CurrentSystemName).ExtensionData.Config.Hardware.Device.DeviceInfo.Label | Where { $_ -like "$($VCodeObjectSTIGData.Check_Param)*" }

            If ($SystemSettingValue) {
                $CustomComment = "Found $($VCodeObjectSTIGData.Check_Param) on this VM:`n`n$($SystemSettingValue -join ""`n"")"

                If ($VCodeObjectSTIGData.Check_Name -eq "No USB Devices") {
                    $USBDeviceList = Get-VM $CurrentSystemName | Get-UsbDevice

                    If ($USBDeviceList) {
                        $CustomComment += "`n`nFound these USB devices:`n`n$($USBDeviceList.Name -join ""`n"")"
                    } Else {
                        #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                        $FindingHint = "NF"
                        $CustomComment += "`n`nUSB Controller is used for SmartCard and no other USB device is found so this is not a finding"
                    }
                }
            } Else {
                #Version 1.03 - Replaced expected and actual values with just setting hint to NF
                $FindingHint = "NF"
                $SystemSettingValue = "No devices found"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AutoOpen") {
            #Version 1.03 - Set this to say the policies are not yet in place
            $SystemSettingValue = "This policy is currently in the process of being enacted"
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AutoClose") {
            #Version 1.06 - Automatically close findings
            $FindingHint = "NF"
            $SystemSettingValue = "The policy for $($VCodeObjectSTIGData.Check_Name) is established and in place"
        }

        #Version 1.08 - First verify that there are available POAMs or Documentables for the vulnerability number
        If ($POAMDocumentableData.Affected_Systems -ne $null) {
            #Version 1.07 - If the current system is on the POAM-Documentable list AND it will end up being a finding
            If ($CurrentSystemName -like "$($POAMDocumentableData.Affected_Systems)*" -and $FindingHint -ne "NF" -and $SystemSettingValue -ne $VCodeObjectSTIGData.Expected_Value) {
                If ($POAMDocumentableData.Type -eq "POAM") {
                    $SystemSettingValue = "$SystemSettingValue - POAM on file"
                } Else { #If this is a documentable
                    $SystemSettingValue = "$SystemSettingValue - This is a documentable finding for this system"
                    $FindingHint = "NF"
                }
            }
        }

        $parms = @{
            CorrectVal = $VCodeObjectSTIGData.Expected_Value
            ActualVal = $SystemSettingValue
            CustomComment = $CustomComment
            FindingHint = $FindingHint
            CurrentSystemName = $CurrentSystemName
        }

        #Version 1.05 - If this is run from Orchestrator then run the check script from a local copy rather than a network one
        If ($RunFromOrchestrator -eq "True") {
            #Run the RecordToChecklist.ps1 script from a local copy
            Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\RecordToChecklist.ps1"" @parms")
        } Else {
            #Run the RecordToChecklist.ps1 script from the network
            Invoke-Expression -Command ("& '$FolderPathToSTIGScript\RecordToChecklist.ps1' @parms")
        }
    }
}

$Checklist_XMLObject.Save($ChecklistFilePath)

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCClAOjKerV5oTIY
# 5TheDw8rI0cgl/w72ryujyaXh5wIWaCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBAIaYO7o3NQFmn5NWEXZUp15ZxPGC2VeDcfeIJUhtnWjANBgkq
# hkiG9w0BAQEFAASCAQAGSTDj5NR7mqAEQrLBaGtOPsR9vMfNPDTbAhuviSl7+MMh
# 8UjRYASic6tDOkclown7k2qjs6/GNTBXBZZDRsj0iWEEqT7klPKNNNNRkJPIKbBt
# NAuGuj71TCK3mt6uvDD8uNkRsCqF8uoVPnzY1ytPFUjx5Ww0/zaTUeNoM+F/nYDA
# DFGG7QSajwAfW9U1GOfFwY4l7n4g8XDOSTz5qB+sgo9C82+bMydtJmzV8jWwtpKx
# 7Bc3pSvDyRS74v8x142l5Hfih3QFkqijhDjOD27GcqZz8PDYQZIQOZKKJ7NB3cOu
# Maa8A3dJO/vxebvBhb2egKWj8+Wr4m9LY5Tcmjby
# SIG # End signature block
