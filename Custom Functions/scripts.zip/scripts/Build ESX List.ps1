#PURPOSE: Create a list of ESX hosts

#CHANGELOG
#Version 1.00 - 07/05/24 - MDR - Initial version
#Version 1.01 - 09/13/24 - MDR - Making this script compatible with Orchestrator
#Version 1.02 - 10/01/24 - MDR - Minor changes to handle issues with the ETC hosts
#Version 1.03 - 01/06/25 - MDR - If an error occurs in the script that prevents any data collection, prevent the CSV from getting overwritten

#Version 1.01 - Adding parameters
Param ( $vCenterPassword, $VRAPassword, $RunFromOrchestrator )

#Configure variables
$TodaysDate = Get-Date -Format "MMddyy"
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports"
$ESXHostData = New-Object System.Collections.Generic.List[System.Object]
$LocationStates = New-Object System.Collections.Generic.List[System.Object]

$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Albany";"State"="GA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Anniston";"State"="AL"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Bahrain";"State"="BH"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Battle Creek";"State"="MI"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Bremerton";"State"="WA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Cape May";"State"="NJ"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Cherry Point";"State"="NC"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Columbus";"State"="OH"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Corpus Christi";"State"="TX"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Dayton";"State"="OH"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Ft. Belvoir";"State"="BA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Ft. Benning";"State"="GA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Ft. Jackson";"State"="SC"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Ft. Leonard Wood";"State"="MO"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Ft. Sill";"State"="OK"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Germersheim";"State"="GE"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Great Lakes";"State"="IL"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Huntsville";"State"="AL"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Jacksonville";"State"="FL"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Kleber";"State"="KL"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Lackland AFB";"State"="TX"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Mechanicsburg";"State"="PA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="New Cumberland";"State"="PA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Norfolk";"State"="VA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Norfolk NSY";"State"="VA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Ogden";"State"="UT"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Oklahoma City";"State"="OK"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Parris Island";"State"="SC"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Philadelphia";"State"="PA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Red River";"State"="TX"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Richmond";"State"="VA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="San Diego (North Island)";"State"="CA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="San Diego (RTC)";"State"="CA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Sigonella";"State"="SI"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Tobyhanna";"State"="PA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Tracy";"State"="CA"}))
$LocationStates.add((New-Object -TypeName "psobject" -Property  @{"Location"="Warner Robins";"State"="GA"}))

#Version 1.01 - Create an ouput file for commands being executed
Start-Transcript C:\Temp\Build_ESX_List_$TodaysDate.txt

#Version 1.01 - If this is run from Orchestrator then generate a credential to perform the PSDrive mapping
If ($RunFromOrchestrator -eq "True") {
    #Version 1.01 - Create a credential for svc_vrapsh
    $VRACred = New-Object System.Management.Automation.PSCredential -ArgumentList @("DIR\svc_vrapsh",(ConvertTo-SecureString -String $VRAPassword -AsPlainText -Force))
    #Version 1.01 - Map a drive to the ReportPath
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -Credential $VRACred | Out-Null
} Else { #If not run from Orchestrator then just map the PSDrive with current credentials
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath | Out-Null
}

Clear

#Version 1.01 - If the vCenter password is passed then no need to prompt for it
If ($vCenterPassword -eq $null) {
    #Prompt for vCenter Password
    $vCenterCreds = Read-Host "Input the vCenter PowerShell account password" -MaskInput
} Else {
    $vCenterCreds = $vCenterPassword
}

#Exit if no password was entered
If ($vCenterCreds -eq $null) {
    Write-Host "No password was entered so exiting the script"
    Break
}

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    #Output vCenter Server name
    Write-Host "`nScanning $($vCenterServer.ServerName)"

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterCreds -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    Try {
        #Disconnected from all vCenter Servers
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    } Catch { }

    #Connect to vCenter Server
    Connect-VIServer $vCenterServer.ServerName -Credential $vCenterSecureCreds | Out-Null
    
    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServer.ServerName })) {
        Write-Host "`nFailed to connect to vCenter Server $($vCenterServer.ServerName)" -ForegroundColor Red
        Break
    }

    #Get a list of all connected ESX hosts
    $ESXHostList = Get-VMHost | Where { $_.ConnectionState -eq "Connected" -or $_.ConnectionState -eq "Maintenance" }

    #Populate variables for progress bar
    $TotalESXHost = $ESXHostList.Count
    $CurrentESXNum = 1

    #Loop through each ESX host
    ForEach ($CurrentESXHost in $ESXHostList) {
        #Version 1.01 - If this is run from Orchestrator then output the ESX host name to get written to the transcript file
        If ($RunFromOrchestrator -eq "True") {
            Write-Host $CurrentESXHost.Name
        } Else { #If not from Orchestrator then write a progress bar
            #Update progress bar
            Write-Progress -Activity "Getting ESX host data" -Status "$CurrentESXNum of $TotalESXHost" -PercentComplete ($CurrentESXNum / $TotalESXHost * 100)
        }

        #Get the data from the ESX host
        $ESXVMHost = Get-VMHost $CurrentESXHost

        #Get the location tag for the server
        $LocationName = ((Get-TagAssignment -Entity $ESXVMHost | Where { $_.Tag -like "*Site_Location*"}).Tag).Name

        #Determine the state for the location
        $StateInitials = ($LocationStates | Where { $_.Location -eq $LocationName }).State

        #Version 1.02 - If no build data is readable then this a symptom of there being an issue reading data from this host and it'll need to be skipped
        If ($ESXVMHostInfo.Build -ne $null) {
            #Get IP Address
            $IPAddr = ($ESXVMHost | Get-VMHostNetworkAdapter | Where { $_.ManagementTrafficEnabled -eq $true -and $_.IP -notlike "10.*" }).IP
        } Else { #Version 1.02 - As a backup, just use the DNS resolution to get the IP address even though it isn't preferable since the DNS entry could theoretically be wrong
            $IPAddr = (Resolve-DnsName $CurrentESXHost.Name).IPAddress
        }

        #Store data from the ESX host
        $ESXHostData.add((New-Object "psobject" -Property @{"vCenterServer"=$vCenterServer.ServerName;"SystemName"=$CurrentESXHost.Name;"Location"=$LocationName;"State"=$StateInitials;"IPAddr"=$IPAddr}))
    
        #Increment progress bar counter
        $CurrentESXNum++
    }

    #Close the progress bar
    Write-Progress -Activity "Getting ESX host data" -Completed
}

#Version 1.03 - Avoid overwritting the spreadsheet if there is no data due to some failure
If ($ESXHostData.count -ne 0 -and $ESXHostData -ne $null) {
    Write-Host "`nData collection completed.  Writing report"
    #Export data to CSV
    $ESXHostData | Select SystemName,vCenterServer,Location,State,IPAddr | Export-CSV "ReportPath:\ESXHostList.csv" -NoTypeInformation -Force
} Else {
    Write-Host "`nFailed to collect any data" -ForegroundColor Red
}

Write-Host "`nScript Complete.  Report written to $ReportPath\ESXHostList.csv" -ForegroundColor Green

#Version 1.01 - Stop the transcript
Stop-Transcript
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBja/bb2YxtbSze
# 3Rjpr9/9Rlw3FfyaAz61evoSdy3woKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCmbVfTfd0GRUTCAFH392MqJV2sDrZTNUBF2JWIhj/ZcjANBgkq
# hkiG9w0BAQEFAASCAQBXq7zJxk+6pOfoNS8/bBo3+znsp07s+zx3M2zRH6D0H/JZ
# a4fIHuu5zRVrBw0MMHUzLL8tUuUWafm86TrwDc9b2gAzOflhkbDpqQsFoiTbIrhE
# mAfS8GHUuylwrbyY1bqrcji9DLuu+JL2t4LhAUnBBPXjNYfcD1mL9pWpRQKn8heC
# 8kZySZH6TWHUTk3CPInKwXvvMwwCNHrvAgwpOJ8xt1w4QChd6+GIk5CDRcfBJ/4G
# gSFRbJZyb/X8bfAcfvxpvU5zLfOhi2SrOoYLuE+OBV9kgxtje3gbC+rQzAtlvJEn
# EhplXDM2BOyL6VIIoCsjdnwyoj2sCyLoStCqswrF
# SIG # End signature block
