#PURPOSE: This script will collect all Azure inventory information

#CHANGELOG
#Version 1.00 - 09/25/24 - MDR - Initial version

Param ( $VRAPassword, $AzurePassword, $ApplicationID, $TenantID, $RunFromOrchestrator )

#Configure variables
$TodaysDate = Get-Date -Format "MMddyyyy"
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Reports"
$ReportFileName = "Master_Azure_VMInventory_$TodaysDate.xlsx"
$ShortReportName = "Master_Azure_VMInventory"
$AzureVMInfoList = New-Object System.Collections.Generic.List[System.Object]

#Report column headers
$ReportColumnHeaders = "VM Name","Resource Group Name","VM Status","Location","Application","Function","Impact","Mission","License Type","VM Size","Managd Disk","VM Memory","VM Cores","VM Agent Version",
                       "VM Agent Status","OS Type","OSDisk","OS Disk Size","BootDiag","BootDiag_SA","Shutdown","Startup","Role","Role_Assignement","VM Generation","Nic_1_Name","Nic1_AcceleratedNetworking",
                       "Nic_1_Subnet","Nic_1_IP1","Nic_1_IP2","Nic_2_Name","Nic2_AcceleratedNetworking","Nic_2_Subnet","Nic_2_IP1","Nic_2_IP2","Nic_3_Name","Nic3_AcceleratedNetworking","Nic_3_Subnet","Nic_3_IP1",
                       "Nic_3_IP2","OS Name","OS Version"

Start-Transcript C:\Temp\Get_All_Azure_Inventory_$TodaysDate.txt

Clear

#If this is run from Orchestrator then generate a credential to perform the PSDrive mapping
If ($RunFromOrchestrator -eq "True") {
    #Convert the VRA password to a secure string
    $VRACred = New-Object System.Management.Automation.PSCredential -ArgumentList @("DIR\svc_vrapsh",(ConvertTo-SecureString -String $VRAPassword -AsPlainText -Force))
    #Map a drive to the ReportPath
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -Credential $VRACred | Out-Null
} Else { #If not run from Orchestrator then just map the PSDrive with current credentials
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -ErrorAction SilentlyContinue | Out-Null
}

#If for some reason an Access Denied error happens here then exit the script
Try {
    #If this report exists already then delete it
    If (Test-Path "ReportPath:\$ReportFileName" -ErrorAction Stop) {
        Remove-Item "ReportPath:\$ReportFileName"
    }
} Catch { #If an Access Denied error occurs or any other error trying to reach the $ReportPath
    Write-Host "Unable to access $ReportPath" -ForegroundColor Red
    Break
}

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Check to see if ImportExcel is installed
$CheckForImportExcel = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If ImportExcel is not found then prompt for folder Where it is located
If (!$CheckForImportExcel) {
    Write-Host "The ImportExcel module is required for this script to run" -ForegroundColor Red
    Write-Host "`nA copy of this module is located in \\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\Software\ImportExcel"
    Write-Host "`nPlace a copy of this module in C:\Program Files\WindowsPowerShell\Modules"
    Break
}

Write-Host "Collecting Azure subscription information"

#If this is run from Orchestrator then you'll need to log into the server to configure this
If ($RunFromOrchestrator -eq "True") {
    #Convert the Azure password to a secure string
    $AzureAppCred = New-Object System.Management.Automation.PSCredential -ArgumentList @($ApplicationID, (ConvertTo-SecureString -String $AzurePassword -AsPlainText -Force))
    #Connect to Azure using the supplied creds from Orchestrator
    Connect-AzAccount -Environment AzureUSGovernment -ServicePrincipal -TenantId $TenantID -Credential $AzureAppCred | Out-Null

    #Get a list of subscriptions
    $SubscriptionList = Get-AzSubscription | Sort Name

    #Check to see if the Orchestrator creds allowed for subscriptions to be read
    If ($SubscriptionList.count -lt 1)  {
        Write-Host "`nNot connected to Azure.  Exiting script"
        Break
    } Else { #Notify that Azure is now connected
        Write-Host "`nConnected to Azure US Government" -ForeGroundColor Cyan 
    }
} Else { #If this is run manually then allow for picking the Azure account to login with
    #Get a list of subscriptions
    $SubscriptionList = Get-AzSubscription | Sort Name

    #Check to see if subscriptions were collected
    If ($SubscriptionList.count -lt 1)  {
        Write-Host "`nNot connected to Azure.  When the popup appears please login to Azure" -ForeGroundColor Yellow
        Connect-AzAccount -EnvironmentName AzureUSGovernment | Out-Null

        #Get a list of subscriptions
        $SubscriptionList = Get-AzSubscription | Sort Name

        #Check to see if the supplied creds allowed for subscriptions to be read
        If ($SubscriptionList.count -lt 1)  {
            Write-Host "`nNot connected to Azure.  Exiting script"
            Break
        } Else { #Notify that Azure is now connected
            Write-Host "`nConnected to Azure US Government" -ForeGroundColor Cyan 
        }
    } Else { #Notify that Azure is now connected
        Write-Host "`nConnected to Azure US Government" -ForeGroundColor Cyan 
    }
}

#Loop through each subscription
ForEach ($CurrSubscription in $SubscriptionList) {
    #Get subscription name
    $SubscriptionName = $CurrSubscription.Name
    #Display subscription name
    Write-Host "`nProcessing Subscription: $SubscriptionName"
    #Set context to current sub
    Set-AzContext $CurrSubscription | Out-Null
    #Get a list of all VMs in the subscription
    $VMList = Get-AzVM

    #Populate variables for progress bar
    $TotalVMs = $VMList.Count
    $CurrentVMNum = 1

    #Loop through all VMs
    ForEach ($VMInfo in $VMList) {
        #Get the host group name
        $VMName = $VMInfo.Name

        #If this is run from Orchestrator then output the VM name to get written to the transcript file
        If ($RunFromOrchestrator -eq "True") {
            Write-Host $VMName
        } Else { #If not from Orchestrator then write a progress bar
            #Update progress bar
            Write-Progress -Activity "Getting host group data" -Status "$CurrentVMNum of $TotalVMs" -PercentComplete ($CurrentVMNum / $TotalVMs * 100)
        }

    


    }

#Write just the basic info for the host but leave the virtual machines blank
$AzureVMInfoList.add((New-Object "psobject" -Property @{"VM Name"=$VMName;"Resource Group Name"="";"VM Status"="";"Location"="";"Application"="";"Function"="";
"Impact"="";"Mission"="";"License Type"="";"VM Size"="";"Managd Disk"="";"VM Memory"="";
"VM Cores"="";"VM Agent Version"="";"VM Agent Status"="";"OS Type"="";"OSDisk"="";"OS Disk Size"="";
"BootDiag"="";"BootDiag_SA"="";"Shutdown"="";"Startup"="";"Role"="";"Role_Assignement"="";
"VM Generation"="";"Nic_1_Name"="";"Nic1_AcceleratedNetworking"="";"Nic_1_Subnet"="";"Nic_1_IP1"="";
"Nic_1_IP2"="";"Nic_2_Name"="";"Nic2_AcceleratedNetworking"="";"Nic_2_Subnet"="";"Nic_2_IP1"="";"Nic_2_IP2"="";
"Nic_3_Name"="";"Nic3_AcceleratedNetworking"="";"Nic_3_Subnet"="";"Nic_3_IP1"="";"Nic_3_IP2"="";"OS Name"="";"OS Version"=""}))




    $change = az account set --subscription $CurrSubscription
        $change
        $VM_name = az vm list --query '[].{name:name}' --output tsv  # Get list of VMs in Subscription
        $VM_RG = az vm list --query '[].{resourceGroup:resourceGroup}' --output tsv # Get corresponding list of Resource Groups
        $M = 0 # counter for cycling through Resource Groups
        ClearVariables
	    TestForFiles 


        # The next line gets all VMs in the Subscription Name
	    # $VM_name = Get-AzVm |sort
            # To do just one RG in the Subscription
	        #   $vms = Get-AzVm | where {$_.Name -like "AZDBVWPP065" } | sort Name
	        # Next line just for testing ONE vm
	        # $vms = Get-AzVm -ResourceGroupName "PR-ENTERPRISECAPABILITIES"  
	
        $azurevms = foreach ($vm in $VM_name) {
            $RG = $($VM_RG[$M]) # Set Resource Group Variable
            $vm1 = Get-AzVm -ResourceGroupName $RG -Name $vm
            #write-host "==========================================================="
            $date = (Get-Date).ToString("HH:mm:ss")
            write-host -ForeGroundColor Cyan "Working on VM... " $vm1.Name " " $date 
            #Added the next line for getting the VM Status
            #$rg = $vm.ResourceGroupName
            if ($vm1.StorageProfile.OSDisk.ManagedDisk -like '') {$managed = "No"}else{$managed = "Yes"} 

            $vmsize = $vm1.HardwareProfile.VMsize            
            $vmdata = Get-AzVMSize -Location $vm1.Location | where {$_.Name -eq $vmsize}
            $OSType = $vm1.StorageProfile.OsDisk.OsType
            $OSDisk = $vm1.StorageProfile.OsDisk.Name
            $OSDiskSize = $vm1.StorageProfile.OsDisk.DiskSizeGb

            #Added the next few lines to get more details about the VM
            $statuses = (Get-AzVM -ResourceGroupName $rg -Name $($vm1.name) -Status)
            #NOTE: Trying to get the OS Name and Version from VM built with custom images
                $OS_Name = $statuses.OsName
                $OS_Version = $statuses.OsVersion
                #This loop is to get the current VM State
                foreach ($status in $statuses.Statuses) {
                    if ($status.Code -notlike "*provisioning*") {
                        $vmstatus = $status.Code.Split('/')[1]
                            if ($status -like "deallocated") {
                                $vmstatus = "stopped"
                            } #End of if -like deallocated
                    } #End of if -notlike provisioning
                } #End of foreach status
            $generation = $statuses.HyperVGeneration
            $agent = $statuses.VMAgent.VMAgentVersion
            # 12/8/21 fixed an issue where the agent isn't installet and status is showing as Ready from previous VM
            if ($agent -like "") {
                #write-host "Agent not installed"
                $agentstatus = "Unknown"
            }
            else {
                $agentstatus = $statuses.VMAgent.Statuses[0].DisplayStatus
            }
            
            $bd = $statuses | Select-Object  @{Name="BootDiag"; Expression={$_.BootDiagnostics.ConsoleScreenshotBlobUri}}
            if ($bd -like "@{BootDiag=}") {
                $bootdiag = $bd
                $sa = "not configured"
            }
            else {
                #write-host -foregroundcolor Cyan "Boot Diagnostic configured"
                    [string]$temp = $bd ; $temp1 = $temp.split("/") ; $temp2 = $temp1[4] ; $bootdiag = $temp2.Replace("}","") ; $temp3 = $temp1[2] ; $temp4 = $temp3.split(".")
                        $sa = $temp4[0]
            } #End of if/else loop
            #Attempting to get BLANK APPLICATION tag
            
            #write-host -ForeGroundColor Cyan "Working on VM... " $vm.Name
            #$app = $vm.Tags
            #    if ($vm.Tags.Count -eq 0) { 
            #        $Application = "not configured"
            #        write-host -ForeGroundColor Yellow "Application Tag is... $Application"
            #    }
            #    else {
            #        $Application = $vm.Tags.Application
            #        write-host -ForeGroundColor Cyan "VM Application tag has data...." $Application
            #    }

            #Try getting the Role Assignment for the VM

#Some VM's have multiple DisplayNames and different number of RoleDefinitionNames, had to separate the IF count test for both
# Do the DisplayName first
            $vmDisplayName = ""
            $namearray = @()
            $rolearray = @()
            #$array1 = Get-AzRoleAssignment | where {$_.Scope -eq $vm.Id} # | Select DisplayName
            $namearray = az role assignment list --scope $vm1.id --query '[].{principalName:principalName}'  --output tsv
           if ($namearray.Count -gt 1) { #This is for VMs with$ multiple roles assigned
                $temp = ""
                $count = $namearray.Count
                while ($count -gt 0 )  {
                    $temp += $namearray[$count - 1]
                    if ($count -gt 1) { #Multiple roles, more to process
                        $temp += " ; "
                    } #Process each role individually until one is left to process
                    else { #Multiple roles this should be the last to process, assign array to the outpur variable
                        [string]$vmDisplayName += $temp
                    } #End of the if/else to process all the roles on a VM with multiple roles assigned
                    $count = $count - 1
                 } # End of do/while loop
                    $vmDisplayName = $temp
                    $Namearray = @()
            } # End of if array.count > 1
            elseif ($namearray.Count -eq 1) { #This is for VMs with only 1 role assigned
                    $temp = ""
                    $count = $namearray.Count
                    $vmDisplayName = $namearray
            } # End of if array1.count = 1
            elseif ($namearray.Count -eq 0 )    { #No role on the VM
                  #  write-host "This VM has NO roles... " $array1 " ..." $array1.DisplayName.count
                    $vmDisplayName = "none"
             }  #End of if for a VM with NO roles assigned on the VM object

# Now do test the RoleDefinitionName, use the same array so not duplicating effort
            $vmrole = ""
            $RoleArray = @()
            #$array2 = @()
            #$array2 = Get-AzRoleAssignment | where {$_.Scope -eq $vm1.Id} # | Select DisplayName
            $rolearray = az role assignment list --scope $vm1.id --query '[].{roleDefinitionName:roleDefinitionName}'  --output tsv
            if ($rolearray.Count -gt 1) { #This is for VMs with multiple roles assigned
                $temp = ""
                $count = $rolearray.Count
                while ($count -gt 0 )  { 
                    $temp += $rolearray[$count - 1]
                    if ($count -gt 1) { #Multiple roles, more to process
                        $temp += " ; "
                    } #Process each role individually until one is left to process
                    else { #Multiple roles this should be the last to process, assign array to the outpur variable
                        [string]$vmrole += $temp
                    } #End of the if/else to process all the roles on a VM with multiple roles assigned
                    $count = $count - 1
                 } # End of do/while loop
                    $vmrole = $temp
                    $rolearray = @()
            } # End of if array.count > 1
            elseif ($rolearray.Count -eq 1) { #This is for VMs with only 1 role assigned
                    $temp = ""
                    $count = $rolearray.Count
                    $vmrole = $rolearray
            } # End of if array1.count = 1
            elseif ($rolearray.Count -eq 0 )    { #No role on the VM
                  #  write-host "This VM has NO roles... " $array1 " ..." $array1.DisplayName.count
                    $vmrole = "none"
             }  #End of if for a VM with NO roles assigned on the VM object
                   
            #Get the nic ip addresses of each vm		
            if ($vm1.NetworkProfile.NetworkInterfaces.Count -gt 1) { #Have MORE than 1 nic
                $netid = $vm1.NetworkProfile.NetworkInterfaces.Id | sort
                $nic_1_id = Get-AzNetworkInterface | where { $_.Id -eq $netid[0] }
                $nic_1_Name = $nic_1_id.Name
#Try puting the Accelerated Network setting below this note
                $nic_1_AcceleratedNetworking = $nic_1_id.EnableAcceleratedNetworking
                #NOTE: To handle the case where multiple IPs attached to a single nic
                if ($nic_1_id.IpConfigurations.Count -gt 1) { #NIC1 with multiple IP Addresses
                    $nic_1_id_ip1 = $nic_1_id.IpConfigurations |where { $_.Primary -eq "True" } |select PrivateIpAddress
                        [string]$temp = $nic_1_id_ip1 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			            $nic_1_id_ip1 = $temp.Replace("}","") 
                    $nic_1_id_subnet = $nic_1_id.IpConfigurations.Subnet |select Id
                        [string]$temp = Split-Path $nic_1_id_subnet -Leaf
                        $nic_1_id_subnet = $temp.Replace("}","")
                    $nic_1_id_IPs = $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select PrivateIpAddress
                    $nic_1_id_IPsCount = $nic_1_id_IPs.Count
                    if ($nic_1_id_IPsCount -gt 1) { #NIC 1 has multiple IP Addresses
                        $nic_1_Names = $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select PrivateIPAddress
                        $array = @()
                        foreach ($name in $nic_1_Names) { #Need to handle one nic with multiple ip's
                            [string]$temp = $name ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("Name=","")
                                $name = $temp.Replace("}","")
                            [string]$temp  += $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select Name, PrivateIpAddress
                                $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
                                $array += $temp.Replace("}","")
                            [string]$nic_1_id_ip2 = $array
                        } #End of foreach
                    } #End of if IPsCount -gt1
                    else { #NIC 1 has only a single IP Address
                        $nic_1_id_ip2 = $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select PrivateIpAddress
                            [string]$temp = $nic_1_id_ip2 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			                    $nic_1_id_ip2 = $temp.Replace("}","")
                        $nic_1_id_ip2 = "none"
                    } # End of if/else processing NIC1 with multiple IP Addresses
                } # End of if/else processing NIC1 with multiple IP Addresses
                else {
                    $nic_1_id_ip1 = $nic_1_id.IpConfigurations.PrivateIpAddress  # Get the subnet name
                    $nic_1_id_subnet = $nic_1_id.IpConfigurations.Subnet |select Id
                        [string]$temp = Split-Path $nic_1_id_subnet -Leaf
                            $nic_1_id_subnet = $temp.Replace("}","") 
                    $nic_1_id_ip2 = "none"    #NOTE: Adding the word none to the nic_1_id_2 when there is only one ip on nic1
                } # End of NIC 1 processing

            #Process the second NIC
            $nic_2_id = Get-AzNetworkInterface | where { $_.Id -eq $netid[1] }
            $nic_2_Name = $nic_2_id.Name
#Try puting the Accelerated Network setting below this note
            $nic_2_AcceleratedNetworking = $nic_2_id.EnableAcceleratedNetworking
            if ($nic_2_id.IpConfigurations.Count -gt 1) { #NIC 2 has multiple IP addresses
                $nic_2_id_ip1 = $nic_2_id.IpConfigurations |where { $_.Name -eq "ipconfig1" } |select PrivateIpAddress
                    [string]$temp = $nic_2_id_ip1 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			            $nic_2_id_ip1 = $temp.Replace("}","") 
                # Trying to get the subnet information, if this works need to copy it other places...
                $nic_2_id_subnet = $nic_2_id.IpConfigurations.Subnet |select Id
                    [string]$temp = Split-Path $nic_2_id_subnet -Leaf
                        $nic_2_id_subnet = $temp.Replace("}","")
                $nic_2_id_ip2 = $nic_2_id.IpConfigurations |where { $_.Name -eq "ipconfig2" } |select PrivateIpAddress
                    [string]$temp = $nic_2_id_ip2 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			            $nic_2_id_ip2 = $temp.Replace("}","")  
            } #End of NIC2 with multiple IPs
            else { #NIC2 has only ONE IP Address
                $nic_2_id_ip1 = $nic_2_id.IpConfigurations.PrivateIpAddress
                $nic_2_id_subnet = $nic_2_id.IpConfigurations.Subnet |select Id
                    [string]$temp = Split-Path $nic_2_id_subnet -Leaf
                        $nic_2_id_subnet = $temp.Replace("}","")
                        $nic_2_id_ip2 = "none" 
            }# End of if/else NIC2 processing

            #Process the third nic
            $nic_3_id = Get-AzNetworkInterface | where { $_.Id -eq $netid[2] }
            #Try puting the Accelerated Network setting below this note
            if ($nic_3_id.Count -gt 0) {
                $nic_3_Name = $nic_3_id.Name
#Try puting the Accelerated Network setting below this note
                $nic_3_AcceleratedNetworking = $nic_3_id.EnableAcceleratedNetworking
                if ($nic_3_id.IpConfigurations.Count -gt 1) { #NIC3 with multiple IP Addresses
                    $nic_3_id_ip1 = $nic_3_id.IpConfigurations |where { $_.Name -eq "ipconfig1" } |select PrivateIpAddress
                        [string]$temp = $nic_3_id_ip1 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			            $nic_3_id_ip1 = $temp.Replace("}","") 
                    $nic_3_id_subnet = $nic_3_id.IpConfigurations.Subnet |select Id
                        [string]$temp = Split-Path $nic_3_id_subnet -Leaf
                        $nic_3_id_subnet = $temp.Replace("}","")
                    $nic_3_id_ip2 = $nic_3_id.IpConfigurations |where { $_.Name -eq "ipconfig2" } |select PrivateIpAddress
                        [string]$temp = $nic_3_id_ip2 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			            $nic_3_id_ip2 = $temp.Replace("}","") 
                } #End of if NIC3 > 1 IP Addresses
                else { #NIC3 with a single IP Address
                    $nic_3_id_ip1 = $nic_3_id.IpConfigurations.PrivateIpAddress
                    # Get the subnet information
                    $nic_3_id_subnet = $nic_3_id.IpConfigurations.Subnet |select Id
                        [string]$temp = Split-Path $nic_3_id_subnet -Leaf
                        $nic_3_id_subnet = $temp.Replace("}","")
                    $nic_3_id_ip2 = "none"  
                } #End of if/else NIC3 with IP addresses
            }
            else { #No NIC3 configured on the VM 
                $nic_3_name = "none" ; $nic_3_id_subnet = "none"; $nic_3_id_ip1 = "none"  ; $nic_3_id_ip2 = "none"
            } #End of  NIC 3 processing
        }
            else { #Have a SINGLE NIC
                $netid = $vm1.NetworkProfile.NetworkInterfaces.Id | sort
                $nic_1_id = Get-AzNetworkInterface | where { $_.Id -eq $netid }
                $nic_1_Name = $nic_1_id.Name
#Try puting the Accelerated Network setting below this note
                $nic_1_AcceleratedNetworking = $nic_1_id.EnableAcceleratedNetworking
                if ($nic_1_id.IpConfigurations.Count -gt 1) { #NIC has multiple IP Addresses
                    $nic_1_id_ip1 = $nic_1_id.IpConfigurations |where { $_.Primary -eq "True" } |select PrivateIpAddress
                        [string]$temp = $nic_1_id_ip1 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			            $nic_1_id_ip1 = $temp.Replace("}","") 
                    $nic_1_id_subnet = $nic_1_id.IpConfigurations.Subnet |select Id
                        [string]$temp = Split-Path $nic_1_id_subnet -Leaf
                        $nic_1_id_subnet = $temp.Replace("}","")
                    $nic_1_id_IPs = $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select PrivateIpAddress
                    $nic_1_id_IPsCount = $nic_1_id_IPs.Count
                    if ($nic_1_id_IPsCount -gt 1) { #NIC 1 has multiple IP Addresses
                        $nic_1_Names = $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select PrivateIPAddress
                        $array = @()
                        foreach ($name in $nic_1_Names) {
                            [string]$temp = $name ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("Name=","")
                            $name = $temp.Replace("}","")
                            [string]$temp  += $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select Name, PrivateIpAddress
                                $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","") ; $array += $temp.Replace("}","")
                            [string]$nic_1_id_ip2 = $array
                        } #End of foreach
                    } #End of if IPsCount -gt1
                    else { #NIC 1 has only a single IP Address
                        $nic_1_id_ip2 = $nic_1_id.IpConfigurations |where { $_.Primary -ne "True" } |select PrivateIpAddress
                            [string]$temp = $nic_1_id_ip2 ; $cutthis = '@{' ; $temp = $temp.TrimStart($cutthis) ; $temp = $temp.Replace("PrivateIpAddress=","")
			                $nic_1_id_ip2 = $temp.Replace("}","")
                        $nic_1_id_ip2 = "none"
                    } # End of if/else processing NIC1 with multiple IP Addresses
                } # End of if processing NIC1 IPAddresses Count > 1
                else { # NIC1 IP Addresses count 1 or less
                    $nic_1_id_ip1 = $nic_1_id.IpConfigurations.PrivateIpAddress
                    $nic_1_id_subnet = $nic_1_id.IpConfigurations.Subnet |select Id
                        [string]$temp = Split-Path $nic_1_id_subnet -Leaf
                        $nic_1_id_subnet = $temp.Replace("}","")
                        $nic_1_id_ip2 = "none"
                    $nic_2_name = "none" ; $nic_2_id_subnet = "none"; $nic_2_id_ip1 = "none" ; $nic_2_id_ip2 = "none"
                    $nic_3_name = "none" ; $nic_3_id_subnet = "none"; $nic_3_id_ip1 = "none" ; $nic_3_id_ip2 = "none"
                } # End of processing a VM with a SINGLE NIC
            } # End of if/else for a single nic
     
    BuildCustomObject
    ClearVariables

    $M++ # Increment Resource Group
    
    #Reset a variable before processing the next vm, need to clear nic info for vm's without multiple nic's and ip's
    $tags = ''
    $count = 0
    $nic_1_id = ''
    $nic_1_Name = ''
    $nic_1_id_ip1 = ''
    $nic_1_id_ip2 = ''
    $nic_1_AcceleratedNetworking = ''
    $nic_2_id = ''
    $nic_2_Name = ''
    $nic_2_AcceleratedNetworking = ''
    $nic_2_id_ip1 = ''
    $nic_2_id_ip2 = ''
    $nic_3_id = ''
    $nic_3_Name = ''
    $nic_3_AcceleratedNetworking = ''
    $nic_3_id_ip1 = ''
    $nic_3_id_ip2 = ''
    $statuses = ''
    $vmstatus = ''
    $managed = ''
    $bootdiag = ''
    $application = ''

  } #End of foreach vms







    
    #Select the subscription
    Select-AzSubscription -SubscriptionName $SubscriptionName | Out-Null
    #Get all host groups
    $HostGroups = Get-AzHostGroup | Sort Name

    #Populate variables for progress bar
    $TotalHGs = $HostGroups.Count
    $CurrentHGNum = 1

    #Loop through all host groups
    ForEach ($CurrHostGroup in $HostGroups) {
        #Get the host group name
        $CurrHostGroupName = $CurrHostGroup.Name

        #If this is run from Orchestrator then output the VM name to get written to the transcript file
        If ($RunFromOrchestrator -eq "True") {
            Write-Host "HostGroup is $CurrHostGroupName"
        } Else { #If not from Orchestrator then write a progress bar
            #Update progress bar
            Write-Progress -Activity "Getting host group data" -Status "$CurrentHGNum of $TotalHGs" -PercentComplete ($CurrentHGNum / $TotalHGs * 100)
        }

        #Get the Resource group
        $RGName = $CurrHostGroup.ResourceGroupName
        #Get list of hosts in the host group
        $HostNames = (Get-AzHost -ResourceGroupName $RGName -HostGroupName $CurrHostGroupName).Name

        #Loop through all hosts in the host group
        ForEach ($CurrHost in $HostNames) {
            #Get the host info
            $AZHostInfo = Get-AzHost -ResourceGroupName $RGName -HostGroupName $CurrHostGroupName -Name $CurrHost
            #Get the host name
            $AZHostName = $AZHostInfo.Name
            #Get the host location
            $Location = $AZHostInfo.location
            #Get the host SKU
            $AZHostSKU = ($AZHostInfo.sku).Name
            #Get a list of all the VMs on the host that are not a scaleset
            $AZHostVMs = $AZHostInfo.VirtualMachines | Where { $_.Id -NotLike "*SCALESET*" }
            #Get the number of VMs on this host
            $AZHostVMCount = $AZHostVMs.count
            
            #Write just the basic info for the host but leave the virtual machines blank
            $AzureHostInfoList.add((New-Object "psobject" -Property @{"Host Name"=$AZHostName;"Location"=$Location;"HostGroup"=$CurrHostGroupName;"SKU"=$AZHostSKU;"Subscription"=$SubscriptionShortName;"Count of VMs"=$AZHostVMCount;
                                                        "Virtual Machine 1"="";"Virtual Machine 2"="";"Virtual Machine 3"="";"Virtual Machine 4"="";"Virtual Machine 5"="";"Virtual Machine 6"="";
                                                        "Virtual Machine 7"="";"Virtual Machine 8"="";"Virtual Machine 9"="";"Virtual Machine 10"="";"Virtual Machine 11"="";"Virtual Machine 12"="";
                                                        "Virtual Machine 13"="";"Virtual Machine 14"="";"Virtual Machine 15"="";"Virtual Machine 16"="";"Virtual Machine 17"="";"Virtual Machine 18"="";
                                                        "Virtual Machine 19"=""}))

            #IF THERE ARE NO VMs ON THE HOST THEN THIS GETS SKIPPED - Loop through the variable for however many VMs there are on the host
            For ($i=1; $AZHostVMCount -ge $i; $i++) {
                #Get the column name for the current virtual machine (ie the first VM will be stored under "Virtual Machine 1" and second under "Virtual Machine 2")
                $ColumnName = "Virtual Machine $i"
                #For the most recent record written for the Host List, store the VM name in the proper column
                $AzureHostInfoList[$AzureHostInfoList.Count - 1].$ColumnName = $AZHostVMs[$i - 1].Id.split('/')[-1]
            }
        } #End of ForEach Host

        #Increment the current host group number for the progress bar
        $CurrentHGNum++
    } #End of ForEach HostGroup

    #Close the progress bar
    Write-Progress -Activity "Getting host group data" -Completed
} #End of ForEach subsciption

Write-Host "`nWriting data to Excel" -ForegroundColor Cyan

#Move the old reports into the SavedFiles path
Get-ChildItem -Path $ReportPath -Filter "$ShortReportName*" | ForEach {
    Move-Item -Path $_.FullName "$ReportPath\SavedFiles" -Force
}

#Set the data headers in the correct order
$FinalOutput = $AzureHostInfoList | Select $ReportColumnHeaders | Sort "Host Name"

#All Azure Hosts
$FinalOutput | Export-Excel -WorksheetName "All_Host" -Path "ReportPath:\$ReportFileName" -AutoSize -Append

#Loop through each Azure subscription
ForEach ($CurrSubscription in $Subscriptions) {
    #Get the subscription short name
    $SubscriptionShortName = $CurrSubscription.Name.split('-')[1]
    #Report data for just this subscription
    $FinalOutput | Where { $_."Subscription" -eq $SubscriptionShortName } | Export-Excel -WorksheetName $SubscriptionShortName -Path "ReportPath:\$ReportFileName" -AutoSize -Append
}

#Set auto filter on all worksheets
#Open the spreadsheet that was created
$ExcelPkg = Open-ExcelPackage -Path "ReportPath:\$ReportFileName"
#Loop through each worksheet
ForEach ($WorkSheet in $ExcelPkg.Workbook.Worksheets) {
    #Get the range of data in the worksheet
    $UsedRange = $WorkSheet.Dimension.Address

    #If the worksheet isn't blank
    If ($UsedRange -ne $null) {
        #Enable auto filter on that range
        $WorkSheet.Cells[$UsedRange].AutoFilter = $true
    }
}
#Close the spreadsheet
Close-ExcelPackage $ExcelPkg

Write-Host "`nScript Complete.  Report written to $ReportPath\$ReportFileName" -ForegroundColor Green

#Stop the transcript
Stop-Transcript
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDSp8IVw3I+qIQc
# rT/ecgP/k22Dz0kKGtZ6Esw9TTcp6aCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDfcaW997O0g5e2LhLbTFRKvbaFdwMuWPXuVZZygbcYNzANBgkq
# hkiG9w0BAQEFAASCAQBJfIWAOSM7cgFvTntYDNeP/GHGlDnc+n212Cs2rh13WfCf
# HRf5buhERFtJIRZWBKBTAPTVlf7LfMo9++JZkOSePWXQfZ4CAtbGSKWBlG238C74
# xxyyZOB46VINuhyvC7hjP9XNxyGLCBx7XlrZaCgb6+4UjjfztVQX6Q7Sz8/WnfoX
# FIhyScUr79c+8Gx+9yFIqYcRluRgOCvmkhNJwVC0C3iF9Yq98QBjHOyE4AF3LOZj
# DdLPBWDNWR41kQFYgml/bRLwCFXpmlM8iWUY1pDU13ptW4D+bVyv5L9VK+oVyeff
# V2CPcW6ycnuE2xDCwDRyr+j89zDr2wmw9OfuBByX
# SIG # End signature block
