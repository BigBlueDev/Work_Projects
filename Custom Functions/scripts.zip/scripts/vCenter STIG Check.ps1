﻿#PURPOSE: Perform a STIG check on a list of vCenter servers and output CKL files with the results

#CHANGELOG
#Version 1.0 - 11/05/24 - MDR - Initial version
#Version 1.01 - 12/30/24 - MDR - Added check for Key Provider

Param ( $ChecklistFilePath, $CurrentSystemName, $STIGParams, $RunFromOrchestrator, $vCenterDomain )

#Create an XML object
$Checklist_XMLObject = New-Object XML
#This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
$Checklist_XMLObject.PreserveWhitespace = $true
#This is the name of the empty checklist template file
$Checklist_XMLObject.Load("$ChecklistFilePath")

$vCenterIP = (Test-Connection $CurrentSystemName -Count 1).Address.IPAddressToString
$vCenterMAC = (Invoke-SSHCommand -SessionId 0 -Command { cat /sys/class/net/eth0/address }).Output

$Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$($CurrentSystemName.Split("."))[0]
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$CurrentSystemName
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = [String]$vCenterIP
$Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = [String]$vCenterMAC

$Global:VULN_DATA = $Checklist_XMLObject.CHECKLIST.STIGS.iSTIG.VULN

#Populate variables for progress bar
$TotalVCodes = $VULN_DATA.Count
$CurrentVCode = 1

ForEach ($Global:VULN in $VULN_DATA) {
    [System.Windows.Forms.Application]::DoEvents()

    Clear-Variable FindingHint -ErrorAction SilentlyContinue

    $Vuln_Num = ($VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq 'Vuln_Num' }).ATTRIBUTE_DATA
    #Collecting Severity for reporting purposes later in the script
    $Global:Severity = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA
    $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $Vuln_Num }

    #If this is run from Orchestrator then output the VM name to get written to the transcript file
    If ($RunFromOrchestrator -eq "True") {
        Write-Host "Scanning V-Code $Vuln_Num"
    } Else { #If not from Orchestrator then write a progress bar
        #Update progress bar
        Write-Progress -Activity "Scanning V-Code $Vuln_Num" -Status "$CurrentVCode of $TotalVCodes" -PercentComplete ($CurrentVCode / $TotalVCodes * 100)
    }

    #If this is an AltCheck then gather the data for this check
    If ($VCodeObjectSTIGData.Expected_Value -like "AltCheck *") {
        $AltCheck = "True"
        $OrigExpectedValue = $VCodeObjectSTIGData.Expected_Value
        $TabName = ($VCodeObjectSTIGData.Expected_Value -Split " ")[1]
        $AltCheckData = $STIGParams[$TabName]
        $VCodeObjectSTIGData.Expected_Value = "Blank" #Set this as the default expectation for the Expected Value though the code for that section may end up not using this
    } Else {
        $AltCheck = "False"
    }

    #If there is a line in $STIGParams for the V-Code in this checklist
    If (!($VCodeObjectSTIGData)) {
        $VULN.COMMENTS = "No entry existed in the STIG parameters file for this V-Code"

        If ($NoSTIGParamList -notcontains $Vuln_Num) {
            $NoSTIGParamList += $Vuln_Num
        }
    } Else {
        Remove-Variable CustomComment, FindingHint, SystemSettingValue -ErrorAction SilentlyContinue

        #If this is a manual check then set this as such
        If ($VCodeObjectSTIGData.Check_Method -eq "NR") {
            $FindingHint = "Manual"
            $CustomComment = "Manual check - $($VCodeObjectSTIGData.Check_Param) - $($VCodeObjectSTIGData.Expected_Value)"
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AutoClose") {
            $FindingHint = "NF"
            $CustomComment = $VCodeObjectSTIGData.Fix_Text
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AutoOpen") {
            $FindingHint = "O"
            $CustomComment = $VCodeObjectSTIGData.Fix_Text
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "LockoutPolicy") {
            $SystemSettingValue = (Get-SsoLockoutPolicy).$($VCodeObjectSTIGData.Check_Param)
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "PasswordPolicy") {
            $SystemSettingValue = (Get-SsoPasswordPolicy).$($VCodeObjectSTIGData.Check_Param)
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AuthPolicy") {
            $SystemSettingValue = (Get-SsoAuthenticationPolicy).$($VCodeObjectSTIGData.Check_Param)
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AuthPolicyMultiple") {
            $AuthPolicy = Get-SsoAuthenticationPolicy | Select SmartCardAuthnEnabled, WindowsAuthnEnabled, PasswordAuthnEnabled

            Clear-Variable SystemSettingValue -ErrorAction SilentlyContinue

            If ($SystemSettingValue.SmartCardAuthnEnabled -eq $false) {
                $SystemSettingValue += "SmartCardAuth is disabled"
            }
            If ($SystemSettingValue.WindowsAuthnEnabled -eq $true) {
                $SystemSettingValue += "`nWindowsAuth is enabled"
            }
            If ($SystemSettingValue.PasswordAuthnEnabled -eq $true) {
                $SystemSettingValue += "`nPasswordAuth is enabled"
            }

            If ($SystemSettingValue -eq $null) {
                $FindingHint = "NF"
                $SystemSettingValue = $AuthPolicy
            } Else {
                $FindingHint = "O"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SSHCommand") {
            [String]$SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command $VCodeObjectSTIGData.Check_Param).Output | Out-String
            $StringArray = $SystemSettingValue -Split "`n"

            If ($VCodeObjectSTIGData.Check_Name -eq "AD authentication must be utilized") {
                $DomainTypeList = $SystemSettingValue -Split "`n" | Where { $_ -like "DomainType*" }

                If ($DomainTypeList | Where { $_ -like "*$($VCodeObjectSTIGData.Expected_Value)*" }) {
                    $FindingHint = "NF"
                    $CustomComment = "EXTERNAL_DOMAIN identity type found`n`n$($DomainTypeList -join ""`n"")"
                } Else {
                    $FindingHint = "O"
                    $CustomComment = "No EXTERNAL_DOMAIN identity type found`n`n$($DomainTypeList -join ""`n"")"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Must terminate sessions after 10 minutes of inactivity") {
                $SystemSettingValue = ($StringArray | Where { $_ -like "session.timeout*" }).Trim()
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "DOD standard banner") {
                #Split to get just the portion of the banner we're looking for
                $BannerSplitFirst = $SystemSettingValue -Split "Logon Banner Content:"
                $BannerSplitSecond = $BannerSplitFirst[1] -Split "Checkbox enabled"
                #Remove excess line breaks at the start and end
                $BannerTrim = $BannerSplitSecond[0].Trim()
                #Replace returns with line breaks
                $BannerNoReturns = $BannerTrim -replace "`r","`n"
                #Take any instances of three consecutive line breaks and turn them into just one line break
                $SystemSettingValue = $BannerNoReturns -replace "(\n){3}", "`n"
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "DOD standard banner" -or $VCodeObjectSTIGData.Check_Name -eq "SSL cert must be issued by DOD authority") {
                $SystemSettingValue = $StringArray | Where { $_ -like "*$($VCodeObjectSTIGData.Expected_Value)*" }

                If ($SystemSettingValue -ne $null) {
                    $FindingHint = "NF"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Must be configured to send logs") {
                #Retrieve the syslog system which should look like "DAISV0PP009.dir.ad.dla.mil:1514"
                $StringArraySplit = ((($StringArray | Where { $_ -like "*@@*" }) -Split ";")[0] -Split "@@")[1]
                #In case there is a "(o)" to remove then remove it
                $SystemSettingValue = $StringArraySplit -Replace '\(o\)',""
                #Storing this data to be used in V-256340
                $SyslogInfo = $SystemSettingValue

                #Split the various expected values
                $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value -Split ","

                #If the value is on the expected values then it is NF.  Otherwise it is open
                If ($ExpectedValueSplit -contains $SyslogInfo) {
                    $FindingHint = "NF"
                    $CustomComment = "Valid syslog configuration found: $SystemSettingValue"
                } Else {
                    $FindingHint = "O"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AdvancedSetting") {
            $SystemSettingValue = (Get-AdvancedSetting -Entity $CurrentSystemName -Name $VCodeObjectSTIGData.Check_Param).Value

            If ($VCodeObjectSTIGData.Check_Name -eq "Disable SNMPv1/2") {
                $SystemSettingValue = $SystemSettingValue -Split " " | Select -Unique
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "Plugins") {
            $extMgr = Get-View ExtensionManager
            $PluginList = ($extMgr.ExtensionList | select @{N='Name';E={$_.Description.Label}} | Where { $_.Name -ne "description" }).Name | Sort | Select -Unique
            $SystemSettingValue = (Compare-Object -ReferenceObject $PluginList -DifferenceObject $AltCheckData.PluginName | Where { $_.SideIndicator -eq "<=" }).InputObject
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "UserPermissions") {
            $PermissionsList = Get-VIPermission | Select -Unique | Select-Object Role, Principal, Entity | Sort Role, Principal, Entity

            #Loop through each AltCheck to remove the appropriate permissions from the finding list
            ForEach ($AltCheckInfo in $AltCheckData) {
                If ($AltCheckInfo.Role -eq "*") {
                    #Remove all items from the list for this principal
                    $PermissionsList = $PermissionsList | Where { $_.Principal -notlike "*\$($AltCheckInfo.Principal)" }
                } ElseIf ($AltCheckInfo.Principal -eq "*") {
                    #Remove items for this role
                    $PermissionsList = $PermissionsList | Where { $_.Role -ne $AltCheckInfo.Role }
                } Else { #If this removal includes the role
                    #Remove items from the list for this role and principal
                    $PermissionsList = $PermissionsList | Where { $_.Principal -notlike "*\$($AltCheckInfo.Principal)" -or $_.Role -ne $AltCheckInfo.Role }
                }
            }

            $SystemSettingValue = $PermissionsList | ForEach { "$($_.Role) - $($_.Principal) - $($_.Entity)"}
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "NIOC") {
            $SystemSettingValue = Get-VDSwitch | select Name,@{N="NIOC Enabled";E={$_.ExtensionData.config.NetworkResourceManagementEnabled}} | Where { $_.'NIOC Enabled' -ne "True" }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "AlarmCheck") {
            $SystemSettingValue = Get-AlarmDefinition | Where {$_.ExtensionData.Info.Expression.Expression.EventTypeId -eq "com.vmware.sso.PrincipalManagement"} | Select Name,Enabled,@{N="EventTypeId";E={$_.ExtensionData.Info.Expression.Expression.EventTypeId}}
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "CEIP") {
            $ceipSettings = (Get-AdvancedSetting -Entity $global:DefaultVIServer -Name VirtualCenter.DataCollector.ConsentData).Value.toString() | ConvertFrom-Json
            $SystemSettingValue = $ceipSettings.consentConfigurations[0].consentAccepted
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "DSHealthCheck") {
            $AllStdSwitches = Get-VDSwitch
            $HealthCheckInfo = $AllStdSwitches | Select @{N='Name';E={$_.Name}}, @{N='HealthCheckConfig';E={$_.ExtensionData.Config.HealthCheckConfig.Enable}}
            
            #Start out with a just a blank array for the return value
            $SystemSettingValue = @()
            #Because each switch returns TWO values (generally it is False and False) I need to check the info from each switch and see what those values are
            ForEach ($HealthCheckItem in $HealthCheckInfo) {
                #Start with the assumption that all switches don't fail the health check
                $FailedHealthCheck = "False"
                #Check both values
                ForEach ($HealthCheck in $HealthCheckItem.HealthCheckConfig) {
                    #If a value is found that is not False then mark the switch as failing the health check
                    If ($HealthCheck -ne $false) {
                        $FailedHealthCheck = "True"
                    }
                }
                
                #If the switch failed then add the name to the array
                If ($FailedHealthCheck -eq "True") {
                    $SystemSettingValue += $HealthCheckItem.Name
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "DistributedSwitches") {
            $SwitchResults = Get-VDSwitch | Get-VDSecurityPolicy -ErrorAction SilentlyContinue
            $SystemSettingValue = $SwitchResults | Select VDSwitch, ($VCodeObjectSTIGData.Check_Param) | Where { $_.($VCodeObjectSTIGData.Check_Param) -ne $false }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "NetFlow") {
            $SystemSettingValue = Get-VDSwitch | Select Name,@{N="NetFlowCollectorIPs";E={$_.ExtensionData.config.IpfixConfig.CollectorIpAddress}} | Where { $_.NetFlowCollectorIPs -ne $null }

            $SystemSettingValue = $SystemSettingValue | Where { $AltCheckData.KnownNetFlowIPs -notcontains $SystemSettingValue.NetFlowCollectorIPs }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "PortGroupNativeVLAN") {
            $SystemSettingValue = Get-VDPortgroup | Select Name, VlanConfiguration | Where { $_.VlanConfiguration -eq $VCodeObjectSTIGData.Check_Param }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "PortGroupVLANTagging") {
            $VLANTrunkPortGroups = Get-VDPortgroup | Where { $_.ExtensionData.Config.Uplink -ne "True" -and $_.VlanConfiguration -like "VLAN Trunk*" } | Select Name, VlanConfiguration
            
            ForEach ($AltCheckInfo in $AltCheckData) {
                $VLANTrunkPortGroups = $VLANTrunkPortGroups | Where { $_.Name -ne $AltCheckInfo.PGName -and $_.VlanConfiguration -ne $AltCheckInfo.VLANs }
            }
            
            $SystemSettingValue = $VLANTrunkPortGroups | ForEach {
                "$($_.Name) - VLAN: $($_.VlanConfiguration)"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "IPBasedStorage") {
            $ESXHostList = Get-VMHost

            #Since the variable only gets adjusted when something is found, it needs to be cleared at the start
            Clear-Variable SystemSettingValue -ErrorAction SilentlyContinue
            
            #Loop through all ESX hosts and determine if any of them are using IP based storage
            ForEach ($ESXHost in $ESXHostList) {
                $SystemSettingValue += Get-VMHostHBA -VMHost $ESXHost | Where { $_.Type -eq "iSCSI" } | Select @{Name="HostName";Expression={$ESXHost.Name}}, Device, Type, Model, Status
            }

            If ($SystemSettingValue -ne $Null) {
                $AllIPStorage = $SystemSettingValue | ForEach { $_ -join "`n" }
                $CustomComment = "IP Storage found on some ESX hosts.  Manually confirm the finding on each host:`n`n$($AllIPStorage -join ""`n"")"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VSANInternet") {
            $SystemSettingValue = Get-VsanDisk

            If ($SystemSettingValue -ne $Null) {
                $CustomComment = "VSAN disks were found so manually check the Internet Connectivity"
            } Else {
                $FindingHint = "NA"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VSANDatastore") {
            $ClusterList = Get-Cluster | Where { $_.VsanEnabled }

            #If VSAN isn't used then this finding is NA
            If ($ClusterList -eq $null) {
                $FindingHint = "NA"
            } Else {
                $VSANDatastoreList = ($ClusterList | Get-Datastore | Where { $_.type -match "vsan" }).Name
                $VSANDatastoreUniqueList = $VSANDatastoreList | Select -Unique

                If ($VSANDatastoreList -eq $null) {
                    $FindingHint = "NA"
                } ElseIf ($VSANDatastoreList.Count -eq $VSANDatastoreUniqueList.Count) { #If there are all unique datastore names then NF
                    $FindingHint = "NF"
                    $CustomComment = "All VSAN datastore names are unique:`n`n$($VSANDatastoreList -join ""`n"")"
                } Else {
                    $SystemSettingValue = $VSANDatastoreList | Group-Object | Where { $_.Count -gt 1 } | Select Name, Count
                    $CustomComment = "The following VSAN datastores have non-unique names:`n`n$($SystemSettingValue -join ""`n"")"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "CryptoRolePermissions") {
            $PermissionsList = Get-VIPermission | Where { $_.Role -eq "Admin" -or $_.Role -eq "NoTrustedAdmin" -or $_.Role -eq "vCLSAdmin" -or $_.Role -eq "vSphereKubernetesManager" } | Select Role, Principal, Entity

            #Loop through each AltCheck to remove the appropriate permissions from the finding list
            ForEach ($SingleAltCheck in $AltCheckData) {
                If ($SingleAltCheck.Role -eq "*") {
                    #Remove all items from the list for this principal
                    $PermissionsList = $PermissionsList | Where { $_.Principal -notlike "*\$($SingleAltCheck.Principal)" }
                } ElseIf ($SingleAltCheck.Principal -eq "*") {
                    #Remove items for this role
                    $PermissionsList = $PermissionsList | Where { $_.Role -ne $SingleAltCheck.Role }
                } Else { #If this removal includes the role
                    #Remove items from the list for this role and principal
                    $PermissionsList = $PermissionsList | Where { $_.Principal -notlike "*\$($SingleAltCheck.Principal)" -or $_.Role -ne $SingleAltCheck.Role }
                }
            }

            $SystemSettingValue = $PermissionsList | ForEach { "$($_.Role) - $($_.Principal) - $($_.Entity)"}
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "CryptoPermissions") {
            $DefaultCryptoPermissionsList = @("Admin", "NoTrustedAdmin", "vCLSAdmin", "vSphereKubernetesManager")
            $AllRoles = Get-VIRole
            $SystemSettingValue = @()
            
            #Loop through all roles
            ForEach ($ThisRole in $AllRoles) {
                $PrivilegeList = $ThisRole.PrivilegeList
                #Check if this role has a privilege that allows cryptographic access
                If ($PrivilegeList -match "Crypto*" -or $PrivilegeList -match "Global.Diagnostics" -or $PrivilegeList -match "Host.Inventory.Add*" -or $PrivilegeList -match "Host.Local operations.Manage user groups") {
                    #Check if this role is on the list of allowed roles to have cryptographic access
                    If ($DefaultCryptoPermissionsList -notcontains $ThisRole.Name) {
                        #By default mark this as NOT a finding
                        $Finding = "False"

                        #If this role is listed in the AltCheck list
                        If ($AltCheckData.Role -contains $ThisRole.Name) {
                            #Check each individual privilege if the AltCheck doesn't state to bypass the check
                            If ($AltCheckData.Privilege -notlike "*Crypto*" -and $PrivilegeList -match "Crypto*") { $Finding = "True" }
                            If ($AltCheckData.Privilege -notlike "*Global.Diagnostics*" -and $PrivilegeList -match "Global.Diagnostics") { $Finding = "True" }
                            If ($AltCheckData.Privilege -notlike "*Host.Inventory.Add*" -and $PrivilegeList -match "Host.Inventory.Add*") { $Finding = "True" }
                            If ($AltCheckData.Privilege -notlike "*Host.Local operations.Manage user groups*" -and $PrivilegeList -match "Host.Local operations.Manage user groups*") { $Finding = "True" }
                        } Else { #If this isn't on the AltCheck list then by default it is a finding
                            $Finding = "True"
                        }

                        #If this is a finding
                        If ($Finding -eq "True") {
                            Clear-Variable FoundPrivileges -ErrorAction SilentlyContinue

                            If ($PrivilegeList -match "Crypto*") { $FoundPrivileges = "Crypto"}
                            If ($PrivilegeList -match "Global.Diagnostics") { $FoundPrivileges += " - Global.Diagnostics"}
                            If ($PrivilegeList -match "Host.Inventory.Add*") { $FoundPrivileges += " - Host.Inventory.Add"}
                            If ($PrivilegeList -match "Host.Local operations.Manage user groups") { $FoundPrivileges += " - Host.Local operations.Manage user groups"}
                            
                            $SystemSettingValue += "$($ThisRole.Name) - $FoundPrivileges"
                        }
                    }
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VSANiSCSITarget") {
            #Once we have VSAN setup, try figuring out how to do this check with Get-VsanIscsiTarget
            
            $SystemSettingValue = Get-VsanDisk

            If ($SystemSettingValue -ne $Null) {
                $CustomComment = "VSAN disks were found.  Try configuring script with Get-VsanIscsiTarget to get more info"
            } Else {
                $FindingHint = "NA"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VSANCHAP") {
            #Once we have VSAN setup, try figuring out how to do this check with Get-VsanIscsiTarget
            
            $VSANDisks = Get-VsanDisk

            If ($VSANDisks -eq $Null) {
                $FindingHint = "NA"
            } Else {
                $SystemSettingValue = "VSAN disks were found.  Try configuring script with Get-VsanIscsiTarget to get more info"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VSANiSCSITarget") {
            $ClusterList = Get-Cluster | Where { $_.VsanEnabled }

            #If VSAN isn't used then this finding is NA
            If ($ClusterList -eq $null) {
                $FindingHint = "NA"
            } Else {
                #Once VSAN is in place then more will need to be done for this check
                $SystemSettingValue = "VSAN disks were found.  Some test code is already in place to help test for this finding which needs to be expanded upon"
                $FindingHint = "O"
                <#
                ForEach ($VSANCluster in $ClusterList) {
                    # Get the vSAN Cluster Configuration View
                    $VsanVcClusterConfig = Get-VsanView -Id "VsanVcClusterConfigSystem-vsan-cluster-config-system"

                    # Get Encryption State
                    $EncryptedVsan = $VsanVcClusterConfig.VsanClusterGetConfig($VsanCluster.ExtensionData.MoRef).DataEncryptionConfig

                    $VsanCluster.vSanEnabled
                    $EncryptedVsan.EncryptionEnabled
                }#>
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "IdentitySources") {
            $SystemSettingValue = Get-IdentitySource -External -ErrorAction SilentlyContinue | Select PrimaryUrl, FailoverUrl

            If ($SystemSettingValue -eq $null) {
                $FindingHint = "O"
                $CustomComment = "No identity source found"
            } ElseIf ($SystemSettingValue.PrimaryUrl -notlike "LDAPS*" -or $SystemSettingValue.FailoverUrl -notlike "LDAPS*") {
                $FindingHint = "O"
                $CustomComment = "Identity source not configured to use LDAPS`n`n$SystemSettingValue"
            } Else {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "IdentitySourcePrivileges") {
            $SystemSettingValue = ((Get-IdentitySource -External -ErrorAction SilentlyContinue).AuthenticationUserName -Split "@")[0]
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "GroupMembership") {
            $SystemSettingValue = (Get-SsoGroup -Domain $vCenterDomain -Name $VCodeObjectSTIGData.Check_Param | Get-SsoPersonUser).Name
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VerifyBackup") {
            If ($CurrentSystemName -eq "daisv0pp222.dir.ad.dla.mil") {
                $LastBackupDate = $daisv0pp222BackupDate
            } ElseIf ($CurrentSystemName -eq "daisv0pp223.dir.ad.dla.mil") {
                $LastBackupDate = $daisv0pp223BackupDate
            } Else {
                $LastBackupDate = ((Get-VM $CurrentSystemName | Get-Annotation -Name "NB_LAST_BACKUP").Value -Split ",")[0]
            }
            
            $LastBackupDateFixed = $LastBackupDate -Replace "  ", " "
            $LastBackupDateSplit = $LastBackupDateFixed -Split " "
            [DateTime]$LastBackupDateCorrected = "$($LastBackupDateSplit[1]) $($LastBackupDateSplit[2]) $($LastBackupDateSplit[4])"
            $DaysSinceLastBackup = ((Get-Date) - $LastBackupDateCorrected).Days

            If ($DaysSinceLastBackup -lt $VCodeObjectSTIGData.Expected_Value) {
                $FindingHint = "NF"
                $CustomComment = "Last backup was on $LastBackupDate which is $DaysSinceLastBackup days ago"
            } Else {
                $FindingHint = "O"
                $CustomComment = "Last backup was on $LastBackupDate which is $DaysSinceLastBackup days ago which exceeds the allowed number of days which is $($VCodeObjectSTIGData.Check_Param)"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "NativeKeyProviders") {
            #Version 1.01 - Get Key Provider information
            $KeyProviderInfo = Get-KeyProvider

            #Version 1.01 - If there is no key provider then this check is N/A 
            If ($KeyProviderInfo -eq $null) {
                $FindingHint = "NA"
                $SystemSettingValue = "No key provider exists on this vCenter server"
            } Else {
                $NativeKeyBackupFolder = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Protected\Key provider backup"
                $NativeKeyProviderCheck = Get-ChildItem -Path $NativeKeyBackupFolder -Filter "$CurrentSystemName*"

                If ($NativeKeyProviderCheck -eq $null) {
                    $FindingHint = "O"
                    $SystemSettingValue = "No native key backup was found in $NativeKeyBackupFolder"
                } Else {
                    $FindingHint = "NF"
                    $SystemSettingValue = $NativeKeyProviderCheck
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "TLS") {
            #Run the command which will fill data into the log file
            Invoke-SSHCommand -SessionId 0 -Command "/usr/lib/vmware-TlsReconfigurator/VcTlsReconfigurator/reconfigureVc scan" | Out-Null
            #Get the data out of the log file
            $LogFileOutput = (Invoke-SSHCommand -SessionId 0 -Command "tail -n 30 /var/log/vmware/vSphere-TlsReconfigurator/VcTlsReconfigurator.log").Output

            #The data is output in table format.  Use this variable to identify which part of the table it is currently in
            $TableSection = 1
            #Start the string off with info
            $SystemSettingValue = "Service --- Port --- TLS Ver`n"
            #Set the default finding hint as "NF"
            $FindingHint = "NF"

            ForEach ($LogLine in $LogFileOutput) {
                #Check to see if this is the title line
                If ($TableSection -eq 1) {
                    If ($LogLine -like "*| Service Name        | TLS Endpoint Port | TLS Version(s) |") {
                        $TableSection = 2
                    }
                } ElseIf ($TableSection -eq 2) { #If it is passed the title line but before the data line
                    If ($LogLine -like "*+---------------------+-------------------+----------------+") {
                        $TableSection = 3
                    }
                } ElseIf ($TableSection -eq 3) { #If we're in the data section
                    #Check to see if it is at the end line
                    If ($LogLine -like "*+---------------------+-------------------+----------------+") {
                        $TableSection = 4
                    } Else { #If it isn't the end line then this is a normal data line
                        $LogLineSplit = $LogLine.Split("|")
                        $ServiceName = $LogLineSplit[1].Trim()
                        $PortNumber = $LogLineSplit[2].Trim()
                        $TLSVersion = $LogLineSplit[3].Trim()

                        #If the TLS version is incorrect then set this as an open finding
                        If ($TLSVersion -ne $VCodeObjectSTIGData.Expected_Value -and $TLSVersion -ne "NOT RUNNING") {
                            $FindingHint = "O"
                        }

                        $SystemSettingValue += "$ServiceName - PortNumber - $TLSVersion`n"
                    }
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ServiceAccts") {
            #For this check, if an application has a matching account to log in with then it is presumed that the application is actually using this account

            #Get a list of all the applications that remotely connect to vCenter based on the AltCheck list
            $AllAppNames = $AltCheckData.AppName | Select -Unique
            #Get a list of all configured permissions
            $PermissionsList = (Get-VIPermission).Principal | Select -Unique | Sort
            #Get a list of all local users
            $LocalUsersList = (Get-VIAccount -Domain $vCenterDomain).Name
            #Start the string off with info
            $SystemSettingValue = "AppName --- AcctName`n"
            #Set the default finding hint as "NF"
            $FindingHint = "NF"

            #Loop through each app to confirm a matching permission is found
            ForEach ($AppName in $AllAppNames) {
                #Get a list of all possible account names that might correspond to this application
                $AllAcctNames = ($AltCheckData | Where { $_.AppName -eq $AppName }).AcctName

                #Clear $AcctFound
                Clear-Variable AcctFound -ErrorAction SilentlyContinue
                ForEach ($AcctName in $AllAcctNames) {
                    #Check to see if the account is found
                    $AcctFound = $PermissionsList | Where { $_ -like "*\$AcctName*" }
                    #If the account isn't found in the permissions list, check the local users list
                    If ($AcctFound -eq $null) {
                        $AcctFound = $LocalUsersList | Where { $_ -like "*\$AcctName*" }
                    }
                    #If there is an option for "None" then use that
                    If ($AcctName -eq "None") {
                        $AcctFound = "None found but also this account isn't required"
                    }
                    #If Account is found then exit the for loop
                    If ($AcctFound -ne $null) { Break }
                }

                #If a matching account is found
                If ($AcctFound -ne $null) {
                    $SystemSettingValue += "$AppName --- $AcctFound`n"
                } Else {
                    $SystemSettingValue += "$AppName --- No account found`n"
                    #Since at least one application has no matching account, mark this as opened
                    $FindingHint = "O"
                }
            }

            #If this is not a finding then I want it to output all the found application accounts in the comment
            If ($FindingHint -eq "NF") {
                $CustomComment = $SystemSettingValue
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ReservedVLANs") {
            $VDPortGroupList = Get-VDPortgroup | Where {$_.ExtensionData.Config.Uplink -ne "True"} | Select Name, VlanConfiguration
            $ExceptionsList = ($AltCheckData | WHere { $_.'VLAN ID' -eq "Exception" }).'DVPortGroup Name'

            $FindingHint = "NF"
            $SystemSettingValue = "`n"

            ForEach ($DVPortGroup in $VDPortGroupList) {
                #If the port is on the exceptions list then skip the check
                If ($ExceptionsList -contains $DVPortGroup.Name) { Continue }

                $DVPortGroupVLAN = $DVPortGroup.VlanConfiguration
                If ($DVPortGroupVLAN.VlanType -eq "Trunk") {
                    $AltCheckTrunkCheck = $AltCheckData | Where { $_.'VLAN ID' -eq "Trunk" -and $_.'DVPortGroup Name' -eq $DVPortGroup.Name}
                    If ($AltCheckTrunkCheck -eq $null) {
                        $SystemSettingValue += "$($DVPortGroup.Name) --- Trunk --- $($DVPortGroupVLAN.Ranges)`n"
                        $FindingHint = "O"
                    }
                } Else { #If this is a single VLAN
                    If ($AltCheckData.'VLAN ID' -contains $DVPortGroupVLAN.VlanID) {
                        $SystemSettingValue += "$($DVPortGroup.Name) --- Single --- $($DVPortGroupVLAN.VlanID)`n"
                        $FindingHint = "O"
                    }
                }
            }

            #If there are no findings then just send the blank variable back
            If ($SystemSettingValue -eq "`n") { Clear-Variable SystemSettingValue }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SNMPv3") {
            $CurrSystemData = $AltCheckData | Where { $_.vCenter -eq $CurrentSystemName }
            $DaysSinceLastCheck = ((Get-Date) - [datetime]($AltCheckData.'Date Checked' -Split " ")[0]).Days

            If ($DaysSinceLastCheck -ge 30) {
                $CustomComment = "It has been $DaysSinceLastCheck since this was last checked.  Please review the data again.  See SNMPv3 tab on the vCenter Parameters spreadsheet."
                $FindingHint = "Manual"
            } ElseIf ($CurrSystemData.Enabled -eq "False" -or ($CurrSystemData.Authentication -eq "SHA1" -and $CurrSystemData.Privacy -eq "AES128")) {
                $CustomComment = "This data was last verified on $($CurrSystemData.'Date Checked').  Enabled status is $($CurrSystemData.Enabled).  Authentication and Privacy is set to $($CurrSystemData.Authentication) and $($CurrSystemData.Privacy)"
                $FindingHint = "NF"
            } Else {
                $CustomComment = "SNMP incorrectly configured.  See SNMPv3 tab on the vCenter Parameters spreadsheet."
                $FindingHint = "O"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "VerifyLogs") {
            $CurrSystemData = $AltCheckData | Where { $_.vCenter -eq $CurrentSystemName }
            $DaysSinceLastCheck = ((Get-Date) - [datetime]($AltCheckData.'Date Checked' -Split " ")[0]).Days

            If ($DaysSinceLastCheck -ge 30) {
                $CustomComment = "It has been $DaysSinceLastCheck since this was last checked.  Please review the data again.  See VerifyLogs tab on the vCenter Parameters spreadsheet."
                $FindingHint = "Manual"
            } ElseIf ($CurrSystemData.LogsVerified -eq "True") {
                $CustomComment = "This data was last verified on $($CurrSystemData.'Date Checked').  Logs were verified as being collected is $($CurrSystemData.LogsVerified)"
                $FindingHint = "NF"
            } Else {
                $CustomComment = "Logs are not being collected on this vCenter server.  See VerifyLogs tab on the vCenter Parameters spreadsheet."
                $FindingHint = "O"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "LogInsight") {
            #I tried a handful of ways to find a satisfactory solution to this but for now it remains an NR

            $FindingHint = "Manual"
            $CustomComment = "Manual check - $($VCodeObjectSTIGData.Check_Param) - $($VCodeObjectSTIGData.Expected_Value)"
            
            <#
            $SyslogInfoSplit = $SyslogInfo -Split ":"
            $CurlString = "curl -v https://$($SyslogInfoSplit[0]):$($SyslogInfoSplit[1])"

            (Invoke-SSHCommand -SessionId 0 -Command { "Test" > /tmp/curloutput.txt }).Output
            (Invoke-SSHCommand -SessionId 0 -Command { cat /tmp/curloutput.txt }).Output

            (Invoke-SSHCommand -SessionId 0 -Command "$CurlString > /tmp/curloutput.txt" ).Output

            (Invoke-SSHCommand -SessionId 0 -Command { nc -uv DAISV0PP009.dir.ad.dla.mil 1514 }).Output
            (Invoke-SSHCommand -SessionId 0 -Command { ping DAISV0PP009.dir.ad.dla.mil -c 1 }).Output
            (Invoke-SSHCommand -SessionId 0 -Command { netstat DAISV0PP009.dir.ad.dla.mil -c 1 }).Output

            #Get a list of all LogInsight Agent files
            $LogInsightFiles = (Invoke-SSHCommand -SessionId 0 -Command { ls -l -t /var/log/loginsight-agent }).Output
            #Find the most recent one
            $liagentFileInfo = $LogInsightFiles | Where { $_ -like "*liagent_*" } | Select -First 1
            #Split the file info by spaces
            $liagentFileSplit = $liagentFileInfo -Split " "
            #Get the file name
            $liagentFileName = $liagentFileSplit[$liagentFileSplit.Count - 1]
            #Pull the last 100 lines of data from the log
            $liagentFileData = (Invoke-SSHCommand -SessionId 0 -Command "tail -n 100 /var/log/loginsight-agent/$liagentFileName").Output
            #>
        }

        $parms = @{
            CorrectVal = $VCodeObjectSTIGData.Expected_Value
            ActualVal = $SystemSettingValue
            CustomComment = $CustomComment
            FindingHint = $FindingHint
            CurrentSystemName = $CurrentSystemName
        }

        #If this is run from Orchestrator then run the check script from a local copy rather than a network one
        If ($RunFromOrchestrator -eq "True") {
            #Run the RecordToChecklist.ps1 script from a local copy
            Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\RecordToChecklist.ps1"" @parms")
        } Else {
            #Run the RecordToChecklist.ps1 script from the network
            Invoke-Expression -Command ("& '$FolderPathToSTIGScript\RecordToChecklist.ps1' @parms")
        }
    }

    #If this is an AltCheck then fill the Expected Value back in to it's original value
    If ($AltCheck -eq "True") {
        $VCodeObjectSTIGData.Expected_Value = $OrigExpectedValue
    }

    #Increment for the progress bar
    $CurrentVCode++
}

#Close the progress bar
Write-Progress -Activity "Scanning V-Code $Vuln_Num" -Completed

$Checklist_XMLObject.Save($ChecklistFilePath)

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAnH0/W8qSECgUG
# MC4UPBDIDqcywec48JntluX5snkw96CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCco56p9LT/HzuPdpY++iONEkDlrYu99dE0oGaPUua06jANBgkq
# hkiG9w0BAQEFAASCAQA0dvxfS/lrkJajwuXgdkR4xbfT1ZZ38c+gTjx38BTo3pAv
# jI3AOU589/XepiprJWESoJk9FVDbzkzlVG4KET7zdjPVK+WjVZlshgfnV+mnYTiM
# wb9BeAI6b29olEVCGzeFW1JCfwinUCqSWAeD65/1Ve1/xHcWa5618mbLqN96VSKw
# XTP7sJWPbX6gftg44k+kumzhuaPlEfZa5sXuGjqdBxjaQ0+rWUzJbtxygSfklgot
# Zes8DG2MLpXX7nmQuMowLACh8c4O/RCX3O/yNwgnj1CxZwAABmLjcWiXX4poeBKx
# II6RvIpaf0b8d3v6MHVTMaCnA9zZacrkeXUDZqar
# SIG # End signature block
