﻿#PURPOSE: Determine whether scripts located in the Windows VM scripts folder all include a PURPOSE line and are digitally signed

#CHANGELOG
#Version 1.0 - MDR - 08/28/23 - Initial version
#Version 1.01 - MDR - 09/19/23 - Added a catch if no scripts are found
#Version 1.02 - MDR - 10/20/23 - Added a complete to the progress bar so it doesn't get stuck on screen sometimes
#Version 1.03 - MDR - 11/29/23 - Report scripts missing PURPOSE or CHANGELOG
#Version 1.04 - MDR - 12/06/23 - Don't even make a validation report if all checks are successful since nothing can be done with it

Clear

#Path to the Windows VM Scripts
$WindowsVMScriptsFolderPath = Read-Host "Which path do you want to scan"
#Path to record the results of the script
$ReportPath = "$WindowsVMScriptsFolderPath\ScriptValidation.csv"
#Create an array to store the final output
$FinalOutput = @()
#Create an array for scripts with issues
$IssuesList = @()

#If the report path already exists from a previous run then delete it
If (Test-Path $ReportPath) {
    Remove-Item $ReportPath -ErrorAction SilentlyContinue -ErrorVariable FailedToDelete
    
    If ($FailedToDelete) {
        Write-Host "$ReportPath is open and must be closed for this script to run.  Exiting" -ForegroundColor Red
        Break
    }
}

#Get list of all scripts
$ScriptList = gci $WindowsVMScriptsFolderPath -Filter "*.ps1" -ErrorAction SilentlyContinue

If ($ScriptList -eq $null) {
    Write-Host "`nNo scripts found.  Exiting"
}

#Get the count in order for the progress bar to output properly
$ScriptCount = $ScriptList.Count
#Set the starting number for the progress bar
$CurrentScript = 1

#A string such as "#PURPOSE:" or "#CHANGELOG" is sent to the function and the function then reports whether this string is found in the script or not
Function StringCheck {
    Param ( $StringToCheck )

    #Check to see if the string exists in the script
    $StringCheck = $ScriptContent | Select-String $StringToCheck

    #Report back whether the string was found
    If ($StringCheck) {
        "True"
    } Else {
        $PurposeExists = "False"
    }
}

#Loop through all scripts to check and record whether they have signed certs and a PURPOSE line
ForEach ($ScriptPath in $ScriptList) {
    #Display the progress bar
    Write-Progress -Activity "Validating scripts" -Status "Reviewing $($ScriptPath.Name)" -PercentComplete ($CurrentScript / $ScriptCount * 100)
    
    #Get the content of the script
    $ScriptContent = Get-Content $ScriptPath.FullName

    #Check the digital signature of the script
    $DigitalSignature = Get-AuthenticodeSignature $ScriptPath.FullName
    #Record the SignerCertificate Thumbprint
    $DigitalCertThumbprint = $DigitalSignature.SignerCertificate.Thumbprint
    #Record the SignerCertificate Subject
    $DigitalCertSubject = $DigitalSignature.SignerCertificate.Subject
    #Record the Status 
    $DigitalCertStatus = $DigitalSignature.Status

    #Store the results for the script
    $FinalOutput += @([PSCustomObject]@{"ScriptName"=$ScriptPath.Name;"ScriptPath"=$ScriptPath.FullName;"PurposeExists"=StringCheck("#PURPOSE:");"ChangeLogExists"=StringCheck("#CHANGELOG");"DigitalThumbprint"=$DigitalCertThumbprint;"DigitalSigner"=$DigitalCertSubject;"DigitalStatus"=$DigitalCertStatus})

    #Increment the script counter
    $CurrentScript++
}

Write-Progress -Activity "Validating scripts" -Status "Complete" -Completed

#Report issues if any exist
$DigitalSignatureMissing = $FinalOutput | Where { $_.DigitalStatus -ne "Valid" }
$PurposeOrChangeLogMissing = $FinalOutput | Where { ($_.PurposeExists -ne "True" -or $_.ChangeLogExists -ne "True") -and $_.DigitalStatus -eq "Valid" }

If ($DigitalSignatureMissing -ne $null -or $PurposeOrChangeLogMissing -ne $null) {
    If ($DigitalSignatureMissing -ne $null) {
        Write-Host "`nThe following scripts are missing digital signatures:`n" -ForegroundColor Yellow
        $DigitalSignatureMissing.ScriptName
    }
    If ($PurposeOrChangeLogMissing -ne $null) {
        Write-Host "`nThe following scripts are missing purpose or changelogs:`n" -ForegroundColor Yellow
        $PurposeOrChangeLogMissing.ScriptName
    }
} Else {
    Write-Host "`nAll scripts passed validation checks" -ForegroundColor Green

    #Version 1.04 - Exit the script if all validation checks succeed rather than generating a report
    #NOTE: I might end up prompting if the report should get made in the future so using Break here rather than moving the report generation into the If statement
    Break
}

#Export the results
$FinalOutput | Export-CSV $ReportPath -NoTypeInformation

Write-Host "`nReport available at $ReportPath" -ForegroundColor Cyan
# SIG # Begin signature block
# MIILxQYJKoZIhvcNAQcCoIILtjCCC7ICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUfOGnufYmf8ya0OjG6mXvRCbx
# RcOgggktMIIEbDCCA1SgAwIBAgIDEjRvMA0GCSqGSIb3DQEBCwUAMFoxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMwHhcNMjMwNDEwMDAw
# MDAwWhcNMjcwNDA3MTM1NTU0WjBmMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5T
# LiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEMMAoGA1UE
# CxMDRExBMRMwEQYDVQQDEwpDUy5ETEEuMDA1MIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAjMaXJ2yQcMI0ZgW8qa3xkItp8L7VtB9FDtfdiQS6chAZC+V8
# RQO4iWMV87+bCdMIbHx/AgTepcuOwX/kAfxKVhb2msv3mHPzu7hhJpNTV9sGFR9S
# c62e4axw0i/O73B/ZsClZG0URlYFDb3X6rV1Qk27BUXdX++683Xgk5CspndiN1Zb
# fjZ69IDsvda5/gV6wyREcXlr5nlEXwn8SuA+J2xlFtkXbDNeLHo4Z88NlY61i13s
# 7C71giua12KEwy1g9saqw2mKlwfFfL4qipyRVrcPJNvc/lTh+wVq5P4WaBA06iKC
# 33IHndFd1cNor0sjp2zviZBYWcsFYngTFwKWCQIDAQABo4IBLTCCASkwHwYDVR0j
# BBgwFoAUF+ZLyBpLyaemcLRMTV7I9jbUMJgwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9ESURDQV82My5jcmwwDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdIAQPMA0wCwYJYIZIAWUCAQsqMB0GA1UdDgQWBBT4AbxTG6dDzp0i
# G4IfIlvBDYoM3TBlBggrBgEFBQcBAQRZMFcwMwYIKwYBBQUHMAKGJ2h0dHA6Ly9j
# cmwuZGlzYS5taWwvc2lnbi9ET0RJRENBXzYzLmNlcjAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwHwYDVR0lBBgwFgYKKwYBBAGCNwoDDQYIKwYBBQUH
# AwMwDQYJKoZIhvcNAQELBQADggEBAApQpCPdOGEWZ/CqUmxr7H/Jkj7CALR3OA6y
# b/vEO2v2QplFIyBiTFRoFs1G4pOt5njGzE8RtkXyO3PRD29RKKMBMwJwQtXLX9vD
# 0YVf/w5Wqtj3lptILtKM5elw+jehhn4KgyncMtp2yJwzToyRaoFdo3g/T5ddSYts
# 03i4XOuxEFnlJW/hozoMFaKFYitF5KMPwvnkLAynzmZLdhw17piUoo2ftPhh0i6y
# ZWwCObwfeti5yqNyUyof1XzD/4+h380+Zye68PeXdLNS/wIdAeKVImKxZB8s1+qq
# DAny4dogj0FU4PgdunbnwgACVTTmVswXUIlZOH6rS/K4iUkLdLYwggS5MIIDoaAD
# AgECAgIFDzANBgkqhkiG9w0BAQsFADBbMQswCQYDVQQGEwJVUzEYMBYGA1UEChMP
# VS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEWMBQG
# A1UEAxMNRG9EIFJvb3QgQ0EgMzAeFw0yMTA0MDYxMzU1NTRaFw0yNzA0MDcxMzU1
# NTRaMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAK
# BgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFEl3WgH6i1/u1Su87lcHX
# lB7dOsy17rfSlynPggESAK/rjElfavjrkmT6ooaq1bmV59HbSOVrN8wM7V2A5D5t
# rhMRCf9UC62PyU7/tqDcaFntnY11MAHs5yRfQud8WS2Wd1y3maLOOLwIgH+AYXCh
# 7KQUXs1dueJe53GE3M9e88GEFjfzJdPPM0fENk4ENeHKiBjHr290hoMu9cLBZMez
# DnAElqJMwZ0pwWwJRQviQ5jSG/rRViRx244X357taauwktYwzkhlLky8tBSnO+X9
# cOcl6TtohohTeW1mi3L/wuvpIE2vuFq/HrMvHETBn8RR9TfyAq5DE6ijnSjaxFyd
# AgMBAAGjggGGMIIBgjAfBgNVHSMEGDAWgBRsipSid7GAch2Behaq8tzOZu5FwDAd
# BgNVHQ4EFgQUF+ZLyBpLyaemcLRMTV7I9jbUMJgwDgYDVR0PAQH/BAQDAgGGMGcG
# A1UdIARgMF4wCwYJYIZIAWUCAQskMAsGCWCGSAFlAgELJzALBglghkgBZQIBCyow
# CwYJYIZIAWUCAQs7MAwGCmCGSAFlAwIBAw0wDAYKYIZIAWUDAgEDETAMBgpghkgB
# ZQMCAQMnMBIGA1UdEwEB/wQIMAYBAf8CAQAwDAYDVR0kBAUwA4ABADA3BgNVHR8E
# MDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RST09UQ0EzLmNy
# bDBsBggrBgEFBQcBAQRgMF4wOgYIKwYBBQUHMAKGLmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvaXNzdWVkdG8vRE9EUk9PVENBM19JVC5wN2MwIAYIKwYBBQUHMAGGFGh0dHA6
# Ly9vY3NwLmRpc2EubWlsMA0GCSqGSIb3DQEBCwUAA4IBAQAGG9UvVRw4kCnDGW7n
# RE7d0PtOn/xUx+sDBhK3u5wsFKl10fG7BSwmQRqQntbweiJFA9dIZbSOtkDF1cff
# fUMuHJE+2f/bOFWQuI9Tr7BS+Z6fS3ei1PrURrmgm5TxES6lznXqtL4M3IIkvlYM
# aaMxBLLGExy2t62aLZxv3EIa+2gPqVSCod0NA2Q8oboRgko/A01gbfMIcQ1FEqBl
# 3zbGhUIH2Hc2FnczW5L5hc61w62TB8EoocxDxbXg0lS8MvfGPIv7krViLom1/kbe
# kC/FlCB/+99HcPrPG07hDL+ryphbZ7LImdFr2+bWR+NR3ZHQ2ZPo1pSMOmLcRnSu
# IXsVMYICAjCCAf4CAQEwYTBaMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5TLiBH
# b3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMM
# RE9EIElEIENBLTYzAgMSNG8wCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFDYglEjQtz9Hc6fu/oNm
# YBWjtmlcMA0GCSqGSIb3DQEBAQUABIIBAESRDgORfuj+N/od4RNbr7BksnKx50VF
# gf7jnrbbkZoIMH6sxcbRs6k35lF8Rz/D0X2RkCi6sQAEZrOzgvGIz9AGNSGXGFIz
# nsiSnd3a/cka66qNTODt+m7HcyvySk48k2TQXsWllCvqNGeIVyFGbFXZjsJitmvc
# mx3R3m4/Lei9gLp3BthSFPnwnD90+sZ5zk+ooNPkbwISVOh8ilYJEMYv13nLlY+Y
# pDQ2zEBAEBYe2esBbZBgmaQYNMqmO2n2BTlJjCGN9V9GzSmVArIr+NJbo/G5md/S
# bSzJsgMEoO/H6fUgdi5VAKD7+DiP5Hx48+TU9LBWwUr/P2BZguCU27w=
# SIG # End signature block
