#PURPOSE: Remove Network Watcher Extension from a list of Azure VMs

#CHANGELOG
#Version 1.0 - 09/24/24 - MDR - Initial version

#Configure variables
$TodaysDate = Get-Date -Format "MMddyy"
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\NetworkWatcherExtensionUpdate-$TodaysDate.csv"

Clear

Clear-Variable ServerList -ErrorAction SilentlyContinue

#If the report already exists then remove it
If (Test-Path $ReportPath) {
    Remove-Item $ReportPath
}

#Get a list of subscriptions
$Subscriptions = Get-AzSubscription -ErrorAction SilentlyContinue -WarningAction SilentlyContinue | Sort Name
#Check to see if subscriptions were collected
If ($Subscriptions.count -lt 1)  {
    Write-Host "`nNot connected to Azure.  When the popup appears please login to Azure" -ForeGroundColor Yellow
    Connect-AzAccount -EnvironmentName AzureUSGovernment | Out-Null
    #Get a list of subscriptions
    $Subscriptions = Get-AzSubscription | Sort Name
} Else { #Notify that Azure is now connected
    Write-Host "`nConnected to Azure US Government" -ForeGroundColor Cyan 
}

#Load the file prompt forms
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
    
#Display a folder dialog box
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
    InitialDirectory = "C:\Temp"
    Filter = "TXT files (*.txt)|*.txt"
}
#Force the window to be on top
$FileBrowser.ShowDialog((New-Object System.Windows.Forms.Form -Property @{ TopMost = $true })) | Out-Null

Try {
    #Store the list of servers
    $ServerList = Get-Content $FileBrowser.FileName
} Catch {}

#If no servers were imported
If ($ServerList -eq $null -or $ServerList -eq "") {
    Write-Host "`nNo servers found.  Exiting"
    Break
}

#Loop through each subscription
ForEach ($CurrSubscription in $SubscriptionList) {
    #Display which subscription is being looked at
    Write-Host "`nChecking subscription $($CurrSubscription.Name)" -ForegroundColor Cyan

    #Connect to current subscription
    Set-AzContext -SubscriptionId $CurrSubscription | Out-Null

    #Get list of all VMs in that subscription
    $VMList = Get-AzVM

    #Loop through each server name in the list
    ForEach ($ServerName in $ServerList) {
        #If the server name is in this subscription
        If ($VMList.Name -contains $ServerName) {
            Write-host "`nChecking $ServerName"

            #Store the info about the VM
            $VMInfo = $VMList | Where { $_.Name -eq $ServerName }

            #Get the data for this VM
            $VMData = Get-AzVM -ResourceGroupName $VMInfo.ResourceGroupName -Name $VMInfo.name -Status

            #Determine if Azure Network Watcher Extension is on this VM
            $ExtensionCheck = $VMData.Extensions | Where { $_.Name -eq "AzureNetworkWatcherExtension" }

            #If the extension was found
            If ($ExtensionCheck -ne $null) {
                Write-Host "Removing extension" -ForegroundColor Cyan
                Get-AzVMExtension -ResourceGroupName $VMInfo.ResourceGroupName -VMName $VMInfo.Name -Name "AzureNetworkWatcherExtension" | Remove-AzVMExtension -Force | Out-Null
                [PSCustomObject]@{"ServerName"=$VMInfo.Name;"Subscription"=$CurrSubscription.Name;"Result"="Extension removed"} | Export-CSV $ReportPath -NoTypeInformation -Append
            } Else { #If extension not found
                Write-Host "No extension found" -ForegroundColor Yellow
                [PSCustomObject]@{"ServerName"=$VMInfo.Name;"Subscription"=$CurrSubscription.Name;"Result"="Extension not found"} | Export-CSV $ReportPath -NoTypeInformation -Append
            }
        }
    }
}

#Script completed
Write-Host "Script complete" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCA29dj20EQ5N6X6
# qJwqz2ISSCsPAv89bv+0WTBnpUKQFKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBR377KYsRxgUd/1feJJfA2QLqMgRvCoDa4HzUcmsh/EDANBgkq
# hkiG9w0BAQEFAASCAQBeuMx7y9AoWBb4aSDMYvDxVtQqgLOxDTwpNgoEQ7WNkFkw
# r58nT7QQiAnD1Pio1AF7YgLl4jsvifRM9uiARt8y2UfxBXjfnGgv5O+qOFlBbH6q
# m2GMvelTyCOpeY+1ZP7N3FDXwNeWkbvjRYwFtCbnohl3mnRDjurOTxeGC13rf1J4
# ymRyIDs70CzAMhw0d8NxyluMt1VIF12qGPXpukObE+g5BXUKZ0fwsrEch8UEFOEc
# zT156T+cIQldSbYEmAv2YYUViShGC0zM+dNszpAI70Ek6YicNlFGguQmjHoB//qt
# iAeEUAYHSUU7SYGj+YkLJsodHfC6sVLl0+L/ImBf
# SIG # End signature block
