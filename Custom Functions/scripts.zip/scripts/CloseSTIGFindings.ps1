#PURPOSE: Used to close STIG findings in a .ckl file

#CHANGELOG
#Version 1.0 - 08/22/24 - MDR - Initial version
#Version 1.03 - 10/01/24 - MDR - Corrected a mistake when filtering for changes for this VM and shortened an If statement
#Version 1.04 - 10/10/24 - MDR - Adding support for POAMs
#Version 1.05 - 10/23/24 - MDR - Prevent running a check on a checklist that doesn't have any changes being made to it when run from Orchestrator

Param ( $SystemChecklists, $ListOfStatusUpdates )

ForEach ($SystemChecklist in $SystemChecklists) {
    #Version 1.05 - If the current checklist has no changes marked for it then skip it
    If ($null -eq ($ListOfStatusUpdates | Where { $_.ServerName -eq $SystemChecklist.SystemName }) -and $AutoSTIGRun -eq "True") {
        Continue
    }

    $Checklist_XML = New-Object XML
    $Checklist_XML.PreserveWhitespace = $true #This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
    $Checklist_XML.Load($SystemChecklist.FullName) #This is the name of the empty checklist template file

    $SystemName = $Checklist_XML.CHECKLIST.ASSET.HOST_FQDN

    $VULN_DATA = $Checklist_XML.CHECKLIST.STIGS.iSTIG.VULN

    #Version 1.02 - Added capability to import that findings into the $STIGResultList Array
    ForEach ($VULN in $VULN_DATA) {
        $Vuln_Num = ($VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq 'Vuln_Num' }).ATTRIBUTE_DATA
        $Severity = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA

        #Version 1.03 - Changed $SystemChecklist.ShortName to $SystemChecklist.SystemName
        $ChangesForThisVM = $ListOfStatusUpdates | Where { $_.ServerName -eq $SystemChecklist.SystemName -and $_.VCode -eq $Vuln_Num }

        #Version 1.02 - If there is a change that needs to be recorded
        #Version 1.03 - Removed the Where $_.VCode -eq $Vuln_Num portion since that is already done when getting the $ChangesForThisVM variable
        If ( $ChangesForThisVM ){
            #Store the new Status and Comment before saving to .CKL file
            #Version 1.02 - Changed from doing a longer string to get the VULN data to just $VULN.STATUS
            $VULN.STATUS = $ChangesForThisVM.Status
            $OriginalComments = $VULN.Comments
            #Version 1.04 - If this is a closed finding
            If ($ChangesForThisVM.Status -eq "NotAFinding") {
                $VULN.Comments = "This finding was resolved by the VM STIG Mitigation script.  Below is what the values were before the mitigation:`n`n$OriginalComments"
            } ElseIf ($ChangesForThisVM.Status -eq "Open") { #Version 1.04 - If this is a POAM item
                $VULN.Comments = "This finding was POAM'd.  No change was made.  Below is information for this finding:`n`n$OriginalComments"
            }
        }
        
        $FindingSeverity = Switch ($Severity) {
            'High' { "CAT I" }
            'Medium' { "CAT II" }
            'Low' { "CAT III" }
        }

        $FindingStatus = Switch ($VULN.Status) {
            'Open' { "O" }
            'NotAFinding' { "NF" }
            'Not_Applicable' { "NA" }
            'Not_Reviewed' { "NR" }
        }

        $Global:STIGResultList.add((New-Object "psobject" -Property @{"SystemName"=$SystemName;"VCode"=$Vuln_Num;"CAT"=$FindingSeverity;"Status"=$FindingStatus}))
    }

    $Checklist_XML.Save($SystemChecklist.TempPath)
}
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBbUS1MtZpcUsgw
# JBGMgbOwVavnZ7jyYncANs5Lp67eLaCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBk42k0Kn3uxlJJ2y7UUVaZfyAjNhKi+45vwmuH5chsMjANBgkq
# hkiG9w0BAQEFAASCAQA+pxFM+LbltyJPHAF8vIvy+Y4tRRtcbwzR13hW1PPv7o+V
# hb5e272RyomkgAr/T2sdMnPcNocs6EnysiHdKA3t461WfgHMY4fjOW/TSc/M2yVl
# 7ScazaGk1aERSQKe+lmPC8GdLQvs24fcC9o+LPnRJvMj5eHfV54w4F/DIw0cZHRn
# p/2rJC/Zvdy9Dg5lxnPu5brDNYHyIvx2EL/JRzOZwCklnmfCPOho1woXvZ6/+PJ/
# u9lwvyNthTmbaUrVAi44ya0AZfsLvsen+gq8UU68HJzwWfvNMKrN2wvptEcjmARx
# /1QT68B8mLCU67FprHcx/bXLj1cxGN4IFrSvVJtW
# SIG # End signature block
