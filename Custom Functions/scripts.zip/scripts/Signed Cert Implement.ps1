#PURPOSE: Implement signed certificate requests for ESX hosts
#         Script process: Confirm cluster stability, place host into Maintenance Mode, disconnect host, apply cert, run services.sh restart, rejoin to vCenter, take out of Maintenance Mode,
#         verify signed cert was applied, wait for storage VMs to come back online

#CHANGELOG
#Version 1.00 - 07/16/24 - MDR - Initial version
#Version 1.01 - 08/15/24 - MDR - Added a second connect line since I believe that the first run just connects it to vCenter and the second removes it from MM
#Version 1.02 - 08/22/24 - MDR - Added imports for the necessary modules for the folder browser.  Lots of minor fixes
#Version 1.03 - 09/04/24 - MDR - Making corrections to ensure implementation is functional
#Version 1.04 - 09/05/24 - MDR - Making additional fixes for the script
#Version 1.05 - 09/09/24 - MDR - Performing additional fixes to try and get a stable working version
#Version 1.06 - 09/10/24 - MDR - Working on tracking reboots
#Version 1.07 - 09/10/24 - MDR - Add reporting
#Version 1.08 - 09/11/24 - MDR - Added a check to make sure PowerCLI and SSH modules are installed
#Version 1.09 - 11/01/24 - MDR - Collect the rui.crt and rui.key files for the hosts
#Version 1.10 - 11/04/24 - MDR - Replace V: with \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam
#Version 1.11 - 11/18/24 - MDR - Check whether SSH is started prior to script starting it.  If it is started already, then don't have the script start it or stop it later on
#Version 1.12 - 01/03/25 - MDR - Added a wait just in case there is any issue with the cluster alarm not working
#Version 1.13 - 01/03/25 - MDR - Added a check after putting the system into maintenance mode to ensure the system truly made it into maintenance mode

#This list is built from the script "Build ESX List.ps1" and will have information in it that is necessary for generating signed cert requests
$ESXHostList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ESXHostList.csv"
#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"
#Version 1.07 - Add reporting
$TodaysDate = Get-Date -Format "MMddyy"
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\SignedCert-$TodaysDate.csv"
$SignedCertData = New-Object System.Collections.Generic.List[System.Object]
$SignedCertBackupFolderPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Certificates\Signed Certificates\Script Added Certs" #Version 1.09 - Store applied certs here

#Version 1.09 - Allow multiple connections to vCenter Servers which is required for this script
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

#Version 1.09 - Verify the signed certs path exists
If (!(Test-Path $SignedCertBackupFolderPath)) {
    New-Item $SignedCertBackupFolderPath -ItemType Directory | Out-Null
}

#Version 1.05 - Track the successful and unsuccessful cert signings
$CertSuccesses = @()
$CertFailures = @()

#Version 1.02 - Import the modules required for the folder browser
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")

#Version 1.08 - Set Invalid Cert Action to Ignore
If ((Get-PowerCLIConfiguration -Scope User).InvalidCertificateAction -ne "Ignore") {
    Set-PowerCLIConfiguration -Scope User -InvalidCertificateAction Ignore -Confirm:$false
}

Clear

#Version 1.08 - Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Version 1.08 - Verify that the PowerCLI module exists
$VerifyPowerCLI = Get-Command Connect-VIServer -ErrorAction SilentlyContinue

#If PowerCLI doesn't exist then explain where to get it from and exit the script
If (!($VerifyPowerCLI)) {
    Write-Host "`nPowerCLI not found" -ForegroundColor Red
    Write-Host "`nPowerCLI can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\VMware PowerCLI\PowerCLI - MikeR"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Version 1.08 - Verify that the SSH module exists
$VerifySSHModule = Get-Command New-SSHSession -ErrorAction SilentlyContinue

#If SSH doesn't exist then explain where to get it from and exit the script
If (!($VerifySSHModule)) {
    Write-Host "`nSSH module not found" -ForegroundColor Red
    Write-Host "`nSSH can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\Posh-SSH"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

###SECTION 1 - Collect signed cert information and ESX / vCenter credentials###

#Verify that the ESX host list was imported
If ($ESXHostList -eq $null){
    Write-Host "The ESX Host List file was not found" -ForegroundColor Red
    Break
}

Write-Host "Select the folder where all of the .cer files are located"

#Prompt for the signed certs folder
$FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{ 
    #Version 1.10 - Default to \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Certificates\Working Files folder instead of V:\Certificates
    SelectedPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Certificates\Working Files"
    Description = "Select Signed Cert folder"
    RootFolder = "MyComputer"
}

#If a folder was selected
If ($FolderBrowser.ShowDialog() -eq "OK") {
    $SignedCertFolderPath = $FolderBrowser.SelectedPath
} Else {
    Write-Host "`nNo folder was selected" -ForegroundColor Red
    Break
}

#Get a list of all .cer files in the folder
$SignedCertList = (Get-ChildItem $SignedCertFolderPath -Filter *.cer).Name

#If no .cer files are found
If ($SignedCertList -eq $null) {
    Write-Host "`nNo .cer files were found" -ForegroundColor Red
    Break
}

#Prompt for vCenter Password
$vCenterPass = Read-Host "`nInput the vCenter PowerShell service account password" -MaskInput

#Prompt for ESX Password
$ESXPass = Read-Host "`nInput the ESX password" -MaskInput

#Generate the ESX credentials to connect
$SecurePassword = ConvertTo-SecureString $ESXPass -AsPlainText -Force
$ESXSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecurePassword )

#Loop through each signed cert
ForEach ($SignedCertFileName in $SignedCertList) {
    ###SECTION 2 - Verify cert and connect to vCenter###

    #Version 1.08 - Changed the split method from .Split to -Split
    $SignedCertHostName = ($SignedCertFileName -Split ".cer")[0]

    #Find the ESX host info for this signed cert
    $ESXHostInfo = $ESXHostList | Where { $_.SystemName -like "$SignedCertHostName*" }

    #Version 1.02 - If no host info is found then skip this cert
    If ($ESXHostInfo -eq $null) {
        Write-Host "`nNo host was found for cert $SignedCertFileName" -ForegroundColor Red
        Continue
    } Else { #Notify that a host is being worked
        Write-Host "`n$($ESXHostInfo.SystemName) will have certificate added" -ForegroundColor Cyan
    }

    #Store all of the variables for the ESX host being processed
    $vCenterServerName = $ESXHostInfo.vCenterServer

    #Only perform a connection attempt to vCenter if it isn't already connected
    If (($global:DefaultVIServers).Name -notcontains $vCenterServerName) {
        #Get the user name that will be used to connect to vCenter
        $vCenterUserName = ($vCenterServerList | Where { $_.ServerName -eq $vCenterServerName }).User

        #Generate the vCenter credentials to connect
        $SecurePassword = ConvertTo-SecureString $vCenterPass -AsPlainText -Force
        $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterUserName, $SecurePassword )

        Try {
            #Disconnected from all vCenter Servers
            Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
        } Catch {}

        #Connect to vCenter Server
        Connect-VIServer $vCenterServerName -Credential $vCenterSecureCreds | Out-Null
        
        #Confirm that the connection worked
        If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServerName })) {
            Write-Host "`nFailed to connect to vCenter Server $vCenterServerName" -ForegroundColor Red
            Break
        }
    }

    ###SECTION 3 - Confirm cluster stability, place host into Maintenance Mode, then Disconnect host###

    #Version 1.03 - Collect the VMHost info
    $VMHost = Get-VMHost $ESXHostInfo.SystemName
    
    #Version 1.03 - Get the cluster name
    $ClusterName = $VMHost.Parent.Name

    #Version 1.03 - Get the alarm IDs
    $UnhealthyAlarmID = (Get-AlarmDefinition | Where { $_.Name -eq "Cluster is unhealthy" }).Id
    $APComplianceAlarmID = (Get-AlarmDefinition | Where { $_.Name -eq "Cluster access policy compliance has degraded" }).Id
    
    #Update the Cluster alarm info
    $ClusterInfo = Get-Cluster $ClusterName
    
    #Version 1.03 - Make sure the cluster isn't in a non-compliance alarm when this runs
    $UnhealthyAlarms = $ClusterInfo.ExtensionData.TriggeredAlarmState | Where { $_.Alarm -eq $UnhealthyAlarmID }
    $NoncomplianceAlarms = $ClusterInfo.ExtensionData.TriggeredAlarmState | Where { $_.Alarm -eq $APComplianceAlarmID }

    #Version 1.03 - If in a noncompliance alarm then exit
    If ($NoncomplianceAlarms -ne $null <#-and $UnhealthyAlarms -eq $null#>) {
        Write-Host "`nThe cluster $ClusterName is in a non-complaint state.  Type RUN to continue or anything else to exit" -ForegroundColor Red
        Break
    }

    #Version 1.13 - Verify that the system is actually in maintenance mode
    $SystemInMM = "False"

    #Version 1.13 - Loop until in MM
    While ($SystemInMM -eq "False" ) {
        #Put host into Maintenance Mode
        Write-Host "`nPlacing $($ESXHostInfo.SystemName) into maintenance mode"
        $VMHost | Set-VMHost -State Maintenance -ErrorAction SilentlyContinue | Out-Null

        $VMHost = Get-VMHost $ESXHostInfo.SystemName

        If ($VMHost.ConnectionState -eq "Maintenance") {
            $SystemInMM = "True"
        } Else {
            Write-Host "$($ESXHostInfo.SystemName) isn't in Maintenance Mode.  Trying again in 15 seconds" -ForegroundColor Yellow
            Start-Sleep 15
        }
    }

    #Disconnect the host from the vCenter server
    Write-Host "`nDisconnecting $($ESXHostInfo.SystemName) from vCenter"
    $VMHost | Set-VMHost -State Disconnected | Out-Null

    #Disconnect PowerCLI from vCenter
    Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue

    ###SECTION 4 - Apply signed cert to the ESX host###

    #Connect to the ESX host
    Write-Host "`nConnecting to $($ESXHostInfo.SystemName) with PowerCLI"
    $ESXConnection = Connect-VIServer $ESXHostInfo.SystemName -Credential $ESXSecureCreds

    #If the connection failed
    If ($ESXConnection -eq $null) {
        Write-Host "Failed to connect to $($ESXHostInfo.SystemName)" -ForegroundColor Red
        #Version 1.03 - Exit the script entirely if the ESX host fails to connect since there is probably a password issue
        Break
    }

    #Get the VMHost data
    $VMHost = Get-VMHost $ESXHostInfo.SystemName

    #Get the ESX certificate data
    $ESXCertData = Get-Content "$SignedCertFolderPath\$SignedCertFileName" -Raw

    #Apply the certificate to the ESX host
    Write-Host "`nAdding signed certificate to $($ESXHostInfo.SystemName)"
    Set-VIMachineCertificate -PemCertificate $ESXCertData -VMHost $VMHost -Confirm:$false -ErrorVariable CertError | Out-Null

    If ($CertError[0] -eq $null) {
        Write-Host "`nCertificate added successfully"
    } Else {
        Write-Host "`nFailed with error $CertError"
        Break
    }

    ###SECTION 5 - SSH into host and run services.sh restart###

    #Version 1.11 - Check to see if SSH is running
    $SSHServiceRunStatus = ($VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" }).Running

    #Version 1.11 - Only start the service if it isn't already running
    If ($SSHServiceRunStatus -eq $false) {
        #Start the SSH service on the host so that services.sh restart can be run later
        $VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" } | Start-VMHostService -Confirm:$false | Out-Null
    }

    #Create an SSH session to the host
    $SSHConnection = New-SSHSession -HostName $VMHost.Name -Credential $ESXSecureCreds -AcceptKey -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

    #Version 1.03 - Verify that the SSH connection succeeded
    If ($SSHConnection -eq $null) {
        Write-Host "`nFailed to SSH into $($VMHost.Name)" -ForegroundColor Red
        Break
    }

    #Get the SSH Session ID
    $SSHSessionID = $SSHConnection.SessionId

    #Run "services.sh restart"
    Write-Host "`nRestarting services on $($ESXHostInfo.SystemName)"
    $RestartServicesOutput = (Invoke-SSHCommand -SessionId $SSHSessionID -Command { services.sh restart }).Output

    #Version 1.05 - Add in this troubleshooting line to see if there are times when restarting services results in an odd number of lines which might indicate it failed
    Write-Host "`nRestarting services output $($RestartServicesOutput.Length) lines.  This is for troubleshooting purposes only"

    #Version 1.09 - Collect the CRT and KEY info
    $CRTInfo = (Invoke-SSHCommand -SessionId $SSHSessionID -Command { cat /etc/vmware/ssl/rui.crt }).Output
    $KEYInfo = (Invoke-SSHCommand -SessionId $SSHSessionID -Command { cat /etc/vmware/ssl/rui.key }).Output

    #Version 1.09 - Verify the signed certs path exists
    If (!(Test-Path "$SignedCertBackupFolderPath\$($ESXHostInfo.SystemName)")) {
        New-Item "$SignedCertBackupFolderPath\$($ESXHostInfo.SystemName)" -ItemType Directory | Out-Null
    }

    #Version 1.09 - Store the file info to a folder
    $CRTInfo | Out-File "$SignedCertBackupFolderPath\$($ESXHostInfo.SystemName)\rui.crt"
    $KEYInfo | Out-File "$SignedCertBackupFolderPath\$($ESXHostInfo.SystemName)\rui.key"

    ###SECTION 7 - Verify that the certificate applied properly and if it didn't then reboot the host###

    #Version 1.06 - Wait for port 902 to become available before attempting to reconnect back to the host
    Write-Host "`nReconnecting to the ESX host"

    $ConnectionSucceeded = "False"

    While ($ConnectionSucceeded -eq "False") {
        try {
            #Reconnect to the ESX host
            Connect-VIServer $ESXHostInfo.SystemName -Credential $ESXSecureCreds | Out-Null
            $ConnectionSucceeded = "True"
        } catch {
            Start-Sleep 1
        }
    }

    #Version 1.05 - Get the VMHost data to check cert info
    $VMHost = Get-VMHost

    #Version 1.05 - Get the certificate issuer data from the ESX host's point of view
    $certMgr = Get-View -Id $VMHost.ExtensionData.ConfigManager.CertificateManager
    $certIssuer = ($certMgr.CertificateInfo.Issuer -Split ",")[0] -replace "CN=",""
    $certSubject = ($certMgr.CertificateInfo.Subject -Split ",")[0] -replace "CN=",""

    #Version 1.05 - If this is a DOD cert then everything went great
    If ($certIssuer -like "*DOD*") {
        Write-Host "`nESX sees that the certificate is issued by $certIssuer for $certSubject" -ForegroundColor Cyan
        $CertInESX = "True"
    } Else { #Otherwise the host needs to be rebooted to apply the cert
        Write-Host "`nDOD cert wasn't properly detected.  ESX host shows certificate is issued by $certIssuer for $certSubject.  The host will be rebooted to apply the cert" -ForegroundColor Yellow
        $CertInESX = "False"

        #Restart the host
        (Invoke-SSHCommand -SessionId $SSHSessionID -Command { esxcli system shutdown reboot -r "Applying certificate" }).Output

        #Wait for the host to go offline
        Write-Host "`nWaiting for the host to go offline"
        While (Test-Connection -ComputerName $ESXHostInfo.SystemName -Count 1 -Quiet) {
            Start-Sleep 5
        }

        #Version 1.06 - Wait for host to come back online
        Write-Host "`nWaiting for the host to come back online"
        Start-Sleep 60

        #Version 1.06 - Loop until the host pings
        While (!(Test-Connection -ComputerName $ESXHostInfo.SystemName -Count 1 -Quiet)) {
            Start-Sleep 5
        }

        #Version 1.06 - Wait for port 443 to become available
        Write-Host "`nWaiting for web interface to come back online"
        Start-Sleep 60

        $PingSucceeded = "False"

        While ($PingSucceeded -eq "False") {
            try {
                $tcpClient = New-Object System.Net.Sockets.TcpClient
                $tcpClient.Connect($ESXHostInfo.SystemName, "443")
                $tcpClient.Close()
                $PingSucceeded = "True"
            } catch {
                Start-Sleep 3
            }
        }

        #Version 1.06 - Wait for port 902 to become available
        Write-Host "`nWaiting for host interface to come back online"
        Start-Sleep 60

        $PingSucceeded = "False"

        While ($PingSucceeded -eq "False") {
            try {
                $tcpClient = New-Object System.Net.Sockets.TcpClient
                $tcpClient.Connect($ESXHostInfo.SystemName, "902")
                $tcpClient.Close()
                $PingSucceeded = "True"
            } catch {
                Start-Sleep 3
            }
        }

        Write-Host "`n$($ESXHostInfo.SystemName) is back online"
    }

    #Version 1.07 - Disconnect SSH session
    Get-SSHSession | Remove-SSHSession | Out-Null

    #Disconnect PowerCLI from the ESX host
    Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue

    ###SECTION 8 - Reconnect to vCenter and rejoin the host to vCenter and remove from Maintenance Mode###

    #Reconnect to vCenter Server
    Connect-VIServer $vCenterServerName -Credential $vCenterSecureCreds | Out-Null

    #Connect the host back to the vCenter server
    Write-Host "`nReconnecting $($ESXHostInfo.SystemName) to vCenter and exiting from maintenance mode"
    Get-VMHost $ESXHostInfo.SystemName | Set-VMHost -State Connected | Out-Null

    #Get the VMHost data to check if the host is not responding
    $VMHost = Get-VMHost $ESXHostInfo.SystemName

    #Version 1.03 - If the host is not responding
    If ($VMHost.ConnectionState -eq "NotResponding") {
        #Try reconnecting the host again
        Get-VMHost $ESXHostInfo.SystemName | Set-VMHost -State Connected | Out-Null

        #Get the VMHost data
        $VMHost = Get-VMHost $ESXHostInfo.SystemName

        #If even after this it isn't responding then exit
        If ($VMHost.ConnectionState -eq "NotResponding") {
            Write-Host "$($ESXHostInfo.SystemName) isn't rejoining vCenter" -ForegroundColor Red
            Break
        }
    }

    ###SECTION 9 - Verify if the signed cert was recognized by vCenter and disable SSH###

    #Get the VMHost data
    $VMHost = Get-VMHost $ESXHostInfo.SystemName

    #Version 1.05 - Get the certificate issuer data from the vCenter point of view
    $certMgr = Get-View -Id $VMHost.ExtensionData.ConfigManager.CertificateManager
    $certIssuer = ($certMgr.CertificateInfo.Issuer -Split ",")[0] -replace "CN=",""
    $certSubject = ($certMgr.CertificateInfo.Subject -Split ",")[0] -replace "CN=",""

    #Version 1.05 - If this is a DOD cert then everything went great
    If ($certIssuer -like "*DOD*") {
        Write-Host "`nvCenter sees that the certificate is issued by $certIssuer for $certSubject" -ForegroundColor Cyan
        $CertSuccesses += $ESXHostInfo.SystemName
        $CertInvCenter = "True"
    } Else { #Otherwise this is bad
        Write-Host "`nWARNING: The vCenter server sees sees that this is not a DOD cert.  Certificate is issued by $certIssuer for $certSubject" -ForegroundColor Yellow
        $CertFailures += $ESXHostInfo.SystemName
        $CertInvCenter = "False"
    }

    #Version 1.03 - If the host is in Maintenance Mode then run the Connect again
    If ($VMHost.ConnectionState -eq "Maintenance") {
        Get-VMHost $ESXHostInfo.SystemName | Set-VMHost -State Connected | Out-Null

        #Get the VMHost data
        $VMHost = Get-VMHost $ESXHostInfo.SystemName
    }

    #Version 1.11 - Only stop the service if it if was started by the script (if the $SSHServiceRunStatus is $false meaning it was stopped prior to the script running)
    If ($SSHServiceRunStatus -eq $false) {
        #Disable SSH on the ESX host
        $VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" } | Stop-VMHostService -Confirm:$false | Out-Null
    }

    ###SECTION 10 - If this is an HX cluster, then wait for the storage VM to come back online###

    #Get a list of VMs that are on this ESX host
    $ESXHostVMList = $VMHost | Get-VM "stCtlVM*"

    #Version 1.03 - Move the VM name check outside of the While loop
    If ($ESXHostVMList -ne $null) {
        #If this is an HX host, wait for the storage VM to start
        $Completed = "False"
        $VMPoweredOn = "False"
        $ComplianceAlarm = "False"
        $UnhealthyAlarm = "False"

        Write-Host "`nWaiting for the HX Storage VM $($ESXHostVMList.Name) to start.  This will likely take several minutes"

        #Version 1.12 - Adding a wait in here just in case there is any issue with the cluster alarm not working
        Start-Sleep 60

        #Version 1.03 - Loop until there are no Compliance related alarms
        While ($Completed -ne "True") {
            #If the storage VM is powered on then mark as completed AND there are no compliance alarms
            If ($ESXHostVMList.PowerState -eq "PoweredOn" -and $NoncomplianceAlarms -eq $null <#-and $UnhealthyAlarms -eq $null#>) {
                $Completed = "True"
                #Version 1.03 - Add 10 seconds to allow system to fully power up
                Write-Host "`n$($ESXHostVMList.Name) is powered up and $ClusterName has no compliance alarms" -ForegroundColor Green
            } Else {
                #Get a list of VMs that are on this ESX host
                $ESXHostVMList = $VMHost | Get-VM "stCtlVM*"

                #Update the Cluster alarm info
                $ClusterInfo = Get-Cluster $ClusterName
                #Check to see what alarms are triggered
                $NoncomplianceAlarms = $ClusterInfo.ExtensionData.TriggeredAlarmState | Where { $_.Alarm -eq $APComplianceAlarmID }
                $UnhealthyAlarms = $ClusterInfo.ExtensionData.TriggeredAlarmState | Where { $_.Alarm -eq $UnhealthyAlarmID }
                
                #Version 1.04 - Provide some notifications of progress being made
                If ($VMPoweredOn -eq "False" -and $ESXHostVMList.PowerState -eq "PoweredOn") {
                    Write-host "`n$($ESXHostVMList.Name) is powered up"
                    $VMPoweredOn = "True"
                }
                If ($ComplianceAlarm -eq "False" -and $NoncomplianceAlarms -eq $null) {
                    Write-host "`nCompliance alarm has cleared"
                    $ComplianceAlarm = "True"
                }
                If ($UnhealthyAlarm -eq "False" -and $UnhealthyAlarms -eq $null) {
                    Write-host "`nUnhealthy alarm has cleared"
                    $UnhealthyAlarm = "True"
                }

                #If any alarms exist or VM not powered on, wait 1 second before checking again
                Start-Sleep 1
            }
        }
    }

    $SignedCertData.add((New-Object "psobject" -Property @{"ServerName"=$ESXHostInfo.SystemName;"Cert Seen By ESX"=$CertInESX;"Cert Seen By vCenter"=$CertInvCenter;"Issuer"=$certMgr.CertificateInfo.Issuer;"Subject"=$certMgr.CertificateInfo.Subject;"Date"=Get-Date -Format "MM/dd/yyyy"}))
}

###SECTION 11 - Perform the final actions for the script###

#Disconnect from all hosts and vCenter
Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue

#Version 1.05 - Report the successes and failures
Write-Host "`nFinal report:"
Write-Host "`nSuccesses:" -ForegroundColor Cyan
$CertSuccesses

#Version 1.07 - Only display failures when there are failures to show
If ($CertFailures -ne $null) {
    Write-Host "`nFailures:" -ForegroundColor Yellow
    $CertFailures
}

#Version 1.07 - Export report
$SignedCertData | Select "ServerName", "Cert Seen By ESX", "Cert Seen By vCenter", "Issuer", "Subject", "Date" | Export-CSV $ReportPath -NoTypeInformation -Append
Write-Host "`nGo to $ReportPath to see report output"

#Notify that the script is completed
Write-Host "`nScript completed" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBn7486sOa0+87w
# en6KqSUVZGO7IVBs86+G0KZWfEUlzKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAyz3vFxDSt0qSFPvAYchCdBMB3IqNNNoJaKqXZTTEAZzANBgkq
# hkiG9w0BAQEFAASCAQB5tb/61IapCjGqp/l40aNvD7uF8cqhT+Np/DkZJ7BiVQsG
# 4Csbb9oNV+Qp49cxhzyauY2INq5ugNX4IEICCbLRxkbi97oa2L+YSUGvx8JPylCG
# sDH/OesbhxaxWIR3SEU0MLCyP4UoRQo15PlzyhmAt0pkkFlA+UlLjN7AgwQlrSoF
# 2HMDBgsyJRirUkqdFJ/nrgrWCj2V+PFTJJ4AuzbCGZqn60fgdPiTvzoEbH246Vrd
# edN5Mo89pY6C52W32rti/mRgRlhL3j/ifmylXMluCv0ya7UryxMG05tYwlVOb/n2
# rALHgqIK03lMFH6r8wY3zsu464ip+lNbcnqqVO2k
# SIG # End signature block
