﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2023 v5.8.218
	 Created on:   	2/15/2023 8:48 AM
	 Created by:   	DMM0090D
	 Organization: 	
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

# Import-Module VMware.VimAutomation.Core


Import-Module VMware.VimAutomation.Core
$vcenter = "trisv0pp212.dir.ad.dla.mil"



<#
.SYNOPSIS

Get the TPM details on a host. if you do not have all of the privileges described as follows:     -  The resource HostSystem referenced by the parameter host requires Host.Tpm.Read.  

.DESCRIPTION

No description available.

.PARAMETER Host
Identifier of the host. The parameter must be an identifier for the resource type: HostSystem.

.PARAMETER Tpm
the TPM identifier. The parameter must be an identifier for the resource type: com.vmware.vcenter.trusted_infrastructure.hosts.hardware.Tpm.

.PARAMETER WithHttpInfo

A switch when turned on will return a hash table of Response, StatusCode and Headers instead of just the Response

.OUTPUTS

TrustedInfrastructureHostsHardwareTpmInfo

.LINK

Online Version: https://developer.vmware.com/docs/vsphere-automation/latest/vcenter/api/vcenter/trusted-infrastructure/hosts/host/hardware/tpm/tpm/get/
#>
function Invoke-GetHostTpmHardware
{
	[CmdletBinding(
				   SupportsShouldProcess = $true,
				   ConfirmImpact = 'None',
				   HelpURI = "https://developer.vmware.com/docs/vsphere-automation/latest/vcenter/api/vcenter/trusted-infrastructure/hosts/host/hardware/tpm/tpm/get/"
				   )]
	Param (
		[Parameter(Mandatory = $true, ValueFromPipeline = $true)]
		[ValidateScript({ $_ -is [string] })]
		${Host},
		[Parameter(Mandatory = $true)]
		[ValidateScript({ $_ -is [string] })]
		${Tpm},
		[Parameter()]
		[vSphereConnectionToServerConfigurationArgumentTransformationAttribute()]
		[PSTypeName('vSphereServerConfiguration')]
		$Server,
		[Switch]
		$WithHttpInfo
	)
	
	Process
	{
		'Calling method: Invoke-GetHostTpmHardware' | Write-Debug
		
		$ServerConfigurations = Get-vSphereServerConfiguration
		if ($PSBoundParameters.ContainsKey('Server'))
		{
			$ServerConfigurations = $Server
		}
		
		if ($null -eq $ServerConfigurations)
		{
			throw "You are not currently connected to any servers. Please connect first using a Connect-VIServer cmdlet or add vSphere Server Configuration with New-vSphereServerConfiguration."
		}
		
		$LocalVarAccepts = @()
		$LocalVarContentTypes = @()
		$LocalVarQueryParameters = @{ }
		$LocalVarHeaderParameters = @{ }
		$LocalVarFormParameters = @{ }
		$LocalVarPathParameters = @{ }
		$LocalVarCookieParameters = @{ }
		$LocalVarBodyParameter = $null
		
		$ServerFromInputParameters = $null
		$InputParametersFromServer = $PSBoundParameters.Values | Where-Object -FilterScript { $_.PSObject.TypeNames -Contains 'ServerObject' }
		
		foreach ($InputParameterFromServer in $InputParametersFromServer)
		{
			$InputParameterServer = $InputParameterFromServer.GetServer()
			if (
				!$PSBoundParameters.ContainsKey('Server') -and
				$null -ne $ServerFromInputParameters -and
				!$ServerFromInputParameters.Equals($InputParameterServer)
			)
			{
				$ErrorMessage = "{0} and {1} come from different servers. {0} from {2} and {1} from {3}. Please specify the -Server parameter of the cmdlet."
				throw ($ErrorMessage -f $ServerFromInputParameters.InputParameter, $InputParameterFromServer, $ServerFromInputParameters.Server, $InputParameterServer)
			}
			
			if ($null -eq $ServerFromInputParameters)
			{
				$ServerFromInputParameters = [PSCustomObject] @{
					InputParameter = $InputParameterFromServer
					Server		   = $InputParameterServer
				}
			}
		}
		
		if (
			$null -ne $ServerFromInputParameters -and
			$PSBoundParameters.ContainsKey('Server') -and
			!$ServerFromInputParameters.Server.Equals($Server)
		)
		{
			$ErrorMessage = "{0} comes from server {1} but server {2} is explicitly specified."
			throw ($ErrorMessage -f $ServerFromInputParameters.InputParameter, $ServerFromInputParameters.Server, $Server)
		}
		
		# HTTP header 'Accept' (if needed)
		$LocalVarAccepts = @('application/json')
		
		
		$serversToProcess = $ServerConfigurations
		
		if (!$PSBoundParameters.ContainsKey('Server') -and $null -ne $ServerFromInputParameters)
		{
			$serversToProcess = $ServerFromInputParameters.Server
		}
		
		foreach ($serverConfiguration in $serversToProcess)
		{
			$shouldProcessActionMessage = "Performing the operation 'GetHostTpmHardware' on target server '$($serverConfiguration.ToString())'."
			$shouldProcessActionCaption = 'Are you sure you want to perform this action?'
			
			if ($PSCmdlet.ShouldProcess(
					$shouldProcessActionMessage,
					$shouldProcessActionMessage,
					$shouldProcessActionCaption
				)
			)
			{
				$LocalVarUri = '/api/vcenter/trusted-infrastructure/hosts/{host}/hardware/tpm/{tpm}'
				$LocalVarMethod = 'GET'
				
				$useDeprecatedApis = ($null -ne $serverConfiguration.UseDeprecatedApis -and $serverConfiguration.UseDeprecatedApis)
				$translationSchema = $null
				$transformedOpertaionInput = New-InputTransformationStructure
				if ($useDeprecatedApis)
				{
					# Use Deprecated APIs
					$translationSchema = Get-OperationTranslationSchema `
																		-operationPath $LocalVarUri.Replace('__', '?') `
																		-operationVerb $LocalVarMethod
					if ($null -ne $translationSchema)
					{
						$LocalVarUri = $translationSchema.OldPath
						$LocalVarMethod = $translationSchema.OldVerb
					}
				}
				
				if (!$Host)
				{
					throw "Error! The required parameter `Host` missing when calling getHostTpmHardware."
				}
				$LocalVarUri = $LocalVarUri.replace('{host}', $Host)
				$LocalVarPathParameters['host'] = $Host
				if (!$Tpm)
				{
					throw "Error! The required parameter `Tpm` missing when calling getHostTpmHardware."
				}
				$LocalVarUri = $LocalVarUri.replace('{tpm}', $Tpm)
				$LocalVarPathParameters['tpm'] = $Tpm
				if ($useDeprecatedApis -and ($null -ne $translationSchema))
				{
					$addTransformationInput = Format-PathParams -OperationTranslateSchema $translationSchema -PathParams $LocalVarPathParameters
					Join-InputTransformationStructure -Base ([ref]$transformedOpertaionInput) -Addition $addTransformationInput
				}
				if ($useDeprecatedApis -and ($null -ne $translationSchema))
				{
					$addTransformationInput = Format-Headers -OperationTranslateSchema $translationSchema -Headers $LocalVarHeaderParameters
					Join-InputTransformationStructure -Base ([ref]$transformedOpertaionInput) -Addition $addTransformationInput
				}
				if (
					$useDeprecatedApis -and
					($null -ne $translationSchema) -and
					($LocalVarQueryParameters.Count -gt 0)
				)
				{
					$inputQuerySctructure = [PSCustomObject]$LocalVarQueryParameters
					$translatedBody = Convert-InputStructure -OperationTranslateSchema $translationSchema -OperationInputObject $inputQuerySctructure -InputType Body
					$translatedQuery = Convert-InputStructure -OperationTranslateSchema $translationSchema -OperationInputObject $inputQuerySctructure -InputType Query
					
					if ($null -ne $translatedBody)
					{
						$LocalVarBodyParameter = $translatedBody | ConvertTo-Json -Depth 100
						
						if ($LocalVarContentTypes.Count -eq 0)
						{
							$LocalVarContentTypes = @('application/json')
						}
					}
					$LocalVarQueryParameters = @{ }
					$translatedQuery.PSObject.Properties | Foreach-Object { $LocalVarQueryParameters[$_.Name] = $_.Value }
				}
				
				if ($useDeprecatedApis -and ($null -ne $translationSchema))
				{
					if ($null -ne $transformedOpertaionInput.Path)
					{
						foreach ($keyValue in $transformedOpertaionInput.Path.GetEnumerator())
						{
							$LocalVarUri = $LocalVarUri.replace("{$($keyValue.Key)}", $keyValue.Value)
						}
					}
					
					if ($null -ne $transformedOpertaionInput.Query)
					{
						foreach ($keyValue in $transformedOpertaionInput.Query.GetEnumerator())
						{
							$LocalVarQueryParameters[$($keyValue.Key)] = $keyValue.Value
						}
					}
					
					if ($null -ne $transformedOpertaionInput.Header)
					{
						foreach ($keyValue in $transformedOpertaionInput.Header.GetEnumerator())
						{
							$LocalVarHeaderParameters[$($keyValue.Key)] = $keyValue.Value
						}
					}
					
					if ($null -ne $transformedOpertaionInput.Body)
					{
						$LocalVarBodyParameter = $transformedOpertaionInput.Body | ConvertTo-Json -Depth 100
					}
				}
				
				$invokeParams = @{
					'Method'		   = $LocalVarMethod
					'Uri'			   = $LocalVarUri
					'Accepts'		   = $LocalVarAccepts
					'ContentTypes'	   = $LocalVarContentTypes
					'Body'			   = $LocalVarBodyParameter
					'HeaderParameters' = $LocalVarHeaderParameters
					'QueryParameters'  = $LocalVarQueryParameters
					'FormParameters'   = $LocalVarFormParameters
					'CookieParameters' = $LocalVarCookieParameters
					'ReturnType'	   = "TrustedInfrastructureHostsHardwareTpmInfo"
					'IsBodyNullable'   = $false
					'Server'		   = $serverConfiguration
				}
				
				if ($PSBoundParameters.ContainsKey('Debug'))
				{
					$invokeParams['Debug'] = $Debug
				}
				
				if ($PSBoundParameters.ContainsKey('Verbose'))
				{
					$invokeParams['Verbose'] = $Verbose
				}
				
				if ($PSBoundParameters.ContainsKey('WarningAction'))
				{
					$invokeParams['WarningAction'] = $PSBoundParameters.WarningAction
				}
				
				if ($PSBoundParameters.ContainsKey('ErrorAction'))
				{
					$invokeParams['ErrorAction'] = $PSBoundParameters.ErrorAction
				}
				
				$invokeParams['InvocationInfo'] = @{
					'ModuleName' = $MyInvocation.MyCommand.ModuleName
					'CmdletName' = $MyInvocation.MyCommand.Name
				}
				
				$invokeResult = Invoke-vSphereApiClient @invokeParams
				
				$invokeResult | Foreach-Object {
					$SingleServerResult = $_
					if ($SingleServerResult -is [hashtable])
					{
						
						if ($useDeprecatedApis -and ($null -ne $translationSchema) -and ($null -ne $SingleServerResult["Response"]))
						{
							$ServerName = $SingleServerResult["Response"].PSObject.TypeNames | Where-Object -FilterScript { $_.StartsWith('Server:') }
							
							$SingleServerResult["Response"] = Convert-OutputBody `
																				 -OperationTranslateSchema $translationSchema `
																				 -OperationOutputObject $SingleServerResult["Response"]
							
							if (![string]::IsNullOrEmpty($ServerName))
							{
								$SingleServerResult["Response"] | ForEach-Object -Process {
									$_.PSObject.TypeNames.Add($ServerName)
									
									$_ = $_ | Add-Member -MemberType ScriptMethod -Name GetServer -Value {
										$productServerString = ($this.PSObject.TypeNames | Where-Object -FilterScript { $_.StartsWith('Server:') }).Substring(7)
										$productSeparatorIndex = $productServerString.IndexOf(':')
										
										$product = $productServerString.Substring(0, $productSeparatorIndex)
										$server = $productServerString.Substring($productSeparatorIndex + 1, $productServerString.Length - $productSeparatorIndex - 1)
										
										Get-ServerConfiguration -Product $product | Where-Object -FilterScript { $_.ToString() -eq $server }
									} -Force -PassThru
									
									$_.PSObject.TypeNames.Add("ServerObject")
								}
							}
						}
						
						$SingleServerResult["Response"].PSObject.TypeNames.Insert(0, "TrustedInfrastructureHostsHardwareTpmInfo")
						
						if ($WithHttpInfo.IsPresent)
						{
							# result object
							$SingleServerResult
						}
						else
						{
							# result object
							$SingleServerResult["Response"]
						}
						
					}
					else
					{
						Write-Warning "An item from the Invoke-vSphereApiClient was expected to be a Hashtable but it is '$($SingleServerResult.GetType())'"
					}
				}
			}
		}
	}
}

<#
.SYNOPSIS

Return a list of configured TPMs on a host. if you do not have all of the privileges described as follows:     -  The resource HostSystem referenced by the parameter host requires Host.Tpm.Read.  

.DESCRIPTION

No description available.

.PARAMETER Host
Identifier of the host. The parameter must be an identifier for the resource type: HostSystem.

.PARAMETER MajorVersions
The TPM major version number. if unset or empty, the result will not be filtered by version number.

.PARAMETER Active
The TPM status. if unset, the result will not be filtered by status.

.PARAMETER WithHttpInfo

A switch when turned on will return a hash table of Response, StatusCode and Headers instead of just the Response

.OUTPUTS

TrustedInfrastructureHostsHardwareTpmSummary[]

.LINK

Online Version: https://developer.vmware.com/docs/vsphere-automation/latest/vcenter/api/vcenter/trusted-infrastructure/hosts/host/hardware/tpm/get/
#>
function Invoke-ListHostTrustedInfrastructureHardwareTpm
{
	[CmdletBinding(
				   SupportsShouldProcess = $true,
				   ConfirmImpact = 'None',
				   HelpURI = "https://developer.vmware.com/docs/vsphere-automation/latest/vcenter/api/vcenter/trusted-infrastructure/hosts/host/hardware/tpm/get/"
				   )]
	Param (
		[Parameter(Mandatory = $true, ValueFromPipeline = $true)]
		[ValidateScript({ $_ -is [string] })]
		${Host},
		[Parameter(Mandatory = $false)]
		[System.Nullable[Int64][]]
		${MajorVersions},
		[Parameter(Mandatory = $false)]
		[System.Nullable[Boolean]]
		${Active},
		[Parameter()]
		[vSphereConnectionToServerConfigurationArgumentTransformationAttribute()]
		[PSTypeName('vSphereServerConfiguration')]
		$Server,
		[Switch]
		$WithHttpInfo
	)
	
	Process
	{
		'Calling method: Invoke-ListHostTrustedInfrastructureHardwareTpm' | Write-Debug
		
		$ServerConfigurations = Get-vSphereServerConfiguration
		if ($PSBoundParameters.ContainsKey('Server'))
		{
			$ServerConfigurations = $Server
		}
		
		if ($null -eq $ServerConfigurations)
		{
			throw "You are not currently connected to any servers. Please connect first using a Connect-VIServer cmdlet or add vSphere Server Configuration with New-vSphereServerConfiguration."
		}
		
		$LocalVarAccepts = @()
		$LocalVarContentTypes = @()
		$LocalVarQueryParameters = @{ }
		$LocalVarHeaderParameters = @{ }
		$LocalVarFormParameters = @{ }
		$LocalVarPathParameters = @{ }
		$LocalVarCookieParameters = @{ }
		$LocalVarBodyParameter = $null
		
		$ServerFromInputParameters = $null
		$InputParametersFromServer = $PSBoundParameters.Values | Where-Object -FilterScript { $_.PSObject.TypeNames -Contains 'ServerObject' }
		
		foreach ($InputParameterFromServer in $InputParametersFromServer)
		{
			$InputParameterServer = $InputParameterFromServer.GetServer()
			if (
				!$PSBoundParameters.ContainsKey('Server') -and
				$null -ne $ServerFromInputParameters -and
				!$ServerFromInputParameters.Equals($InputParameterServer)
			)
			{
				$ErrorMessage = "{0} and {1} come from different servers. {0} from {2} and {1} from {3}. Please specify the -Server parameter of the cmdlet."
				throw ($ErrorMessage -f $ServerFromInputParameters.InputParameter, $InputParameterFromServer, $ServerFromInputParameters.Server, $InputParameterServer)
			}
			
			if ($null -eq $ServerFromInputParameters)
			{
				$ServerFromInputParameters = [PSCustomObject] @{
					InputParameter = $InputParameterFromServer
					Server		   = $InputParameterServer
				}
			}
		}
		
		if (
			$null -ne $ServerFromInputParameters -and
			$PSBoundParameters.ContainsKey('Server') -and
			!$ServerFromInputParameters.Server.Equals($Server)
		)
		{
			$ErrorMessage = "{0} comes from server {1} but server {2} is explicitly specified."
			throw ($ErrorMessage -f $ServerFromInputParameters.InputParameter, $ServerFromInputParameters.Server, $Server)
		}
		
		# HTTP header 'Accept' (if needed)
		$LocalVarAccepts = @('application/json')
		
		
		$serversToProcess = $ServerConfigurations
		
		if (!$PSBoundParameters.ContainsKey('Server') -and $null -ne $ServerFromInputParameters)
		{
			$serversToProcess = $ServerFromInputParameters.Server
		}
		
		foreach ($serverConfiguration in $serversToProcess)
		{
			$shouldProcessActionMessage = "Performing the operation 'ListHostTrustedInfrastructureHardwareTpm' on target server '$($serverConfiguration.ToString())'."
			$shouldProcessActionCaption = 'Are you sure you want to perform this action?'
			
			if ($PSCmdlet.ShouldProcess(
					$shouldProcessActionMessage,
					$shouldProcessActionMessage,
					$shouldProcessActionCaption
				)
			)
			{
				$LocalVarUri = '/api/vcenter/trusted-infrastructure/hosts/{host}/hardware/tpm'
				$LocalVarMethod = 'GET'
				
				$useDeprecatedApis = ($null -ne $serverConfiguration.UseDeprecatedApis -and $serverConfiguration.UseDeprecatedApis)
				$translationSchema = $null
				$transformedOpertaionInput = New-InputTransformationStructure
				if ($useDeprecatedApis)
				{
					# Use Deprecated APIs
					$translationSchema = Get-OperationTranslationSchema `
																		-operationPath $LocalVarUri.Replace('__', '?') `
																		-operationVerb $LocalVarMethod
					if ($null -ne $translationSchema)
					{
						$LocalVarUri = $translationSchema.OldPath
						$LocalVarMethod = $translationSchema.OldVerb
					}
				}
				
				if (!$Host)
				{
					throw "Error! The required parameter `Host` missing when calling listHostTrustedInfrastructureHardwareTpm."
				}
				$LocalVarUri = $LocalVarUri.replace('{host}', $Host)
				$LocalVarPathParameters['host'] = $Host
				if ($useDeprecatedApis -and ($null -ne $translationSchema))
				{
					$addTransformationInput = Format-PathParams -OperationTranslateSchema $translationSchema -PathParams $LocalVarPathParameters
					Join-InputTransformationStructure -Base ([ref]$transformedOpertaionInput) -Addition $addTransformationInput
				}
				if ($useDeprecatedApis -and ($null -ne $translationSchema))
				{
					$addTransformationInput = Format-Headers -OperationTranslateSchema $translationSchema -Headers $LocalVarHeaderParameters
					Join-InputTransformationStructure -Base ([ref]$transformedOpertaionInput) -Addition $addTransformationInput
				}
				if ($null -ne $MajorVersions)
				{
					$LocalVarQueryParameters['major_versions'] = $MajorVersions
				}
				
				if ($null -ne $Active)
				{
					$LocalVarQueryParameters['active'] = $Active
				}
				
				if (
					$useDeprecatedApis -and
					($null -ne $translationSchema) -and
					($LocalVarQueryParameters.Count -gt 0)
				)
				{
					$inputQuerySctructure = [PSCustomObject]$LocalVarQueryParameters
					$translatedBody = Convert-InputStructure -OperationTranslateSchema $translationSchema -OperationInputObject $inputQuerySctructure -InputType Body
					$translatedQuery = Convert-InputStructure -OperationTranslateSchema $translationSchema -OperationInputObject $inputQuerySctructure -InputType Query
					
					if ($null -ne $translatedBody)
					{
						$LocalVarBodyParameter = $translatedBody | ConvertTo-Json -Depth 100
						
						if ($LocalVarContentTypes.Count -eq 0)
						{
							$LocalVarContentTypes = @('application/json')
						}
					}
					$LocalVarQueryParameters = @{ }
					$translatedQuery.PSObject.Properties | Foreach-Object { $LocalVarQueryParameters[$_.Name] = $_.Value }
				}
				
				if ($useDeprecatedApis -and ($null -ne $translationSchema))
				{
					if ($null -ne $transformedOpertaionInput.Path)
					{
						foreach ($keyValue in $transformedOpertaionInput.Path.GetEnumerator())
						{
							$LocalVarUri = $LocalVarUri.replace("{$($keyValue.Key)}", $keyValue.Value)
						}
					}
					
					if ($null -ne $transformedOpertaionInput.Query)
					{
						foreach ($keyValue in $transformedOpertaionInput.Query.GetEnumerator())
						{
							$LocalVarQueryParameters[$($keyValue.Key)] = $keyValue.Value
						}
					}
					
					if ($null -ne $transformedOpertaionInput.Header)
					{
						foreach ($keyValue in $transformedOpertaionInput.Header.GetEnumerator())
						{
							$LocalVarHeaderParameters[$($keyValue.Key)] = $keyValue.Value
						}
					}
					
					if ($null -ne $transformedOpertaionInput.Body)
					{
						$LocalVarBodyParameter = $transformedOpertaionInput.Body | ConvertTo-Json -Depth 100
					}
				}
				
				$invokeParams = @{
					'Method'		   = $LocalVarMethod
					'Uri'			   = $LocalVarUri
					'Accepts'		   = $LocalVarAccepts
					'ContentTypes'	   = $LocalVarContentTypes
					'Body'			   = $LocalVarBodyParameter
					'HeaderParameters' = $LocalVarHeaderParameters
					'QueryParameters'  = $LocalVarQueryParameters
					'FormParameters'   = $LocalVarFormParameters
					'CookieParameters' = $LocalVarCookieParameters
					'ReturnType'	   = "TrustedInfrastructureHostsHardwareTpmSummary[]"
					'IsBodyNullable'   = $false
					'Server'		   = $serverConfiguration
				}
				
				if ($PSBoundParameters.ContainsKey('Debug'))
				{
					$invokeParams['Debug'] = $Debug
				}
				
				if ($PSBoundParameters.ContainsKey('Verbose'))
				{
					$invokeParams['Verbose'] = $Verbose
				}
				
				if ($PSBoundParameters.ContainsKey('WarningAction'))
				{
					$invokeParams['WarningAction'] = $PSBoundParameters.WarningAction
				}
				
				if ($PSBoundParameters.ContainsKey('ErrorAction'))
				{
					$invokeParams['ErrorAction'] = $PSBoundParameters.ErrorAction
				}
				
				$invokeParams['InvocationInfo'] = @{
					'ModuleName' = $MyInvocation.MyCommand.ModuleName
					'CmdletName' = $MyInvocation.MyCommand.Name
				}
				
				$invokeResult = Invoke-vSphereApiClient @invokeParams
				
				$invokeResult | Foreach-Object {
					$SingleServerResult = $_
					if ($SingleServerResult -is [hashtable])
					{
						
						if ($useDeprecatedApis -and ($null -ne $translationSchema) -and ($null -ne $SingleServerResult["Response"]))
						{
							$ServerName = $SingleServerResult["Response"].PSObject.TypeNames | Where-Object -FilterScript { $_.StartsWith('Server:') }
							
							$SingleServerResult["Response"] = Convert-OutputBody `
																				 -OperationTranslateSchema $translationSchema `
																				 -OperationOutputObject $SingleServerResult["Response"]
							
							if (![string]::IsNullOrEmpty($ServerName))
							{
								$SingleServerResult["Response"] | ForEach-Object -Process {
									$_.PSObject.TypeNames.Add($ServerName)
									
									$_ = $_ | Add-Member -MemberType ScriptMethod -Name GetServer -Value {
										$productServerString = ($this.PSObject.TypeNames | Where-Object -FilterScript { $_.StartsWith('Server:') }).Substring(7)
										$productSeparatorIndex = $productServerString.IndexOf(':')
										
										$product = $productServerString.Substring(0, $productSeparatorIndex)
										$server = $productServerString.Substring($productSeparatorIndex + 1, $productServerString.Length - $productSeparatorIndex - 1)
										
										Get-ServerConfiguration -Product $product | Where-Object -FilterScript { $_.ToString() -eq $server }
									} -Force -PassThru
									
									$_.PSObject.TypeNames.Add("ServerObject")
								}
							}
						}
						
						foreach ($element in $SingleServerResult["Response"])
						{
							$element.PSObject.TypeNames.Insert(0, "TrustedInfrastructureHostsHardwareTpmSummary")
						}
						
						if ($WithHttpInfo.IsPresent)
						{
							# result object
							$SingleServerResult
						}
						else
						{
							# result object
							$SingleServerResult["Response"]
						}
						
					}
					else
					{
						Write-Warning "An item from the Invoke-vSphereApiClient was expected to be a Hashtable but it is '$($SingleServerResult.GetType())'"
					}
				}
			}
		}
	}
}




if (-not (Test-Connection -TargetName $vcenter -Count 1 -Quiet))
{
	write-host "`nProvided vCenter Server # $vcenter # is Not Reachable, please enter a valid FQDN or IP Address"
	exit
}
try
{
	$VCConnection = Connect-VIServer -Server $vcenter -user administrator@DLA-Prod.local -password 1DAascQ_2014_sso! | Out-Null
}
catch
{
	$error_message = $_.Exception.Message
	write-host "Unable to login to vCenter Server - $error_message"
	exit
}

$VIBVerificationStatus = @()

$ESXiHosts = Get-VMHost | Select-Object -First 50

write-host "`nTotal Number of ESXi hosts to scan - $($ESXiHosts.Count)`n"

foreach ($ESXiHost in $ESXiHosts)
{
	
	Invoke-GetHostTpmHardware -Host $ESXiHost
	write-host "Checking Host - $($ESXiHost.Name)"
	if (($ESXiHost.ConnectionState -eq "Connected") -or ($ESXiHost.ConnectionState -eq "Maintenance"))
	{
		
		
		#Execute esxcli software vib signature verify status on each ESXi host
		Connect-VIServer -Server $ESXiHost.name -User root -Password 1DAascQ_20o9!esx
		
		$esxhost | ForEach-Object -Process {
			$cmd1 = "/usr/lib/vmware/secureboot/bin] ./secureBoot.py -s"
			$cmd2 = "/usr/lib/vmware/secureboot/bin] ./secureBoot.py -c"
			if (!(Get-VMHostService -VMHost $_).where({ $_.Key -eq 'TSM-SSH' }).Running)
			{
				Get-VMHost -name $esxhost | get-vmhostservice | Where-Object { $_.key -eq "TSM-SSH" } | Start-VMHostService
				$ssh = New-SSHSession -ComputerName $_.Name -Credential $cred -AcceptKey -KeepAliveInterval 5 -Verbose
				Invoke-SSHCommand -SessionId $ssh.SessionId -Command $cmd1 -TimeOut 30
				Invoke-SSHCommand -SessionId $ssh.SessionId -Command $cmd2 -TimeOut 30
				Remove-SSHSession -SessionId $ssh.SessionId  }
		
		
	}
}

$ResultFilename = "\\orgaze\DCC\VirtualTeam\Reports\secure boot\" + $vcenter.tostring() + "_" + (Get-Date).tostring("dd-MM-yy-hh-mm") + ".csv"
		try
		{
			Write-Host "got here 5"
			#Export the overall result to CSV file
			$VIBVerificationStatus | Sort-Object OverallStatus | export-csv $ResultFilename -NoTypeInformation -ErrorAction Stop
			write-host "`nPlease check the final result file - " $ResultFilename
		}
		catch
		{
			Write-Host "got here 6"
			#catch the failure and export the result to a different filename in current script execution path
			$ResultFilename = "Secureboot" + $vcenter + "_" + (Get-Date).tostring("dd-MM-yyyy-hh-mm-ss") + ".csv"
			$VIBVerificationStatus | Sort-Object OverallStatus | export-csv $ResultFilename -NoTypeInformation
			$result = Get-Item $ResultFilename
			write-host "`nPlease check the final result file saved in current directory - " $result.fullname
		}
		finally
		{
			#Disconnect the vCenter Server
			$VCConnection = Disconnect-VIServer -Server $vcenter -confirm:$false
			
		}


# SIG # Begin signature block
# MIIllAYJKoZIhvcNAQcCoIIlhTCCJYECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCJUUlUSsAZlg2E
# GQan/eNRyrln3H3/z8RcBPc5kIZ3LqCCH58wggNzMIICW6ADAgECAgEBMA0GCSqG
# SIb3DQEBCwUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1l
# bnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9v
# dCBDQSAzMB4XDTEyMDMyMDE4NDY0MVoXDTI5MTIzMDE4NDY0MVowWzELMAkGA1UE
# BhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQww
# CgYDVQQLEwNQS0kxFjAUBgNVBAMTDURvRCBSb290IENBIDMwggEiMA0GCSqGSIb3
# DQEBAQUAA4IBDwAwggEKAoIBAQCp7BRyiuhLcKPaEAOEpvunNg0qOlIWvzAVUoYF
# RyDPqqbNdcRkbu/xYCPLCmZArrTIaCoAUWhJN+lZMk2VvEMn6UCNOhDOFLxDGKH5
# 3sznhXZzXhgaI1u9Px/y7Y0ZzAPRQKSPpyACTCdaeTb2ozchjgBaBhbK01WWbzEp
# u3IOy+JIUfLUN6Q11m/uF7OxBqsLGYboI20xGyh4ZcXeYlK8wX3r7qBdVAT7sssr
# siNUkYJM8L+6dEA7DARFgGdcxeuiV8MafwotvX+53MGZsMgH5AyGNpQ6JS/yfeaX
# PBuUtJdZBsk65AvZ6un8O3M0b/3nmOTzocKQXxz1Py7XGdN/AgMBAAGjQjBAMB0G
# A1UdDgQWBBRsipSid7GAch2Behaq8tzOZu5FwDAOBgNVHQ8BAf8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAn3GkwLaW0oBDoEjpH3YE
# +cU8rWYYWGObw7boaIqFWkJmErTS5ouIf4f0mPWoxgnJH/AsH+yCuPSlRzjBMyvf
# TH6avgsLscsPfFAoEM+KjaLpuqyG19Sxk18ij5YFtE4MdZF90/LnlMKUFHZPjwyr
# EIdYMoUHdYYSC17qU7QKyEyEkh/r6EGGPLr0TkFK0WxYR0HDhlry7unymCeC6i42
# 1vgGXoLxoFKTRAm60qkZWlijqF0gbU9k+DCHG5ATSIHNypDHDcHUmD+O8g5XaDMS
# jpkJsfDk9hD0NvJJveqjOMhWQSODmt+hGzV86z9Bs/VvSzperm+TdpjS8ZmdRcSO
# cjCCBLkwggOhoAMCAQICAgMFMA0GCSqGSIb3DQEBCwUAMFsxCzAJBgNVBAYTAlVT
# MRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UE
# CxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTE5MDQwMjEzMzgzMloX
# DTI1MDQwMjEzMzgzMlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292
# ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERP
# RCBJRCBDQS01OTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMwXhJ8t
# wQpXrRFNNVc/JEcvHA9jlr27cDE8rpxWkobvpCJOoOVUbJ724Stx6OtTAZpRiXNa
# S0jjRgYaW6cq9pdnjjQM5ovHPPde1ewaZyWb2I+uqhkZmOBV1+lGUOhnQCyinnSS
# qzEH1PC5nASfyxnCdBeOt+UKHBrPVKBUuYS4Fcn5Q0wv+sfBD24vyV5OjeoqHeSS
# AMTaeqlv+WQb4YrjKNfaGF+S7lMvQelu3ANHEcoL2HMCimCvnCHQaMQI9+MsNhyS
# PEULePdEDxgpWYc9FmBbjUp1CYEx7HYdlTRJ9gBHts2ITxTZQrt4Epjkqeb8aWVm
# zCEPHE7+KUVhuO8CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyKlKJ3sYByHYF6
# Fqry3M5m7kXAMB0GA1UdDgQWBBR1CaYVE66HPPpzlADy8PV5ubJyFDAOBgNVHQ8B
# Af8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsG
# CWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMC
# AQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTAD
# gAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RP
# RFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDov
# L2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3YzAgBggrBgEF
# BQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQELBQADggEBADkF
# G9IOpz71qHNXCeYJIcUshgN20CrvB5ym4Pr7zKTBRMKNqd9EXWBxrwP9xhra5YcQ
# agHDqnmBeU3F2ePhWvQmyhPwIJaArk4xGLdv9Imkr3cO8vVapO48k/R9ZRSAEBxz
# d0xMDdZ6+xxFlZJIONRlxcVNNVB30e74Kk08/t82S9ogqgA1Q7KZ2tFuaResjJWu
# oJ+LtE5lrtknqgaXLb3XH0hV5M0AWRk9Wg/1thb9NCsKEIAdpdnolZOephIzfzHi
# OSqeJ+e5qURLB7rT+F5y0NNWTdqoJ/vOOCUa8z0NKWsz2IkpeD3iNhVCLRKwOjm/
# wzxdG2tst5OHRZFEwKcwggUXMIID/6ADAgECAgQBG1VrMA0GCSqGSIb3DQEBCwUA
# MFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNTkwHhcN
# MjExMDI3MDAwMDAwWhcNMjQxMDI2MjM1OTU5WjB7MQswCQYDVQQGEwJVUzEYMBYG
# A1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BL
# STEMMAoGA1UECxMDRExBMSgwJgYDVQQDEx9NSUxMRVIuTUFUVEhFVy5XQVlORS4x
# MjY1Njc0MzAxMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAk/T/sloO
# XNYYZH003Wgn+xmjbZtuHQXY+udUStHKm9xkG1/fh5GeDhHnDa+exdY7qGN+L/e0
# +3QT1vjj+vU7AFO/RIqGoZ6w1R/hdqmfgH7ja0nRGZhAtSChMcMjO4wI9M27Xyin
# LyRo1vH7yru8ME3uHmpAOArg86uZKkCtgzfCQ6L22j8GvKzp44xcBpwtc8vfgM6+
# cYktY7AGFSGwHSKhoMvdJkSsY/qRlBZpwFwbxhjfdd4tu3/0ob3/NntlNQBIgBy9
# Wv7E7gqk1f+XxOP1iN04kDmGgGpWTatxocJfxqgxzv27vmAucVZw/FkUVclty6FY
# j1Hh8U5+JXcyNQIDAQABo4IBwjCCAb4wHwYDVR0jBBgwFoAUdQmmFROuhzz6c5QA
# 8vD1ebmychQwPgYDVR0fBDcwNTAzoDGgL4YtaHR0cDovL2NybC5kaXNhLm1pbC9j
# cmwvRE9ESURDQV81OV9OQURNSU4uY3JsMA4GA1UdDwEB/wQEAwIHgDAjBgNVHSAE
# HDAaMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswHQYDVR0OBBYEFI+StvPXvusM
# H8mXt2o2jmD6v6OfMGUGCCsGAQUFBwEBBFkwVzAzBggrBgEFBQcwAoYnaHR0cDov
# L2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNTkuY2VyMCAGCCsGAQUFBzABhhRo
# dHRwOi8vb2NzcC5kaXNhLm1pbDAbBgNVHQkEFDASMBAGCCsGAQUFBwkEMQQTAlVT
# MFkGA1UdEQRSMFCgHwYKKwYBBAGCNxQCA6ARDA9kMTI2NTY3NDMwMUBtaWyGLXVy
# bjp1dWlkOjFmNjQwNDk1LTgxMDktNGIyNi1BQzMzLTMwODg0NzY2MTdGOTAoBgNV
# HSUEITAfBggrBgEFBQcDAgYKKwYBBAGCNxQCAgYHKwYBBQIDBDANBgkqhkiG9w0B
# AQsFAAOCAQEAgy8cep3g7p2K7S8+Q5y5JpFky4qnZQn6vkNzZuBBWb2XaRDKKnJ/
# vtWTHkEJAng0dHs/rLQrvA7zyvVw6jv++q8X5UrHjVb8NQs9Xrec1jTfyYgihjEQ
# 7fAI5cExs80ggsHUT0Ok0/oFl29ulnsLlGrz9ZJjRc8WTaHMV8i6fRvPQm1Bo/8l
# f7ix+xQlq2J6CjBprKqdl0SocZ2IAujCQEtWGJgE/g8hTOWhg8kMGKErp7LtnbsM
# PdauWS0ORyr4fffZ42Lmozu+g6s+sdEpHm1ykGZxqFSecqBiZxsEl52hpSjt3CMJ
# /KZQGAcHEUNTV6ZqwfTmOwE0KQwFKNyscTCCBYMwggNroAMCAQICDkXmuwODM8OF
# ZUjm/0VRMA0GCSqGSIb3DQEBDAUAMEwxIDAeBgNVBAsTF0dsb2JhbFNpZ24gUm9v
# dCBDQSAtIFI2MRMwEQYDVQQKEwpHbG9iYWxTaWduMRMwEQYDVQQDEwpHbG9iYWxT
# aWduMB4XDTE0MTIxMDAwMDAwMFoXDTM0MTIxMDAwMDAwMFowTDEgMB4GA1UECxMX
# R2xvYmFsU2lnbiBSb290IENBIC0gUjYxEzARBgNVBAoTCkdsb2JhbFNpZ24xEzAR
# BgNVBAMTCkdsb2JhbFNpZ24wggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoIC
# AQCVB+hzymb57BTKezz3DQjxtEULLIK0SMbrWzyug7hBkjMUpG9/6SrMxrCIa8W2
# idHGsv8UzlEUIexK3RtaxtaH7k06FQbtZGYLkoDKRN5zlE7zp4l/T3hjCMgSUG1C
# Zi9NuXkoTVIaihqAtxmBDn7EirxkTCEcQ2jXPTyKxbJm1ZCatzEGxb7ibTIGph75
# ueuqo7i/voJjUNDwGInf5A959eqiHyrScC5757yTu21T4kh8jBAHOP9msndhfuDq
# jDyqtKT285VKEgdt/Yyyic/QoGF3yFh0sNQjOvddOsqi250J3l1ELZDxgc1Xkvp+
# vFAEYzTfa5MYvms2sjnkrCQ2t/DvthwTV5O23rL44oW3c6K4NapF8uCdNqFvVIrx
# clZuLojFUUJEFZTuo8U4lptOTloLR/MGNkl3MLxxN+Wm7CEIdfzmYRY/d9XZkZeE
# CmzUAk10wBTt/Tn7g/JeFKEEsAvp/u6P4W4LsgizYWYJarEGOmWWWcDwNf3J2iiN
# GhGHcIEKqJp1HZ46hgUAntuA1iX53AWeJ1lMdjlb6vmlodiDD9H/3zAR+YXPM0j1
# ym1kFCx6WE/TSwhJxZVkGmMOeT31s4zKWK2cQkV5bg6HGVxUsWW2v4yb3BPpDW+4
# LtxnbsmLEbWEFIoAGXCDeZGXkdQaJ783HjIH2BRjPChMrwIDAQABo2MwYTAOBgNV
# HQ8BAf8EBAMCAQYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4EFgQUrmwFo5MT4qLn
# 4tcc1sfwf8hnU6AwHwYDVR0jBBgwFoAUrmwFo5MT4qLn4tcc1sfwf8hnU6AwDQYJ
# KoZIhvcNAQEMBQADggIBAIMl7ejR/ZVSzZ7ABKCRaeZc0ITe3K2iT+hHeNZlmKlb
# qDyHfAKK0W63FnPmX8BUmNV0vsHN4hGRrSMYPd3hckSWtJVewHuOmXgWQxNWV7Oi
# szu1d9xAcqyj65s1PrEIIaHnxEM3eTK+teecLEy8QymZjjDTrCHg4x362AczdlQA
# Iiq5TSAucGja5VP8g1zTnfL/RAxEZvLS471GABptArolXY2hMVHdVEYcTduZlu8a
# HARcphXveOB5/l3bPqpMVf2aFalv4ab733Aw6cPuQkbtwpMFifp9Y3s/0HGBfADo
# mK4OeDTDJfuvCp8ga907E48SjOJBGkh6c6B3ace2XH+CyB7+WBsoK6hsrV5twAXS
# e7frgP4lN/4Cm2isQl3D7vXM3PBQddI2aZzmewTfbgZptt4KCUhZh+t7FGB6ZKpp
# Q++Rx0zsGN1s71MtjJnhXvJyPs9UyL1n7KQPTEX/07kwIwdMjxC/hpbZmVq0mVcc
# pMy7FYlTuiwFD+TEnhmxGDTVTJ267fcfrySVBHioA7vugeXaX3yLSqGQdCWnsz5L
# yCxWvcfI7zjiXJLwefechLp0LWEBIH5+0fJPB1lfiy1DUutGDJTh9WZHeXfVVFsf
# rSQ3y0VaTqBESMjYsJnFFYQJ9tZJScBluOYacW6gqPGC6EU+bNYC1wpngwVayaQQ
# MIIGWTCCBEGgAwIBAgINAewckkDe/S5AXXxHdDANBgkqhkiG9w0BAQwFADBMMSAw
# HgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSNjETMBEGA1UEChMKR2xvYmFs
# U2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjAeFw0xODA2MjAwMDAwMDBaFw0zNDEy
# MTAwMDAwMDBaMFsxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52
# LXNhMTEwLwYDVQQDEyhHbG9iYWxTaWduIFRpbWVzdGFtcGluZyBDQSAtIFNIQTM4
# NCAtIEc0MIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA8ALiMCP64Bvh
# mnSzr3WDX6lHUsdhOmN8OSN5bXT8MeR0EhmW+s4nYluuB4on7lejxDXtszTHrMMM
# 64BmbdEoSsEsu7lw8nKujPeZWl12rr9EqHxBJI6PusVP/zZBq6ct/XhOQ4j+kxkX
# 2e4xz7yKO25qxIjw7pf23PMYoEuZHA6HpybhiMmg5ZninvScTD9dW+y279Jlz0UL
# VD2xVFMHi5luuFSZiqgxkjvyen38DljfgWrhsGweZYIq1CHHlP5CljvxC7F/f0aY
# Doc9emXr0VapLr37WD21hfpTmU1bdO1yS6INgjcZDNCr6lrB7w/Vmbk/9E818ZwP
# 0zcTUtklNO2W7/hn6gi+j0l6/5Cx1PcpFdf5DV3Wh0MedMRwKLSAe70qm7uE4Q6s
# bw25tfZtVv6KHQk+JA5nJsf8sg2glLCylMx75mf+pliy1NhBEsFV/W6RxbuxTAhL
# ntRCBm8bGNU26mSuzv31BebiZtAOBSGssREGIxnk+wU0ROoIrp1JZxGLguWtWoan
# Zv0zAwHemSX5cW7pnF0CTGA8zwKPAf1y7pLxpxLeQhJN7Kkm5XcCrA5XDAnRYZ4m
# iPzIsk3bZPBFn7rBP1Sj2HYClWxqjcoiXPYMBOMp+kuwHNM3dITZHWarNHOPHn18
# XpbWPRmwl+qMUJFtr1eGfhA3HWsaFN8CAwEAAaOCASkwggElMA4GA1UdDwEB/wQE
# AwIBhjASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQWBBTqFsZp5+PLV0U5M6Tw
# QL7Qw71lljAfBgNVHSMEGDAWgBSubAWjkxPioufi1xzWx/B/yGdToDA+BggrBgEF
# BQcBAQQyMDAwLgYIKwYBBQUHMAGGImh0dHA6Ly9vY3NwMi5nbG9iYWxzaWduLmNv
# bS9yb290cjYwNgYDVR0fBC8wLTAroCmgJ4YlaHR0cDovL2NybC5nbG9iYWxzaWdu
# LmNvbS9yb290LXI2LmNybDBHBgNVHSAEQDA+MDwGBFUdIAAwNDAyBggrBgEFBQcC
# ARYmaHR0cHM6Ly93d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wDQYJKoZI
# hvcNAQEMBQADggIBAH/iiNlXZytCX4GnCQu6xLsoGFbWTL/bGwdwxvsLCa0AOmAz
# HznGFmsZQEklCB7km/fWpA2PHpbyhqIX3kG/T+G8q83uwCOMxoX+SxUk+RhE7B/C
# pKzQss/swlZlHb1/9t6CyLefYdO1RkiYlwJnehaVSttixtCzAsw0SEVV3ezpSp9e
# FO1yEHF2cNIPlvPqN1eUkRiv3I2ZOBlYwqmhfqJuFSbqtPl/KufnSGRpL9KaoXL2
# 9yRLdFp9coY1swJXH4uc/LusTN763lNMg/0SsbZJVU91naxvSsguarnKiMMSME6y
# CHOfXqHWmc7pfUuWLMwWaxjN5Fk3hgks4kXWss1ugnWl2o0et1sviC49ffHykTAF
# nM57fKDFrK9RBvARxx0wxVFWYOh8lT0i49UKJFMnl4D6SIknLHniPOWbHuOqhIKJ
# PsBK9SH+YhDtHTD89szqSCd8i3VCf2vL86VrlR8EWDQKie2CUOTRe6jJ5r5IqitV
# 2Y23JSAOG1Gg1GOqg+pscmFKyfpDxMZXxZ22PLCLsLkcMe+97xTYFEBsIB3CLegL
# xo1tjLZx7VIh/j72n585Gq6s0i96ILH0rKod4i0UnfqWah3GPMrz2Ry/U02kR1l8
# lcRDQfkl4iwQfoH5DZSnffK1CfXYYHJAUJUg1ENEvvqglecgWbZ4xqRqqiKbMIIG
# aDCCBFCgAwIBAgIQAUiQPcKKvKehGU0MHFe4KTANBgkqhkiG9w0BAQsFADBbMQsw
# CQYDVQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTExMC8GA1UEAxMo
# R2xvYmFsU2lnbiBUaW1lc3RhbXBpbmcgQ0EgLSBTSEEzODQgLSBHNDAeFw0yMjA0
# MDYwNzQxNThaFw0zMzA1MDgwNzQxNThaMGMxCzAJBgNVBAYTAkJFMRkwFwYDVQQK
# DBBHbG9iYWxTaWduIG52LXNhMTkwNwYDVQQDDDBHbG9iYWxzaWduIFRTQSBmb3Ig
# TVMgQXV0aGVudGljb2RlIEFkdmFuY2VkIC0gRzQwggGiMA0GCSqGSIb3DQEBAQUA
# A4IBjwAwggGKAoIBgQDCydwDthtQ+ioN6JykIdsopx31gLUSdCP+Xi/DGl2WsiAZ
# GVBfdiMmNcYh7JTvtaI6xZCBmyHvCyek4xdkO9qT1FYvPNdY+W2swC+QeCNJwPjB
# j3AT1GvfJohadntI9+Gkpu8LGvMlVA+AniMSEhPRsPcC4ysN/0A+AEJD3hrvTPSH
# qfKePNAG5+Jj0utMW91dWJTT5aU5KKoHXnYjMPz8f5gNxWVtG9V0RTpGsKIWdd6i
# wipwfLZ2vNkbrrpdnPaHlc6qqOK1o7GTbkClmxCIdhZONKH8nvHhGlTRyCRXlHat
# wsfso6OWdeLGKGsCBehLubXgUit4AYwqMSxM6AXlb58PhCYuaGz6y00ZfBjB/2oa
# qcu+o3X46cgYsszdL0FAIBzPiAsXybCKQ8via5NR8RG+Qrz4UfLaAAK+CBgoBSfE
# 3DtddykeGdRBKmZ9tFJzXEKlkNONxaOqN85zAZQkGUJD0ZSPS37dy228G057+aoL
# IktJgElwGy1P3jRgPr0CAwEAAaOCAZ4wggGaMA4GA1UdDwEB/wQEAwIHgDAWBgNV
# HSUBAf8EDDAKBggrBgEFBQcDCDAdBgNVHQ4EFgQUW2t79HB0CMENKsjv8cS5QNJK
# xv0wTAYDVR0gBEUwQzBBBgkrBgEEAaAyAR4wNDAyBggrBgEFBQcCARYmaHR0cHM6
# Ly93d3cuZ2xvYmFsc2lnbi5jb20vcmVwb3NpdG9yeS8wDAYDVR0TAQH/BAIwADCB
# kAYIKwYBBQUHAQEEgYMwgYAwOQYIKwYBBQUHMAGGLWh0dHA6Ly9vY3NwLmdsb2Jh
# bHNpZ24uY29tL2NhL2dzdHNhY2FzaGEzODRnNDBDBggrBgEFBQcwAoY3aHR0cDov
# L3NlY3VyZS5nbG9iYWxzaWduLmNvbS9jYWNlcnQvZ3N0c2FjYXNoYTM4NGc0LmNy
# dDAfBgNVHSMEGDAWgBTqFsZp5+PLV0U5M6TwQL7Qw71lljBBBgNVHR8EOjA4MDag
# NKAyhjBodHRwOi8vY3JsLmdsb2JhbHNpZ24uY29tL2NhL2dzdHNhY2FzaGEzODRn
# NC5jcmwwDQYJKoZIhvcNAQELBQADggIBAC5rPo9/sLBg2fGdhNyVtt9fDb8kUeMa
# BqpVBMthwe9lca4L/ZQkVwDH5PYMvBiVfS8ZamAzpr7QCFVWBLbj/h675RB2VDur
# XCFeKjVNRsumTLoEQGBgLNvT9p3eyjIQDHiwu1bFB0twvKcPq3K8jcvr7sFMa9n6
# mKF0PumoyHl8dndI/c/j8A3B6cOS4AcMEy8/a3812dW37m98WMDxPwwZsgKjSUyc
# BMPwtJen4E1qJbo0FmJmyHi8aXOqX3KiNVgeJuu/MhSqEnrr9JZrf3Ks6qc5CDMB
# Nj5hJH4RnREediJU40C7LoYMdp5p0sQcPaILjIgEA1Te6RsX/iwrntnWWyI4/GRA
# hs0Xf+Gpn7m/kkGobyZq9A8osECRkC9OtnZQvE0j2X9Pa5Mpp2zn0DA+qZMfwlAr
# OcWy+E0nJNH9dti++ZP0qVQK1XZY0Tye6hroJMT7NvEvWdOSw+zLYFIeHEYlCP9+
# 2ZOuFJWohooHLlSLc0w3FThQVofxT64cj8mhbC8L/Lscby29qrbraCPw7ZQnFGPL
# rPRniiyB0xQSGAE/hHqu7EdgP2hYmclKwqGZFQXCrd6i79enVXy8hBtNlLuOSoVE
# 2YE9qqMlVV+ka802bAD5/3LeWuz/yaBBlhpAaoWRHK91Y6jLWjO1lDN+so0Pc76H
# /K86cx97INtyMYIFSzCCBUcCAQEwYjBaMQswCQYDVQQGEwJVUzEYMBYGA1UEChMP
# VS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEVMBMG
# A1UEAxMMRE9EIElEIENBLTU5AgQBG1VrMA0GCWCGSAFlAwQCAQUAoEwwGQYJKoZI
# hvcNAQkDMQwGCisGAQQBgjcCAQQwLwYJKoZIhvcNAQkEMSIEIKHrjxvtRQOb1oTW
# 9ADCiy2gS+/AXaUzJpZfpZnl7peeMA0GCSqGSIb3DQEBAQUABIIBAIrBL0MdcO/D
# hnX38Z3eQZ5RxKGEWgYpv5OC2V/FsgbMRrtYVkuNSzURuB31Wm3n7bKEByKYWMmc
# SjVxL6ExqimUiFeEaBH09xBvyEYozAHZfz1a4Ad6e3cRZccOQULqths6fR/hemxs
# qY9dQMKYugxVtMc/DVYb4N+yTUK4+C2tlXb8mCdbtmWLAzYvRzwrDuXHeLDdBr5N
# 1XpnmllYq9DBdlRYRFwk6TeJhoGcYr1q7s+3misuIMN0cH7aGGhe12dzP0RwQAw6
# b37PPKoKUFdLwNTcU6qujKYnKqjM96hWmp8CVzwz0ncpMyuTIzj7pGNOyvQrntcS
# Uz/1vTl87rKhggNsMIIDaAYJKoZIhvcNAQkGMYIDWTCCA1UCAQEwbzBbMQswCQYD
# VQQGEwJCRTEZMBcGA1UEChMQR2xvYmFsU2lnbiBudi1zYTExMC8GA1UEAxMoR2xv
# YmFsU2lnbiBUaW1lc3RhbXBpbmcgQ0EgLSBTSEEzODQgLSBHNAIQAUiQPcKKvKeh
# GU0MHFe4KTALBglghkgBZQMEAgGgggE9MBgGCSqGSIb3DQEJAzELBgkqhkiG9w0B
# BwEwHAYJKoZIhvcNAQkFMQ8XDTIzMDMwNzE4MjY1MFowKwYJKoZIhvcNAQk0MR4w
# HDALBglghkgBZQMEAgGhDQYJKoZIhvcNAQELBQAwLwYJKoZIhvcNAQkEMSIEIN0G
# zfCkGlKWGhLRk6XZU2uP7LA3/eGk2PlkQZeCuKTSMIGkBgsqhkiG9w0BCRACDDGB
# lDCBkTCBjjCBiwQUMQMOF2qkWS6rLIut6DKZ/LVYXc8wczBfpF0wWzELMAkGA1UE
# BhMCQkUxGTAXBgNVBAoTEEdsb2JhbFNpZ24gbnYtc2ExMTAvBgNVBAMTKEdsb2Jh
# bFNpZ24gVGltZXN0YW1waW5nIENBIC0gU0hBMzg0IC0gRzQCEAFIkD3CirynoRlN
# DBxXuCkwDQYJKoZIhvcNAQELBQAEggGAje5n05vpU3SNPnkuJu3VPIdVIgFmTX6L
# dVvnZhD7i+YRFVd5W85z0n5mQrED92KtLeOFaEROlUEyI5KqW4E/OE03v71Q8cGm
# MASD6LzE301a0ktjUDZS15EW1Rfslf2il78wNZk3gvUBNoqSthiREddB3xkDah9A
# TRkbP3dby2QlSvDWDPdrpg+0kGPQ66f3+eb1sfOnyGZBFABy++pdnOzf8clRAwM0
# Y9Z/c6o9uori6Iq+Kf46y4IszYRyRkCH34ptV46YKgGK0tIJfbb4XuXv4uYWEkvw
# PsXbBBnFW/UeZBmoevQgF8TFN4aq035A9Y1dIXDV69U5JFZQyo4bl5NhDhiVH8Vl
# ny78kQlnDejc8yDPenIttx4Qb85lUjMQwLZ9MWihtJVc5Nothj/sfH273FQtRdUm
# nqhwrzJBN8iJEJzKS3vSpEdZHFLsOdQ5tum1FOTxXMmPP/1RZ4ng1I6siUrc329t
# SkFqQxn61AuDb+fLUkzeqac0S8IF+zQY
# SIG # End signature block
