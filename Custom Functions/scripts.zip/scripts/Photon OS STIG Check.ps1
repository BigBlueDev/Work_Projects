﻿#PURPOSE: Perform a STIG check on VMs running Photon OS

#CHANGELOG
#Version 1.0 - 04/09/24 - MDR - Created based off Photon STIG Check

Param ( $ChecklistFilePath, $CurrentSystemName, $STIGParams )

#Check the PhotonOS version number
$PhotonOSVersionInfo = (Invoke-SSHCommand -SessionId 0 -Command "cat /etc/photon-release" -Timeout 300).Output
$PhotonOSVersionSplit = $PhotonOSVersionInfo[0].Split(" ")
$PhotonOSVersion = $PhotonOSVersionSplit[$PhotonOSVersionSplit.Count - 1]

#Create an XML object
$Checklist_XMLObject = New-Object XML
#This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
$Checklist_XMLObject.PreserveWhitespace = $true
#This is the name of the empty checklist template file
$Checklist_XMLObject.Load("$ChecklistFilePath")

#Check to see if the provided name is different from the VM name
$VMNameMismatchCheck = $VMNameMismatches | Where { $_.ProvidedName -eq $CurrentSystemName }

#If there isn't a mismatch then look up the VM by the provided name
If ($VMNameMismatchCheck -eq $null) {
    $PhotonGuestView = (Get-VM $CurrentSystemName | Get-View).Guest
    $PhotonMacAddr = (Get-VM $CurrentSystemName | Get-NetworkAdapter).MacAddress
} Else { #If there is a mismatch then look up the VM by the actual VM name
    $PhotonGuestView = (Get-VM $VMNameMismatchCheck.ActualName | Get-View).Guest
    $PhotonMacAddr = (Get-VM $VMNameMismatchCheck.ActualName | Get-NetworkAdapter).MacAddress
}

#Depending on whether VMware Tools has info then add the best info available
If ($PhotonGuestView.HostName) {
    #If the HostName doesn't have any "." in it then it is just a short name and needs the domain name added to it
    If ($PhotonGuestView.HostName.Split(".").Count -le 1) {
        $PhotonHostName = $PhotonGuestView.IpStack[0].DnsConfig.HostName + "." + $PhotonGuestView.IpStack[0].DnsConfig.DomainName
    } Else { #Otherwise the HostName is the FQDN and can be used
        $PhotonHostName = $PhotonGuestView.HostName
    }

    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$($PhotonHostName.Split("."))[0]
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$PhotonHostName
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = [String]$($PhotonGuestView.IPAddress)
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = [String]$PhotonMacAddr
} Else { #Only use this if VMware Tools can't pull the proper information
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_NAME = [String]$($CurrentSystemName.Split("."))[0]
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_FQDN = [String]$CurrentSystemName
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_IP = ""
    $Checklist_XMLObject.CHECKLIST.ASSET.HOST_MAC = ""
}

$Global:VULN_DATA = $Checklist_XMLObject.CHECKLIST.STIGS.iSTIG.VULN

ForEach ($Global:VULN in $VULN_DATA) {
    #$SystemSettingValue
    #$Counter--
    #$VULN = $VULN_DATA[$Counter]
    [System.Windows.Forms.Application]::DoEvents()

    $Vuln_Num = ($VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq 'Vuln_Num' }).ATTRIBUTE_DATA
    #Collecting Severity for reporting purposes later in the script
    $Severity = ($VULN.STIG_DATA | Where {$_.VULN_ATTRIBUTE -eq 'Severity'}).ATTRIBUTE_DATA

    #Pull the VCode number based on the version of Photon being scanned
    If ($PhotonOSVersion -eq "3.0") {
        $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num_V3 -eq $Vuln_Num }
    } ElseIf ($PhotonOSVersion -eq "4.0") {
        $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num_V4 -eq $Vuln_Num }
    } ElseIf ($PhotonOSVersion -eq "5.0") {
        $VCodeObjectSTIGData = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num_V5 -eq $Vuln_Num }
    } Else {
        Break
    }

    #Clear
    #Write-Host "$Counter - $Vuln_Num - $($VCodeObjectSTIGData.Check_Name)"

    #If there is a line in $STIGParams for the V-Code in this checklist
    If (!($VCodeObjectSTIGData)) {
        $VULN.COMMENTS = "No entry existed in the STIG parameters file for this V-Code"

        If ($NoSTIGParamList -notcontains $Vuln_Num) {
            $NoSTIGParamList += $Vuln_Num
        }
    } Else {
        Clear-Variable CustomComment, FindingHint, SystemSettingValue -ErrorAction SilentlyContinue

        #If this has multiple checks then don't attempt to run what is in Check_Param
        If ($VCodeObjectSTIGData.Check_Method -ne "MultipleChecks") {
            $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command $VCodeObjectSTIGData.Check_Param -Timeout 300).Output
            #Remove any commented out items
            $SystemSettingValue = $SystemSettingValue | Where { $_ -notlike "#*" }
        }

        If ($VCodeObjectSTIGData.Check_Method -eq "SSHCheck" -or $VCodeObjectSTIGData.Check_Method -eq "AuditCheck") {
            If ($VCodeObjectSTIGData.Check_Method -eq "AuditCheck") {
                $SystemSettingValue = $SystemSettingValue.Replace("-1","4294967295")
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Remove all software components after update") {
                #This value can be 1, yes, or true.  Just make sure if it matches any of those it comes back as true
                $SystemSettingValue = $SystemSettingValue.Replace("=1","=true")
                $SystemSettingValue = $SystemSettingValue.Replace("=yes","=true")
            }

            If ($VCodeObjectSTIGData.Expected_Value -eq "BLANK") {
                $VCodeObjectSTIGData.Expected_Value = ""
            }

            $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value -Split "`n"

            If ($SystemSettingValue -ne $Null) {
                $ComparisonResult = Compare-Object $SystemSettingValue $ExpectedValueSplit
            }

            #This finding allows excess items to show up as long as all of the Expected_Values are included
            If ($VCodeObjectSTIGData.Check_Name -eq "Disable loading unnecessary kernel modules") {
                $ComparisonResult = $ComparisonResult | Where { $_.SideIndicator -ne "<=" }
            #This finding allows excess items to show up as long as all of the SystemSettingValues are included
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Configure auditd to keep logging") {
                $ComparisonResult = $ComparisonResult | Where { $_.SideIndicator -ne "=>" }
            }

            If ($VCodeObjectSTIGData.Expected_Value -eq "NOT BLANK" -and $SystemSettingValue -ne "") {
                $FindingHint = "NF"
            } ElseIf ($ComparisonResult -eq $null) {
                $FindingHint = "NF"
            } ElseIf ($VCodeObjectSTIGData.Expected_Value -eq ($SystemSettingValue -replace '\s+',' ')) {
                #This removes excessive spaces from SystemSetttingValue and reduces it to just one space
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SSHCheckContains") {
            If ($SystemSettingValue -like "$($VCodeObjectSTIGData.Expected_Value)*") {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "ServiceCheck") {
            #Split the Expected_Value into [0] as Active value and [1] as Loaded value
            $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value.Split(" ")

            #Get the Loaded and Active values for the service
            $ServiceLoadedInfo = $SystemSettingValue | Where { $_ -like "*Loaded:*" }
            $ServiceActiveInfo = $SystemSettingValue | Where { $_ -like "*Active:*" }

            If ($ServiceActiveInfo -like "*$($ExpectedValueSplit[0])*" -and ($ExpectedValueSplit[1] -eq "na" -or $ServiceLoadedInfo -like "*$($ExpectedValueSplit[1])*")) {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "OwnershipCheck") {
            #Start off with the OwnershipMatch being true
            $OwnershipMatch = "True"

            #Split the ExpectedValue by line breaks
            $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value -Split "`n"

            #Loop through each item being analyzed
            ForEach ($ItemInfo in $SystemSettingValue) {
                #Split it into Path, Owner, Group Owner, and CHMOD
                $ItemInfoSplit = $ItemInfo.Split(" ")

                #If there is a path defined for the expected value
                If ($VCodeObjectSTIGData.Expected_Value.Substring(0,2) -ne "na") {
                    #Find the Expected Value that has the same Path as this item
                    $ItemExpectedValue = $ExpectedValueSplit | Where { $_ -like "$($ItemInfoSplit[0])*" }
                } Else { #If the path is "na"
                    $ItemExpectedValue = $VCodeObjectSTIGData.Expected_Value
                }

                #If for some reason there is no expected entry for this path then mark this as a finding
                If ($ItemExpectedValue -eq $null) {
                    $OwnershipMatch = "False"
                } Else {
                    #Split the expected value into Path, Owner, Group Owner, and CHMOD
                    $ItemExpectedValueSplit = $ItemExpectedValue.Split(" ")

                    #Check to see if the Owner matches
                    If ($ItemExpectedValueSplit[1] -ne "na" -and $ItemExpectedValueSplit[1] -ne $ItemInfoSplit[1]) {
                        $OwnershipMatch = "False"
                    }

                    #Check to see if the Group Owner matches
                    If ($ItemExpectedValueSplit[2] -ne "na" -and $ItemExpectedValueSplit[2] -ne $ItemInfoSplit[2]) {
                        $OwnershipMatch = "False"
                    }

                    #Check to see if the CHMOD permissions matches
                    If ($ItemExpectedValueSplit[3] -ne "na" -and $ItemExpectedValueSplit[3] -ne $ItemInfoSplit[3]) {
                        $OwnershipMatch = "False"
                    }
                }
            }

            If ($OwnershipMatch -eq "True") {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SubstringCheckContents") {
            #Since we're looking at a substring, need to split the full setting value into pieces so we can find the piece we're looking for
            $SystemSettingValueSplit = $SystemSettingValue.Split(" ")
            #There can be multiple expected values so split this by line breaks
            $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value -Split "`n"

            #Split to find out which line has to include which value
            $ExpectedIncludes = $ExpectedValueSplit[0] -split " INCLUDES "

            #If it is expected for pam_pwhistory.so to include use_authtok then see if that line exists
            $ExpectedValueLine = $SystemSettingValue | Where { $_ -like "*$($ExpectedIncludes[0])*$($ExpectedIncludes[1])*" }

            #If there is an expected value to evaluate and the number of lines in the expected value is more than 1 meaning there is a NOT line
            If ($ExpectedValueLine -ne $null -and $ExpectedValueSplit.count -gt 1) {
                #Remove the word NOT from this expected value
                $ExpectedValueSplit[1] = $ExpectedValueSplit[1] -replace "NOT ",""
                #Split to find out which line has to include which value
                $ExpectedNotIncludes = $ExpectedValueSplit[1] -split " OR "

                #Loop through each value that shouldn't exist
                ForEach ($NotIncludedValue in $ExpectedNotIncludes) {
                    #If one of the not included values exists then mark this as a finding
                    If ($ExpectedValueLine | Where { $_ -like "* $NotIncludedValue *" }) {
                        $FindingHint = "O"
                    }
                }

                #If the finding didn't get marked as open then mark it as NF
                If ($FindingHint -ne "O") {
                    $FindingHint = "NF"
                }
            } Else {
                #If there is an expected line value that includes all of the necessary items mark as NF
                If ($ExpectedValueLine -ne $null) {
                    $FindingHint = "NF"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -like "SubstringCheck*") {
            #Since we're looking at a substring, need to split the full setting value into pieces so we can find the piece we're looking for
            $SystemSettingValueSplit = $SystemSettingValue.Split(" ")
            #There can be multiple expected values so split this by line breaks
            $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value -Split "`n"

            #Set the initial value as a match
            $StringMatch = "True"

            #Loops through all of the expected values
            ForEach ($ExpectedValue in $ExpectedValueSplit) {
                #If this is a greater than or less than sort of comparison
                If ($ExpectedValue -like "*>=*" -or $ExpectedValue -like "*<=*") {
                    #Split the expected value into three pieces.  [0] will be the name, [1] will be gt or lt, [2] is the value
                    $ExpectedValueSplit = $ExpectedValue.Split(" ")
                    #Find the portion of the system value that matches the name of the expected value we're looking for
                    $SystemSettingMatch = $SystemSettingValueSplit | Where { $_ -like "$($ExpectedValueSplit[0])*" }

                    #If there is a setting to attempt to match then split it by "="
                    If ($SystemSettingMatch -ne $null -and $VCodeObjectSTIGData.Check_Method -ne "SubstringCheckNoEqual") {
                        #Split the matching system value by = so [0] is the name and [1] is the value
                        $SystemSettingValue = ($SystemSettingMatch.Split("="))[1]
                    } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "SubstringCheckNoEqual") { #If the system setting is something like "PASS_MAX_DAYS   90" which has no equal sign separating the setting and value 
                        #Pick the last item from when the value was split by " " as the value to use in the comparison to the ExpectedValue
                        $SystemSettingValue = $SystemSettingValueSplit[$SystemSettingValueSplit.Count - 1]
                    }

                    #If we're trying to confirm the value is less than or equal to
                    If ($ExpectedValueSplit[1] -eq "<=") {
                        #If it is greater than then this is bad
                        If ($ExpectedValueSplit[2] -gt $SystemSettingValue) {
                            $StringMatch = "False"
                        }
                    } ElseIf ($ExpectedValueSplit[1] -eq ">=") { #If we're trying to confirm the value is greater than or equal to
                        #If it is less than then this is bad
                        If ($ExpectedValueSplit[2] -lt $SystemSettingValue) {
                            $StringMatch = "False"
                        }
                    }
                } Else { #If this is NOT a greater than or equal to comparison
                    $UnmatchedValues = $SystemSettingValue | Where { $_ -notlike "*$ExpectedValue*" }
                    
                    If ($VCodeObjectSTIGData.Check_Method -eq "SubstringCheckSingleMatch") { #If even a single match is found
                        $MatchedValues = $SystemSettingValue | Where { $_ -like "*$ExpectedValue*" }

                        If ($MatchedValues -eq $null) {
                            $StringMatch = "False"
                        }
                    } ElseIf ($UnmatchedValues -ne $null) { #If there were values that didn't match
                        $StringMatch = "False"
                    }
                }
            }

            If ($StringMatch -eq "True") {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "OpenSSHVersion") {
            #Start with the assumption the OpenSSH version is good
            $OpenSSHVersionGood = "True"

            #Convert to a string so I can get a length check
            [String]$ExpectedValueString = $VCodeObjectSTIGData.Expected_Value
            #Find the length of the version number being looked at
            $VersionNumberLength = $ExpectedValueString.Length

            #Loop through each OpenSSH version
            ForEach ($SystemSetting in $SystemSettingValue) {
                #Split by "-"
                $SystemSettingSplit = $SystemSetting.Split("-")

                #Loop through each portion of the version string
                ForEach ($OpenSSHVersion in $SystemSettingSplit) {
                    #If the first character if this string is a number then it is the version portion of the string
                    If ($OpenSSHVersion[0] -match "^\d+$") {
                        #If the OpenSSH version is less than the expected value then that is bad
                        If ([Version]$OpenSSHVersion.Substring(0,$VersionNumberLength) -lt [Version]$VCodeObjectSTIGData.Expected_Value) {
                            $OpenSSHVersionGood = "False"
                        }
                        #Exit the ForEach loop since the version number has been compared already
                        Break
                    }
                }
            }

            If ($OpenSSHVersionGood -eq "True") {
                $FindingHint = "NF"
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "MultipleChecks") {
            If ($VCodeObjectSTIGData.Check_Name -eq "Audit the execution of privileged functions") {
                #Store a list of mismatched UIDs
                $MismatchedUIDs = @()

                $SetUIDList = (Invoke-SSHCommand -SessionId 0 -Command "find / -xdev -path /var/lib/containerd -prune -o \( -perm -4000 -type f -o -perm -2000 \) -type f -print | sort" -Timeout 300).Output

                ForEach ($SetUIDItem in $SetUIDList) {
                    $SetUIDValue = (Invoke-SSHCommand -SessionId 0 -Command "auditctl -l | grep $SetUIDItem" -Timeout 300).Output

                    #Verify that when looking for things like "/usr/bin/su" that "/usr/bin/sudo" doesn't also get added
                    $SetUIDValue = $SetUIDValue | Where { $_ -like "* path=$SetUIDItem *" }

                    #Check if $SetUIDValue 
                    If ($SetUIDValue -ne $null) {
                        #Replace any instances of 4294967295 with -1
                       $SetUIDValue = $SetUIDValue.Replace("4294967295","-1")
                    }

                    $ExpectedValue = "-a always,exit -S all -F path=$SetUIDItem -F perm=x -F auid>=1000 -F auid!=-1 -F key=privileged"

                    If ($SetUIDValue -ne $ExpectedValue) {
                        $MismatchedUIDs += $SetUIDItem
                    }
                }

                #If there are no mismatches
                If ($MismatchedUIDs.Count -eq 0) {
                    $SystemSettingValue = $SetUIDList
                    $FindingHint = "NF"
                } Else { #If there are mismatches
                    $SystemSettingValue = "The following UIDs did not match the expected value:`n`n$MismatchedUIDs"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Require users to reauthenticate for escalation") {
                $Sudoers = (Invoke-SSHCommand -SessionId 0 -Command "grep -ihs nopasswd /etc/sudoers /etc/sudoers.d/*|grep -v '^#'|grep -v '^%'|awk '{print $1}'" -Timeout 300).Output

                $SUDOList = @()

                ForEach ($Sudoer in $Sudoers) {
                    $PreTabFilter = ($Sudoer.Split(" "))[0]
                    #Content-Library for some reason needs to split by tab as well
                    $SUDOList += ($PreTabFilter.Split("`t"))[0]
                }

                #Find only unique versions of users
                $SUDOList = $SUDOList | Select -Unique

                $OtherUsers = (Invoke-SSHCommand -SessionId 0 -Command "awk -F: '($2 != 'x' && $2 != '!') {print $1}' /etc/shadow" -Timeout 300).Output

                #If OtherUsers is blank then it is safe to assume this isn't a finding
                If ($OtherUsers[0] -eq "") {
                    $FindingHint = "NF"
                } Else { #Otherwise this is a manual check for now since I don't know how to code the check yet
                    $SystemSettingValue = "The following users were found:`n`n$($SUDOList -join ""`n"")`n`nIf none of the users listed here are listed in the next output then this is NF:`n`n$OtherUsers"
                    $FindingHint = "Manual"
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Configure to synchronize with a DOD time source") {
                #Get the NTP configuration
                $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command "grep -E '^\s*(server|peer|multicastclient)' /etc/ntp.conf" -Timeout 300).Output

                #If the NTP config is null then this is a finding, but if it's not then continue the check
                If ($SystemSettingValue -ne $null) {
                    $CustomComment = "The code for this finding hasn't been written yet.  Please update the code for this finding - $SystemSettingValue"

                    #If timesyncd is used to sync time, do the following
                    #$SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command "grep '^NTP' /etc/systemd/timesyncd.conf" -Timeout 300).Output

                    #If chrony is used to sync time, do the following:
                    #$SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command "grep '^server' /etc/chrony/chrony.conf" -Timeout 300).Output
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Configure AIDE to detect changes to baseline configurations") {
                #Check the AIDE configuration
                $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command "grep -v '^#' /etc/aide.conf | grep -v '^$'" -Timeout 300).Output

                $AIDEConfig = "STIG = p+i+n+u+g+s+m+S`nLOGS = p+n+u+g`n/boot   STIG`n/opt    STIG`n/usr    STIG`n/etc    STIG`n/var/log   LOGS"

                #If the NTP config is null then this is a finding, but if it's not then continue the check
                If ($SystemSettingValue -ne $null) {
                    $CustomComment = "The code for this finding hasn't been written yet.  Please update the code for this finding"

                    #$SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command "aide --check" -Timeout 300).Output
                }
            } ElseIf ($VCodeObjectSTIGData.Check_Name -eq "Enforce three invalid logons and in 15 minutes") {
                #Get the entirety of the Faillock.conf file
                $SystemSettingValue = (Invoke-SSHCommand -SessionId 0 -Command "cat /etc/security/faillock.conf" -Timeout 300).Output

                #Get the Deny value
                $DenySetting = $SystemSettingValue | Where { $_ -like "deny*" }
                #Get the FailInterval value
                $FailInterval = $SystemSettingValue | Where { $_ -like "fail_interval*" }

                #If the Deny value exists then get its exact value
                If ($DenySetting -ne $null) {
                    $DenyValue = (($DenySetting -replace " ","").Split("="))[1]
                }

                #If the Fail Interval value exists then get its exact value
                If ($FailInterval -ne $null) {
                    $FailIntervalValue = (($FailInterval -replace " ","").Split("="))[1]
                }

                #If the Deny and Fail Interval exist and Deny is less than or equal to 3 but not 0 and Fail Interval is less than or equal to 900
                If ($DenyValue -ne $null -and $FailIntervalValue -ne $null -and $DenyValue -le 3 -and $DenyValue -ne 0 -and $FailIntervalValue -ge 900) {
                    $FindingHint = "NF"
                }
            }
        } ElseIf ($VCodeObjectSTIGData.Check_Method -eq "CheckOrder") {
            $ExpectedValueSplit = $VCodeObjectSTIGData.Expected_Value -split " BEFORE "

            $BeforeItemData = $SystemSettingValue | Where { $_ -like "*$($ExpectedValueSplit[0])*" }
            $AfterItemData = $SystemSettingValue | Where { $_ -like "*$($ExpectedValueSplit[1])*" }

            If ($BeforeItemData -ne $null) {
                $BeforeItemIndexNum = $SystemSettingValue.IndexOf($BeforeItemData)
            } Else {
                #Setting it to -1 guarantees that this will be a finding
                $BeforeItemIndexNum = -1
            }

            If ($AfterItemData -ne $null) {
               $AfterItemIndexNum = $SystemSettingValue.IndexOf($AfterItemData)
            } Else {
                #Setting it to -1 guarantees that this will be a finding
                $AfterItemIndexNum = -1
            }

            #If neither Before nor After is -1 and the After number is greater than the Before number
            If ($BeforeItemIndexNum -ne "-1" -and $AfterItemIndexNum -ne "-1" -and $AfterItemIndexNum -gt $BeforeItemIndexNum) {
                $FindingHint = "NF"
            }
        }

        <#If ($FindingHint) {
            Write-Host $FindingHint
        } ElseIf ($VCodeObjectSTIGData.Expected_Value -eq $SystemSettingValue) {
            Write-Host "NF"
        } Else {
            Write-Host $SystemSettingValue
        }#>

        $parms = @{
            CorrectVal = $VCodeObjectSTIGData.Expected_Value
            ActualVal = $SystemSettingValue
            CustomComment = $CustomComment
            FindingHint = $FindingHint
            CurrentSystemName = $CurrentSystemName
        }

        Invoke-Expression -Command ("& '$FolderPathToSTIGScript\RecordToChecklist.ps1' @parms")

        If ($AltCheck -eq "True") {
            $VCodeObjectSTIGData.Expected_Value = $OrigExpectedValue
        }

        #$Counter++
    }
}

$Checklist_XMLObject.Save($ChecklistFilePath)

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAf7gB+rRrYMbJ9
# Dd/GzcNRuE7hrFoU2pAxiSDLpjw42KCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCv4n7/LhYUCBkprT7JDdFUSiFsL46EcHBebNzs9+nP0jANBgkq
# hkiG9w0BAQEFAASCAQBEqaFivkWuVjoNOFxbNWyY2lKOll4GfJxcZrQ+6Cmk+Sno
# frbFVREX0Yf+s/41bleEcrq2gOXflt/CZqVQa5hB14dvS6hUQ4H3d0WPlSjn/fti
# qSx7lHFxLtN6JACypoToYg5At+L3Nlq549vFkEHPD7ww6JOlX1ebr5wRXxQrsK5d
# uZlnfm9FEBehGmJBXZrddNShYqmUkTqugOFMmCOSOw0Uzpc7gpatEMtqi5FincgW
# r0jy91XrIb/Az6N/JGpOVQjqXY2bAWqjx+W6yDckvtA1bmUgxbP0thBW9ahu0Ubi
# Hb7qsehxjSnWU/WOplW87EDtY9HmFJfWtoWRb6Xf
# SIG # End signature block
