﻿#PURPOSE: Mitigate ESX STIGs

#CHANGELOG
#Version 1.0 - 03/26/24 - MDR - Initial version
#Version 1.01 - 05/16/24 - MDR - Added ability to update Cim Permissions
#Version 1.02 - 10/09/24 - MDR - Changed NTP to include an AltCheck
#Version 1.03 - 10/23/24 - MDR - Update to perform differently when run from Orchestrator
#Version 1.04 - 10/24/24 - MDR - Check to see if the ESX host exists before continuing on
#Version 1.05 - 10/25/24 - MDR - Making AltCheck compatible with Orchestrator
#Version 1.06 - 10/30/24 - MDR - Adding code for SSHQuery
#Version 1.07 - 10/31/24 - MDR - Adding code for sshd_config
#Version 1.08 - 10/31/24 - MDR - Corrected an issue with LockdownExceptions when doing an AltCheck
#Version 1.09 - 11/18/24 - MDR - Check whether SSH is started prior to script starting it.  If it is started already, then don't have the script start it or stop it later on

#Version 1.05 - Added the $RunFromOrchestrator parameter
Param ( $FindingsList, $STIGParam, $MitigationType, $RunFromOrchestrator, $AutoSTIGRun )

$FindingCount = $FindingsList.Count
$CurrentFinding = 1

#Version 1.03 - If this is run from Orchestrator then setup required variables
If ($AutoSTIGRun -eq "True") {
    $STIGParams = $STIGParam
    $FolderPathToSTIGScript = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR"
}

#Version 1.06 - Add the ability to connect to a server over SSH
Function ConnectSSH {
    #Get the ESX Host info and store as script level so that it can be used to disable SSH on the host later
    $Script:VMHost = Get-VMHost $FindingItem.SystemName

    #Version 1.09 - Check to see if SSH is running
    $Script:SSHServiceRunStatus = ($VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" }).Running

    #Version 1.09 - Only start the service if it isn't already running
    If ($SSHServiceRunStatus -eq $false) {
        #Start the SSH service on the host so that services.sh restart can be run later
        $VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" } | Start-VMHostService -Confirm:$false | Out-Null
    }

    #Create an SSH session to the host
    $SSHConnection = New-SSHSession -HostName $VMHost.Name -Credential $ESXSecureCreds -AcceptKey -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

    #Verify that the SSH connection succeeded
    If ($SSHConnection -eq $null) {
        Write-Host "`nFailed to SSH into $($VMHost.Name)" -ForegroundColor Red
        Continue
    }

    #Return the SSH Session ID
    Return $SSHConnection.SessionId
}

ForEach ($FindingItem in $FindingsList) {
    #Version 1.03 - Don't update the form if this is run from Orchestrator and not the GUI
    If ($AutoSTIGRun -ne "True") {
        [System.Windows.Forms.Application]::DoEvents()

        $ProgressBarMitigate.Value = ($CurrentFinding / $FindingCount) * 100
        $LabelProgressBarMitigate.Text = "$CurrentFinding out of $FindingCount - $($FindingItem.SystemName)"
    } Else { #Version 1.03 - If this is from Orchestrator, then pull the STIGParam for the VulnNumber here rather than letting the calling script do it
        $STIGParam = $STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $FindingItem.VulnNumber }
    }

    $AltCheck = "False" #If this becomes true then it will reset the Expected_Value back to what it was prior to the AltCheck script changing that value
    $MitigationSuccess = "True" #If this is true at the end then it will record the mitigation to $ListOfStatusUpdates

    #Version 1.04 - Check that the ESX Host exists first
    $ESXInfo = Get-VMHost $FindingItem.SystemName -ErrorAction SilentlyContinue
    If ($ESXInfo -eq $null) {
        Continue
    }

    If ($STIGParam.Expected_Value -like "AltCheck *") {
        $AltCheck = "True"
        $OrigExpectedValue = $STIGParam.Expected_Value

        $parms = @{
            AltCheck = $STIGParam.Expected_Value
            STIGParams = $STIGParams
            CurrentSystemName = $FindingItem.SystemName
            SystemType = "ESX"
        }

        #Version 1.05 - If this is run from Orchestrator then run the check script from a local copy rather than a network one
        If ($RunFromOrchestrator -eq "True") {
            #Run the RecordToChecklist.ps1 script from a local copy
            $STIGParam.Expected_Value = Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\AltCheck.ps1"" @parms")
        } Else {
            #Run the RecordToChecklist.ps1 script from the network
            $STIGParam.Expected_Value = Invoke-Expression -Command ("& '$FolderPathToSTIGScript\AltCheck.ps1' @parms")
        }
    }
    
    #MitigationType is either going to be Mitigate or Fixed.  Fixed means skip any mitigations and just mark it as fixed by updating $ListOfStatusUpdates
    If ($MitigationType -eq "Mitigate") {
        If ($STIGParam.Check_Method -eq "AdvancedSetting") {
            $SettingValue = $ESXInfo | Get-AdvancedSetting -Name $STIGParam.Check_Param
            
            If ($STIGParam.Check_Name -eq "Advanced Setting Syslog.global.logHost") {
                $STIGParam.Expected_Value = $STIGParam.Expected_Value.AltCheckExpectedValue
            } ElseIf ($STIGParam.Check_Name -eq "Advanced Setting Syslog.global.logDir") {
                $ScratchLocation = ($ESXInfo | Get-AdvancedSetting -Name "ScratchConfig.CurrentScratchLocation").Value

                If ($ScratchLocation -ne "/tmp/scratch") {
                    $STIGCheck.Expected_Value = "[] /scratch/logs"
                }
            }

            If ($STIGParam.Expected_Value -eq "Does not exist" -and $SettingValue -ne $null) {
                $ESXInfo | Get-AdvancedSetting -Name $STIGParam.Check_Param | Remove-AdvancedSetting -Confirm:$false | Out-Null
            } ElseIf ($SettingValue -eq $null) {
                $ESXInfo | New-AdvancedSetting -Name $STIGParam.Check_Param -Value $STIGParam.Expected_Value -Confirm:$false | Out-Null
            } Else {
                $ESXInfo | Get-AdvancedSetting -Name $STIGParam.Check_Param | Set-AdvancedSetting -Value $STIGParam.Expected_Value -Confirm:$false | Out-Null
            }
        } ElseIf ($STIGParam.Check_Method -eq "EsxCli") {
            $esxcli = Get-EsxCli -VMHost $FindingItem.SystemName -v2

            If ($STIGParam.Check_Name -eq "SSH must use FIPS 140") {
                $arguments = $esxcli.system.security.fips140.ssh.set.CreateArgs()
                $arguments.enable = $true
                $esxcli.system.security.fips140.ssh.set.Invoke($arguments)
            } ElseIf ($STIGParam.Check_Name -eq "VIB Acceptance Level") {
                $arguments = $esxcli.software.acceptance.set.CreateArgs()
                $arguments.level = "PartnerSupported"
                $esxcli.software.acceptance.set.Invoke($arguments)
            } ElseIf ($STIGParam.Check_Name -eq "Audit Logging Enabled") {
                $arguments = $esxcli.system.auditrecords.local.set.CreateArgs()
                $arguments.size="100"
                $esxcli.system.auditrecords.local.disable.Invoke() | Out-Null
                $esxcli.system.auditrecords.local.set.Invoke($arguments) | Out-Null
                $esxcli.system.auditrecords.local.enable.Invoke() | Out-Null
                $esxcli.system.auditrecords.remote.enable.Invoke() | Out-Null
            } ElseIf ($STIGParam.Check_Name -eq "x509 Verification") {
                $arguments = $esxcli.system.syslog.config.set.CreateArgs()
                $arguments.x509strict = $true
                $esxcli.system.syslog.config.set.Invoke($arguments) | Out-Null
                $esxcli.system.syslog.reload.Invoke() | Out-Null
            } ElseIf ($STIGParam.Check_Name -eq "rhttpproxy Must Use FIPS") {
                $arguments = $esxcli.system.security.fips140.rhttpproxy.set.CreateArgs()
                $arguments.enable = $true
                $esxcli.system.security.fips140.rhttpproxy.set.Invoke($arguments) | Out-Null
            } ElseIf ($STIGParam.Check_Name -eq "Secure Boot Required") {
                $arguments = $esxcli.system.settings.encryption.set.CreateArgs()
                $arguments.requiresecureboot = $true
                $esxcli.system.settings.encryption.set.Invoke($arguments) | Out-Null
            }
        } ElseIf ($STIGParam.Check_Method -eq "DomainJoin") {
            #Try prompting for Z account to elevate to create computer accounts in DIR
            #Need to configure vCenter Auth Proxy on all vCenter's
            #\\orgaze\DCC\VirtualTeam\Scripts\STIG_Scripts\Join-Hosttodomain.ps1
            #We need to adjust the script to use vCenter's Auth Proxy

            $MitigationSuccess = "False"
        } ElseIf ($STIGParam.Check_Method -eq "FirewallDefaultPolicy") {
            $ESXInfo | Get-VMHostFirewallDefaultPolicy | Set-VMHostFirewallDefaultPolicy -AllowIncoming $false -AllowOutgoing $false
        } ElseIf ($STIGParam.Check_Method -eq "LockdownMode") {
            $vmhost = $ESXInfo | Get-View
            $lockdown = Get-View $vmhost.ConfigManager.HostAccessManager

            #Prior to Lockdown Mode being enabled, make sure that Lockdown Exceptions are in place
            $parms = @{
                AltCheckValue = "AltCheck LockdownModeExceptions"
                STIGParams = $STIGParams
                CurrentSystemName = $FindingItem.SystemName
                SystemType = "ESX"
            }

            #Version 1.05 - If this is run from Orchestrator then run the check script from a local copy rather than a network one
            If ($RunFromOrchestrator -eq "True") {
                #Run the RecordToChecklist.ps1 script from a local copy
                $LockdownExceptions = Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\AltCheck.ps1"" @parms")
            } Else {
                #Run the RecordToChecklist.ps1 script from the network
                $LockdownExceptions = Invoke-Expression -Command ("& '$FolderPathToSTIGScript\AltCheck.ps1' @parms")
            }
            
            $lockdown.UpdateLockdownExceptions($LockdownExceptions.AltCheckExpectedValue -split ",")

            $lockdown.ChangeLockdownMode("lockdownNormal")
        } ElseIf ($STIGParam.Check_Method -eq "LockdownExceptions") {
            $vmhost = $ESXInfo | Get-View
            $lockdown = Get-View $vmhost.ConfigManager.HostAccessManager
            $lockdown.UpdateLockdownExceptions($STIGParam.Expected_Value.AltCheckExpectedValue -split ",") #Version 1.08 - Corrected this to use AltCheckExpectedValue
        } ElseIf ($STIGParam.Check_Method -eq "Service") {
            If ($STIGParam.Expected_Value -eq "False - Off") {
                $ESXInfo | Get-VMHostService | Where { $_.Label -eq $STIGParam.Check_Param } | Set-VMHostService -Policy Off | Out-Null
                $ESXInfo | Get-VMHostService | Where { $_.Label -eq $STIGParam.Check_Param } | Stop-VMHostService -Confirm:$false | Out-Null
            } ElseIf ($STIGParam.Check_Param -eq "NTP Daemon") {
                #Version 1.02 - Previously NTP wasn't configured properly, but this AltCheck will make it function as intended
                $parms = @{
                    AltCheckValue = "AltCheck NTP"
                    STIGParams = $STIGParams
                    CurrentSystemName = $FindingItem.SystemName
                    SystemType = "ESX"
                }
                $NTPServerAddress = Invoke-Expression -Command ("& '$FolderPathToSTIGScript\AltCheck.ps1' @parms")
                $NTPServers = $NTPServerAddress.AltCheckExpectedValue
                
                $ESXInfo | Add-VMHostNTPServer $NTPServers
                $ESXInfo | Get-VMHostService | Where {$_.Label -eq "NTP Daemon"} | Set-VMHostService -Policy On | Out-Null
                $ESXInfo | Get-VMHostService | Where {$_.Label -eq "NTP Daemon"} | Start-VMHostService | Out-Null
            }
        } ElseIf ($STIGParam.Check_Method -eq "ServicePermissions") {
            #Version 1.02 - For STANDALONE
            #If ($ESXUsingvCenter -ne "STANDALONE") {
                #Connect to ESX Host
                Connect-VIServer $FindingItem.SystemName -Credential $SystemCreds -ErrorAction SilentlyContinue -ErrorVariable ConnectError | Out-Null
            #}

            #Confirm that the host connected
            If ($global:DefaultVIServers | Where { $_.Name -eq $FindingItem.SystemName }) {

                $CheckCIMRoleExists = Get-VIRole -Server $FindingItem.SystemName -Name CIMRole -ErrorAction SilentlyContinue
                $CheckCIMServiceExists = Get-VMHostAccount -Server $FindingItem.SystemName -id CIMService -ErrorAction SilentlyContinue
                #Version 1.01 - Added this to be able to handle adding just the CIM permissions
                $CIMRolePermissions = (Get-VIRole -Server $FindingItem.SystemName -Name CIMRole -ErrorAction SilentlyContinue | Get-VIPrivilege).Name

                #Version 1.01 - Added this If statement to be able to add the CIM interation if it is missing
                If ($CheckCIMRoleExists -and $CIMRolePermissions -notcontains "CIM interaction") {
                    Set-VIRole -Server $FindingItem.SystemName -Role CIMRole -AddPrivilege (Get-VIPrivilege -Server $FindingItem.SystemName -id "Host.Cim.Ciminteraction") | Out-Null
                } ElseIf ($CheckCIMServiceExists -or $CheckCIMRoleExists) {
                    $MitigationSuccess = "False"
                    #Write-Host "`nOn $($FindingItem.SystemName) either the CIMService or CIMRole already exist and need to manually be removed"
                } Else {
                    New-VIRole -Server $FindingItem.SystemName -Name CIMRole | Out-Null
                    Set-VIRole -Server $FindingItem.SystemName -Role CIMRole -AddPrivilege (Get-VIPrivilege -Server $FindingItem.SystemName -id "Host.Cim.Ciminteraction") | Out-Null
                    New-VMHostAccount -Server $FindingItem.SystemName -Id CIMService -Password "Ms]:Q6qV)bdJL^Db5" -Description "CIM Service" | Out-Null

                    $VMHostView = $ESXInfo | Get-View
                    $LockdownView = Get-View $VMHostView.ConfigManager.HostAccessManager
                    $LockdownExceptions = $LockdownView.QueryLockdownExceptions()
                    $LockdownExceptions += "CIMService"
                    $LockdownView.UpdateLockdownExceptions($LockdownExceptions)

                    New-VIPermission -Entity (Get-Folder root) -Principal CIMService -Role CIMRole | Out-Null
                }
                
                #If ($ESXUsingvCenter -ne "STANDALONE") {
                    Disconnect-VIServer -Server $FindingItem.SystemName -Confirm:$false
                #}
            }
        } ElseIf ($STIGParam.Check_Method -eq "SNMP") {
            #NOTE: This command seems like it only works if directly connected to the ESX host
            Get-VMHostSnmp | Set-VMHostSnmp -Enabled $false
        } ElseIf ($STIGParam.Check_Method -eq "sshd_config") {
            #Version 1.07 - Adding code to make this work

            #Connect to SSH
            $SSHSessionID = ConnectSSH

            #Get the first word that is used to identify what the current value is for this finding
            $SSHDItemSearch = ($STIGParam.Expected_Value -Split " ")[0]

            #Gather the current SSHD_Config data
            $SSHDConfigInfo = (Invoke-SSHCommand -SessionId $SSHSessionID -Command { cat /etc/ssh/sshd_config }).Output
            #(Invoke-SSHCommand -SessionId 0 -Command { /usr/lib/vmware/openssh/bin/sshd -T }).Output
            $CurrentSSHDItem = $SSHDConfigInfo | Where { $_ -like "$SSHDItemSearch*" }
            
            #Check to see if there is a current item that needs to get replaced
            If ($CurrentSSHDItem -ne $null) {
                $SSHDConfigInfo = $SSHDConfigInfo -replace $CurrentSSHDItem, $STIGParam.Expected_Value
            } Else { #If there is nothing then create a new line
                $SSHDConfigInfo += $STIGParam.Expected_Value
            }

            #Format the new SSHD_Config info so that it will have line breaks in it when stored to the system
            $SSHDConfigInfoJoin = $SSHDConfigInfo -join "`n"

            #Make a backup copy of sshd_config just in case anything needs to get reversed
            (Invoke-SSHCommand -SessionId $SSHSessionID -Command { cp -f /etc/ssh/sshd_config /etc/ssh/sshd_config_backup }).Output | Out-Null
            #Put in the new SSHD_Config info into the existing file
            (Invoke-SSHCommand -SessionId $SSHSessionID -Command "echo '$SSHDConfigInfoJoin' > /etc/ssh/sshd_config").Output | Out-Null

            #Disconnect SSH session
            Get-SSHSession | Remove-SSHSession | Out-Null
        } ElseIf ($STIGParam.Check_Method -eq "SSHQuery") {
            #Version 1.06 - Adding code to make this work

            #Connect to SSH
            $SSHSessionID = ConnectSSH

            #Perform actions based on whichever finding this is for
            If ($STIGParam.Check_Name -eq "Disable ESX Override Config") {
                (Invoke-SSHCommand -SessionId $SSHSessionID -Command { echo -n >/etc/vmware/settings }).Output | Out-Null
            } ElseIf ($STIGParam.Check_Name -eq "Disable ESX Override Log") {
                (Invoke-SSHCommand -SessionId $SSHSessionID -Command { cp /etc/vmware/config /etc/vmware/config.bak }).Output | Out-Null
                (Invoke-SSHCommand -SessionId $SSHSessionID -Command { grep -v "^vmx\.log" /etc/vmware/config.bak>/etc/vmware/config }).Output | Out-Null
            } Else {
                Write-Host "There is no code for this finding"
                $MitigationSuccess = "False"
            }

            #Disconnect SSH session
            Get-SSHSession | Remove-SSHSession | Out-Null

            #Version 1.09 - Only stop the service if it if was started by the script (if the $SSHServiceRunStatus is $false meaning it was stopped prior to the script running)
            If ($SSHServiceRunStatus -eq $false) {
                #Stop SSH on the ESX host
                $VMHost | Get-VMHostService | Where { $_.Label -eq "SSH" } | Stop-VMHostService -Confirm:$false | Out-Null
            }
        } ElseIf ($STIGParam.Check_Method -eq "StandardSwitch") {
            If ($STIGParam.Check_Param -eq "Reject Forged Transmits") {
                Get-VirtualSwitch -Standard | Get-SecurityPolicy | Set-SecurityPolicy -ForgedTransmits $false
                Get-VirtualPortGroup -Standard | Get-SecurityPolicy | Set-SecurityPolicy -ForgedTransmitsInherited $true
            } ElseIf ($STIGParam.Check_Param -eq "Reject MAC Address Changed") {
                Get-VirtualSwitch -Standard | Get-SecurityPolicy | Set-SecurityPolicy -MacChanges $false
                Get-VirtualPortGroup -Standard | Get-SecurityPolicy | Set-SecurityPolicy -MacChangesInherited $true
            } ElseIf ($STIGParam.Check_Param -eq "Reject Promiscuous Mode") {
                Get-VirtualSwitch -Standard | Get-SecurityPolicy | Set-SecurityPolicy -AllowPromiscuous $false
                Get-VirtualPortGroup -Standard | Get-SecurityPolicy | Set-SecurityPolicy -AllowPromiscuousInherited $true
            }
        } ElseIf ($STIGParam.Check_Method -eq "FirewallAllowAll") {
            $esxcli = Get-EsxCli -VMHost $FindingItem.SystemName -v2 -ErrorAction SilentlyContinue

            #Collect the IP ranges currently in use
            $HostFirewallIPRanges = $esxcli.network.firewall.ruleset.allowedip.list.invoke()

            $FirewallArgs = $esxcli.network.firewall.ruleset.set.createargs()
            $IPArgs = $esxcli.network.firewall.ruleset.allowedip.add.createargs()
            $FirewallArgs.allowedall = $false

            #Split the list of firewall rules that needs to be fixed
            $FirewallRuleToFixList = $FindingsList.Comments -Split "`n"

            ForEach ($FirewallItem in $STIGParam.Expected_Value) {
                $ChangeMade = "False"

                #Check to see if the firewall rule being looked at is also one that is on the list of ones that needs to be fixed
                $FirewallCheck = Compare-Object $FirewallRuleToFixList $FirewallItem.FriendlyName | Where { $_.SideIndicator -eq "=>" }
                
                #If this one doesn't need to get fixed then skip it
                If ($FirewallCheck -ne $null) {
                    Continue
                }

                #vSphereClient cannot be updated automatically without risking causing the ESX host to go into a Disconnected state
                If ($FirewallItem.FirewallRuleName -eq "vSphereClient") {
                    Continue
                } Else {
                    $FirewallArgs.rulesetid = $FirewallItem.FirewallRuleName
                    $IPArgs.rulesetid = $FirewallItem.FirewallRuleName

                    $CurrentIPRanges = ($HostFirewallIPRanges | Where { $_.Ruleset -eq $FirewallItem.FirewallRuleName }).AllowedIPAddresses
                }

                If ($FirewallItem.Enabled -eq $true) {
                    $FirewallArgs.enabled = $true
                } ElseIf ($FirewallItem.Enabled -eq $false) {
                    $FirewallArgs.enabled = $false
                }

                $CurrentFirewallRuleConfig = $ESXInfo | Get-VMHostFirewallException $FirewallItem.FriendlyName

                #Attempt to set AllowedAll.  This will error out if for instance it is already set to $true and is again asking it to be set to $true
                If ($CurrentFirewallRuleConfig.extensiondata.allowedhosts.allip -ne $FirewallArgs.allowedall) {
                    $ChangeMade = "True"
                    $esxcli.network.firewall.ruleset.set.invoke($FirewallArgs) | Out-Null
                }

                #Enabled has to be done separately from trying to set the AllowedAll parameter
                If ($CurrentFirewallRuleConfig.Enabled -ne $FirewallArgs.enabled) {
                    $ChangeMade = "True"
                    $CurrentFirewallRuleConfig | Set-VMHostFirewallException -Enabled $FirewallArgs.enabled | Out-Null
                }

                If ($FirewallItem.IPRanges -ne "BLANK" -and $FirewallItem.Enabled -eq "True") {
                    $IPRanges = $FirewallItem.IPRanges.Split(",")

                    ForEach ($IPRange in $IPRanges) {
                        If ($CurrentIPRanges -notcontains $IPRange) {
                            $IPArgs.ipaddress = $IPRange
                            $esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs) | Out-Null
                            $ChangeMade = "True"
                        }
                    }

                    $IPRangesToRemove = Compare-Object $CurrentIPRanges $IPRanges | Where { $_.SideIndicator -eq "<=" }

                    ForEach ($IPRangeToRemove in $IPRangesToRemove) {
                        If ($IPRangeToRemove.InputObject -ne "All") {
                            $IPArgs.ipaddress = $IPRangeToRemove.InputObject
                            $esxcli.network.firewall.ruleset.allowedip.remove.invoke($IPArgs) | Out-Null
                            $ChangeMade = "True"
                        }
                    }
                }

                If ($ChangeMade -eq "True") {
                    $esxcli.network.firewall.refresh.Invoke() | Out-Null
                }
            }
        }
    }

    $CurrentFinding++

    If ($AltCheck -eq "True") {
        $STIGParam.Expected_Value = $OrigExpectedValue
    }

    #Version 1.03 - I changed this from False to True because I think it was configured incorrectly
    If ($MitigationSuccess -eq "True") {
        $Global:ListOfStatusUpdates.Add((New-Object "psobject" -Property @{"ServerName"=$FindingItem.SystemName;"VCode"=$FindingItem.VulnNumber;"Status"="NotAFinding"}))
    }
}

#Version 1.03 - Don't update the form if this is run from Orchestrator and not the GUI
If ($AutoSTIGRun -ne "True") {
    $ProgressBarMitigate.Value = 0
    $LabelProgressBarMitigate.Text = "Complete"
}
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCv7ABYWrL+Nmkm
# T99hkdJ93EJ00Qd5fvJsdwWtbD5v36CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCCM7RGG3KQufw+l0RlduBDp0SkLqDkCX+ibSe/KvTjBWTANBgkq
# hkiG9w0BAQEFAASCAQAyJr2y5U1dfqkw5Zq7Jeh2teVcZVDYDQvGTlrVKcCOpUpK
# ITkPwuT1XkzndVVruk3RbmlBEFwD8WpMv8ugv6mKqWvYZbTl80guVC3lsWeDXs2H
# RQzv62Akp5UQv6iAWyheWQnYAH3uB+BUuAcS7Pot5tTUU8xBJjdX6v0XOzjypBR1
# CU5gXBKF+EBNhFnJQjvMtgL2v1Cm4lMJKGxisJ9B7QpYHYbjf5rkuRBriI1KCVAY
# CevE9Au/1BrS+9BzEvBRq/4GMFcNiA52XtfC+bKpchZud2wtGMto6w8EAdLE6nRd
# 4AOzwimx7rL/yZTzh5tEZgSoBpX0GLxnhfa5bb/H
# SIG # End signature block
