#PURPOSE: Export a list of what VMs have CD Drives connected as well as what is connected to it EXCEPT those in the VDI environment

#CHANGELOG
#Version 1.00 - 10/28/24 - MDR - Initial version
#Version 1.01 - 11/21/24 - MDR - Adding App POC data and VM notes as well as checking when the ISO was connected

#Adding parameters
Param ( $vCenterPassword, $VRAPassword, $RunFromOrchestrator )

#Configure variables
$TodaysDate = Get-Date -Format "MMddyy"
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports"
$VMCDInfo = New-Object System.Collections.Generic.List[System.Object]
$WindowsACASReportPath = "\\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\RAP Team\Scripts\ACAS Report\ACAS_Report_Data.xlsx"
$VMCDLastAttached = New-Object System.Collections.Generic.List[System.Object] #Version 1.01 - Record when VM had something attached to their CD drive

#Create an ouput file for commands being executed
Start-Transcript C:\Temp\Get_CDs_Connected_To_VM_$TodaysDate.txt

#If this is run from Orchestrator then generate a credential to perform the PSDrive mapping
If ($RunFromOrchestrator -eq "True") {
    #Create a credential for svc_vrapsh
    $VRACred = New-Object System.Management.Automation.PSCredential -ArgumentList @("DIR\svc_vrapsh",(ConvertTo-SecureString -String $VRAPassword -AsPlainText -Force))
    #Map a drive to the ReportPath
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -Credential $VRACred | Out-Null
} Else { #If not run from Orchestrator then just map the PSDrive with current credentials
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath | Out-Null
}

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Check to see if ImportExcel is installed
$CheckForImportExcel = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If ImportExcel is not found then prompt for folder where it is located
If (!$CheckForImportExcel) {
    Write-Host "The ImportExcel module is required for this script to run" -ForegroundColor Red
    Write-Host "`nA copy of this module is located in \\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\Software\ImportExcel"
    Write-Host "`nPlace a copy of this module in C:\Program Files\WindowsPowerShell\Modules"
    Break
}

Clear

#If the vCenter password is passed then no need to prompt for it
If ($vCenterPassword -eq $null) {
    #Prompt for vCenter Password
    $vCenterCreds = Read-Host "Input the vCenter PowerShell account password" -MaskInput
} Else {
    $vCenterCreds = $vCenterPassword
}

#Exit if no password was entered
If ($vCenterCreds -eq $null) {
    Write-Host "No password was entered so exiting the script"
    Break
}

#Import list of all vCenter servers EXCEPT VDI systems since this STIG check should not include VDI servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv" | Where { $_.User -notlike "*VDI*" }

Write-Host "`nCollecting report information"

#Version 1.01 - Adding Windows App POC info in to help get POC data
If (Test-Path $WindowsACASReportPath) {
    $AppPOCs = Import-Excel -Path $WindowsACASReportPath -WorksheetName "App POCs"
}

#Version 1.01 - Get the current date for filtering purposes
$CurrentDate = (Get-Date).ToShortDateString() -Split "/"

#Version 1.01 - If it is January then roll back the month and year
If ($CurrentDate[0] -eq 1) {
    $PreviousMonth = 12
    $PreviousYear = $CurrentDate[2] - 1
} Else { #Otherwise just go back one month
    $PreviousMonth = $CurrentDate[0] - 1
    $PreviousYear = $CurrentDate[2]
}

#Version 1.01 - Get all instances of the VM STIG reports over the past two months
$ReportsList = (Get-ChildItem -Path $ReportPath -Filter "Master_VM_Check_STIG_Server_Report_$PreviousMonth*$PreviousYear.xlsx").FullName
$ReportsList += (Get-ChildItem -Path $ReportPath -Filter "Master_VM_Check_STIG_Server_Report_$($CurrentDate[0])*$($CurrentDate[2]).xlsx").FullName

#Version 1.01 - Loop through each report and collect the last time each VM had a finding for CD being connected
ForEach ($ReportFile in $ReportsList) {
    Write-Host "Scanning $ReportFile"
    #Split the report name to determine the date it was created
    $SplitReportFileName = $ReportFile -Split "_"
    [DateTime]$FileDate = $SplitReportFileName[$SplitReportFileName.Count - 1].Substring(0,2) + "/" + $SplitReportFileName[$SplitReportFileName.Count - 1].Substring(2,2) + "/" + $SplitReportFileName[$SplitReportFileName.Count - 1].Substring(4,4)
    
    #Subtract the day of the file from the current date
    $FileAgeInDays = ((Get-Date) - $FileDate).Days

    #Collect the VMs on this report that have the finding for CD being attached
    $ReportData = (Import-Excel -Path $ReportFile | Where {$_.'CAT III' -like "*V-256458*"}).SystemName

    #If there is data in this array already
    If ($VMCDLastAttached -ne $null) {
        #####Compare the systems in this report to what has already been recorded to find new systems and systems that fell off the list#####

        #Find new systems
        $NewCDAttachments = (Compare-Object -ReferenceObject $ReportData -DifferenceObject $VMCDLastAttached.VMName | Where { $_.SideIndicator -eq "<=" }).InputObject

        #Find systems that no longer have this finding
        $RemovedCDAttachments = (Compare-Object -ReferenceObject $ReportData -DifferenceObject $VMCDLastAttached.VMName | Where { $_.SideIndicator -eq "=>" }).InputObject
    } Else { #If there is no data in the array
        $NewCDAttachments = $ReportData
        Clear-Variable RemovedCDAttachments -ErrorAction SilentlyContinue
    }
    
    #Create records for all new items
    ForEach ($VMName in $NewCDAttachments) {
        $VMCDLastAttached.add((New-Object "psobject" -Property @{"VMName"=$VMName;"AgeInDays"=$FileAgeInDays}))
    }

    #Remove records for all removed items
    ForEach ($VMName in $RemovedCDAttachments) {
        $VMCDLastAttached.RemoveAt($VMCDLastAttached.VMName.IndexOf($VMName))
    }
}

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    #Output vCenter Server name
    Write-Host "`nScanning for CD connections on $($vCenterServer.ServerName)"

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterCreds -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    Try {
        #Disconnected from all vCenter Servers
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    } Catch { }

    #Connect to vCenter Server
    Connect-VIServer $vCenterServer.ServerName -Credential $vCenterSecureCreds | Out-Null
    
    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServer.ServerName })) {
        Write-Host "`nFailed to connect to vCenter Server $($vCenterServer.ServerName)" -ForegroundColor Red
        Break
    }

    #Get a list of all VMs
    $VMList = Get-VM

    #Populate variables for progress bar
    $TotalVMs = $VMList.Count
    $CurrentVMNum = 1

    #Loop through each VM
    ForEach ($CurrentVM in $VMList) {
        #If this is run from Orchestrator then output the VM name to get written to the transcript file
        If ($RunFromOrchestrator -eq "True") {
            Write-Host $CurrentVM.Name
        } Else { #If not from Orchestrator then write a progress bar
            #Update progress bar
            Write-Progress -Activity "Getting VM CD data" -Status "$CurrentVMNum of $TotalVMs" -PercentComplete ($CurrentVMNum / $TotalVMs * 100)
        }

        #Get the VM CD information
        $CDInfo = Get-VM $CurrentVM | Get-CDDrive | Where {$_.extensiondata.connectable.connected -eq $true} | Select Name, IsoPath

        #If there is CD data to report
        If ($CDInfo -ne $null) {
            #Report the CD found
            Write-Host "$($CurrentVM.Name) has CD $($CDInfo.IsoPath)"
            #Version 1.01 - Get VM notes
            $VMNotes = $CurrentVM.Notes
            #Version 1.01 - Check to see if this VM has App POC data
            $AppPOCData = $AppPOCs | Where { $_.'Server Name' -like "$($CurrentVM.Name)*" } | Select 'POC 1', 'POC 2', 'POC 3'
            #Version 1.01 - Get how long this CD has been connected for
            $AgeInDays = ($VMCDLastAttached | Where { $_.VMName -eq $CurrentVM.Name}).AgeInDays | Select -First 1
            #Store data from the VM
            $VMCDInfo.add((New-Object "psobject" -Property @{"SystemName"=$CurrentVM.Name;"vCenterServer"=$vCenterServer.ServerName;"IsoPath"=$CDInfo.IsoPath;"AgeInDays"=$AgeInDays;"VMNotes"=$VMNotes;
            "POC1" = $AppPOCData.'POC 1';"POC2" = $AppPOCData.'POC 2';"POC3" = $AppPOCData.'POC 3'}))
        }

        #Increment progress bar counter
        $CurrentVMNum++
    }

    #Close the progress bar
    Write-Progress -Activity "Getting VM CD data" -Completed
}

#Disconnected from all vCenter Servers
Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue

Write-Host "Exporting data, please wait"

#Export data to CSV
$VMCDInfo | Select SystemName,vCenterServer,IsoPath,AgeInDays,VMNotes,POC1,POC2,POC3 | Export-CSV "ReportPath:\VM_CD_Info_$TodaysDate.csv" -NoTypeInformation -Force

Write-Host "`nScript Complete.  Report written to $ReportPath\VM_CD_Info_$TodaysDate.csv" -ForegroundColor Green

#Stop the transcript
Stop-Transcript
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCh63a93rgNaVvR
# CYSyXeixMdZEQ9zkzFLV1nR5kyu7AKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDEnhQR1O9QslThNNJ6n7DBHe/xeIu11YFal8pGRa0UXjANBgkq
# hkiG9w0BAQEFAASCAQCMZhzeCw8A3gyWTrxCzJCsfK1HwyP5iWuyVImdnIEHyRKE
# SXVfHup/85wiDuGwjc8uXu9WLmbY13cQ5Of316VgmTxt0IOWsvP/DfIkBZrUlObj
# sJitrd9rW0C0RIV26DCItecMT6tChhaaEp7wa0ElESDFBI9GVEnItZo+7P2bCfkz
# hj7FPmqa0s6HE3SQGNqtefA6uXq+XodWSDtqb1VSZ+9maCtTS6fQuZFC9XS+Ye84
# PQnRGFpRNnoa1U1hc6ahlsIph+thAQiud43Gc5qBY643YmcqnlKKuvyvujUVAicN
# lLlGa6WdyyFxChBkrtKbzGgYPwD1wpIiGymbCV8J
# SIG # End signature block
