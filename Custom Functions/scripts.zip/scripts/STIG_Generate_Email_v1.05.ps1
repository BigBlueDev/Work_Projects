﻿#PURPOSE: Generate an email based on ESX and VM STIG Check data

#CHANGELOG:
#Version 1.00 - 09/30/24 - MDR - Initial version  
#Version 1.01 - 10/10/24 - MDR - Display new findings that have changed since last week
#Version 1.02 - 10/30/24 - MDR - Added a section for "Average findings per VM by vCenter"
#Version 1.03 - 10/31/24 - MDR - Hide vCLS findings and display which files are being used to generate this data
#Version 1.04 - 12/06/24 - MDR - Add vCenter STIG data
#Version 1.06 - 01/08/25 - MDR - Ignoring HXVM VMs

#Phase 1 - **** INITIALIZATION / IMPORT DATA****

#Script should be run with user account. Check to see if an admin account is being used. If so, break out of the script. If not continue.
If (($env:UserName).Length -eq 8) { #If this is an elevated account
    Write-Warning "You need to run this with your non-elevated account."
    Read-Host "`nHit enter to close this window."
    Break
}

#Variable initialization
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports"
$Tab = [char]9 #This will be used to tab over HTML data so that it is readable within the variable $EmailHTMLBody
$EmailHTMLBody = "<br><br><br>" #Start the email off with empty lines so text can be input there

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Check to see if ImportExcel is installed
$CheckForImportExcel = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If ImportExcel is not found then prompt for folder Where it is located
If (!$CheckForImportExcel) {
    Write-Host "The ImportExcel module is required for this script to run" -ForegroundColor Red
    Write-Host "`nA copy of this module is located in \\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\Software\ImportExcel"
    Write-Host "`nPlace a copy of this module in C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#AddDataToTableFunction takes in two variables, the $DataToAdd in variable and the explaination for that $DataToAdd variable. This function will be called each time to add data and explainations to a table that will later be used to generate an email.
Function AddDataToTable {
    Param ( $DataToAdd, $TableExplanation )
    #If this is the first time calling this function, $DataUpon the first run create
    If ($DataToAdd -ne $null) {
        
        #Get the number of columns in the dataset
        $DataColumnCount = $DataToAdd[0].psobject.Properties.Value.Count

        #Add the explanation for the table
        $Script:EmailHTMLBody += "<font size=3 color=blue>$TableExplanation</font><br><br>`n"

        #Create the table
        $Script:EmailHTMLBody += "<Table border='1' cellspacing='0' cellpadding='7' style='border-collapse:collapse;border:none'><font size='2' face='Calibri' color='black'>`n"

    ###Create the headers###
        $Script:EmailHTMLBody += "$Tab<tr align='Center'; style='height:13.00pt'>`n" #Create a new row

        If ($DataToAdd.Count -ge 200) {
            $Script:EmailHTMLBody += "$Tab$Tab<font size=3 color=red><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'><b>Not displaying full output of this table due to this finding having over 100 line items.  Actual finding count is $($DataToAdd.Count).  See full report to view data on this finding.</b></td></font>`n"
            $Script:EmailHTMLBody += "$Tab</tr>`n" #End the row
        } Else {
            ForEach ($HeaderName in $DataToAdd[0].psobject.Properties.Name) { #For each cell in the row
                $Script:EmailHTMLBody += "$Tab$Tab<font size=3><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'><b>" + $HeaderName + "</b></td></font>`n"
            }
            $Script:EmailHTMLBody += "$Tab</tr>`n" #End the row

        ###Add data###
            ForEach ($DataItem in $DataToAdd) { #For each row of data
                $Script:EmailHTMLBody += "$Tab<tr align='Center'; style='height:13.00pt'>`n" #Create a new row
        
                For ($Count = 0; $Count -lt $DataColumnCount; $Count++) { #For each cell in the row
                    If ($DataColumnCount -ne 1) { #If there are multiple columns
                        $Script:EmailHTMLBody += "$Tab$Tab<font size=3><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'>" + $DataItem.psobject.Properties.Value[$Count] + "</td></font>`n"
                    } Else { #Do this if there is just 1 column because otherwise it'll only output one character at a time
                        $Script:EmailHTMLBody += "$Tab$Tab<font size=3><td valign='Center' style='text-align: left; border:none; padding:0cm 5.4pt 0cm 5.4pt;height:15.00pt'>" + $DataItem.psobject.Properties.Value + "</td></font>`n"
                    }
                }

                $Script:EmailHTMLBody += "$Tab</tr>`n" #End the row
            }
        }
        
        $Script:EmailHTMLBody += "</font></table><br><br>`n`n" #End the table
    }
}

Clear

Write-Host "Importing report data, please wait"

#Get a list of all Master Check STIG reports
$MasterCheckSTIGList = Get-ChildItem -Path $ReportPath -Filter "*Master_*_Check_STIG_*" | Sort LastWriteTime -Descending

#Version 1.01 - Instead of getting just the most recent reports, get the two most recent reports
$ESXCheckSTIGServerReports = ($MasterCheckSTIGList | Where { $_.Name -like "*ESX_Check_STIG_Server_Report*" } | Select -First 2).FullName
$ESXCheckSTIGVCodeReports = ($MasterCheckSTIGList | Where { $_.Name -like "*ESX_Check_STIG_VCode_Report*" } | Select -First 2).FullName
$VMCheckSTIGServerReports = ($MasterCheckSTIGList | Where { $_.Name -like "*VM_Check_STIG_Server_Report*" } | Select -First 2).FullName
$VMCheckSTIGVCodeReports = ($MasterCheckSTIGList | Where { $_.Name -like "*VM_Check_STIG_VCode_Report*" } | Select -First 2).FullName
#Version 1.04 - Added vCenter STIG imports
$vCenterCheckSTIGServerReports = ($MasterCheckSTIGList | Where { $_.Name -like "*vCenter_Check_STIG_Server_Report*" } | Select -First 2).FullName
$vCenterCheckSTIGVCodeReports = ($MasterCheckSTIGList | Where { $_.Name -like "*vCenter_Check_STIG_VCode_Report*" } | Select -First 2).FullName

#Version 1.03 - Display the files being used to generate this data
Write-Host "`nThe following files are being used to generate this report:`n"
$ESXCheckSTIGServerReports
$ESXCheckSTIGVCodeReports
$VMCheckSTIGServerReports
$VMCheckSTIGVCodeReports
#Version 1.04 - Display vCenter data
$vCenterCheckSTIGServerReports
$vCenterCheckSTIGVCodeReports

#Find the latest version of each STIG report
#Version 1.01 - Include whether these are ESX or VMs
$CurrESXCheckSTIGServerReportInfo = Import-Excel $ESXCheckSTIGServerReports[0] | Select *, @{Name="Device";Expression={"ESX"}}
$CurrESXCheckSTIGVCodeReportInfo = Import-Excel $ESXCheckSTIGVCodeReports[0] | Select *, @{Name="Device";Expression={"ESX"}}
#Version 1.03 - Until we're in vSphere 8.x, vCLS systems can't be STIG'd anyways so ignore new findings on them
#Version 1.05 - Also ignoring HXVM since those only exist during cluster upgrades
$CurrVMCheckSTIGServerReportInfo = Import-Excel $VMCheckSTIGServerReports[0] | Select *, @{Name="Device";Expression={"VM"}} | Where { $_.SystemName -notlike "vCLS-*" -and $_.SystemName -notlike "HXVM-*" }
$CurrVMCheckSTIGVCodeReportInfo = Import-Excel $VMCheckSTIGVCodeReports[0] | Select *, @{Name="Device";Expression={"VM"}}
#Version 1.04 - Include vCenter data
$CurrvCenterCheckSTIGServerReportInfo = Import-Excel $vCenterCheckSTIGServerReports[0] | Select *, @{Name="Device";Expression={"vCenter"}}
$CurrvCenterCheckSTIGVCodeReportInfo = Import-Excel $vCenterCheckSTIGVCodeReports[0] | Select *, @{Name="Device";Expression={"vCenter"}}

$ESXHostList = Import-CSV "$ReportPath\ESXHostList.csv"
$VMList = Import-CSV "$ReportPath\VMList.csv"

#Version 1.01 - Find the previous version of each STIG report
$PrevESXCheckSTIGServerReportInfo = Import-Excel $ESXCheckSTIGServerReports[1]
$PrevVMCheckSTIGServerReportInfo = Import-Excel $VMCheckSTIGServerReports[1]
$PrevvCenterCheckSTIGServerReportInfo = Import-Excel $vCenterCheckSTIGServerReports[1]

#####Version 1.01 - Find the differences between the current and previous STIG reports#####

Write-Host "`nComparing current and previous data"

#When performing mitigations, store a list of status changes that get made as the script runs
$ListOfNewFindings = New-Object System.Collections.Generic.List[System.Object]

#This function will receive the current and previous findings for a single server and record any new V-codes
Function FindSTIGChanges ($CurrData, $PrevData, $CATFinding) {
    #If there are no VCodes then skip
    If ($CurrData -ne "0") {
        #Find the V-code values in the current and previous scan for this server
        $CurrDataVCodes = ([regex]::Matches($CurrData, 'V-\d+')).Value
        $PrevDataVCodes = ([regex]::Matches($PrevData, 'V-\d+')).Value

        #Clear all variables
        Clear-Variable NewFindings, NewlyFoundFindings -ErrorAction SilentlyContinue

        #If this is from a system that has previous data to compare against
        If ($PrevSTIGData -ne $null) {
            #If there is STIG data for this CAT finding to compare against
            If ($PrevDataVCodes -ne $null) {
                #Record only V-Code values that were added since the last scan
                $NewFindings = (Compare-Object -ReferenceObject $CurrDataVCodes -DifferenceObject $PrevDataVCodes | Where { $_.SideIndicator -eq "<=" }).InputObject
            } Else {
                #If there are no findings to compare against
                $NewFindings = $CurrDataVCodes
            }
        } Else {
            #If these findings come from there being no previous scan of the host store all VCodes
            $NewlyFoundFindings = $CurrDataVCodes
        }

        #Record each new finding
        ForEach ($VCode in $NewFindings) {
            #Get the Name of the vCode for this finding
            If ($CurrSystem.Device -eq "ESX") {
                $VCodeName = ($CurrESXCheckSTIGVCodeReportInfo | Where { $_.VCode -eq $VCode }).Name
            } ElseIf ($CurrSystem.Device -eq "VM") { #If it is a VM
                $VCodeName = ($CurrVMCheckSTIGVCodeReportInfo | Where { $_.VCode -eq $VCode }).Name
            } ElseIf ($CurrSystem.Device -eq "vCenter") { #If it is a vCenter
                $VCodeName = ($CurrvCenterCheckSTIGVCodeReportInfo | Where { $_.VCode -eq $VCode }).Name
            }

            #Record the finding
            $Script:ListOfNewFindings.Add((New-Object "psobject" -Property @{"ServerName"=$CurrSystem.SystemName;"VCode"=$VCode;"VCodeName"=$VCodeName;"CAT"=$CATFinding;"Type"="New finding";Device=$CurrSystem.Device}))
        }

        #Record each finding from a previously unscanned system
        ForEach ($VCode in $NewlyFoundFindings) {
            #Get the Name of the vCode for this finding
            If ($CurrSystem.Device -eq "ESX") {
                $VCodeName = ($CurrESXCheckSTIGVCodeReportInfo | Where { $_.VCode -eq $VCode }).Name
            } ElseIf ($CurrSystem.Device -eq "VM") { #If it is a VM
                $VCodeName = ($CurrVMCheckSTIGVCodeReportInfo | Where { $_.VCode -eq $VCode }).Name
            } ElseIf ($CurrSystem.Device -eq "vCenter") { #If it is a vCenter
                $VCodeName = ($CurrvCenterCheckSTIGVCodeReportInfo | Where { $_.VCode -eq $VCode }).Name
            }

            #Record the finding
            $Script:ListOfNewFindings.Add((New-Object "psobject" -Property @{"ServerName"=$CurrSystem.SystemName;"VCode"=$VCode;"VCodeName"=$VCodeName;"CAT"=$CATFinding;"Type"="New system";Device=$CurrSystem.Device}))
        }
    }
}

#Get the progress bar data
$FindingCount = $CurrESXCheckSTIGServerReportInfo.Count
$CurrFinding = 1

#Loop through each ESX Server
ForEach ($CurrSystem in $CurrESXCheckSTIGServerReportInfo) {
    #Display progress bar
    Write-Progress -Activity $CurrSystem.SystemName -Status "$CurrFinding of $FindingCount" -PercentComplete ($CurrFinding / $FindingCount * 100)

    #Gather the previous STIG data for this system
    $PrevSTIGData = $PrevESXCheckSTIGServerReportInfo | Where { $_.SystemName -eq $CurrSystem.SystemName }

    #Compare the current and previous findings
    FindSTIGChanges $CurrSystem.'CAT I' $PrevSTIGData.'CAT I' "CAT I"
    FindSTIGChanges $CurrSystem.'CAT II' $PrevSTIGData.'CAT II' "CAT II"
    FindSTIGChanges $CurrSystem.'CAT III' $PrevSTIGData.'CAT III' "CAT III"

    #Increment the progress bar
    $CurrFinding++
}

#Close progress bar
Write-Progress -Activity $CurrSystem.SystemName -Completed

#Get the progress bar data
$FindingCount = $CurrVMCheckSTIGServerReportInfo.Count
$CurrFinding = 1

#Loop through each VM Server
ForEach ($CurrSystem in $CurrVMCheckSTIGServerReportInfo) {
    #Display progress bar
    Write-Progress -Activity $CurrSystem.SystemName -Status "$CurrFinding of $FindingCount" -PercentComplete ($CurrFinding / $FindingCount * 100)

    #Gather the previous STIG data for this system
    $PrevSTIGData = $PrevVMCheckSTIGServerReportInfo | Where { $_.SystemName -eq $CurrSystem.SystemName }

    #Compare the current and previous findings
    FindSTIGChanges $CurrSystem.'CAT I' $PrevSTIGData.'CAT I' "CAT I"
    FindSTIGChanges $CurrSystem.'CAT II' $PrevSTIGData.'CAT II' "CAT II"
    FindSTIGChanges $CurrSystem.'CAT III' $PrevSTIGData.'CAT III' "CAT III"

    #Increment the progress bar
    $CurrFinding++
}

#Close progress bar
Write-Progress -Activity $CurrSystem.SystemName -Completed

#Get the progress bar data
$FindingCount = $CurrvCenterCheckSTIGServerReportInfo.Count
$CurrFinding = 1

#Loop through each vCenter server
ForEach ($CurrSystem in $CurrvCenterCheckSTIGServerReportInfo) {
    #Display progress bar
    Write-Progress -Activity $CurrSystem.SystemName -Status "$CurrFinding of $FindingCount" -PercentComplete ($CurrFinding / $FindingCount * 100)

    #Gather the previous STIG data for this system
    $PrevSTIGData = $PrevvCenterCheckSTIGServerReportInfo | Where { $_.SystemName -eq $CurrSystem.SystemName }

    #Compare the current and previous findings
    FindSTIGChanges $CurrSystem.'CAT I' $PrevSTIGData.'CAT I' "CAT I"
    FindSTIGChanges $CurrSystem.'CAT II' $PrevSTIGData.'CAT II' "CAT II"
    FindSTIGChanges $CurrSystem.'CAT III' $PrevSTIGData.'CAT III' "CAT III"

    #Increment the progress bar
    $CurrFinding++
}

#Close progress bar
Write-Progress -Activity $CurrSystem.SystemName -Completed

#Export the new findings to a CSV
$ListOfNewFindings | Select "ServerName","Device","VCode","VCodeName","CAT","Type" | Export-CSV "C:\Temp\NewFindings.csv" -NoTypeInformation

#Get the latest ESX failure report
$ESXFailureReportPath = Get-ChildItem -Path $ReportPath -Filter "*ESX_Check_STIG_Failure_Report*" | Sort LastWriteTime -Descending | Select -First 1
#If there is a failure path to import
If ($ESXFailureReportPath -ne $null) {
    #Import latest failure report
    $ESXFailureReport = Import-CSV $ESXFailureReportPath
}

#Phase 2: ***Data analysis to create email****

#All Sections contain the following parts:
#$SectionData = New-Object System.Collections.Generic.List[System.Object] #$SectionData gets created/cleared in each section.
#$SectionExplaination is the text that describes the information being presented
#SortedList - always contains the ServerNames and data to add to the email
#A call to the AddDataToTable function which require the parameters of $SortedList and $SectionExplaination

#Report any failures

$SectionExplanation = "Failures encountered running ESX scan"

AddDataToTable $ESXFailureReport $SectionExplanation

###Display top 20 ESX Hosts with findings###

Write-Host "`nGenerating report"

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "ESX hosts with most findings:"

$TopESXHostFindings = $CurrESXCheckSTIGServerReportInfo | Where { $_.O -gt 0 } | Sort "O" -Descending | Select -First 20

ForEach ($DataItem in $TopESXHostFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"HostName"=$DataItem.SystemName;"Open findings"=$DataItem.O;"Closed findings"=$DataItem.NF}))
}

$SortedList = $SectionData | Select "HostName","Open findings","Closed findings"

AddDataToTable $SortedList $SectionExplanation

###Display top 20 ESX VCodes###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "ESX vCodes with most findings:"

$TopESXVCodeFindings = $CurrESXCheckSTIGVCodeReportInfo | Where { $_.O -gt 0 } | Sort "O" -Descending | Select -First 20

ForEach ($DataItem in $TopESXVCodeFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"VCode"=$DataItem.VCode;"Name"=$DataItem.Name;"Open findings"=$DataItem.O;"Closed findings"=$DataItem.NF}))
}

$SortedList = $SectionData | Select "VCode","Name","Open findings","Closed findings"

AddDataToTable $SortedList $SectionExplanation

###Display ESX VCodes that have NRs###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "ESX vCodes with Not Reviewed entries:"

$ESXVCodesWithNR = $CurrESXCheckSTIGVCodeReportInfo | Where { $_.NR -gt 0 }

ForEach ($DataItem in $ESXVCodesWithNR) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"VCode"=$DataItem.VCode;"Name"=$DataItem.Name;"Not Reviewed findings"=$DataItem.NR}))
}

#Only output this is there is data to report
If ($SectionData -ne $null) {
    $SortedList = $SectionData | Select "VCode","Name","Not Reviewed findings"

    AddDataToTable $SortedList $SectionExplanation
}

###Display average ESX findings by vCenter Server###

$SectionData = New-Object System.Collections.Generic.List[System.Object]
$vCenterAverageData = @()

$SectionExplanation = "Average findings per ESX host by vCenter:"

#Get a list of all vCenter servers
$ListOfvCenterServers = $ESXHostList.vCenterServer | Select -Unique

ForEach ($vCenterServer in $ListOfvCenterServers) {
    #Get a list of all ESX hosts in this vCenter Server
    $AllVMsInThisvCenter = ($ESXHostList | Where { $_.vCenterServer -eq $vCenterServer }).SystemName

    #Get all ESX host findings for systems in this vCenter Server.  Requires either O or NF to not be equal to 0 to ensure blank data isn't used
    $DataForAllVMsInThisvCenter = $CurrESXCheckSTIGServerReportInfo | Where { $AllVMsInThisvCenter -contains $_.SystemName -and ($_.O -ne 0 -or $_.NF -ne 0) }

    #Record the Average number of findings for ESX hosts on this vCenter rounded to 2 decimal places
    $AverageOpenFindings = [MATH]::Round(($DataForAllVMsInThisvCenter.O | Measure-Object -Average).Average,2)

    #Record the Average number of findings for ESX hosts on this vCenter rounded to 2 decimal places
    $AverageClosedFindings = [MATH]::Round(($DataForAllVMsInThisvCenter.NF | Measure-Object -Average).Average,2)

    #Store the findings for this host
    $vCenterAverageData += [PSCustomObject]@{'vCenterServer'=$vCenterServer;'Average Open Findings'=$AverageOpenFindings;'Average Closed Findings'=$AverageClosedFindings}
}

$SortedvCenterAverageData = $vCenterAverageData | Sort "Average Open Findings" -Descending

ForEach ($DataItem in $SortedvCenterAverageData) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"vCenterServer"=$DataItem.vCenterServer;"Average Open Findings"=$DataItem.'Average Open Findings';"Average Closed Findings"=$DataItem.'Average Closed Findings'}))
}

$SortedList = $SectionData | Select "vCenterServer","Average Open Findings","Average Closed Findings"

AddDataToTable $SortedList $SectionExplanation

###Display top 20 VMs with findings###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "VMs with most findings:"

$TopVMHostFindings = $CurrVMCheckSTIGServerReportInfo | Where { $_.O -gt 0 -and $_.SystemName -notlike "vCLS*" } | Sort "O" -Descending | Select -First 20

ForEach ($DataItem in $TopVMHostFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"HostName"=$DataItem.SystemName;"Open findings"=$DataItem.O;"Closed findings"=$DataItem.NF}))
}

$SortedList = $SectionData | Select "HostName","Open findings","Closed findings"

AddDataToTable $SortedList $SectionExplanation

###Display top 20 VM VCodes###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "VM vCodes with most findings:"

$TopVMVCodeFindings = $CurrVMCheckSTIGVCodeReportInfo | Where { $_.O -gt 0 } | Sort "O" -Descending | Select -First 20

ForEach ($DataItem in $TopVMVCodeFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"VCode"=$DataItem.VCode;"Name"=$DataItem.Name;"Open findings"=$DataItem.O;"Closed findings"=$DataItem.NF}))
}

$SortedList = $SectionData | Select "VCode","Name","Open findings","Closed findings"

AddDataToTable $SortedList $SectionExplanation

###Display VM VCodes that have NRs###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "VM vCodes with Not Reviewed entries:"

$VMVCodesWithNR = $CurrVMCheckSTIGVCodeReportInfo | Where { $_.NR -gt 0 }

ForEach ($DataItem in $VMVCodesWithNR) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"VCode"=$DataItem.VCode;"Name"=$DataItem.Name;"Not Reviewed findings"=$DataItem.NR}))
}

#Only output this is there is data to report
If ($SectionData -ne $null) {
    $SortedList = $SectionData | Select "VCode","Name","Not Reviewed findings"

    AddDataToTable $SortedList $SectionExplanation
}

###Display average VM findings by vCenter Server###

$SectionData = New-Object System.Collections.Generic.List[System.Object]
$vCenterAverageData = @()

$SectionExplanation = "Average findings per VM by vCenter:"

#Get a list of all vCenter servers
$ListOfvCenterServers = $VMList.vCenterServer | Select -Unique

ForEach ($vCenterServer in $ListOfvCenterServers) {
    #Get a list of all VMs in this vCenter Server
    $AllVMsInThisvCenter = ($VMList | Where { $_.vCenterServer -eq $vCenterServer }).SystemName

    #Get all VM findings for systems in this vCenter Server.  Requires either O or NF to not be equal to 0 to ensure blank data isn't used
    $DataForAllVMsInThisvCenter = $CurrVMCheckSTIGServerReportInfo | Where { $AllVMsInThisvCenter -contains $_.SystemName -and ($_.O -ne 0 -or $_.NF -ne 0) }

    #Record the Average number of findings for VMs on this vCenter rounded to 2 decimal places
    $AverageOpenFindings = [MATH]::Round(($DataForAllVMsInThisvCenter.O | Measure-Object -Average).Average,2)

    #Record the Average number of findings for VMs on this vCenter rounded to 2 decimal places
    $AverageClosedFindings = [MATH]::Round(($DataForAllVMsInThisvCenter.NF | Measure-Object -Average).Average,2)

    #Store the findings for this vCenter
    $vCenterAverageData += [PSCustomObject]@{'vCenterServer'=$vCenterServer;'Average Open Findings'=$AverageOpenFindings;'Average Closed Findings'=$AverageClosedFindings}
}

$SortedvCenterAverageData = $vCenterAverageData | Sort "Average Open Findings" -Descending

ForEach ($DataItem in $SortedvCenterAverageData) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"vCenterServer"=$DataItem.vCenterServer;"Average Open Findings"=$DataItem.'Average Open Findings';"Average Closed Findings"=$DataItem.'Average Closed Findings'}))
}

$SortedList = $SectionData | Select "vCenterServer","Average Open Findings","Average Closed Findings"

AddDataToTable $SortedList $SectionExplanation

###Display vCenter findings###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "vCenter findings:"

$TopvCenterFindings = $CurrvCenterCheckSTIGServerReportInfo | Where { $_.O -gt 0 } | Sort "O" -Descending

ForEach ($DataItem in $TopvCenterFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"HostName"=$DataItem.SystemName;"Open findings"=$DataItem.O;"Closed findings"=$DataItem.NF}))
}

$SortedList = $SectionData | Select "HostName","Open findings","Closed findings"

AddDataToTable $SortedList $SectionExplanation

###Display top 20 vCenter VCodes###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "vCenter vCodes with most findings:"

$TopvCenterVCodeFindings = $CurrvCenterCheckSTIGVCodeReportInfo | Where { $_.O -gt 0 } | Sort "O" -Descending | Select -First 20

ForEach ($DataItem in $TopvCenterVCodeFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"VCode"=$DataItem.VCode;"Name"=$DataItem.Name;"Open findings"=$DataItem.O;"Closed findings"=$DataItem.NF}))
}

$SortedList = $SectionData | Select "VCode","Name","Open findings","Closed findings"

AddDataToTable $SortedList $SectionExplanation

###Display vCenter VCodes that have NRs###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "vCenter vCodes with Not Reviewed entries:"

$vCenterVCodesWithNR = $CurrvCenterCheckSTIGVCodeReportInfo | Where { $_.NR -gt 0 } | Sort "NR" -Descending

ForEach ($DataItem in $vCenterVCodesWithNR) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"VCode"=$DataItem.VCode;"Name"=$DataItem.Name;"Not Reviewed findings"=$DataItem.NR}))
}

#Only output this is there is data to report
If ($SectionData -ne $null) {
    $SortedList = $SectionData | Select "VCode","Name","Not Reviewed findings"

    AddDataToTable $SortedList $SectionExplanation
}

###Display New findings since last scan###

$SectionData = New-Object System.Collections.Generic.List[System.Object]

$SectionExplanation = "New findings since last scan:"

ForEach ($DataItem in $ListOfNewFindings) {
    $SectionData.add((New-Object -TypeName "psobject" -Property  @{"ServerName"=$DataItem.ServerName;"Device"=$DataItem.Device;"VCode"=$DataItem.VCode;"VCodeName"=$DataItem.VCodeName;"CAT"=$DataItem.CAT;"Type"=$DataItem.Type}))
}

#Only output this is there is data to report
If ($SectionData -ne $null) {
    $SortedList = $SectionData | Select "ServerName","Device","VCode","VCodeName","CAT","Type"

    AddDataToTable $SortedList $SectionExplanation
}

#Phase 3 ***Create Email*****

Write-Host "`nGenerating email"

#Add link to Server Problem Report at the bottom of the email
$Script:EmailHTMLBody += "<br>Data generated from STIG Check Reports in $ReportPath<br>"

###Construct the email###
$objOutlook = New-Object -comObject Outlook.Application

$Email = $objOutlook.CreateItem(0)
$Email.To = "joseph.nicklous@dla.mil; carlton.parker.ctr@dla.mil; kenneth.smith.ctr@dla.mil; dawn.gordon@dla.mil"
$Email.CC = "john.siegrist@dla.mil; casey.wyckoff@dla.mil; michael.d.russcher@dla.mil"
$Email.Subject = "vSphere STIG Report - $(Get-Date -Format MM/dd/yy)"

#Version 1.01 - Add new findings to the email
Try {
    $Email.Attachments.Add("C:\Temp\NewFindings.csv") | Out-Null
    Remove-Item "C:\Temp\NewFindings.csv"
} Catch { }

$Email.HTMLBody = $EmailHTMLBody

$Email.save()

$Inspector = $Email.GetInspector
$Inspector.Display()

Write-Host "`nScript complete" -ForegroundColor Green

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCA/Evo1OXQed8g
# KukVPj7yq4YfsypM1u1k9OUjFOLb16CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDiTD70KlkcSYh0KkR77BJjv9NMVJdzpyBv3D/0O160MTANBgkq
# hkiG9w0BAQEFAASCAQAse3uXfZBq84aTexr3Teh+561ilzaJKczhkIGn47aaaqm4
# XeAxuZegr+odDs8WDiSvrknwIHm10Ca3LXbWyeWBVa0ogg2O8uojULCiY6vo3fky
# aY0NkB08krwlvMyZIaW7/13l4FK/r8wMMJZ5TbEQyP1DoKNZHamFtn9OjnAUzcBC
# SZ+7VFJwyUQH/Eyq0wOuHo9MBUukkjYUYpsxRT7wdGtIfWaMyOMNx2MiNfiI1pv9
# 2VstTyksQLn3gbKvwQtFdkrK8LFfdJwY/WkmszU+dDMMvztQkax+W+POI1rX0ERq
# 965sr2+TXL5e5ltdKAFspTCtJ7aQcUqMpKKbL0MO
# SIG # End signature block
