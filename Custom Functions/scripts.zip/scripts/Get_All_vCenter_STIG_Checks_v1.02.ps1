#PURPOSE: This script will run vCenter STIG checks against all vCenter environments

#CHANGELOG
#Version 1.00 - 12/02/24 - MDR - Initial version
#Version 1.01 - 12/24/24 - MDR - Retrieve the backup information from the VDI VMs while connected to Dayton Prod
#Version 1.02 - 12/27/24 - MDR - Added SSO connection

Param ( $ParameterPath, $RunFromOrchestrator )

#Only import parameters from file if run from Orchestrator
If ($RunFromOrchestrator -eq "True") {
    #Import Base64 passwords from CSV
    $Base64Passwords = Import-CSV $ParameterPath

    #Delete the CSV file since it is no longer needed and for security reasons
    Remove-Item $ParameterPath | Out-Null

    #Store passwords to temp variables
    $vCenterPasswordBase64 = $Base64Passwords.vCenterPassword
    $vCenterRootPasswordBase64 = $Base64Passwords.vCenterRootPassword
    $VRAPasswordBase64 = $Base64Passwords.VRAPassword

    #Decode passwords from Base64 to plain text
    $vCenterPassword = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($vCenterPasswordBase64))
    $vCenterRootPassword = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($vCenterRootPasswordBase64))
    $VRAPassword = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($VRAPasswordBase64))
}

#Configure variables
$TodaysDate = Get-Date -Format "MMddyyyy" #Made this a 4 digit year
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports" #Changed path to VPM share \ Reports folder
$Global:STIGResultList = New-Object System.Collections.Generic.List[System.Object] #This is Global because RecordToChecklist.ps1 is what writes to it
$Global:FolderPathToSTIGScript = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR" #This is Global because the STIG Check.ps1 script utilizes it
$Global:NoSTIGParamList = @() #This is Global because the STIG Check.ps1 script utilizes it.  List of STIG checks that were NOT on the Parameters list
$FailureList = @() #Failure list will keep a list of all issues connecting to ESX hosts during the script

#Added to support DoEvents which is utilized in STIG Check.ps1
Add-Type -AssemblyName System.Windows.Forms

#Create a transcript file
Start-Transcript C:\Temp\Get_All_vCenter_STIG_Checks_$TodaysDate.txt

#Allow multiple connections to vCenter Servers which is required for this script
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

Clear

#If this is run from Orchestrator then generate a credential to perform the PSDrive mapping
If ($RunFromOrchestrator -eq "True") {
    #Convert the VRA password to a secure string
    $VRACred = New-Object System.Management.Automation.PSCredential -ArgumentList @("DIR\svc_vrapsh",(ConvertTo-SecureString -String $VRAPassword -AsPlainText -Force))
    #Map a drive to the ReportPath
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -Credential $VRACred | Out-Null
} Else { #If not run from Orchestrator then just map the PSDrive with current credentials
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -ErrorAction SilentlyContinue | Out-Null
}

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Check to see if ImportExcel is installed
$CheckForImportExcel = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If ImportExcel is not found then prompt for folder Where it is located
If (!$CheckForImportExcel) {
    Write-Host "The ImportExcel module is required for this script to run" -ForegroundColor Red
    Write-Host "`nA copy of this module is located in \\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\Software\ImportExcel"
    Write-Host "`nPlace a copy of this module in C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Verify PoshSSH module exists
$VerifyPoshSSHModule = Get-Command New-SSHSession -ErrorAction SilentlyContinue

#If PoshSSH doesn't exist then explain where to get it from and exit the script
If (!($VerifyPoshSSHModule)) {
    Write-Host "`nPoshSSH module not found" -ForegroundColor Red
    Write-Host "`nPoshSSH can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\Posh-SSH"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Verify SSOAdmin module exists
$VerifySSOAdminModule = Get-Command Get-SsoPasswordPolicy -ErrorAction SilentlyContinue

#If PoshSSH doesn't exist then explain where to get it from and exit the script
If (!($VerifySSOAdminModule)) {
    Write-Host "`nSSOAdmin module not found" -ForegroundColor Red
    Write-Host "`nSSOAdmin can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\VMware PowerCLI"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#If the vCenter password is passed then no need to prompt for it
If ($vCenterPassword -eq $null) {
    #Prompt for vCenter Password
    $vCenterPassword = Read-Host "Input the vCenter password" -MaskInput
}

#Exit if no password was entered
If ($vCenterPassword -eq $null) {
    Write-Host "`nNo password was entered so exiting the script" -ForegroundColor Red
    Break
}

#If the vCenter root password is passed then no need to prompt for it
If ($vCenterRootPassword -eq $null) {
    #Prompt for vCenter Password
    $vCenterRootPassword = Read-Host "Input the vCenter Root password (NOTE THIS IS NOT THE ESX ROOT PASSWORD)" -MaskInput
}

#Exit if no password was entered
If ($vCenterRootPassword -eq $null) {
    Write-Host "`nNo root password was entered so exiting the script" -ForegroundColor Red
    Break
}

#Store the password to a PSCredential
$SecureSystemPassword = ConvertTo-SecureString $vCenterRootPassword -AsPlainText -Force
$vCenterRootSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecureSystemPassword )

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#Get info for each type of STIG (ie info on the Parameters and script locations for VM, ESX, and Photon OS STIGs)
$STIGScriptInfo = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\STIG_Script_Info.csv"

#Get the ESX STIG Info
$STIGInfo = $STIGScriptInfo | Where { $_.STIGType -eq "vCenter" }

#If it already exists then make sure no .ckl files exist in it
If (Test-Path $STIGInfo.TempPath) {
    Remove-Item "$($STIGInfo.TempPath)\vCenter - *.ckl" | Out-Null
} Else { #Create the Temp Checklist folder
    New-Item $STIGInfo.TempPath -ItemType Directory | Out-Null
}

#Get the date that will be used in the checklist folder
$ShortDate = Get-Date -Format MM-dd-yy
#Generate the full folder path that will be used when copying checklists over
$CompletedFolderPath = "$($STIGInfo.NetworkPath)\vCenter\$ShortDate - All"

#If the folder for the completed checklists doesn't exist then create it
If (!(Test-Path $CompletedFolderPath)) {
    New-Item $CompletedFolderPath -ItemType Directory | Out-Null
}

#Get the blank checklist info
$BlankChecklist = Get-ChildItem ( $STIGInfo.BlankChecklistPath ) | Select Name, FullName
#Copy a blank checklist in the temp directory
Copy-Item $BlankChecklist.FullName $STIGInfo.TempPath

#Collect the ESX STIG checklist parameters
$STIGParams = Import-Excel $STIGInfo.ParmetersPath -WorksheetName *

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    #Get the current system name
    $CurrentSystemName = $vCenterServer.ServerName
    #Collect the vCenter domain
    $vCenterDomain = ($vCenterServer.User -Split "@")[1]

    #Output vCenter Server name
    Write-Host "`nScanning vCenter Server $CurrentSystemName"

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterPassword -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    #Disconnected from all vCenter Servers
    Try {
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    } Catch {}

    #Version 1.02 - Disconnected from all SSO Admin Servers
    Try {
        Disconnect-SsoAdminServer -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
    } Catch {}

    #Remove any SSH connections
    Get-SSHSession | Remove-SSHSession | Out-Null

    #Connect to vCenter Server
    Connect-VIServer $CurrentSystemName -Credential $vCenterSecureCreds -ErrorAction SilentlyContinue | Out-Null
    
    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $CurrentSystemName })) {
        #Disconnect from all vCenter Servers
        Write-Host "`nFailed to connect to vCenter Server $CurrentSystemName" -ForegroundColor Red
        $FailureList += [PSCustomObject]@{"SystemName"=$CurrentSystemName;"Error"="Failed to connect to vCenter Server"}
        Clear-Variable vCenterPassword -ErrorAction SilentlyContinue
        Break
    }

    #Version 1.02 - Create SSO connection
    Connect-SsoAdminServer -Server $CurrentSystemName -Credential $vCenterSecureCreds | Out-Null

    #Version 1.01 - Because the two VDI vCenter servers have VMs location in Dayton Prod, need to pull backup in from them when connected to Dayton Prod and use that info later
    If ($CurrentSystemName -eq "daisv0pp212.dir.ad.dla.mil") {
        $Global:daisv0pp222BackupDate = ((Get-VM "daisv0pp222.dir.ad.dla.mil" | Get-Annotation -Name "NB_LAST_BACKUP").Value -Split ",")[0]
        $Global:daisv0pp223BackupDate = ((Get-VM "daisv0pp223.dir.ad.dla.mil" | Get-Annotation -Name "NB_LAST_BACKUP").Value -Split ",")[0]
    }

    #Start the SSH Session
    $Global:SSHConnection = New-SSHSession -HostName $CurrentSystemName -Credential $vCenterRootSecureCreds -AcceptKey -Force -WarningAction SilentlyContinue -ErrorAction SilentlyContinue

    #Verify the connection worked
    If ($SSHConnection -eq $null) {
        Write-Host "`nFailed to connect to SSH on $CurrentSystemName" -ForegroundColor Red
        $FailureList += [PSCustomObject]@{"SystemName"=$CurrentSystemName;"Error"="Failed to connect to SSH on vCenter Server"}
        Clear-Variable vCenterRootPassword -ErrorAction SilentlyContinue
        Break
    }

    #Take the blank .ckl file and make a copy of it for the host being scanned right now
    $ChecklistFilePath = "$($STIGInfo.TempPath)\vCenter STIG - $CurrentSystemName-$TodaysDate.ckl"
    $LocalBlankChecklistPath = "$($STIGInfo.TempPath)\$($BlankChecklist.Name)"
    Copy-Item $LocalBlankChecklistPath $ChecklistFilePath

    #Store parameters that will be utilized by the ESX STIG Check script
    $parms = @{
        ChecklistFilePath = $ChecklistFilePath
        CurrentSystemName = $CurrentSystemName
        STIGParams = $STIGParams
        RunFromOrchestrator = $RunFromOrchestrator
        vCenterDomain = $vCenterDomain
    }

    #If this is run from Orchestrator then run the check script from a local copy rather than a network one
    If ($RunFromOrchestrator -eq "True") {
        #Split by folder and files names
        $ScriptPathSplit = $STIGInfo.CheckScriptPath -split "\\"
        #Get the file name of the script
        $ScriptName = $ScriptPathSplit[$ScriptPathSplit.Count - 1]
        #Run the STIG Check.ps1 script from a local copy
        Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\$ScriptName"" @parms")
    } Else {
        #Run the STIG Check.ps1 script from the network
        Invoke-Expression -Command ("& '$($STIGInfo.CheckScriptPath)' @parms")
    }
}

If ($FailureList -ne $null) {
    $FailureList | Export-CSV "$ReportPath\vCenter_Check_STIG_Failure_Report_$TodaysDate.csv"
    Break
}

#Move the checklists for this vCenter server over
Write-Host "`nMoving vCenter checklists to $CompletedFolderPath"

#If the folder for the completed checklists doesn't exist then create it
If (!(Test-Path "$CompletedFolderPath")) {
    New-Item "$CompletedFolderPath" -ItemType Directory | Out-Null
}

#Copy checklists to the network path
Get-ChildItem -Path "$($STIGInfo.TempPath)\vCenter STIG - *.ckl" | Move-Item -Destination $CompletedFolderPath -Force

#Notify that the STIG checks are now completed
Write-Host "`nSTIG checks completed.  Generating reports."

#Disconnect from vCenter
Disconnect-VIServer -Server * -Confirm:$false

#Version 1.02 - Disconnected from all SSO Admin Servers
Disconnect-SsoAdminServer

#Remove any SSH connections
Get-SSHSession | Remove-SSHSession | Out-Null

###Generate Reports###

#Store VCode results broken down by NR/NA/NF/O
$VCodeReport = New-Object System.Collections.Generic.List[System.Object]
#Store the number of findings per server broken down by NR/NA/NF/O and CAT I/II/III
$ServerReport = New-Object System.Collections.Generic.List[System.Object]

#Get a unique list of all the VCodes and setup variables that will be used for generating the reports
$VCodeList = $STIGResultList.VCode | Select -Unique
$CATList = @("CAT I", "CAT II", "CAT III")
$StatusList = @("O", "NF", "NA", "NR")
$RecordCount = 0

#Generate the VCode Report
ForEach ($VCode in $VCodeList) {
    #Find all STIG checks that had this V-Code
    $VCodeResultList = $STIGResultList | Where { $_.VCode -eq $VCode }
    #Determine what CAT this finding is
    $CAT = ($VCodeResultList | Select -First 1).CAT
    #Get the Check_Name so the reports contains the check name and not just the V-Code ID
    $VCodeName = ($STIGParams["VCode_Parameters"] | Where { $_.Vuln_Num -eq $VCode }).Check_Name
    #Store the results for this V-Code
    $VCodeReport.add((New-Object "psobject" -Property @{"VCode"=$VCode;"CAT"=$CAT;"Name"=$VCodeName;"O"=0;"NF"=0;"NA"=0;"NR"=0;"ServerList"=""}))

    #Loop through each type of finding ("O", "NF", "NA", "NR")
    ForEach ($Status in $StatusList) {
        #Update the count for this record for each type of finding
        $VCodeReport[$RecordCount].$Status = ($VCodeResultList | Where { $_.Status -eq $Status }).Count
    }
    
    #Move onto the next V-Code
    $RecordCount++
}

#Reset the count for the Server report
$RecordCount = 0
#Get a list of all vCenter servers
$SystemScanList = $STIGResultList.SystemName | Select -Unique

#Generate the Server Report
ForEach ($SystemName in $SystemScanList) {
    #Find all STIG checks for this system
    $SystemResultList = $STIGResultList | Where { $_.SystemName -eq $SystemName }
    #Create a generic record for this finding
    $ServerReport.add((New-Object "psobject" -Property @{"SystemName"=$SystemName;"O"=0;"NF"=0;"NA"=0;"NR"=0;"CAT I"=0;"CAT II"=0;"CAT III"=0}))

    #Loop through each type of finding ("O", "NF", "NA", "NR")
    ForEach ($Status in $StatusList) {
        #Update the count for this record for each type of finding
        $ServerReport[$RecordCount].$Status = ($SystemResultList | Where { $_.Status -eq $Status }).Count
    }

    #Loop through each type of CAT finding ("CAT I", "CAT II", "CAT III")
    ForEach ($CAT in $CATList) {
        #For this system, gather the open findings for just this CAT type
        $VCodeFindingList = $SystemResultList | Where { $_.CAT -eq $CAT -and $_.Status -eq "O" }
        #Store the count of how many open findings there are for this CAT type
        $ServerReport[$RecordCount].$CAT = [String]$VCodeFindingList.Count

        #If there is more than one finding for this CAT type
        If ($VCodeFindingList.Count -ne 0) {
            #Build a string for this.  It will ultimately look like "2 - (V-256446, V-256447)" if there were two findings
            $ServerReport[$RecordCount].$CAT += " - ("

            #Loop through each finding
            ForEach ($VCodeFinding in $VCodeFindingList) {
                #If there are more than two findings remaining then there will need to be a comma to separate the V-Codes
                If ($ServerReport[$RecordCount].$CAT.Split("-").Count -gt 2) {
                    $ServerReport[$RecordCount].$CAT += ", " + $VCodeFinding.VCode
                } Else { #Otherwise just add the V-Code
                    $ServerReport[$RecordCount].$CAT += $VCodeFinding.VCode
                }
            }

            #Finish off the string with an end parenthasis
            $ServerReport[$RecordCount].$CAT += ")"
        }
    }

    #Move onto the next V-Code
    $RecordCount++
}

#Display if there were any STIG checks that were not on the Parameter spreadsheet
If ($NoSTIGParamList) {
    Write-Host "`nThe following V-Codes had no STIG param item:"
    $NoSTIGParamList
}

#Output the VCode and Server reports
$VCodeReport | Select "VCode","Name","O","NF","NA","NR" | Export-Excel "$ReportPath\Master_vCenter_Check_STIG_VCode_Report_$TodaysDate.xlsx" -FreezePane 2, 2
$ServerReport | Select "SystemName","O","NF","NA","NR","CAT I","CAT II","CAT III" | Export-Excel "$ReportPath\Master_vCenter_Check_STIG_Server_Report_$TodaysDate.xlsx" -FreezePane 2, 2

Write-Host "`nScript Complete.  Report written to $ReportPath" -ForegroundColor Green

#Stop the transcript
Stop-Transcript
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDsw2C9Wh/BekQz
# 3rNZvge3KgyuD3lfW2gE6iQBZOJn46CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCB369c+iuZed5sha03UMLwPuwY7yGcMSxtuDc0fUwwe0DANBgkq
# hkiG9w0BAQEFAASCAQAlNyjqgpkwTYaiuReRwMOto7WE+/Or+TxqYz24aTIr+mNj
# aVLq4V8eMzdpAOuGAyB0VBheGTtH7o7+TZu85bHiPc0HoQZ4k5EF+WzRB+eCmRdm
# uZeLqCYybPPgOqzMtZrrJ+t9Y34JFcS66z80hzv3S503nyXsd6ruclP1fjQyAXjm
# nxE+fhPU8Tp+i7V07N21Kza6xtJnY0LuJR8ALxN3d01WwvPr7Hwxx9khWE4jsiE8
# bJNBNwx0PFdmHDDPIIxEyxQ6R3/RRLEVDTUK5idJPFqYM79HvIDpDMhkWrfHOpyV
# Xlnld3Vem2/fgBbMFbYJw0UXBP4l3Ki7lJO3Vvse
# SIG # End signature block
