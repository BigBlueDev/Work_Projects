﻿
<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2021 v5.8.188
	 Created on:   	6/8/2021 10:12 AM
	 Created by:   	Matthew Miller
	 Organization: 	INFO OPTERATIONS
	 Filename:     	
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2017 v5.4.140
	 Created on:   	6/8/2017 8:59 PM
	 Created by:   	adam.branham
	 Organization: 	
	 Filename:     	DataCollection.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

#region Variables
$ServerCollection = 'HPCE-DSC', 'HPCE-DC'
$GetVMData = $true
$ThrottleLimit = '20'
$SQLServer = 'HPCE-MSSQL'
$vCenterServer = 'vcenter.hpce.int'
$SQLWorkingDB = 'ServerInventory'
$ServerDataArray = @()
#endregion Variables

#region vCenterConnection
if ($GetVMData -eq $true)
{
	Get-Module -Name VMware* -ListAvailable | Import-Module
	$vServer = Connect-VIServer -Server $vCenterServer
}
#endregion vCenterConnection
<#
#region SQLConnection
$SQLCon = New-Object System.Data.SqlClient.SqlConnection
$SQLConString = "Server = $SQLServer; Initial Catalog = $SQLWorkingDB; Integrated Security = True; Connection Timeout = $SQLTimeOut;"
$SQLCon.ConnectionString = $SQLConString
$SQLCon.Open()
#Verify SQL Connection
if ($SQLCon.State -ne [Data.ConnectionState]::Open) { Write-Verbose 'Connection to SQL Database not Open'; Exit }
#endregion SQLConnection
#>

Try
{
	# Create PSRemote Session with all servers
	$PSSession = $ServerCollection | New-PSSession
	
	#region GatherDataDirect
	$Bios = Invoke-Command -ScriptBlock { Get-WmiObject Win32_Bios } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Processor = Invoke-Command -ScriptBlock { Get-WmiObject Win32_Processor } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Memory = Invoke-Command -ScriptBlock { Get-WmiObject Win32_PhysicalMemory } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$System = Invoke-Command -ScriptBlock { Get-WmiObject Win32_ComputerSystem } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$TimeZone = Invoke-Command -ScriptBlock { Get-WmiObject Win32_TimeZone } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$OS = Invoke-Command -ScriptBlock { Get-WmiObject Win32_OperatingSystem } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$PageFile = Invoke-Command -ScriptBlock { Get-WmiObject Win32_PageFile } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Network = Invoke-Command -ScriptBlock { Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled='True'" } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Drives = Invoke-Command -ScriptBlock { Get-WmiObject Win32_Volume -Filter "(Not Name LIKE '\\\\?\\%')" } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Roles = Invoke-Command -ScriptBlock { Get-WmiObject Win32_ServerFeature } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Tasks = Invoke-Command -ScriptBlock { Get-ScheduledTask } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Software = Invoke-Command -ScriptBlock { Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$HotFix = Invoke-Command -ScriptBlock { Get-Hotfix } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Services = Invoke-Command -ScriptBlock { Get-Service } -Session $PSSession -ThrottleLimit $ThrottleLimit
	$Shares = Invoke-Command -ScriptBlock { Get-SmbShare } -Session $PSSession -ThrottleLimit $ThrottleLimit
	#endregion GatherDataDirect
	
	#Compile data into array
	foreach ($Server in $PSSession.ComputerName)
	{
		$SysBios = $Bios | Where-Object { $_.PSComputerName -eq $Server }
		$SysProcessor = $Processor | Where-Object { $_.PSComputerName -eq $Server }
		$SysMemory = $Memory | Where-Object { $_.PSComputerName -eq $Server }
		$SysSystem = $System | Where-Object { $_.PSComputerName -eq $Server }
		$SysTimeZone = $TimeZone | Where-Object { $_.PSComputerName -eq $Server }
		$SysOS = $OS | Where-Object { $_.PSComputerName -eq $Server }
		$SysPageFile = $PageFile | Where-Object { $_.PSComputerName -eq $Server }
		$SysNetwork = $Network | Where-Object { $_.PSComputerName -eq $Server }
		$SysDrives = $Drives | Where-Object { $_.PSComputerName -eq $Server }
		$SysRoles = $Roles | Where-Object { $_.PSComputerName -eq $Server }
		$SysTasks = $Tasks | Where-Object { $_.PSComputerName -eq $Server }
		$SysSoft = $Software | Where-Object { $_.PSComputerName -eq $Server }
		$SysHotFix = $Hotfix | Where-Object { $_.PSComputerName -eq $Server }
		$SysServices = $Services | Where-Object { $_.PSComputerName -eq $Server }
		$SysShare = $Shares | Where-Object { $_.PSComputerName -eq $Server }
		
		#region GetvCenterData
		if ($vServer.IsConnected)
		{
			$VMDetails = Get-VM | Where-Object -FilterScript { $_.Guest.HostName -like "$Server*" }
		}
		#endregion GetvCenterData
		
		$SysObject = New-Object -TypeName System.Management.Automation.PSObject
		$OBJData = [pscustomobject]@{
			Hostname = $Server
			TimeZone = $SysTimeZone.Caption
			Bios	 = @(
				[pscustomobject]@{
					Manufacturer = $SysBios.Manufacturer
					Version	     = $SysBios.Version
					SMBIOSBIOSVersion = $SysBios.SMBIOSBIOSVersion
					SMBIOSMajorVersion = $SysBios.SMBIOSMajorVersion
					SMBIOSMinorVersion = $SysBios.SMBIOSMinorVersion
					SystemBiosMajorVersion = $SysBios.SystemBiosMajorVersion
					SystemBiosMinorVersion = $SysBios.SystemBiosMinorVersion
					Name		 = $SysBios.Name
					PrimaryBIOS  = $SysBios.PrimaryBIOS
				}
			)
			System   = @(
				[pscustomobject]@{
					Domain = $SysSystem.Domain
					Manufacturer = $SysSystem.Manufacturer
					Model  = $SysSystem.Model
					Name   = $SysSystem.Name
					PrimaryOwnerName = $SysSystem.PrimaryOwnerName
					BootupState = $SysSystem.BootupState
					AdminPasswordStatus = $SysSystem.AdminPasswordStatus
					Status = $SysSystem.Status
					AutomaticManagedPagefile = $SysSystem.AutomaticManagedPagefile
					AutomaticResetBootOption = $SysSystem.AutomaticResetBootOption
					AutomaticResetCapability = $SysSystem.AutomaticResetCapability
					BootROMSupported = $SysSystem.BootROMSupported
					HypervisorPresent = $SysSystem.HypervisorPresent
					NetworkServerModeEnabled = $SysSystem.NetworkServerModeEnabled
				}
			)
			OS	     = @(
				[pscustomobject]@{
					Caption = $SysOS.Caption
					Architecture = $SysOS.OSArchitecture
					ServicePackMajorVersion = $SysOS.ServicePackMajorVersion
					Manufacturer = $SysOS.Manufacturer
					SystemDrive = $SysOS.SystemDrive
					SystemDirectory = $SysOS.SystemDirectory
					Organization = $SysOS.Organization
					BuildNumber = $SysOS.BuildNumber
					RegisteredUser = $SysOS.RegisteredUser
					SerialNumber = $SysOS.SerialNumber
					Version = $SysOS.Version
					BuildType = $SysOS.BuildType
					WindowsDirectory = $SysOS.WindowsDirectory
				}
			)
			Software = @(
				[pscustomobject]@{
					DisplayName = $SysSoft.DisplayName
					Comments    = $SysSystem.Comments
					Contact	    = $SysSystem.Contact
					DisplayVersion = $SysSoft.DisplayVersion
					Publisher   = $SysSoft.Publisher
					HelpLink    = $SysSoft.HelpLink
					HelpPhone   = $SysSoft.HelpTelephone
					InstallDate = $SysSoft.InstallDate
					InstallLocation = $SysSoft.InstallLocation
					InstallSource = $SysSoft.InstallSource
					ModifyPath  = $SysSoft.ModifyPath
					UninstallString = $SysSoft.UninstallString
					URLInfoAbout = $SysSoft.URLInfoAbout
					URLUpdateInfo = $SysSoft.URLUpdateInfo
					Readme	    = $SysSoft.Readme
				}
			)
			Hotfix   = @(
				[pscustomobject]@{
					HotFixID = $SysHotFix.HotFixID
					Description = $SysHotFix.Description
					Caption  = $SysHotFix.Caption
					InstalledBy = $SysHotFix.InstalledBy
					InstallDate = $SysHotFix.InstallDate
				}
			)
			Services = @(
				[pscustomobject]@{
					Name = $SysServices.Name
					RequiredServices = $SysServices.RequiredServices
					CanPauseAndContinue = $SysServices.CanPauseAndContinue
					CanShutdown = $SysServices.CanShutdown
					DisplayName = $SysServices.DisplayName
					DependentServices = $SysServices.DependentServices
					Status = $SysServices.Status
					ServiceType = $SysServices.ServiceType
					StartType = $SysServices.StartType
				}
			)
			Shares   = @(
				[pscustomobject]@{
					ShareState = $SysShare.ShareState
					AvailabilityType = $SysShare.AvailabilityType
					ShareType  = $SysShare.ShareType
					FolderEnumerationMode = $SysShare.FolderEnumerationMode
					CachingMode = $SysShare.CachingMode
					SmbInstance = $SysShare.SmbInstance
					CATimeout  = $SysShare.CATimeout
					ConcurrentUserLimit = $SysShare.ConcurrentUserLimit
					ContinuouslyAvailable = $SysShare.ContinuouslyAvailable
					Description = $SysShare.Description
					EncryptData = $SysShare.EncryptData
					Name	   = $SysShare.Name
					Path	   = $SysShare.Path
				}
			)
			Processor = @()
			Memory   = @()
			Network  = @()
			Roles    = @()
			Drives   = @()
			VMData   = @()
			Tasks    = @() # Needs to be completed.
		}
		$OBJData.VMData += [pscustomobject]@{
			DisplayName = $VMDetails.Name
			PowerState  = $VMDetails.PowerState
			Notes	    = $VMDetails.Notes
			NumCpu	    = $VMDetails.NumCpu
			CoresPerSocket = $VMDetails.CoresPerSocket
			MemoryMB    = $VMDetails.MemoryMB
			MemoryGB    = $VMDetails.MemoryGB
			VMHostId    = $VMDetails.VMHostId
			VMHost	    = $VMDetails.VMHost
			VApp	    = $VMDetails.VApp
			FolderId    = $VMDetails.FolderId
			Folder	    = $VMDetails.Folder
			ResourcePoolId = $VMDetails.ResourcePoolId
			ResourcePool = $VMDetails.ResourcePool
			HARestartPriority = $VMDetails.HARestartPriority
			HAIsolationResponse = $VMDetails.HAIsolationResponse
			DrsAutomationLevel = $VMDetails.DrsAutomationLevel
			VMSwapfilePolicy = $VMDetails.VMSwapfilePolicy
			VMId	    = $VMDetails.VMResourceConfiguration.VMId
			NumCpuShares = $VMDetails.VMResourceConfiguration.NumCpuShares
			CpuReservationMhz = $VMDetails.VMResourceConfiguration.CpuReservationMhz
			CpuSharesLevel = $VMDetails.VMResourceConfiguration.CpuSharesLevel
			NumMemShares = $VMDetails.VMResourceConfiguration.NumMemShares
			MemReservationMB = $VMDetails.VMResourceConfiguration.MemReservationMB
			MemReservationGB = $VMDetails.VMResourceConfiguration.MemReservationGB
			MemLimitMB  = $VMDetails.VMResourceConfiguration.MemLimitMB
			MemLimitGB  = $VMDetails.VMResourceConfiguration.MemLimitGB
			MemSharesLevel = $VMDetails.VMResourceConfiguration.MemSharesLevel
			DiskResourceConfiguration = $VMDetails.VMResourceConfiguration.DiskResourceConfiguration.DiskSharesLevel
			DiskKey	    = $VMDetails.VMResourceConfiguration.DiskResourceConfiguration.Key
			NumDiskShares = $VMDetails.VMResourceConfiguration.DiskResourceConfiguration.NumDiskShares
			DiskLimitIOPerSecond = $VMDetails.VMResourceConfiguration.DiskResourceConfiguration.DiskLimitIOPerSecond
			HTCoreSharing = $VMDetails.VMResourceConfiguration.HTCoreSharing
			UsedSpaceGB = $VMDetails.UsedSpaceGB
			ProvisionedSpaceGB = $VMDetails.ProvisionedSpaceGB
			
		}
		foreach ($CPU in $SysProcessor)
		{
			$OBJData.Processor += [pscustomobject]@{
				DeviceID = $CPU.DeviceID
				Manufacturer = $CPU.Manufacturer
				Name	 = $CPU.Name
				NumberOfCores = $CPU.NumberOfCores
				NumberOfEnabledCore = $CPU.NumberOfEnabledCore
				NumberOfLogicalProcessors = $CPU.NumberOfLogicalProcessors
				ThreadCount = $CPU.ThreadCount
				MaxClockSpeed = $CPU.MaxClockSpeed
				CpuStatus = $CPU.CpuStatus
			}
		}
		foreach ($RAM in $SysMemory)
		{
			$OBJData.Memory += [pscustomobject]@{
				BankLabel = $RAM.BankLabel
				Capacity  = $RAM.Capacity
				ConfiguredClockSpeed = $RAM.ConfiguredClockSpeed
				ConfiguredVoltage = $RAM.ConfiguredVoltage
				Description = $RAM.Description
				DeviceLocator = $RAM.DeviceLocator
				HotSwappable = $RAM.HotSwappable
				Tag	      = $RAM.Tag
			}
		}
		foreach ($NIC in $SysNetwork)
		{
			$OBJData.Network += [pscustomobject]@{
				Index = $NIC.Index
				Description = $NIC.Description
				DHCPEnabled = $NIC.DHCPEnabled
				DHCPServer = $NIC.DHCPServer
				DNSDomain = $NIC.DNSDomain
				DNSEnabledForWINSResolution = $NIC.DNSEnabledForWINSResolution
				DNSHostName = $NIC.DNSHostName
				DNSServerSearchOrder = $NIC.DNSServerSearchOrder
				DomainDNSRegistrationEnabled = $NIC.DomainDNSRegistrationEnabled
				FullDNSRegistrationEnabled = $NIC.FullDNSRegistrationEnabled
				IPAddress = $NIC.IPAddress
				IPEnabled = $NIC.IPEnabled
				IPFilterSecurityEnabled = $NIC.IPFilterSecurityEnabled
				WINSEnableLMHostsLookup = $NIC.WINSEnableLMHostsLookup
				WINSHostLookupFile = $NIC.WINSHostLookupFile
				WINSPrimaryServer = $NIC.WINSPrimaryServer
				WINSScopeID = $NIC.WINSScopeID
				WINSSecondaryServer = $NIC.WINSSecondaryServer
				DefaultIPGateway = $NIC.DefaultIPGateway
				DefaultTOS = $NIC.DefaultTOS
				DefaultTTL = $NIC.DefaultTTL
				IPSubnet = $NIC.IPSubnet
				MACAddress = $NIC.MACAddress
				MTU   = $NIC.MTU
			}
		}
		foreach ($Role in $SysRoles)
		{
			$OBJData.Roles += [pscustomobject]@{
				Name = $Role.Name
				ID   = $Role.ID
			}
		}
		foreach ($Drive in $SysDrives)
		{
			$OBJData.Drives += [pscustomobject]@{
				Caption = $Drive.Caption
				DriveLetter = $Drive.DriveLetter
				Capacity = $Drive.Capacity
				BootVolume = $Drive.BootVolume
				Automount = $Drive.Automount
				BlockSize = $Drive.BlockSize
				Compressed = $Drive.Compressed
				Description = $Drive.Description
				DriveType = $Drive.DriveType
				FileSystem = $Drive.FileSystem
				IndexingEnabled = $Drive.IndexingEnabled
				Label   = $Drive.Label
				PageFilePresent = $Drive.PageFilePresent
				SerialNumber = $Drive.SerialNumber
				
			}
		}
		foreach ($Task in $SysTasks)
		{
			$OBJData.Tasks += [pscustomobject]@{
				Name = $Task.TaskName
				State = $Task.State
				Path = $Task.TaskPath
				Action = $Task.Action.Execute
				Arguments = $Task.Action.Arguments
				WorkingDir = $Task.Action.WorkingDirectory
				Author = $Task.Author
				Date = $Task.Date
				Description = $Task.Description
			}
		}
		$ServerDataArray += $OBJData
	}
}
Catch
{
}

$ServerDataArray

#region vCenterConnectionClose
if ($vServer.IsConnected)
{
	Disconnect-VIServer $vServer -Force -Confirm:$false -WarningAction SilentlyContinue -ErrorAction SilentlyContinue | Out-Null
}
#endregion vCenterConnectionClose
<#
#region SQLConnectionClose
$SQLCon.Close()
if ($SQLCon.State -ne [Data.ConnectionState]::Closed) { Write-Verbose 'Unable to Close SQL Connection'; Exit }
#endregion SQLConnectionClose
#>

