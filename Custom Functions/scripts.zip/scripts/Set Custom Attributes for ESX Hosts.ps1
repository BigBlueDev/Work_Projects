#PURPOSE: Configure the Custom Attributes for ESX hosts based on the data imported from a CSV file

#CHANGELOG
#Version 1.00 - 12/23/2024 - MDR - Initial version

$TodaysDate = Get-Date -Format "MMddyyyy" #4 digit year
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ESXCustomAttributes-$TodaysDate.csv"
$CustomAttribChangeList = New-Object System.Collections.Generic.List[System.Object]

Clear-Host

#Notify the user of the format the CSV file must be in
Write-Host "IMPORTANT: The CSV file must have a header of ServerName which will include the ESX host names.  All other headers MUST match the name of the tag you wish to check or implement" -ForegroundColor Yellow
Read-Host "`nHit enter to continue"

#Added to support dialog box
Add-Type -AssemblyName System.Windows.Forms

#Display dialog box for the CSV file
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
    InitialDirectory = "c:\temp"
    Filter = "(*.csv) | *.csv"
}
$FileBrowser.ShowDialog() | Out-Null
$CustomAttributesFile = $FileBrowser.FileName

#If no file was selected
If ($CustomAttributesFile -eq $null) {
    Write-Host "No custom attribute file was selected.  Exiting"
    Break
}

#Retrieve data from the file
$CustomAttributesData = Import-CSV $CustomAttributesFile

#Store a list of all headers
$HeaderList = @()

#*****Get name of a List array column header*****
ForEach ($HeaderName in $CustomAttributesData[0].psobject.Properties.Name) {
    $HeaderList += $HeaderName
}

#Output the tags that will be checked or implemented
Write-Host "`nThe following tags will be checked for or implemented for $($CustomAttributesData.Count) ESX Hosts`n" -ForegroundColor Yellow
$HeaderList | Where { $_ -ne "ServerName" }
Read-Host "`nHit enter to begin checking"

#Get a list of all ESX hosts to check
$ServerList = $CustomAttributesData.ServerName

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"
#Retrieve a list of all ESX hosts and the vCenter server they are on
$ESXHostList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ESXHostList.csv"

#Gather data from just the ESX hosts that will be reviewed
$ESXHostTrimmedList = $ESXHostList | Where { $ServerList -contains $_.SystemName }

#If the vCenter password is passed then no need to prompt for it
If ($vCenterPassword -eq $null) {
    #Prompt for vCenter Password
    $vCenterPassword = Read-Host "Input the vCenter password" -MaskInput
}

#Exit if no password was entered
If ($vCenterPassword -eq $null) {
    Write-Host "`nNo password was entered so exiting the script" -ForegroundColor Red
    Break
}

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    $CurrentSystemName = $vCenterServer.ServerName
    Write-Host "`nCheck for ESX hosts on $CurrentSystemName" -ForegroundColor Cyan

    #Get a list of ESX hosts on this vCenter
    $ESXHostsOnThisvCenter = $ESXHostTrimmedList | Where { $_.vCenterServer -eq $CurrentSystemName }

    #If no ESX hosts were found then move onto the next vCenter
    If ($ESXHostsOnThisvCenter -eq $null) {
        Write-Host "`nNo ESX hosts on this vCenter"
        Continue
    }

    #Disconnected from all vCenter Servers
    Try {
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    } Catch {}

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterPassword -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    #Connect to vCenter Server
    Connect-VIServer $CurrentSystemName -Credential $vCenterSecureCreds -ErrorAction SilentlyContinue | Out-Null
    
    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $CurrentSystemName })) {
        #Disconnect from all vCenter Servers
        Write-Host "`nFailed to connect to vCenter Server $CurrentSystemName" -ForegroundColor Red
        Break
    }

    #Loop through each ESX Host
    ForEach ($ESXHost in $ESXHostsOnThisvCenter) {
        Write-Host "`nChecking $($ESXHost.SystemName)"

        #Get the Custom Attribute data fro the ESX host
        $ESXHostCustomAttribData = Get-VMHost $ESXHost.SystemName | Get-Annotation

        #Get the new ESX data
        $NewESXHostAttribData = $CustomAttributesData | Where { $_.ServerName -eq $ESXHost.SystemName }

        #Loop through each Attribute check
        ForEach ($ColumnHeader in $NewESXHostAttribData.psobject.Properties.Name) {
            #If this is the ServerName column header then skip it
            If ($ColumnHeader -eq "ServerName") {
                Continue
            }

            #Record the data that should be in the Custom Attribute field
            $AttribDataCheck = $NewESXHostAttribData.$ColumnHeader

            #If the data being checked for isn't valid data then skip it
            If ($AttribDataCheck -eq "" -or $AttribDataCheck -eq $null -or $AttribDataCheck -eq "-") {
                Continue
            }

            #Get the current value for this Custom Attribute
            $AttribCurrentValue = ($ESXHostCustomAttribData | Where { $_.Name -eq $ColumnHeader }).Value

            #If the attribute doesn't exist
            If ($AttribCurrentValue -eq $null) {
                #Notify user of the new custom attribute being made
                Write-Host "$($ESXHost.SystemName) will have $ColumnHeader added with a value of $AttribDataCheck"

                #Create a new Custom Attribute on all ESX hosts on the vCenter server
                New-CustomAttribute -TargetType VMHost -Name $ColumnHeader | Out-Null

                #Set the attribute name
                Get-VMHost $ESXHost.SystemName | Set-Annotation -CustomAttribute $ColumnHeader -Value $AttribDataCheck | Out-Null

                #Record the attribute change
                $CustomAttribChangeList.add((New-Object "psobject" -Property @{"vCenterServer"=$vCenterServer.ServerName;"ESXHost"=$ESXHost.SystemName;"AttribName"=$ColumnHeader;"OldValue"=$AttribCurrentValue;"NewValue"=$AttribDataCheck}))
            } ElseIf ($AttribCurrentValue -ne $AttribDataCheck) { #If the value needs to get updated
                #If the current value is empty then set it to the word "blank"
                If ($AttribCurrentValue -eq "") {
                    $AttribCurrentValue = "blank"
                }

                #Notify user of the update being made
                Write-Host "$($ESXHost.SystemName) will have $ColumnHeader changed from $AttribCurrentValue to $AttribDataCheck"

                #Update the Custom Attribute
                Get-VMHost $ESXHost.SystemName | Set-Annotation -CustomAttribute $ColumnHeader -Value $AttribDataCheck | Out-Null

                #Record the attribute change
                $CustomAttribChangeList.add((New-Object "psobject" -Property @{"vCenterServer"=$vCenterServer.ServerName;"ESXHost"=$ESXHost.SystemName;"AttribName"=$ColumnHeader;"OldValue"=$AttribCurrentValue;"NewValue"=$AttribDataCheck}))
            }
        }
    }
}

#Disconnected from all vCenter Servers
Try {
    Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
} Catch {}

$CustomAttribChangeList | Select vCenterServer,ESXHost,AttribName,OldValue,NewValue | Export-CSV $ReportPath -NoTypeInformation -Force

Write-Host "Script completed.  Report output to $ReportPath" -ForegroundColor Green

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAAdRPom9IU4yj8
# Nd8v77OMFP2MzqcfJInKs2jJtx6jmaCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCC6oi87JsTwd9qI3kdOp62XKTnQR0A7RrQIH4tMIUrwZDANBgkq
# hkiG9w0BAQEFAASCAQBsoVyHyWWnAqfbfhgyr1V4KNLBKCzoX7pwcGCoQsxGT/T4
# KyDBX1XlfYNceEKtESazFAs46hG1ru4NqLHouwL0FymalSPLJZxhyKv2rIX2jUgj
# 0yMOcBGbKq/k7nX+OeYVBlOSwDJIMMIH8s9JJyY5tMoZNFzQYmGTW9ZItEXCHn6T
# d7bJXOf4WXiWaXgN8I2xL1FZRaZDdyQYjDJuDyGOzp4fYqNE5X/ASZ+oX62zFQ4q
# MY/44IU4XYdc1kd88JVoWN1pdn/il+NFoRLT7CHyE/9Qjl1WJs5KgkqEO2uR+g14
# FdqXZj2WXHLER8iwH18nsNFfR30Pyve+pWLBFqrA
# SIG # End signature block
