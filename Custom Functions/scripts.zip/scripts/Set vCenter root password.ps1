#PURPOSE: Set the root password through SSH on vCenter or ESX hosts

#CHANGELOG
#Version 1.00 - 12/03/24 - MDR - Initial version
#Version 1.01 - 12/06/24 - MDR - Added password complexity checks and a confirmation SSH connection after the new password was set
#Version 1.02 - 01/08/25 - MDR - Minor tweaks including renaming some variables

###NOTE: If a host fails to set the password then "chsh -s /bin/bash root" may need to be run on it to ensure it is set to automatically use Shell

#Add support for forms
Add-Type -AssemblyName System.Windows.Forms

Clear

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Verify PoshSSH module exists
$VerifyPoshSSHModule = Get-Command New-SSHSession -ErrorAction SilentlyContinue

#If PoshSSH doesn't exist then explain where to get it from and exit the script
If (!($VerifyPoshSSHModule)) {
    Write-Host "`nPoshSSH module not found" -ForegroundColor Red
    Write-Host "`nPoshSSH can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\Posh-SSH"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

Write-Host "Select the file with the list of systems to update the root password on"

#*****Prompt for dialog box*****
$FileBrowser = New-Object System.Windows.Forms.OpenFileDialog -Property @{ 
    InitialDirectory = "c:\temp"
    Filter = "(*.txt) | *.txt"
}
$FileBrowser.ShowDialog() | Out-Null
$ServerListPath = $FileBrowser.FileName

#Version 1.02 - If there are no servers selected then exit
If ($ServerListPath -eq $null) {
    Write-Host "`nNo servers were selected.  Exiting"
    Break
} Else {
    #Store the server list
    $ServerList = Get-Content $ServerListPath
    
    Write-Host "`n$($ServerList.Count) systems will have their root passwords updated"
}

#Get the SSH password
$SSHCurrentPassword = Read-Host "`nEnter the CURRENT SSH password or if they are different for each system then leave blank"

#Get the new password
$SSHNewPassword = Read-Host "`nEnter the NEW SSH password"

#Version 1.01 - Verify new password is at least 15 characters long
If ($SSHNewPassword.Length -lt 15) {
    Write-Host "`nThe password needs to be at least 15 characters long"
    Break
} ElseIf ($SSHNewPassword -cnotmatch "[A-Z]") { #Verify new password has uppercase letters
    Write-Host "`nThe password needs uppercase letters"
    Break
} ElseIf ($SSHNewPassword -cnotmatch "[a-z]") { #Verify new password has lowercase letters
    Write-Host "`nThe password needs lowercase letters"
    Break
} ElseIf ($SSHNewPassword -notmatch "[0-9]") { #Verify new password has numerical characters
    Write-Host "`nThe password needs numerical characters"
    Break
} ElseIf ($SSHNewPassword -notmatch "[^a-zA-Z0-9]") { #Verify new password has special characters
    Write-Host "`nThe password needs special characters"
    Break
} Else {
    Write-Host "`nConfirmed that the new password meets all complexity requirements" -ForegroundColor Cyan

    #Store the password to a PSCredential
    $SecureSystemPassword = ConvertTo-SecureString $SSHNewPassword -AsPlainText -Force
    $NewSystemCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecureSystemPassword )
}

#Loop through each server
ForEach ($ServerName in $ServerList) {
    Write-Host "`nPreparing to change password for $ServerName"

    #Check password
    If ($SSHCurrentPassword -eq "" -or $SSHCurrentPassword -eq $null) {
        #Get the SSH password
        $SSHCurrentPasswordFinal = Read-Host "`nEnter the current SSH password for $ServerName"
    } Else {
        $SSHCurrentPasswordFinal = $SSHCurrentPassword
    }

    #Store the password to a PSCredential
    $SecureSystemPassword = ConvertTo-SecureString $SSHCurrentPasswordFinal -AsPlainText -Force
    $SystemCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecureSystemPassword )

    #Start the SSH Session
    $SSHSession = New-SSHSession -HostName $ServerName -Credential $SystemCreds -AcceptKey -Force -WarningAction SilentlyContinue

    #Verify the connection worked
    If ($SSHSession.Connected -ne "True") {
        Read-Host "`nFailed to connect to SSH on $ServerName" -ForegroundColor Red
        Continue
    }

    #Update the password
    (Invoke-SSHCommand -SessionId $SSHSession.SessionID -Command "echo 'root:$SSHNewPassword' | sudo chpasswd").Output

    #Remove any SSH connections
    Get-SSHSession | Remove-SSHSession | Out-Null

    #Version 1.01 - Test that the new password was set properly
    $SSHSession = New-SSHSession -HostName $ServerName -Credential $NewSystemCreds -AcceptKey -Force -WarningAction SilentlyContinue

    #Verify the connection worked
    If ($SSHSession.Connected -ne "True") {
        Read-Host "`nFailed to connect to SSH on $ServerName with the new password" -ForegroundColor Red
        Break
    } Else {
        Write-Host "`nVerified that the new password worked on $ServerName" -ForegroundColor Cyan
    }

    #Remove any SSH connections
    Get-SSHSession | Remove-SSHSession | Out-Null
}

Write-Host "`nScript Complete" -ForegroundColor Green

Write-Host "`nNOTE: Remember to update the vCenter Root Creds variable in Orchestrator and KeePass with the new password" -ForegroundColor Yellow

# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDtAO6wK0SjF3eR
# H/r7lxt47v2pXJpb3sq/tIB+KgcyWaCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAKKU8OSxnEsEHaocyeBuRoxfQKGwQdS/MsYv+x9ymHDDANBgkq
# hkiG9w0BAQEFAASCAQCLLISv0cinxh5Q7bxEgy8DNGUC23XBfZtIP3+NNG7EYnmB
# T0JtW1xSVufIp7HjLV9b6g02K7/BO2dY/+N9L/EgTsxijuMpK1t83QEkiErit70/
# rv4C53h4L7JlSevDuP4RX1Eh7wS4AN81Jp3RCtSr/TgDLLN6lPh2Sic/JiD7gHKY
# 8X5QCrsY7nw/3q9r0qncB9AXY5peE5K7dWyo9z6EoQHqOICjPgROUq9AN14zVJl6
# +g2/IyfMk2tH89Vd6iaelmGZ8RChQXMKvJtwCy5IyoSfke3l7aHxqWCcjcMlwzIt
# jH1lgaWu6e6PpQqgfR9BKbV+SC0V6ihAIKFMMF9v
# SIG # End signature block
