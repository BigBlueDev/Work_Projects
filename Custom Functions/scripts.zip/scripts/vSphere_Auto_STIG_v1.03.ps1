#PURPOSE: This script will automatically STIG vSphere items based off the spreadsheet vSphere_Auto_STIG_Parameters.xlsx

#CHANGELOG
#Version 1.00 - 10/22/24 - MDR - Initial version
#Version 1.01 - 10/24/24 - MDR - Remove the copy and move .ckl process
#Version 1.02 - 12/04/24 - MDR - Handle failures to connect to a single vCenter server more gracefully
#Version 1.03 - 01/08/25 - MDR - Ignorning HXVM systems since those only exist during HX cluster upgrades

Param ( $ParameterPath, $RunFromOrchestrator )

$FailureList = @() #Record any vCenter connection failures

#Only import parameters from file if run from Orchestrator
If ($RunFromOrchestrator -eq "True") {
    #Import Base64 passwords from CSV
    $Base64Passwords = Import-CSV $ParameterPath

    #Delete the CSV file since it is no longer needed and for security reasons
    Remove-Item $ParameterPath | Out-Null

    #Store passwords to temp variables
    $vCenterPasswordBase64 = $Base64Passwords.vCenterPassword
    $ESXPasswordBase64 = $Base64Passwords.ESXPassword
    $VRAPasswordBase64 = $Base64Passwords.VRAPassword

    #Decode passwords from Base64 to plain text
    $vCenterPassword = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($vCenterPasswordBase64))
    $ESXPassword = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($ESXPasswordBase64))
    $VRAPassword = [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($VRAPasswordBase64))
}

#Configure variables
$TodaysDate = Get-Date -Format "MMddyyyy" #Made this a 4 digit year
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports"
$AutoSTIGFinalReport = New-Object System.Collections.Generic.List[System.Object]
#Store STIG results as the script runs
$Global:STIGResultList = New-Object System.Collections.Generic.List[System.Object]
$AutoSTIGRun = "True" #Version 1.01 - Rather than using $RunFromOrchestrator to tip off other scripts that this is Auto STIG, changing to using $AutoSTIGRun

#Version 1.01 - If this is run from Orchestrator then run the scripts locally rather than over the network
If ($RunFromOrchestrator -eq "True") {
    $FolderPathToSTIGScript = "C:\DLA-Failsafe\vRA\MikeR"
} Else { #Otherwise run from the network
    $FolderPathToSTIGScript = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR"
}

Clear

#Create a transcript file
Start-Transcript C:\Temp\vSphere_Auto_STIG_$TodaysDate.txt

#Allow multiple connections to vCenter Servers which is required for this script
Set-PowerCLIConfiguration -DefaultVIServerMode Multiple -Confirm:$false | Out-Null
Set-PowerCLIConfiguration -Scope User -ParticipateInCEIP $false -Confirm:$false | Out-Null

#If this is run from Orchestrator then generate a credential to perform the PSDrive mapping
If ($RunFromOrchestrator -eq "True") {
    #Convert the VRA password to a secure string
    $VRACred = New-Object System.Management.Automation.PSCredential -ArgumentList @("DIR\svc_vrapsh",(ConvertTo-SecureString -String $VRAPassword -AsPlainText -Force))
    #Map a drive to the ReportPath
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -Credential $VRACred | Out-Null
} Else { #If not run from Orchestrator then just map the PSDrive with current credentials
    New-PSDrive -Name "ReportPath" -PSProvider FileSystem -Root $ReportPath -ErrorAction SilentlyContinue | Out-Null
}

#Check for PowerShell 7.x.  If running an older version then exit the script
If ($PSVersionTable.PSVersion -lt [Version]"7.0.0") {
    Write-Host "You are running PowerShell version $($PSVersionTable.PSVersion) and at least 7.x is required"
    Break
}

#Check to see if ImportExcel is installed
$CheckForImportExcel = Get-Command Import-Excel -ErrorAction SilentlyContinue

#If ImportExcel is not found then prompt for folder Where it is located
If (!$CheckForImportExcel) {
    Write-Host "The ImportExcel module is required for this script to run" -ForegroundColor Red
    Write-Host "`nA copy of this module is located in \\orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\Software\ImportExcel"
    Write-Host "`nPlace a copy of this module in C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#Verify PoshSSH module exists
$VerifyPoshSSHModule = Get-Command New-SSHSession -ErrorAction SilentlyContinue

#If PoshSSH doesn't exist then explain where to get it from and exit the script
If (!($VerifyPoshSSHModule)) {
    Write-Host "`nPoshSSH module not found" -ForegroundColor Red
    Write-Host "`nPoshSSH can be found here: \\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Software & ISOs\Coding Software\PowerShell Software\Posh-SSH"
    Write-Host "The module has to be copied to C:\Program Files\WindowsPowerShell\Modules"
    Break
}

#If the vCenter password is passed then no need to prompt for it
If ($vCenterPassword -eq $null) {
    #Prompt for vCenter Password
    $vCenterPassword = Read-Host "`nInput the vCenter password" -MaskInput
}

#Exit if no password was entered
If ($vCenterPassword -eq $null) {
    Write-Host "`nNo password was entered so exiting the script" -ForegroundColor Red
    Break
}

#If the ESX password is passed then no need to prompt for it
If ($ESXPassword -eq $null) {
    #Prompt for vCenter Password
    $ESXPassword = Read-Host "`nInput the ESX password" -MaskInput
}

#Exit if no password was entered
If ($ESXPassword -eq $null) {
    Write-Host "`nNo password was entered so exiting the script" -ForegroundColor Red
    Break
}

#Importing data for the script
Write-Host "`nImporting data"

#Generate ESX host credentials
$SecureSystemPassword = ConvertTo-SecureString $ESXPassword -AsPlainText -Force
#Store this as Global since it will get used by ESX STIG Mitigation.ps1
$Global:ESXSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecureSystemPassword )

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"
#Get info for each type of STIG (ie info on the Parameters and script locations for VM, ESX, and Photon OS STIGs)
$STIGScriptInfo = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\STIG_Script_Info.csv" 

#Get the ESX STIG Info
$ESXSTIGInfo = $STIGScriptInfo | Where { $_.STIGType -eq "ESX" }
#Get the VM Info
$VMSTIGInfo = $STIGScriptInfo | Where { $_.STIGType -eq "VM" }

#Get the ESX STIG Parameters
$ESXSTIGParams = Import-Excel $ESXSTIGInfo.ParmetersPath -WorksheetName *
#Get the VM STIG Parameters
$VMSTIGParams = Import-Excel $VMSTIGInfo.ParmetersPath -WorksheetName *
#Get list of Auto STIG Parameters
$AutoSTIGParams = Import-Excel "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\vSphere_Auto_STIG_Parameters.xlsx"

#Find a list of All scans for ESX
$ESXScanList = Get-ChildItem "$($ESXSTIGInfo.NetworkPath)\ESX scans" | Select Name, FullName, LastWriteTime
#Find a list of All scans for VM
$VMScanList = Get-ChildItem "$($VMSTIGInfo.NetworkPath)\VM scans" | Select Name, FullName, LastWriteTime

#Find the latest date for the ESX scans
$LatestESXScanDate = ((($ESXScanList | Where { $_.FullName -like "* - All" }).Name -Replace " - All", "") | ForEach { [PSCustomObject]@{'Name'=$_;'Date'=[DateTime]$_} } | Sort Date -Descending | Select -First 1).Name
#Find the latest date for the VM scans
$LatestVMScanDate = ((($VMScanList | Where { $_.FullName -like "* - All" }).Name -Replace " - All", "") | ForEach { [PSCustomObject]@{'Name'=$_;'Date'=[DateTime]$_} } | Sort Date -Descending | Select -First 1).Name

#Get the folder path to the latest ESX scan
$ESXLatestScanFolderPath = ($ESXScanList | Where { $_.Name -eq "$LatestESXScanDate - All" }).FullName
#Get the folder path to the latest VM scan
$VMLatestScanFolderPath = ($VMScanList | Where { $_.Name -eq "$LatestVMScanDate - All" }).FullName

#Version 1.01 - Change the ESX TempPath to be the network location of the .ckl files
Write-Host "`nESX CKL files from $ESXLatestScanFolderPath will be utilized for the STIG process"
$ESXSTIGInfo.TempPath = $ESXLatestScanFolderPath

#Version 1.01 - Change the VM TempPath to be the network location of the .ckl files
Write-Host "`nVM CKL files from $VMLatestScanFolderPath will be utilized for the STIG process"
$VMSTIGInfo.TempPath = $VMLatestScanFolderPath

#This function will be able to mitigate either ESX or VM checklists
Function MitigateItems ($CHKList, $SystemType, $STIGParams) {
    #When performing mitigations, store a list of status changes that get made as the script runs
    $Global:ListOfStatusUpdates = New-Object System.Collections.Generic.List[System.Object]

    #Get the Auto STIG parameters for this system type (ie ESX or VM)
    $CurrAutoSTIGParams = $AutoSTIGParams | Where { $_.System_Type -eq $SystemType }

    #Populate variables for progress bar
    $TotalSystems = $CHKList.Count
    $CurrentSystemNum = 1

    #Store a list of all findings that can be mitigated
    $Script:MitigationFindingArray = New-Object System.Collections.Generic.List[System.Object]

    #If this is run from Orchestrator then display which types of systems will be scanned
    If ($RunFromOrchestrator -ne "True") {
        Write-Host "`nChecking for $SystemType findings"
    }

    ForEach ($SystemCKL in $CHKList) {
        $Checklist_XML = New-Object XML
        $Checklist_XML.PreserveWhitespace = $true #This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
        $Checklist_XML.Load($SystemCKL.FullName) #Load the CKL file

        $SystemName = $Checklist_XML.CHECKLIST.ASSET.HOST_FQDN
        $SystemShortName = $Checklist_XML.CHECKLIST.ASSET.HOST_NAME
        $VULN_DATA = $Checklist_XML.CHECKLIST.STIGS.iSTIG.VULN

        #If for some reason the system name isn't recorded then pull it from the file name
        If ($SystemName -eq "") {
            $SystemName = (($SystemCKL.FullName -Split " STIG - ")[1] -Split "-")[0]
            $SystemShortName = ($SystemName.Split("."))[0]
        }

        #This SystemName gets used when closing out STIG findings
        $SystemCKL.SystemName = $SystemName

        #If this is not run from Orchestrator then display a progress bar
        If ($RunFromOrchestrator -ne "True") {
            #Update progress bar
            Write-Progress -Activity "Checking for $SystemType findings" -Status "$CurrentSystemNum of $TotalSystems" -PercentComplete ($CurrentSystemNum / $TotalSystems * 100)
        }

        #Look for NR or Open findings
        $VulnDataFiltered = $VULN_DATA | Where { $_.Status -eq "Open" }

        #Loop through the Checklist to see if there is data for each Vulnerability in the XCCDFData array
        ForEach ($VULN in $VulnDataFiltered) {
            $VulnArray = $VULN.STIG_DATA
            $VulnNumber = ($VulnArray | Where {$_.Vuln_Attribute -eq "Vuln_Num"}).ATTRIBUTE_DATA
            
            #If the VulnNumber is not an auto STIG V-Code then skip it
            If ($CurrAutoSTIGParams.Vuln_Num -notcontains $VulnNumber) {
                Continue
            } Else { #Notify that this item will be mitigated
                $CheckName = ($AutoSTIGParams | Where { $_.Vuln_Num -eq $VulnNumber }).Check_Name
                Write-Host "Queuing $SystemName - $VulnNumber - $CheckName for mitigation"
            }

            $VulnTitle = ($VulnArray | Where {$_.Vuln_Attribute -eq "Rule_Title"}).Attribute_Data
            $VulnFixText = ($VulnArray | Where {$_.Vuln_Attribute -eq "Fix_Text"}).Attribute_Data
            $VulnCheckContent = ($VulnArray | Where {$_.Vuln_Attribute -eq "Check_Content"}).Attribute_Data
            $VulnDiscuss = ($VulnArray | Where {$_.Vuln_Attribute -eq "Vuln_Discuss"}).Attribute_Data
            $VulnSeverity = $VulnArray | Where {$_.Vuln_Attribute -eq "Severity"}
            If ($Vuln.Comments.Length -gt 30000) { #If a comment is over about 32k then Excel lets it spill out into other fields
                $VulnComments = $Vuln.Comments.Substring(0,30000) 
            } Else {
                $VulnComments = $Vuln.Comments
            }

            #Check to see if this is a POAM item
            ForEach ($POAMItem in $STIGParams["POAMs"]) {
                #If this is a POAM item then mark it and exit the ForEach loop
                If ($VulnNumber -eq $POAMItem.Vuln_Num -and $SystemName -like "*$($POAMItem.Affected_Systems)*" ) {
                    $VULN.Status = "POAM"
                    $SystemName += " - POAM"
                    Break
                }
            }

            #Store findings to an array that will later be used by the mitigation script
            $Script:MitigationFindingArray.add((New-Object -TypeName "psobject" -property @{"SystemName"=$SystemName;"ShortName"=$SystemShortName;"VulnStatus"=$VULN.Status;"Severity"=$VulnSeverity.Attribute_Data;"VulnNumber"=$VulnNumber`
            ;"RuleTitle"=$VulnTitle;"Comments"=$VulnComments;"CKLFullPath"=$SystemCKL.FullName;"CKLFileName"=$SystemCKL.name}))

            #Store data for the final report
            $AutoSTIGFinalReport.add((New-Object -TypeName "psobject" -property @{"SystemName"=$SystemName;"SystemType"=$SystemType;"vCenterServer"=$vCenterServer.ServerName;"VulnNumber"=$VulnNumber;"CheckName"=$CheckName;"OrigVulnStatus"=$VULN.Status}))
        }

        #Increment the progress bar counter
        $CurrentSystemNum++
    }

    #Close the progress bar
    Write-Progress -Activity "Checking for $SystemType findings" -Completed

    #If there are findings to mitigate
    If ($MitigationFindingArray -ne $null) {
        #Notify user of how many findings will be mitigated
        Write-Host "`n$($MitigationFindingArray.Count) $SystemType findings will be mitigated"

        #Store the parameters for the mitigation script
        $parms = @{
            FindingsList = $MitigationFindingArray
            STIGParam = $STIGParams
            MitigationType = "Mitigate"
            RunFromOrchestrator = $RunFromOrchestrator
            AutoSTIGRun = $AutoSTIGRun
        }

        #Get the mitigation script path based on system type
        If ($SystemType -eq "ESX") {
            $MitigateScriptPath = $ESXSTIGInfo.MitigateScriptPath
        } ElseIf ($SystemType -eq "VM") {
            $MitigateScriptPath = $VMSTIGInfo.MitigateScriptPath
        }

        #If this is run from Orchestrator then run the check script from a local copy rather than a network one
        If ($RunFromOrchestrator -eq "True") {
            #Split by folder and files names
            $ScriptPathSplit = $MitigateScriptPath -split "\\"
            #Get the file name of the script
            $ScriptName = $ScriptPathSplit[$ScriptPathSplit.Count - 1]
            #Run the STIG Check.ps1 script from a local copy
            Invoke-Expression -Command ("& ""C:\DLA-Failsafe\vRA\MikeR\$ScriptName"" @parms")
        } Else {
            #Run the mitigation script
            Invoke-Expression -Command ("& '$MitigateScriptPath' @parms")
        }

        #Notify user of how many findings will be closed
        Write-Host "`n$($MitigationFindingArray.Count) $SystemType findings will be closed.  This can take a significant amount of time when updating ckl files over the network"

        #Store the parameters for the close STIG findings script
        $parms = @{
            SystemChecklists = $CHKList
            ListOfStatusUpdates = $ListOfStatusUpdates
        }

        #Run the close STIG findings script
        Invoke-Expression -Command ("& '$FolderPathToSTIGScript\CloseSTIGFindings.ps1' @parms")
    } Else {
        #Notify user that no mitigations are needed
        Write-Host "`nNo $SystemType findings found"
    }
}

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    #Output vCenter Server name
    Write-Host "`nMitigating items on vCenter Server $($vCenterServer.ServerName)" -ForegroundColor Cyan

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterPassword -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    #Disconnected from all vCenter Servers
    Try {
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    } Catch {}

    #Connect to vCenter Server
    Connect-VIServer $vCenterServer.ServerName -Credential $vCenterSecureCreds -ErrorAction SilentlyContinue | Out-Null
    
    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServer.ServerName })) {
        #Disconnect from all vCenter Servers
        Write-Host "`nFailed to connect to vCenter Server $($vCenterServer.ServerName)" -ForegroundColor Red
        $FailureList += [PSCustomObject]@{"SystemName"=$vCenterServer.ServerName;"Error"="Failed to connect to vCenter Server"}
        Continue #Version 1.02 - Changed from Break to Continue
    }

    #Get a list of all ESX hosts that have checklists for this vCenter server
    $ESXCKLList = Get-ChildItem "$($ESXSTIGInfo.TempPath)\$($vCenterServer.ServerName)" | Select Name, FullName, @{Name="SystemName";Expression={""}}, @{Name="TempPath";Expression={$_.FullName}}
    #Get a list of all VMs that have checklists for this vCenter server.  For now vCLS systems are excluded.  HXVM will always be excluded since these are created during cluster upgrades
    $VMCKLList = Get-ChildItem "$($VMSTIGInfo.TempPath)\$($vCenterServer.ServerName)" | Where { $_.Name -notlike "*vCLS-*" -and $_.Name -notlike "*HXVM-*" } | Select Name, FullName, @{Name="SystemName";Expression={""}}, @{Name="TempPath";Expression={$_.FullName}}

    #Mitigate ESX hosts based on checklists
    MitigateItems $ESXCKLList "ESX" $ESXSTIGParams
    #Mitigate VMs based on checklists
    MitigateItems $VMCKLList "VM" $VMSTIGParams
}

#Notify that the STIG checks are now completed
Write-Host "`nMitigations completed.  Generating reports."

#Version 1.02 - Do a try just in case there is no vCenter server to disconnect from
Try {
    #Disconnect from vCenter
    Disconnect-VIServer -Server * -Confirm:$false
} Catch { }

#Version 1.02 - Output failures
If ($FailureList -ne $null -and $FailureList -ne "") {
    Write-Host "`nThe below vCenter servers failed to connect:`n"
    $FailureList
}

#Export Auto STIG report
$AutoSTIGFinalReport | Select "SystemName","SystemType","vCenterServer","VulnNumber","CheckName","OrigVulnStatus" | Export-Excel "$ReportPath\AutoSTIGReport-$TodaysDate.xlsx" -AutoSize

Write-Host "`nScript Complete.  Report written to $ReportPath\AutoSTIGReport-$TodaysDate.xlsx" -ForegroundColor Green

#*****Send email*****
$smtpServer = "164.87.32.17"
$senderEmail = "NoReply_AutoSTIGReport@dla.mil"
$recipientEmail = @("joseph.nicklous@dla.mil", "carlton.parker.ctr@dla.mil", "kenneth.smith.ctr@dla.mil")
$CCEmail = @("john.siegrist@dla.mil", "casey.wyckoff@dla.mil", "michael.d.russcher@dla.mil")
$subject = "Auto STIG Report - $TodaysDate"
$body = "Attached are the STIGs findings that were mitigated by the Auto STIG script"
$attachment = "$ReportPath\AutoSTIGReport-$TodaysDate.xlsx"
Send-MailMessage -To $recipientEmail -CC $CCEmail -From $senderEmail -Subject $subject -Body $body -SmtpServer $smtpServer -Port 25 -Attachments $attachment

#Stop the transcript
Stop-Transcript
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAg1xih2Q/GQmvI
# La1IT/FstCDcEV33gGtnJtLzp0An06CCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAgLE9TmUJ9pkHJWynUjOAe7JwmOGgnzt+jenOFBS8DDzANBgkq
# hkiG9w0BAQEFAASCAQBaYvUEYg6VxAb3XLbj809W5klgi/tRetbi+nSfzdvxZ0oG
# 853OmyZtlUfXX3HOz61l/hJZHukp8c7fcFTe9oQ6Zns6H10xRrGpOWXhRYcd00z6
# XhK+auysnuRHf9Opl35mRW2h1OgXcy88eiopNRpxdJ15y6hDIPWIOCzIUn6VAPYZ
# t1RwWppx3ZSM9AzHXic2gp8FxbnscjjIRW3h4vS5v6SZ0xK+l5N+1Dp04Ipz7sG+
# ejUQmipxod7D6glfd9WxLJxqPiXdXc/Hdb/K6LLDC6ImAaeFFAGUYvKvZE70Gpow
# fGZ8g/zIG1781GN/UGO8vtIRP0SJcXxlXGmzOulJ
# SIG # End signature block
