#PURPOSE: Convert .ckl files into .cklb so that they are compatible with STIG Viewer 3.  The original files will remain in place and a new folder will be created for the .cklb files to be generated

#CHANGELOG
#Version 1.00 - 12/19/2024 - MDR - Initial version

$ChecklistFolderPath = "\\orgaze.dir.ad.dla.mil\dcc\VirtualTeam\STIGs\VMware\vSphere 7\Checklists"
$DefaultPath = "\\orgaze.dir.ad.dla.mil\dcc\VirtualTeam\STIGs\VMware\vSphere 7\Completed Checklists"
$TempFolderPath = "c:\temp\CKLB"

Clear-Host

Write-Host "Select the folder that you want to convert all .ckl files to .cklb"
Write-Host "`nNOTE: If you selected a folder that has subfolders, those subfolders will be processed as well"

#Added to support DoEvents which is utilized in STIG Check.ps1
Add-Type -AssemblyName System.Windows.Forms

#Display a folder dialog box
$FolderBrowser = New-Object System.Windows.Forms.FolderBrowserDialog -Property @{ 
    SelectedPath = $DefaultPath
    Description = "Select the Checklist folder"
    RootFolder = "MyComputer"
}

#If OK is selected
If ($FolderBrowser.ShowDialog((New-Object System.Windows.Forms.Form -Property @{ TopMost = $true })) -eq "OK") {
    $SelectedFolderPath = $FolderBrowser.SelectedPath
} Else {
    Write-Host "No folder path was selected"
    Break
}

#Build a folder layout to get all folder names that will be processed
$FolderLayout = @()
$FolderLayout += $SelectedFolderPath

#Get the folder structure of the selected folder
$FolderLayout += (Get-ChildItem $SelectedFolderPath -Directory -Recurse).FullName

#If there are subfolders then verify that the user is aware of this and wants to process them all
If ($FolderLayout.Count -gt 1) {
    Write-Host "`nThe script will generate .cklb files for all .ckl files in the following directories:`n"
    $FolderLayout
    Read-Host "`nHit enter to continue"
}

#Loop through all folders
ForEach ($FolderName in $FolderLayout) {
    Write-Host "`nChecking folder $FolderName"

    #Get the folder structure of the selected folder
    $FileLayout = Get-ChildItem $FolderName -File

    #Populate variables for progress bar
    $TotalFiles = $FileLayout.Count
    $CurrentFile = 1

    #If there is at least one file that will need to be converted then determine the folder name that will be used to store the converted files
    If ($TotalFiles -ge 1) {
        #Determine the name of the folder to write to
        $SplitFolderName = $FolderName -Split "\\"
        $SplitFolderCount = $SplitFolderName.Count

        #Generate the new folder path
        $NewFolderPath = "$DefaultPath\CLKB\$($SplitFolderName[$SplitFolderCount-2])\$($SplitFolderName[$SplitFolderCount-1])"

        #If the folder doesn't exist then create it
        If (!(Test-Path $NewFolderPath)) {
            New-Item $NewFolderPath -ItemType Directory | Out-Null
        }

        #If the folder doesn't exist then create it
        If (!(Test-Path $TempFolderPath)) {
            New-Item $TempFolderPath -ItemType Directory | Out-Null
        }
    }

    #Loop through all files in the folder
    ForEach ($FileName in $FileLayout) {
        #Update progress bar
        Write-Progress -Activity "Converting $($FileName.Name)" -Status "$CurrentFile of $TotalFiles" -PercentComplete ($CurrentFile / $TotalFiles * 100)

        #Create an XML object
        $Checklist_XML = New-Object XML
        #This needs to be done otherwise the STIG Viewer won't be able to open the file that gets created
        $Checklist_XML.PreserveWhitespace = $true
        #This is the name of the empty checklist template file
        $Checklist_XML.Load($FileName.FullName)

        #Get the version of the CKL that was used to create the file
        $CKLVersion = ($Checklist_XML.CHECKLIST.STIGS.iSTIG.STIG_INFO.SI_DATA | Where { $_.SID_NAME -eq "filename" }).SID_DATA
        $CKLVersion = $CKLVersion -Replace "Virtual_Machine","VM"
        #Split the version by "_"
        $CKLVerSplit = $CKLVersion -Split "_"

        #Perform replacements to help determine the name of the checklist that needs to get opened
        $CKLVerSplit[3] = $CKLVerSplit[3] -Replace "-","."
        $CKLVerSplit[4] = $CKLVerSplit[4] -Replace "ESXi","ESX"

        #Build the checklist file name
        $CKLBFileName = "$($CKLVerSplit[4]) $($CKLVerSplit[3]) $($CKLVerSplit[6]).cklb"
        $CKLBFilePath = "$ChecklistFolderPath\$CKLBFileName"
        
        #Confirm the cklb file exists
        If (!(Test-Path $CKLBFilePath)) {
            Write-Host "$CKLBFilePath was not found" -ForegroundColor Red
        }

        #Import the JSON data
        $Checklist_JSON = Get-Content $CKLBFilePath | ConvertFrom-Json

        #Move the asset data over to the JSON file
        $Checklist_JSON.TARGET_DATA.FQDN = $Checklist_XML.CHECKLIST.ASSET.HOST_FQDN
        $Checklist_JSON.TARGET_DATA.HOST_NAME = $Checklist_XML.CHECKLIST.ASSET.HOST_NAME
        $Checklist_JSON.TARGET_DATA.IP_ADDRESS = $Checklist_XML.CHECKLIST.ASSET.HOST_IP
        $Checklist_JSON.TARGET_DATA.MAC_ADDRESS = $Checklist_XML.CHECKLIST.ASSET.HOST_MAC

        #Open the CKL vuln data
        $CKL_VULN_DATA = $Checklist_XML.CHECKLIST.STIGS.iSTIG.VULN
        #Open the JSON vuln data
        $JSON_VULN_DATA = $Checklist_JSON.STIGS.RULES

        ForEach ($CKL_VULN in $CKL_VULN_DATA) {
            #Find the Vuln num
            $Vuln_Num = ($CKL_VULN.STIG_DATA | Where { $_.VULN_ATTRIBUTE -eq "Vuln_Num" }).ATTRIBUTE_DATA

            #Get the JSON record that has to be updated
            $JSON_VULN = $JSON_VULN_DATA | Where { $_.GROUP_ID -eq $Vuln_Num }

            #Verify whether vulnerability data was found for this vuln num
            If ($JSON_VULN -eq $null) {
                Write-Host "No vulnerability data found for $Vuln_Num"
                Continue
            }

            #Migrate vuln data over
            $JSON_VULN.COMMENTS = $CKL_VULN.COMMENTS
            #STIG Viewer 3 is CASE SENSITIVE!  This is why these renames occur despite them looking almost the same
            If ($CKL_VULN.STATUS -eq "NotAFinding") {
                $JSON_VULN.STATUS = "not_a_finding"
            } ElseIf ($CKL_VULN.STATUS -eq "Not_Reviewed") {
                $JSON_VULN.STATUS = "not_reviewed"
            } ElseIf ($CKL_VULN.STATUS -eq "Open") {
                $JSON_VULN.STATUS = "open"
            } ElseIf ($CKL_VULN.STATUS -eq "Not_Applicable") {
                $JSON_VULN.STATUS = "not_applicable"
            }
        }

        #Build the checklist file name
        $JSONFileName = $FileName.Name -Replace ".ckl",".cklb"
        $JSONFilePath = "$TempFolderPath\$JSONFileName"

        #Export the JSON data
        $Checklist_JSON | ConvertTo-Json -Depth 99 | Out-File $JSONFilePath -Encoding ascii

        #Increment the progress bar counter
        $CurrentFile++
    }

    #Close the progress bar
    Write-Progress -Activity "Converting $($FileName.Name)" -Completed

    #If there are files that need to get moved to the network
    If ($TotalFiles -ne 0) {
        #Transfer files from temp directory to network drive
        Write-Host "`nMoving $TotalFiles files to $NewFolderPath.  Please wait."
        Get-ChildItem -Path $TempFolderPath | Move-Item -Destination $NewFolderPath -Force
    }
}

Write-Host "`nScript complete.  All files have been moved to $DefaultPath\CLKB\$($SplitFolderName[$SplitFolderCount-2])" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAnG9bviIc/4shd
# vpveSruL1iSI68ZDi3YhNuT3ONJS/aCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCA0VbiI5Ojd7VtmZ0CoWhS/Frhm6LXZub9IsTGJrs+5EjANBgkq
# hkiG9w0BAQEFAASCAQBIsutyYnuFA235FwhpMLajNzL20bk543vqlexQLjKYvKAW
# ub4zT1A7KJ1+z7zniJfx+5EadGWCrMIcK3Vkm/KpJYXxjsPpcP1vUqHmXzUIIT7p
# DTRtXcuGrzwBKsRICG/aYkeIKOxn9oJ4Y/oocf/4Jckg2h3JcdfjiL/vKFzbX8hv
# GRGlwEy17+TYoQ4DyMKg2uqPVgj0Qd8ap7NKkzDWksHD2cQRdc3fpu+LQrC7SpmQ
# h/kInXa9VOi8z0jWQOqdHA7js4//zNd+Gh71buoXskFmQmZWmzYwwVuMivR1i/KF
# VkRE5e10Ax4yUVJELLM3z1gfkE0sV7dKxT7SFm8G
# SIG # End signature block
