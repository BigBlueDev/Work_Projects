#PURPOSE: Some findings don't have the STIG parameters as part of the main section of the spreadsheet but rather have a tab all their own.  This script handles those cases

#CHANGELOG
#Version 1.0 - 08/22/24 - MDR - Initial version
#Version 1.01 - 10/01/24 - MDR - Adding the word "Return" since Orchestrator seems to require it
#Version 1.02 - 10/01/24 - MDR - Found that the Firewall version of AltCheck works fine, but others get this wrong because it wasn't just returning the "lowest level" value such as Cluster

Param ( $AltCheckValue, $STIGParams, $CurrentSystemName, $SystemType )

$OutputArray = @()

$STIGParamsTabName = $AltCheckValue -replace "AltCheck ",""
$AltCheckData = $STIGParams[$STIGParamsTabName]
$AltCheckvCenterData = $AltCheckData | Where { $_.Environment -like "vCenter*" }
$AltCheckDatacenterData = $AltCheckData | Where { $_.Environment -like "Datacenter*"}
$AltCheckClusterData = $AltCheckData | Where { $_.Environment -like "Cluster*"}

If ($SystemType -eq "ESX") {
    $vCenterServerName = ((Get-VMHost $CurrentSystemName).ExtensionData.Client.ServiceURL -Split "/")[2]
    $DataCenterName = (Get-Datacenter -VMHost $CurrentSystemName).Name
    $ClusterName = (Get-Cluster -VMHost $CurrentSystemName).Name
} ElseIf ($SystemType -eq "VM") {
    $vCenterServerName = ((Get-VM $CurrentSystemName).ExtensionData.Client.ServiceURL -Split "/")[2]
    $DataCenterName = (Get-Datacenter -VM $CurrentSystemName).Name
    $ClusterName = (Get-Cluster -VM $CurrentSystemName).Name
}

#If the system finds a match at a lower level such as Cluster then don't also include matches at a higher level like vCenter
#Version 1.02 - Added " -and ($OutputArray.count -eq 0 -or $STIGParamsTabName -eq "Firewall")" to all If statements to ensure it only pulled the lowest level data UNLESS it is a firewall AltCheck
If ($AltCheckClusterData -ne $null -and ($OutputArray.count -eq 0 -or $STIGParamsTabName -eq "Firewall")) {
    $OutputArray += $AltCheckClusterData | Where { $_.Environment -like "Cluster - $ClusterName" }
}

If ($AltCheckDatacenterData -ne $null -and ($OutputArray.count -eq 0 -or $STIGParamsTabName -eq "Firewall")) {
    $OutputArray += $AltCheckDatacenterData | Where { $_.Environment -like "Datacenter - $DataCenterName" }
}

If ($AltCheckvCenterData -ne $null -and ($OutputArray.count -eq 0 -or $STIGParamsTabName -eq "Firewall")) {
    $OutputArray += $AltCheckvCenterData | Where { $_.Environment -like "vCenter - $vCenterServerName" }
}

If ($OutputArray.count -eq 0 -or $STIGParamsTabName -eq "Firewall") {
    $OutputArray += $AltCheckData | Where { $_.Environment -eq "All" }
}

If ($OutputArray.count -eq 0) {
    Write-Host "No $STIGParamsTabName AltCheck data found for $CurrentSystemName"
}

#Version 1.01 - Adding the word "Return"
Return $OutputArray
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCw/Na9EGr4Wg9f
# m7CyIEQwryTh3DXuRbnwuN+6yWi8CKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDEjVpjiaMTSRwnrg9DFLnNM2N5a14Qc4e6f+n6zgFCeTANBgkq
# hkiG9w0BAQEFAASCAQBhHoQ9O8r/euP5bQVvtMeTeJCKMxIzNY2CWWEpUote+kRS
# zP9A0+TRe7K46UCTom88gyrXewSN/AfAjrbQfLdhHTW11nPL4CnnwMj+GuPej+xU
# tmSGKasD3aZ+70w7MuYrURsJ+5DKy47xb+QnqXx9SO2Jr3XzVZWb+wINw/TkjNWn
# Xl4KD3bYffPhySSpCBx2ap7j5TT0FRTZNWPmTpTOZA13RewXsCCQ/u8Ev4Gyuota
# nWcuiyffhmEvF+2Q1nvC0XKPIMIAiY21kNEhimwM+Tr1rMv2nLUrVGqR6082Q6oo
# du4suRxCmVcbM6hhl80ShGDp1RvTOpSErCVZBBAN
# SIG # End signature block
