#PURPOSE: Configur the ACAS service account permissions on all ESX hosts

#CHANGELOG
#Version 1.00 - 07/02/24 - MDR - Initial version

#Configure variables
$TodaysDate = Get-Date -Format "MMddyy"
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ACASPermissions-$TodaysDate.csv"
$ACASPermissionsData = New-Object System.Collections.Generic.List[System.Object]

Clear

#Prompt for vCenter Password
$vCenterCreds = Read-Host "Input the vCenter password" -MaskInput

#Exit if no password was entered
If ($vCenterCreds -eq $null) {
    Break
}

#Prompt for vCenter Password
$ESXCreds = Read-Host "Input the ESX password" -MaskInput

#Exit if no password was entered
If ($ESXCreds -eq $null) {
    Break
}

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    #Output vCenter Server name
    Write-Host "`nScanning $($vCenterServer.ServerName)`n"

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterCreds -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    #If any vCenter servers are connected then disconnect them
    If ($global:DefaultVIServers) {
        #Disconnected from all vCenter Servers
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    }

    #Connect to vCenter Server
    Connect-VIServer $vCenterServer.ServerName -Credential $vCenterSecureCreds | Out-Null

    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServer.ServerName })) {
        #Disconnect from all vCenter Servers
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
        Write-Host "`nFailed to connect to vCenter Server $($vCenterServer.ServerName)" -ForegroundColor Red
        Break
    }

    #Get a list of all connected ESX hosts
    $ESXHostList = Get-VMHost | Where { $_.ConnectionState -eq "Connected" -or $_.ConnectionState -eq "Maintenance" }

    #Populate variables for progress bar
    $TotalESXHost = $ESXHostList.Count
    $CurrentESXNum = 1

    #Generate the ESX credentials to connect
    $SecurePassword = ConvertTo-SecureString $ESXCreds -AsPlainText -Force
    $ESXSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( "root", $SecurePassword )

    #Loop through each ESX host
    ForEach ($ESXHostName in $ESXHostList.Name){
        #Update progress bar
        Write-Progress -Activity "Getting permissions data" -Status "$CurrentESXNum of $TotalESXHost" -PercentComplete ($CurrentESXNum / $TotalESXHost * 100)

        #Connect to the ESX host
        Connect-VIServer $ESXHostName -Credential $ESXSecureCreds | Out-Null

        #Confirm that the connection worked
        If (!($global:DefaultVIServers | Where { $_.Name -eq $ESXHostName })) {
            Continue
        }

        #Get a list of all local permissions on the host
        $AllPermissions = Get-VIPermission -Server $ESXHostName

        #Get just the ACAS service permissions
        $ACASPermissions = $AllPermissions | Where { $_.Principal -like "*svc_acas*"}

        #If no ACAS service permissions are found then create them
        If ($ACASPermissions -eq $null) {
            #Get the Lockdown Mode Exceptions list
            $ESXHostView = Get-VMHost $ESXHostName | Get-View
            $LockdownView = Get-View $ESXHostView.ConfigManager.HostAccessManager
            $LockdownExceptions = $LockdownView.QueryLockdownExceptions()

            #If this is a DIR server then use svc_acas_gscan
            If ($ESXHostName -like "*.dir.ad.dla.mil") {
                Write-Host "Updating permissions on $ESXHostName"
                #If the ACAS service account isn't in the Lockdown Mode Exceptions list then add it
                If ($LockdownExceptions -notcontains "DIR\svc_acas_gscan") {
                    $LockdownExceptions += "DIR\svc_acas_gscan"
                    $LockdownView.UpdateLockdownExceptions($LockdownExceptions)
                }

                New-VIPermission -Entity (Get-Folder -Server $ESXHostName root) -Principal "DIR\svc_acas_gscan" -Role "ReadOnly" | Out-Null
                $ACASRole = "New - DIR ReadOnly"
            #If this is an ICS server then use svc_acas_iscan
            } ElseIf ($ESXHostName -like "*.ics.dla.mil") {
                Write-Host "Updating permissions on $ESXHostName"
                #If the ACAS service account isn't in the Lockdown Mode Exceptions list then add it
                If ($LockdownExceptions -notcontains "ICS\svc_acas_iscan") {
                    $LockdownExceptions += "ICS\svc_acas_iscan"
                    $LockdownView.UpdateLockdownExceptions($LockdownExceptions)
                }

                New-VIPermission -Entity (Get-Folder -Server $ESXHostName root) -Principal "ICS\svc_acas_iscan" -Role "ReadOnly" | Out-Null
                $ACASRole = "New - ICS ReadOnly"
            }
        } Else {
            $ACASRole = $ACASPermissions.Role
        }

        #Record the ACAS permissions info
        $ACASPermissionsData.add((New-Object "psobject" -Property @{"vCenterServer"=$vCenterServer.ServerName;"ESXServer"=$ESXHostName;"ACAS Service Permission"=$ACASRole}))

        #Disconnect from the ESX host
        Disconnect-VIServer $ESXHostName -Confirm:$false

        #Increment progress bar counter
        $CurrentESXNum++
    } #Finish looping through ESX hosts

    #Close the progress bar
    Write-Progress -Activity "Getting permissions data" -Completed
} #Finish looping through vCenter servers

#Export data to CSV
$ACASPermissionsData | Select vCenterServer,ESXServer,"ACAS Service Permission" | Export-CSV $ReportPath -NoTypeInformation -Force
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDRRu0wMEXo6VG0
# Wig8WoqEpfeO1l54x83T6MDsprUn0aCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCB2Ra4xeBJA2P1otweuaF0I3dCWTXSc6HmzWLafUINIXTANBgkq
# hkiG9w0BAQEFAASCAQBLoNOEBZx7oC8BIg/A+0ID0YL9ZHLgaceAxiJQjv4F5vnW
# nnHO2zzUhjbOR3RShIrpd/EByQXQm5zyowA/gVbKFPjoEGZ115jS5J51ll5kUQ9P
# UZxPxKiOFNlH8bWQnNEPrR9cKQiFW/xZpG/MY9YrxMmx64KlEXy+U5n05/hpu8VN
# cfdm2dZYn6vkPb3QRdji6ThflnL5//MWGSVPlIsd3LCYt6kf5YCX8OtotTsCnl+3
# MUMJF7LNeFPr/ufcT1PzXwBw5+gol1ch3xW4ULaXqyprGlXMtxKnaPNsau+qB0Yn
# Uvm6I4+S6/S7xCeJd9aHkigSfi+fO51lX9Llcrm+
# SIG # End signature block
