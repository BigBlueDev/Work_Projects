#PURPOSE: This script will collect info on an Advanced Setting across all ESX hosts and optionally set it to a specified value

#CHANGELOG
#Version 1.00 - 09/24/24 - MDR - Initial version

$ESXSettingData = New-Object System.Collections.Generic.List[System.Object]
$ReportPath = "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\STIGs\VMware\vSphere 7\Reports\ESX Advanced Settings Change.csv"

#If this report exists already then delete it
If (Test-Path $ReportPath) {
    Remove-Item $ReportPath
}

Clear

#Get the name of the setting to change
$AdvancedSettingName = Read-Host "Enter the Advanced Setting name (ie Security.PasswordMaxDays)"

#Get the value to change to
$NewAdvancedSettingValue = Read-Host "`nIf you want this Advanced Setting value changed then enter that here or leave blank to just collect data"

#Prompt for vCenter Password
$vCenterPassword = Read-Host "`nInput the vCenter password" -MaskInput

#Exit if no password was entered
If ($vCenterPass -eq $null) {
    Write-Host "`nNo password was entered so exiting the script"
    Break
}

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#Loop through each vCenter server
ForEach ($vCenterServer in $vCenterServerList) {
    #Output vCenter Server name
    Write-Host "`nScanning $($vCenterServer.ServerName)"

    #Generate the vCenter credentials to connect
    $SecurePassword = ConvertTo-SecureString $vCenterPassword -AsPlainText -Force
    $vCenterSecureCreds = New-Object System.Management.Automation.PSCredential -ArgumentList ( $vCenterServer.User, $SecurePassword )

    #Disconnected from all vCenter Servers
    Try {
        Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
    } Catch {}

    #Connect to vCenter Server
    Connect-VIServer $vCenterServer.ServerName -Credential $vCenterSecureCreds | Out-Null
    
    #Confirm that the connection worked
    If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServer.ServerName })) {
        #Disconnect from all vCenter Servers
        Write-Host "`nFailed to connect to vCenter Server $($vCenterServer.ServerName)" -ForegroundColor Red
        Break
    }

    #Get a list of all ESX hosts
    $ESXList = Get-VMHost | Sort Name

    #Populate variables for progress bar
    $TotalESXs = $ESXList.Count
    $CurrentESXNum = 1

    ForEach ($ESXHostName in $ESXList) {
        #Update progress bar
        Write-Progress -Activity "Getting ESX data" -Status "$CurrentESXNum of $TotalESXs" -PercentComplete ($CurrentESXNum / $TotalESXs * 100)

        #Get ESX Host VMHost data
        $VMHostData = Get-VMHost $ESXHostName

        #Check to see if ESX host is connected in vCenter
        If (@("Connected","Maintenance") -notcontains $VMHostData.ConnectionState) {
            Write-Host "$ESXHostName is not connected in vCenter $($vCenterServer.ServerName)" -ForegroundColor Yellow
            $ESXSettingData.add((New-Object "psobject" -Property @{"HostName"=$ESXHostName.Name;"SettingName"=$AdvancedSettingName;"StartingValue"="ESX Host not connected";"UpdatedValue"=""}))
            Continue
        }

        #Get the value of the Advanced setting as it currently stands
        $CurrentSettingValue = ($VMHostData | Get-AdvancedSetting -Name $AdvancedSettingName).Value

        #Check to see if the $CurrentSettingValue came back blank indicating an issue
        If ($CurrentSettingValue -eq $null) {
            Write-Host "`nNo such advanced setting value of $AdvancedSettingName exists on $($ESXHostName.Name)" -ForegroundColor Red
            $ESXSettingData.add((New-Object "psobject" -Property @{"HostName"=$ESXHostName.Name;"SettingName"=$AdvancedSettingName;"StartingValue"="No setting found";"UpdatedValue"=""}))
            Continue
        }

        #If there is a value entered for the new Advanced Setting and it needs to be updated
        If ($NewAdvancedSettingValue -ne $null -and $NewAdvancedSettingValue -ne "" -and $NewAdvancedSettingValue -ne $CurrentSettingValue) {
            #Set the new setting value
            $VMHostData | Get-AdvancedSetting -Name $AdvancedSettingName | Set-AdvancedSetting -Value $NewAdvancedSettingValue -Confirm:$false | Out-Null

            #Get the updated value
            $UpdatedSettingValue = ($VMHostData | Get-AdvancedSetting -Name $AdvancedSettingName).Value

            #Check to see if the update succeeded or failed and report the outcome
            If ($CurrentSettingValue -ne $UpdatedSettingValue) {
                Write-Host "Updated $AdvancedSettingName on $ESXHostName.Name from $CurrentSettingValue to $UpdatedSettingValue" -ForegroundColor Green
            } Else {
                Write-Host "Failed to udpate $AdvancedSettingName on $ESXHostName.Name from $CurrentSettingValue to $UpdatedSettingValue" -ForegroundColor Red
            }
        } Else { #If there was no update then reset this variable
            $UpdatedSettingValue = ""
        }

        #Log the current info
        $ESXSettingData.add((New-Object "psobject" -Property @{"HostName"=$ESXHostName.Name;"SettingName"=$AdvancedSettingName;"StartingValue"=$CurrentSettingValue;"UpdatedValue"=$UpdatedSettingValue}))

        #Increment the current ESX host number for the progress bar
        $CurrentESXNum++
    }

    #Close the progress bar
    Write-Progress -Activity "Getting ESX data" -Completed
}

Try {
    #Disconnected from all vCenter Servers
    Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
} Catch {}

Write-Host "`nOutputting report"

#Output data to report
$ESXSettingData | Select "HostName","SettingName","StartingValue","UpdatedValue" | Export-CSV $ReportPath -NoTypeInformation

#Notify that the script is completed
Write-Host "`nScript completed.  Report output to $ReportPath" -ForegroundColor Green
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCHOliyc1ZBnpWB
# u0NPIuQFLRQ/IPAkiO1PJiXoQBnCmKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAf5z6X5sQytaRp1KoR1mv5uAh92d1qQySCejfcaLdl9DANBgkq
# hkiG9w0BAQEFAASCAQAQVQs9eA1FKUGTHS2C0Koyzr2iBXp/tQCUVSWZduLaPz3W
# GvEW0oFEZpTOVYiYxbdWI4HDZWdK9DU50zpuU0a9ogT8//K+cUVURAGKyhb1gP/7
# uCc6Ccl5ORPDujdpp67LGoaeVQR/LlouK7XO8Ppv92/r18NPG5PKOISgQF9B7w7G
# KsH9KTrAVjzXg5VYs/iLeQhS6kL0246/K35q5BeWNVEtmZL0WDsKKJL0jpw/dixC
# jsFMQb4FDjY5k/y9PiU4I9MZPuBhR9mQrXdisPzPJoqRN7Hc84wBrQ+2LmY/g/qO
# OBWKKU3y4BmWDFEvs9sKJwvGfyhzjlI7WVaK/lSl
# SIG # End signature block
