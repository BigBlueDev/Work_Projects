#PURPOSE: This is a legacy script that was used in ESX 6 to update the firewall

#CHANGELOG
#Version 1.0 - 08/22/24 - MDR - Initial version

$esxhost = "trespen002.ics.dla.mil" #Enter the name of the host.  Using FQDN is optional since it only sets the name used by the ESX Scratch folder and is used to connect to the host in the script
$vMotion = "192.168.254.0/24"
$ESXManagementNetwork = "214.73.49.0/24" #This network needs to include all of the ESX host management IPs that it will be able to communicate with
$DNSServer1 = "131.78.255.254"
$DNSServer2 = "131.78.255.250"
$NTPServer1 = "131.78.1.253" #Normally 131.76.179.16 which is Dayton DC
$NTPServer2 = "131.78.41.253" #Normally 131.76.187.16 which is Tracy DC
$NTPServer3 = "131.78.174.121" #Normally empty
$VCSANetwork = "214.73.49.0/24" #Make sure this range covers the PSC & vCenter IPs
$vROPSNetwork = "131.76.181.0/24" #This just needs to include our vROPS IP
$iSCSI1 = "" #Usually this will be left blank unless iSCSI is in use
$iSCSI2 = "" #Usually this will be left blank unless iSCSI is in use
$FaultTolerance = "" #Usually this will be left blank unless Fault Tolerance is in use

connect-viserver $esxhost

Write-Host "Enable SSH"
Get-VMHost | Get-AdvancedSetting -Name UserVars.ESXiShellTimeOut | Set-AdvancedSetting -Value "600" -Confirm:$false #Ensures that SSH stays enabled for only 15 minutes after being started per STIG
Get-VMHostService | Where-Object {$_.Key -eq "TSM-SSH"} | Start-VMHostService #Starts the SSH service which is useful in case an issue occurs during this script and something needs to be backed out via SSH

Write-Host "Set Firewall"
Get-VMHostFirewallDefaultPolicy | Set-VMHostFirewallDefaultPolicy -AllowIncoming $false -AllowOutgoing $false

$esxcli = Get-EsxCli -V2 -VMHost $esxhost
$FirewallArgs = $esxcli.network.firewall.ruleset.set.createargs()
$FirewallArgs.enabled=$true #Should be set to TRUE to keep services enabled by default.  Another part of the script will disable a service if necessary
$FirewallArgs.allowedall=$false #Should be FALSE when enabling the STIG but can be set to true if you want to reverse the STIG
$IPArgs = $esxcli.network.firewall.ruleset.allowedip.add.createargs()

#Set firewall to "Only allow connections from the following networks" then set firewall "Allowed IP Addresses" for every service

Write-Host "SSH Server - sshServer"
$FirewallArgs.rulesetid="sshServer"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="sshServer"
$IPArgs.ipaddress="131.64.0.0/11"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="164.87.0.0/16" #EIS Admin
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "SSH Client - sshClient"
$FirewallArgs.rulesetid="sshClient"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "SSH Client" | Set-VMHostFirewallException -Enabled $False #sshClient is not used
Write-Host "Active Directory All - activeDirectoryAll"
$FirewallArgs.rulesetid="activeDirectoryAll"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="activeDirectoryAll"
$IPArgs.ipaddress="131.64.0.0/11"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="140.18.67.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="164.87.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="192.67.251.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="198.97.74.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="206.38.33.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.3.14.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "CIM Server - CIMHttpServer"
$FirewallArgs.rulesetid="CIMHttpServer"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="CIMHttpServer"
$IPArgs.ipaddress=$VCSANetwork #Whatever vCenter/VCSA the host is attached to
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$vROPSNetwork #vRops Server
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "CIM Secure Server - CIMHttpsServer"
$FirewallArgs.rulesetid="CIMHttpsServer"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="CIMHttpsServer"
$IPArgs.ipaddress=$VCSANetwork #Whatever vCenter/VCSA the host is attached to
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$vROPSNetwork #vRops Server
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "CIM SLP - CIMSLP"
$FirewallArgs.rulesetid="CIMSLP"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "CIM SLP" | Set-VMHostFirewallException -Enabled $False #CIM SLP (Service Location Protocol) is not used
Write-Host "DHCP Client - dhcp"
$FirewallArgs.rulesetid="dhcp"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "DHCP Client" | Set-VMHostFirewallException -Enabled $False #DHCP is not used
Write-Host "DHCPv6 - DHCPv6"
$FirewallArgs.rulesetid="DHCPv6"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "DHCPv6" | Set-VMHostFirewallException -Enabled $False #DHCP is not used
Write-Host "DNSClient - dns"
$FirewallArgs.rulesetid="dns"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="dns"
$IPArgs.ipaddress=$DNSServer1
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$DNSServer2
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "DVFilter - DVFilter"
$FirewallArgs.rulesetid="DVFilter"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "DVFilter" | Set-VMHostFirewallException -Enabled $False #DVFilter is not used
Write-Host "DVSSync - DVSSync"
$FirewallArgs.rulesetid="DVSSync"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="DVSSync"
$IPArgs.ipaddress=$FaultTolerance
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
#Get-VMHost | Get-VMHostFirewallException "DVSSync" | Set-VMHostFirewallException -Enabled $False #DVSSync is only required if using VM Fault Tolerance in which case it needs to be able to communicate between hosts
Write-Host "exsupdate - esxupdate"
$FirewallArgs.rulesetid="esxupdate"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="esxupdate"
$IPArgs.ipaddress=$VCSANetwork
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Get-VMHost | Get-VMHostFirewallException "esxupdate" | Set-VMHostFirewallException -Enabled $False #esxupdate refers to the "esxupdate" command which can be run in SSH.  It is not used in our environment
Write-Host "Fault Tolerance - faultTolerance"
$FirewallArgs.rulesetid="faultTolerance"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="faultTolerance"
$IPArgs.ipaddress=$FaultTolerance
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
#Get-VMHost | Get-VMHostFirewallException "Fault Tolerance" | Set-VMHostFirewallException -Enabled $False #faultTolerance is only required if using VM Fault Tolerance in which case it needs to be able to communicate between hosts
Write-Host "FTP Client - ftpClient"
$FirewallArgs.rulesetid="ftpClient"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "FTP Client" | Set-VMHostFirewallException -Enabled $False #ftpClient is not used
Write-Host "gdbserver - gdbserver"
$FirewallArgs.rulesetid="gdbserver"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "gdbserver" | Set-VMHostFirewallException -Enabled $False #gdbserver (aka GNU Debugger) is used for debugging Linux/Unix code
Write-Host "HBR - HBR"
$FirewallArgs.rulesetid="HBR"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "HBR" | Set-VMHostFirewallException -Enabled $False #HBR is used for vSphere Replication and VMware Site Recovery Manager.  Not used in our environment
Write-Host "httpClient - httpClient"
$FirewallArgs.rulesetid="httpClient"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "httpClient" | Set-VMHostFirewallException -Enabled $False #httpClient-Not sure what this does but it is disabled by default and only does Outgoing traffic
Write-Host "IKED - IKED"
$FirewallArgs.rulesetid="IKED"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "IKED" | Set-VMHostFirewallException -Enabled $False #IKED (aka IKE Daemon) is used for IPsec key exchange.  Not used in our environment
Write-Host "iofiltervp - iofiltervp"
$FirewallArgs.rulesetid="iofiltervp"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="iofiltervp"
$IPArgs.ipaddress=$VCSANetwork
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "NFC - NFC"
$FirewallArgs.rulesetid="NFC"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs) #NFC is required for being able to view the console.  Needs to be open for all Juniper and internal DLA addresses
$IPArgs.rulesetid="NFC"
$IPArgs.ipaddress="10.0.0.0/8"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="131.64.0.0/11"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="164.87.0.0/16" #EIS Admin
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="172.17.0.0/16" #Dayton
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="172.19.0.0/16" #Tracy
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="192.67.252.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="192.168.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="198.97.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="199.10.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.7.44.0/22"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.17.194.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.73.0.0/16" #Dev and ICS
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "NFS Client - nfsClient"
$FirewallArgs.rulesetid="nfsClient"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "NFS Client" | Set-VMHostFirewallException -Enabled $False #nfsClient is not used
Write-Host "nfs41Client - nfs41Client"
$FirewallArgs.rulesetid="nfs41Client"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "nfs41Client" | Set-VMHostFirewallException -Enabled $False #nfs41Client is not used
Write-Host "NSX Distributed Logical Router Service - ipfam"
$FirewallArgs.rulesetid="ipfam"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "NSX Distributed Logical Router Service" | Set-VMHostFirewallException -Enabled $False #NSX Distributed Logical Router Service is not used
Write-Host "NTP Client - ntpClient"
$FirewallArgs.rulesetid="ntpClient"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="ntpClient"
$IPArgs.ipaddress=$NTPServer1
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$NTPServer2
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$NTPServer3
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "rabbitmqproxy - rabbitmqproxy"
$FirewallArgs.rulesetid="rabbitmqproxy"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "rabbitmqproxy" | Set-VMHostFirewallException -Enabled $False #rabbitmqproxy allows applications within VMs to communicate with AMQP brokers, bypassing the VM NIC.  Not used in our environment
Write-Host "Replication-to-Cloud Traffic - Replication-to-Cloud Traffic"
$FirewallArgs.rulesetid="Replication-to-Cloud Traffic"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "Replication-to-Cloud Traffic" | Set-VMHostFirewallException -Enabled $False #Replication-to-Cloud Traffic is not used
Write-Host "SNMP Server - snmp"
$FirewallArgs.rulesetid="snmp"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "SNMP Server" | Set-VMHostFirewallException -Enabled $False #snmp is disabled by STIG
Write-Host "Software iSCSI Client - iSCSI"
$FirewallArgs.rulesetid="iSCSI"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="iSCSI"
$IPArgs.ipaddress=$iSCSI1
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$iSCSI2
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "syslog - syslog"
$FirewallArgs.rulesetid="syslog"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="syslog"
$IPArgs.ipaddress="131.64.0.0/11" #All DIR Syslog servers
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.73.0.0/16" #All ICS Syslog servers
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "vCenter Update Manager - updateManager"
$FirewallArgs.rulesetid="updateManager"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="updateManager"
$IPArgs.ipaddress=$VCSANetwork
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "Virtual SAN Clustering Service - cmmds"
$FirewallArgs.rulesetid="cmmds"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "vSAN Clustering Service" | Set-VMHostFirewallException -Enabled $False #VSAN is not used
Write-Host "Virtual SAN Transport - rdt"
$FirewallArgs.rulesetid="rdt"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "vSAN Transport" | Set-VMHostFirewallException -Enabled $False #VSAN is not used
Write-Host "VM serial port connected over network - remoteSerialPort"
$FirewallArgs.rulesetid="remoteSerialPort"
#$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "VM serial port connected over network" | Set-VMHostFirewallException -Enabled $False #Remote Serial Port is not used
Write-Host "VM serial port connected to vSPC - vSPC"
$FirewallArgs.rulesetid="vSPC"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "VM serial port connected to vSPC" | Set-VMHostFirewallException -Enabled $False #Serial Ports to vSPC is not used
Write-Host "vMotion - vMotion"
$FirewallArgs.rulesetid="vMotion"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="vMotion"
$IPArgs.ipaddress=$vMotion
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "Vmware vCenter Agent - vpxHeartbeats"
$FirewallArgs.rulesetid="vpxHeartbeats"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="vpxHeartbeats"
$IPArgs.ipaddress=$ESXManagementNetwork
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress=$VCSANetwork #Whatever vCenter/VCSA the host is attached to
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "vprobeServer - vprobeServer"
$FirewallArgs.rulesetid="vprobeServer"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "vprobeServer" | Set-VMHostFirewallException -Enabled $False #This is used for data collection and intrusion detection
Write-Host "vsanhealth-multicasttest - vsanhealth-multicasttest"
$FirewallArgs.rulesetid="vsanhealth-multicasttest"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "vsanhealth-multicasttest" | Set-VMHostFirewallException -Enabled $False #VSAN is not used
Write-Host "vsanvp - vsanvp"
$FirewallArgs.rulesetid="vsanvp"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "vsanvp" | Set-VMHostFirewallException -Enabled $False #VSAN VASA Vendor Provider is not used
Write-Host "vSphere High Availability Agent - fdm"
$FirewallArgs.rulesetid="fdm"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="fdm"
$IPArgs.ipaddress=$ESXManagementNetwork
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
Write-Host "vSphere Web Access - webAccess"
$FirewallArgs.rulesetid="webAccess"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
$IPArgs.rulesetid="webAccess"
$IPArgs.ipaddress="10.0.0.0/8"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="131.64.0.0/11"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="164.87.0.0/16" #EIS Admin
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="172.17.0.0/16" #Dayton
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="172.19.0.0/16" #Tracy
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="192.67.252.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="192.168.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="198.97.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="199.10.0.0/16"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.7.44.0/22"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.17.194.0/24"
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
$IPArgs.ipaddress="214.73.0.0/16" #Dev and ICS
$esxcli.network.firewall.ruleset.allowedip.add.invoke($IPArgs)
#Write-Host "vSphere Web Client - vSphereClient"
#$FirewallArgs.rulesetid="vSphereClient"
#$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
###NOTE: This service needs to be enabled manually.  Trying to automate it will cause the host to fall off the network and need to be manually added back through the DCUI.  Just copy "NFC" firewall rules for this one
###esxcli network firewall ruleset set --ruleset-id vSphereClient --allowed-all true
Write-Host "vvold - vvold"
$FirewallArgs.rulesetid="vvold"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "vvold" | Set-VMHostFirewallException -Enabled $False #VVOLs are not used
Write-Host "WOL - WOL"
$FirewallArgs.rulesetid="WOL"
$esxcli.network.firewall.ruleset.set.invoke($FirewallArgs)
Get-VMHost | Get-VMHostFirewallException "WOL" | Set-VMHostFirewallException -Enabled $False #WOL is used for Dynamic Power Management (DPM).  WOL is not used

#Refresh firewall entries
$esxcli.network.firewall.refresh.Invoke()

Write-Host "Complete"

disconnect-viserver
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDkTTN0xxDUtGhV
# 7rY6XCEj+7OYR6gkZF6K3qV8sDOQxKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDXoSAHRlNUl0Pipilx10EOZt3FU7RiacN6XNjlyaay2zANBgkq
# hkiG9w0BAQEFAASCAQA/f8mI81Pf7So/dhMqizxD7qWmBxdARMbHjmo1CEY2MBJP
# 1bnBZ3uS1MnmYz8g+/WBs6x7XcNE/gPfnQUWA6kfKPbo+E3GnXUC2C+EHxzd5MiF
# deRNzjOm1nlUFveyZG4P/C/jRTQXg40zWJqQTWnFmfYflCkK2JDFcZe8/33U0d3I
# lrqgHl1xAki1REFboViyX0idokOdznQEYRDJEiPkUBYnTMwU+a8FTPc6sf5ivC6O
# oPfP0+/SgodElj0jcjPcz+W1Kii6/soGuULcLib6Yg8WgS5x+7cQAIg4g4zBhDQz
# QsUv+actn2wveniEhoXd7kLl7EDuQap5b4t2SX3W
# SIG # End signature block
