#PURPOSE: Get the configured DNS IP address from a host and compare it to what is allowed to pass through the DNS firewall rule

#CHANGELOG
#Version 1.0 - Initial version

Clear

#Import list of all vCenter servers and additional info about those servers
$vCenterServerList = Import-CSV "\\orgaze.dir.ad.dla.mil\DCC\VirtualTeam\Scripts\MikeR\vCenter_Servers.csv"

#Display all vCenter servers
Write-Host "vCenter Server list:"
$vCenterServerList.ServerName

#Prompt for the vCenter server that will be connected to
$vCenterServerName = Read-Host "`nEnter the vCenter server name"

#Check to see if the vCenter Server name is valid.  If it is then get the User ID that will be used to connect to the vCenter Server
If ($vCenterServerList.ServerName -notcontains $vCenterServerName) {
    Write-Host "This is not a valid vCenter Server"
    Break
} Else {
    $vCenterUserName = ($vCenterServerList | Where { $_.ServerName -eq $vCenterServerName }).user
}

#Get credentials to connect to the vCenter Server
$Creds = Get-Credential -UserName $vCenterUserName

#Attempt to connect to the vCenter Server
Connect-VIServer -Server $vCenterServerName -Credential $Creds | Out-Null

#If the connection failed then report it and exit
If (!($global:DefaultVIServers | Where { $_.Name -eq $vCenterServerName })) {
    Write-Host "Failed to connect to vCenter Server" -ForegroundColor Red
    Break
}

#Get a list of all VMs
$VMList = (Get-VMHost).Name
#Get the count of VMs
$TotalVMs = $VMList.Count
#Start the counter for the progress bar at 1
$CurrentVM = 1

#Loop through each ESX Host on this vCenter Server
ForEach ($VMHost in $VMList) {
    #Display the VM being scanned and the current VM count
    Write-Progress -Activity "Scanning $VMHost" -Status "$CurrentVM of $TotalVMs" -PercentComplete ($CurrentVM / $TotalVMs * 100)

    #If the host isn't connected to the vCenter server
    If ((Get-VMHost $VMHost).ConnectionState -ne "Connected") {
        #Move onto the next host
        Continue
    }

    #Get the ESXCLI connection setup for this host
    $ESXCLI = Get-EsxCli -VMHost $VMHost -v2 -ErrorAction SilentlyContinue

    #Get the current ESX Admin Group configuration for this system
    $ESXAdminGroup = (Get-VMHost $VMHost | Get-AdvancedSetting -Name "Config.HostAgent.plugins.hostsvc.esxAdminsGroup").Value

    #If the ESX Admin host group is not set correctly then fix it
    If ($ESXAdminGroup -ne "ESX Admins Host Group") {
        Write-Host "`nCorrecting the ESX Admin group on $VMHost"
        Get-VMHost $VMHost | Get-AdvancedSetting -Name "Config.HostAgent.plugins.hostsvc.esxAdminsGroup" | Set-AdvancedSetting -Value "ESX Admins Host Group" -Confirm:$false | Out-Null
    }

    #Get all firewall IP data for the host
    $HostFirewallIPRanges = $ESXCLI.network.firewall.ruleset.allowedip.list.invoke()
    #Find just the Allowed DNS IP addresses
    $DNSFirewallIPs = ($HostFirewallIPRanges | Where { $_.ruleset -eq "dns"}).AllowedIPAddresses

    #Get information for this ESX Host
    $ESXVMHost = Get-VMHost $VMHost
    #Pull the DNS IP info for this host
    $DNSIPsConfigured = (Get-VMHostNetwork -VMHost $ESXVMHost).DnsAddress

    #Get a list of DNS IPs that are in use but not allowed by firewall
    $ListOfDNSIPsNotAllowedByFirewall = Compare-Object $DNSFirewallIPs $DNSIPsConfigured | Where { $_.SideIndicator -ne "<=" }

    #If there are DNS entries that are not in the firewall
    If ($ListOfDNSIPsNotAllowedByFirewall -ne $null) {
        #Notify of the mismatch
        Write-Host "`nThe following IPs will get added to the DNS Firewall on $VMHost"
        $ListOfDNSIPsNotAllowedByFirewall.InputObject

        #Get the current DNS firewall configuration for the system
        $CurrentFirewallRuleConfig = Get-VMHost $ESXVMHost | Get-VMHostFirewallException "DNS Client"
        
        #If the firewall rule is set to allow all IPs then set it to false
        If ($CurrentFirewallRuleConfig.extensiondata.allowedhosts.allip -eq $true) {
            #Create the firewall argument array
            $FirewallArgs = $ESXCLI.network.firewall.ruleset.set.createargs()

            #Ensure that allowedall is set to false
            $FirewallArgs.allowedall = $false
            #Set the rule ID to dns
            $FirewallArgs.rulesetid = "dns"

            #Set allowedall to false
            $ESXCLI.network.firewall.ruleset.set.invoke($FirewallArgs) | Out-Null
        }

        #Loop throgh each IP that needs to get added
        ForEach ($IPToAdd in $ListOfDNSIPsNotAllowedByFirewall.InputObject) {
            #Create the firewall and IP argument arrays
            $IPArgs = $ESXCLI.network.firewall.ruleset.allowedip.add.createargs()
            
            #Set the rule ID to dns
            $IPArgs.rulesetid = "dns"
            #Configure the IP to add
            $IPArgs.ipaddress = $IPToAdd

            #Add the IP address to the firewall rule
            $ESXCLI.network.firewall.ruleset.allowedip.add.invoke($IPArgs) | Out-Null
        }
    }

    #Keep track of which VM is currently being scanned
    $CurrentVM++
}

#Exit the progress bar
Write-Progress -Activity "Scanning $VMHost" -Completed

#Disconnect from all vCenter Servers
Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue
# SIG # Begin signature block
# MIIL6gYJKoZIhvcNAQcCoIIL2zCCC9cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBvlohwK0sqkC5y
# m2+M8JeKzcEqnrpuRdF7+bGXuuNaDKCCCS0wggRsMIIDVKADAgECAgMSNG8wDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS02MzAeFw0yMzA0MTAwMDAwMDBaFw0yNzA0MDcxMzU1NTRaMGYxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMQwwCgYDVQQLEwNETEExEzARBgNVBAMTCkNTLkRMQS4wMDUw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCMxpcnbJBwwjRmBbyprfGQ
# i2nwvtW0H0UO192JBLpyEBkL5XxFA7iJYxXzv5sJ0whsfH8CBN6ly47Bf+QB/EpW
# Fvaay/eYc/O7uGEmk1NX2wYVH1JzrZ7hrHDSL87vcH9mwKVkbRRGVgUNvdfqtXVC
# TbsFRd1f77rzdeCTkKymd2I3Vlt+Nnr0gOy91rn+BXrDJERxeWvmeURfCfxK4D4n
# bGUW2RdsM14sejhnzw2VjrWLXezsLvWCK5rXYoTDLWD2xqrDaYqXB8V8viqKnJFW
# tw8k29z+VOH7BWrk/hZoEDTqIoLfcged0V3Vw2ivSyOnbO+JkFhZywVieBMXApYJ
# AgMBAAGjggEtMIIBKTAfBgNVHSMEGDAWgBQX5kvIGkvJp6ZwtExNXsj2NtQwmDA3
# BgNVHR8EMDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RJRENB
# XzYzLmNybDAOBgNVHQ8BAf8EBAMCB4AwFgYDVR0gBA8wDTALBglghkgBZQIBCyow
# HQYDVR0OBBYEFPgBvFMbp0POnSIbgh8iW8ENigzdMGUGCCsGAQUFBwEBBFkwVzAz
# BggrBgEFBQcwAoYnaHR0cDovL2NybC5kaXNhLm1pbC9zaWduL0RPRElEQ0FfNjMu
# Y2VyMCAGCCsGAQUFBzABhhRodHRwOi8vb2NzcC5kaXNhLm1pbDAfBgNVHSUEGDAW
# BgorBgEEAYI3CgMNBggrBgEFBQcDAzANBgkqhkiG9w0BAQsFAAOCAQEAClCkI904
# YRZn8KpSbGvsf8mSPsIAtHc4DrJv+8Q7a/ZCmUUjIGJMVGgWzUbik63meMbMTxG2
# RfI7c9EPb1EoowEzAnBC1ctf28PRhV//Dlaq2PeWm0gu0ozl6XD6N6GGfgqDKdwy
# 2nbInDNOjJFqgV2jeD9Pl11Ji2zTeLhc67EQWeUlb+GjOgwVooViK0Xkow/C+eQs
# DKfOZkt2HDXumJSijZ+0+GHSLrJlbAI5vB962LnKo3JTKh/VfMP/j6HfzT5nJ7rw
# 95d0s1L/Ah0B4pUiYrFkHyzX6qoMCfLh2iCPQVTg+B26dufCAAJVNOZWzBdQiVk4
# fqtL8riJSQt0tjCCBLkwggOhoAMCAQICAgUPMA0GCSqGSIb3DQEBCwUAMFsxCzAJ
# BgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0Rv
# RDEMMAoGA1UECxMDUEtJMRYwFAYDVQQDEw1Eb0QgUm9vdCBDQSAzMB4XDTIxMDQw
# NjEzNTU1NFoXDTI3MDQwNzEzNTU1NFowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoT
# D1UuUy4gR292ZXJubWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTAT
# BgNVBAMTDERPRCBJRCBDQS02MzCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAMUSXdaAfqLX+7VK7zuVwdeUHt06zLXut9KXKc+CARIAr+uMSV9q+OuSZPqi
# hqrVuZXn0dtI5Ws3zAztXYDkPm2uExEJ/1QLrY/JTv+2oNxoWe2djXUwAeznJF9C
# 53xZLZZ3XLeZos44vAiAf4BhcKHspBRezV254l7ncYTcz17zwYQWN/Ml088zR8Q2
# TgQ14cqIGMevb3SGgy71wsFkx7MOcASWokzBnSnBbAlFC+JDmNIb+tFWJHHbjhff
# nu1pq7CS1jDOSGUuTLy0FKc75f1w5yXpO2iGiFN5bWaLcv/C6+kgTa+4Wr8esy8c
# RMGfxFH1N/ICrkMTqKOdKNrEXJ0CAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFGyK
# lKJ3sYByHYF6Fqry3M5m7kXAMB0GA1UdDgQWBBQX5kvIGkvJp6ZwtExNXsj2NtQw
# mDAOBgNVHQ8BAf8EBAMCAYYwZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZI
# AWUCAQsnMAsGCWCGSAFlAgELKjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAM
# BgpghkgBZQMCAQMRMAwGCmCGSAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAM
# BgNVHSQEBTADgAEAMDcGA1UdHwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvY3JsL0RPRFJPT1RDQTMuY3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcw
# AoYuaHR0cDovL2NybC5kaXNhLm1pbC9pc3N1ZWR0by9ET0RST09UQ0EzX0lULnA3
# YzAgBggrBgEFBQcwAYYUaHR0cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEL
# BQADggEBAAYb1S9VHDiQKcMZbudETt3Q+06f/FTH6wMGEre7nCwUqXXR8bsFLCZB
# GpCe1vB6IkUD10hltI62QMXVx999Qy4ckT7Z/9s4VZC4j1OvsFL5np9Ld6LU+tRG
# uaCblPERLqXOdeq0vgzcgiS+VgxpozEEssYTHLa3rZotnG/cQhr7aA+pVIKh3Q0D
# ZDyhuhGCSj8DTWBt8whxDUUSoGXfNsaFQgfYdzYWdzNbkvmFzrXDrZMHwSihzEPF
# teDSVLwy98Y8i/uStWIuibX+Rt6QL8WUIH/730dw+s8bTuEMv6vKmFtnssiZ0Wvb
# 5tZH41HdkdDZk+jWlIw6YtxGdK4hexUxggITMIICDwIBATBhMFoxCzAJBgNVBAYT
# AlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoG
# A1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMCAxI0bzANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDoI+1mbpw1JcjAf6UhOlXnIodSGYSayLPECNMYDRXpfzANBgkq
# hkiG9w0BAQEFAASCAQA0/c3Z9+q+gIWdzoGVPZbn/CshE+7g80mrMyrTsHS0Gk7f
# Bew5VnrahL8fmP06Q4ZOTwopBk4EK2nRvpPU17V8yzJ7p/LQ7+ywTUAl/hi2JyGC
# +xYQbJRdRdZW7Rkury79rNHgPYK5CYp1fhrBrqsf4TRU/lMplVveYiNugMOYYHNO
# MrbCJqslyyLyhXlymkXPT7EMEA7Zpem+kF+YDXXxoBQxGsAfZWjborbtJWiPclx4
# pOZdnJFS7GlTfDjcREKiC27qm/BgdXTZ6Gvm3arzog+wyVIQt0kxhflJpIYoC3w2
# J3gyjq6pRQzHGrW2GI00XvJMoPcHdNvD92rOwf3A
# SIG # End signature block
