#PURPOSE: Import the App POC information from the share drive and then allow the user to query information about that server

#CHANGELOG
#Version 1.0 - 01/18/24 - MDR - Initial version
#Version 1.01 - 01/26/24 - MDR - Add Server Name text box

#TYPES OF OBJECTS THAT CAN BE PLACED IN A GUI:

#CheckBox — used to list some options and select them before running script;
#RadioButton — lists some text options and allows to select only one of them;
#TextBox — user can write some text. It can be used to get the value of the PowerShell script parameter;
#LabelInputServerName — used for LabelInputServerNameing some parts of scripts’ GUI;
#CheckedListBox — shows a list of items;
#DataGridView — allows to view some tabular data;
#GroupBox — allows viewing and grouping a set of controls together;
#ListBox — can store several text items;
#TabControl — allows you to split your form into different areas (tabs);
#ListView — displays a list of items with text and (optionally) an icon;
#TreeView — hierarchical objects view;
#DateTimePicker — allows to select date and time;
#TrackBar — scrollable control;
#PictureBox — allows to show a picture on the form;
#ProgressBar — indicates the operation progress;
#HScrollBar — horizontal scroll bar;
#VScrollBar — vertical scroll bar;
#ContextMenu — right-click menus;
#Menu — top menu in your form.

#Store path to the App POCs csv file
$AppPOCsCSVPath = "\\Orgaze.dir.ad.dla.mil\J6_INFO_OPS\J64\J64C\WinAdmin\VulnMgt\RAP Team\Scripts\ACAS Report\AppPOCs.csv"

#Create variables to define the Left value for different columns in the form
$Column1LeftValue = 10
$Column2LeftValue = 250

Clear

#Confirm that the App POCs csv exists
If (Test-Path $AppPOCsCSVPath) {
    #Notify that the data is being imported
    Write-Host "Importing App POCs data.  Please wait"
    #Import the App POCs data
    $AppPOCsData = Import-CSV $AppPOCsCSVPath
} Else { #If the file DOESN'T exist
    #Report the missing file and exit the script
    Read-Host "Could not find $AppPOCsCSVPath.  This file should get created by the ACAS Report script.  Press any key to exit" -ForegroundColor Red
    Break
}

#Confirm that App POC data was imported
If ($AppPOCsData -ne $null) {
    #Report successfully loading App POC data
    Write-Host "`nImport successful.  Loading GUI" -ForegroundColor Green
} Else { #If no App POC data was imported
    #Notify of an issue importing App POC data
    Read-Host "`nThere was an issue importing App POC data.  Press any key to exit" -ForegroundColor Red
    Break
}

#Add the Forms assembly that will allow for the creation of a GUI
Add-Type -Assembly System.Windows.Forms

###CREATE THE MAIN FORM###

#Create an object for the primary form
$MainForm = New-Object System.Windows.Forms.Form
#Give a title to the form
$MainForm.Text ='Server POC Query - Version 1.0'
#Set the width and height
$MainForm.Width = 900
$MainForm.Height = 610
#Allow it to autosize if something is placed outside the bounds of the form
$MainForm.AutoSize = $true

#Create variables for the CreateObject function
$ObjectArray = @()
$ObjectCount = 0

#Creates all objects in the form
Function CreateObject {
    Param ( $ObjectType, $Text, $XValue, $YValue, $Width, $Height )

    #Determine what type of object is being created
    If ($ObjectType -eq "Label") {
        $Script:ObjectArray += New-Object System.Windows.Forms.Label
    } ElseIf ($ObjectType -eq "TextBox") {
        $Script:ObjectArray += New-Object System.Windows.Forms.TextBox
    } ElseIf ($ObjectType -eq "ListBox") {
        $Script:ObjectArray += New-Object System.Windows.Forms.ListBox
    }

    #Write the text to the object
    $Script:ObjectArray[$ObjectCount].Text = $Text
    #Set the location of the object
    $Script:ObjectArray[$ObjectCount].Location = New-Object System.Drawing.Point($XValue,$YValue)

    #Use $True to AutoSize the object
    If ($Width -eq $True) {
        $Script:ObjectArray[$ObjectCount].AutoSize = $true
    } Else { #Otherwise if a width is provided
        $Script:ObjectArray[$ObjectCount].Width = $Width
    }

    #If a value for Height is provided then set height
    If ($Height -ne $False) {
        $Script:ObjectArray[$ObjectCount].Height = $Height
    }

    #Add the object to the form
    $MainForm.Controls.Add($ObjectArray[$ObjectCount])

    #Return the current object.  This is useful when something like .Add_Click() needs to be done with the object.  Otherwise use " | Out-Null" to ignore this info
    $ObjectArray[$ObjectCount]
    
    #Increment the object counter
    $Script:ObjectCount++
}

###CREATE LABEL FOR INPUT SERVER NAME###
CreateObject "Label" "Input Server Name" $Column1LeftValue 10 $True $False | Out-Null

###CREATE TEXT BOX FOR SERVER NAME###
$TextBoxServerName = CreateObject "TextBox" "" $Column1LeftValue 30 200 $False

###CREATE LABEL FOR SERVER NAME MATCHES###
CreateObject "Label" "Server Name Matches" $Column1LeftValue 60 $True $False | Out-Null

###CREATE LIST BOX FOR SERVER NAME MATCHES###
$ListBoxServerNameMatches = CreateObject "ListBox" "Server Name Matches" $Column1LeftValue 80 200 470

###CREATE LABEL FOR POC1###
CreateObject "Label" "Server Name" $Column2LeftValue 10 $True $False | Out-Null

###CREATE TEXT BOX FOR POC1###
$TextBoxShowServerName = CreateObject "TextBox" "" $Column2LeftValue 30 300 $False

###CREATE LABEL FOR POC1###
CreateObject "Label" "POC 1" $Column2LeftValue 60 $True $False | Out-Null

###CREATE TEXT BOX FOR POC1###
$TextBoxPOC1 = CreateObject "TextBox" "" $Column2LeftValue 80 300 $False

###CREATE LABEL FOR POC2###
CreateObject "Label" "POC 2" $Column2LeftValue 110 $True $False | Out-Null

###CREATE TEXT BOX FOR POC2###
$TextBoxPOC2 = CreateObject "TextBox" "" $Column2LeftValue 130 300 $False

###CREATE LABEL FOR POC3###
CreateObject "Label" "POC 3" $Column2LeftValue 160 $True $False | Out-Null

###CREATE TEXT BOX FOR POC3###
$TextBoxPOC3 = CreateObject "TextBox" "" $Column2LeftValue 180 300 $False

###CREATE LABEL FOR NOTES###
CreateObject "Label" "Notes" $Column2LeftValue 210 $True $False | Out-Null

###CREATE TEXT BOX FOR NOTES###
$TextBoxNotes = CreateObject "TextBox" "" $Column2LeftValue 230 300 $False

###CREATE LABEL FOR Operating System###
CreateObject "Label" "Operating System" $Column2LeftValue 260 $True $False | Out-Null

###CREATE TEXT BOX FOR Operating System###
$TextBoxOS = CreateObject "TextBox" "" $Column2LeftValue 280 300 $False

###CREATE LABEL FOR Last Seen###
CreateObject "Label" "Last Seen" $Column2LeftValue 310 $True $False | Out-Null

###CREATE TEXT BOX FOR Last Seen###
$TextBoxLastSeen = CreateObject "TextBox" "" $Column2LeftValue 330 300 $False

###CREATE LABEL FOR Application###
CreateObject "Label" "Application" $Column2LeftValue 360 $True $False | Out-Null

###CREATE TEXT BOX FOR Application###
$TextBoxApplication = CreateObject "TextBox" "" $Column2LeftValue 380 300 $False

###CREATE LABEL FOR Maintenance Window###
CreateObject "Label" "Maintenance Window" $Column2LeftValue 410 $True $False | Out-Null

###CREATE TEXT BOX FOR Maintenance Window###
$TextBoxMW = CreateObject "TextBox" "" $Column2LeftValue 430 300 $False

###CREATE LABEL FOR IP Address###
CreateObject "Label" "IP Address" $Column2LeftValue 460 $True $False | Out-Null

###CREATE TEXT BOX FOR IP Address###
$TextBoxIP = CreateObject "TextBox" "" $Column2LeftValue 480 300 $False

###CREATE LABEL FOR Platform###
CreateObject "Label" "Platform" $Column2LeftValue 510 $True $False | Out-Null

###CREATE TEXT BOX FOR Platform###
$TextBoxPlatform = CreateObject "TextBox" "" $Column2LeftValue 530 300 $False

#Each time the Server Name entry has changed
$TextBoxServerName.Add_TextChanged({
    #If the text in the server name box is less than 3 characters in length then no need to do a search just yet
    If ($TextBoxServerName.Text.Length -lt 3) {
        #Clear the list box that shows the matches for all server names
        $ListBoxServerNameMatches.Items.Clear()
        #Tell user to enter at least 3 characters into the server name field
        $ListBoxServerNameMatches.Items.AddRange("Input at least 3 characters")
    } Else { #If at least three letters have been entered for the Server Name
        #Perform a look up for any servers that match what has been typed into this text box
        $ServerNameMatchList = $AppPOCsData.'Server Name' | Where { $_ -like "*$($TextBoxServerName.Text)*" }

        #Verify that neither the filter list nor listbox are empty prior to performing a compare
        If ($ServerNameMatchList -ne $null -and $ListBoxServerNameMatches.Items -ne $null) {
            #Check to see if there are any differences between the filter and current list box
            $CompareLists = Compare-Object $ServerNameMatchList $ListBoxServerNameMatches.Items
        } Else {
            #If either the filter list or listbox are empty then record that no comparison can be done
            $CompareLists = "No comparison could be done"
        }

        #Verify that the filter has items to add to the listbox AND that the filter doesn't match what is already in the listbox
        If ($ServerNameMatchList -ne $null -and $CompareLists -ne $null) {
            #Clear the list box that shows the matches for all server names
            $ListBoxServerNameMatches.Items.Clear()
            #Add the results of that filter to the list box
            $ListBoxServerNameMatches.Items.AddRange($ServerNameMatchList)
        } ElseIf ($ServerNameMatchList -eq $null) { #If the filter is blank
            #Clear the list box that shows the matches for all server names
            $ListBoxServerNameMatches.Items.Clear()
            #Tell user that no matches were found
            $ListBoxServerNameMatches.Items.AddRange("No matches found")
        }
    }
})

#Fill in the POC info for the server selected in the listbox
Function UpdatePOCInfo {
    #If the selection is NOT null
    If ($ListBoxServerNameMatches.SelectedItem -ne $null) {
        #Filter App POCs for the server name that was selected
        $SelectedServerData = $AppPOCsData | Where { $_.'Server Name' -eq $ListBoxServerNameMatches.SelectedItem }

        #Output the POC data for the selected server
        $TextBoxShowServerName.Text = $SelectedServerData.'Server Name'
        $TextBoxPOC1.Text = $SelectedServerData.'POC 1'
        $TextBoxPOC2.Text = $SelectedServerData.'POC 2'
        $TextBoxPOC3.Text = $SelectedServerData.'POC 3'
        $TextBoxNotes.Text = $SelectedServerData.'Other / Notes'
        $TextBoxOS.Text = $SelectedServerData.'Operating System'
        $TextBoxLastSeen.Text = $SelectedServerData.'Last Seen'
        $TextBoxApplication.Text = $SelectedServerData.Application
        $TextBoxMW.Text = $SelectedServerData.'Maint Window'
        $TextBoxIP.Text = $SelectedServerData.'IP Address'
        $TextBoxPlatform.Text = $SelectedServerData.Platform
    }
}

#Each time a key is pressed while the List Box of Server Matches has focus
$ListBoxServerNameMatches.Add_KeyDown({
    UpdatePOCInfo
})

#Each time the List Box of Server Matches gets clicked
$ListBoxServerNameMatches.Add_Click({
    UpdatePOCInfo
})

#Display the form
$MainForm.ShowDialog()
# SIG # Begin signature block
# MIILxQYJKoZIhvcNAQcCoIILtjCCC7ICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUSP6+t7IlFAE3qfwmjv2KkGV7
# CY+gggktMIIEbDCCA1SgAwIBAgIDEjRvMA0GCSqGSIb3DQEBCwUAMFoxCzAJBgNV
# BAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEM
# MAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMwHhcNMjMwNDEwMDAw
# MDAwWhcNMjcwNDA3MTM1NTU0WjBmMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5T
# LiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEMMAoGA1UE
# CxMDRExBMRMwEQYDVQQDEwpDUy5ETEEuMDA1MIIBIjANBgkqhkiG9w0BAQEFAAOC
# AQ8AMIIBCgKCAQEAjMaXJ2yQcMI0ZgW8qa3xkItp8L7VtB9FDtfdiQS6chAZC+V8
# RQO4iWMV87+bCdMIbHx/AgTepcuOwX/kAfxKVhb2msv3mHPzu7hhJpNTV9sGFR9S
# c62e4axw0i/O73B/ZsClZG0URlYFDb3X6rV1Qk27BUXdX++683Xgk5CspndiN1Zb
# fjZ69IDsvda5/gV6wyREcXlr5nlEXwn8SuA+J2xlFtkXbDNeLHo4Z88NlY61i13s
# 7C71giua12KEwy1g9saqw2mKlwfFfL4qipyRVrcPJNvc/lTh+wVq5P4WaBA06iKC
# 33IHndFd1cNor0sjp2zviZBYWcsFYngTFwKWCQIDAQABo4IBLTCCASkwHwYDVR0j
# BBgwFoAUF+ZLyBpLyaemcLRMTV7I9jbUMJgwNwYDVR0fBDAwLjAsoCqgKIYmaHR0
# cDovL2NybC5kaXNhLm1pbC9jcmwvRE9ESURDQV82My5jcmwwDgYDVR0PAQH/BAQD
# AgeAMBYGA1UdIAQPMA0wCwYJYIZIAWUCAQsqMB0GA1UdDgQWBBT4AbxTG6dDzp0i
# G4IfIlvBDYoM3TBlBggrBgEFBQcBAQRZMFcwMwYIKwYBBQUHMAKGJ2h0dHA6Ly9j
# cmwuZGlzYS5taWwvc2lnbi9ET0RJRENBXzYzLmNlcjAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwHwYDVR0lBBgwFgYKKwYBBAGCNwoDDQYIKwYBBQUH
# AwMwDQYJKoZIhvcNAQELBQADggEBAApQpCPdOGEWZ/CqUmxr7H/Jkj7CALR3OA6y
# b/vEO2v2QplFIyBiTFRoFs1G4pOt5njGzE8RtkXyO3PRD29RKKMBMwJwQtXLX9vD
# 0YVf/w5Wqtj3lptILtKM5elw+jehhn4KgyncMtp2yJwzToyRaoFdo3g/T5ddSYts
# 03i4XOuxEFnlJW/hozoMFaKFYitF5KMPwvnkLAynzmZLdhw17piUoo2ftPhh0i6y
# ZWwCObwfeti5yqNyUyof1XzD/4+h380+Zye68PeXdLNS/wIdAeKVImKxZB8s1+qq
# DAny4dogj0FU4PgdunbnwgACVTTmVswXUIlZOH6rS/K4iUkLdLYwggS5MIIDoaAD
# AgECAgIFDzANBgkqhkiG9w0BAQsFADBbMQswCQYDVQQGEwJVUzEYMBYGA1UEChMP
# VS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEWMBQG
# A1UEAxMNRG9EIFJvb3QgQ0EgMzAeFw0yMTA0MDYxMzU1NTRaFw0yNzA0MDcxMzU1
# NTRaMFoxCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAK
# BgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRUwEwYDVQQDEwxET0QgSUQgQ0EtNjMw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDFEl3WgH6i1/u1Su87lcHX
# lB7dOsy17rfSlynPggESAK/rjElfavjrkmT6ooaq1bmV59HbSOVrN8wM7V2A5D5t
# rhMRCf9UC62PyU7/tqDcaFntnY11MAHs5yRfQud8WS2Wd1y3maLOOLwIgH+AYXCh
# 7KQUXs1dueJe53GE3M9e88GEFjfzJdPPM0fENk4ENeHKiBjHr290hoMu9cLBZMez
# DnAElqJMwZ0pwWwJRQviQ5jSG/rRViRx244X357taauwktYwzkhlLky8tBSnO+X9
# cOcl6TtohohTeW1mi3L/wuvpIE2vuFq/HrMvHETBn8RR9TfyAq5DE6ijnSjaxFyd
# AgMBAAGjggGGMIIBgjAfBgNVHSMEGDAWgBRsipSid7GAch2Behaq8tzOZu5FwDAd
# BgNVHQ4EFgQUF+ZLyBpLyaemcLRMTV7I9jbUMJgwDgYDVR0PAQH/BAQDAgGGMGcG
# A1UdIARgMF4wCwYJYIZIAWUCAQskMAsGCWCGSAFlAgELJzALBglghkgBZQIBCyow
# CwYJYIZIAWUCAQs7MAwGCmCGSAFlAwIBAw0wDAYKYIZIAWUDAgEDETAMBgpghkgB
# ZQMCAQMnMBIGA1UdEwEB/wQIMAYBAf8CAQAwDAYDVR0kBAUwA4ABADA3BgNVHR8E
# MDAuMCygKqAohiZodHRwOi8vY3JsLmRpc2EubWlsL2NybC9ET0RST09UQ0EzLmNy
# bDBsBggrBgEFBQcBAQRgMF4wOgYIKwYBBQUHMAKGLmh0dHA6Ly9jcmwuZGlzYS5t
# aWwvaXNzdWVkdG8vRE9EUk9PVENBM19JVC5wN2MwIAYIKwYBBQUHMAGGFGh0dHA6
# Ly9vY3NwLmRpc2EubWlsMA0GCSqGSIb3DQEBCwUAA4IBAQAGG9UvVRw4kCnDGW7n
# RE7d0PtOn/xUx+sDBhK3u5wsFKl10fG7BSwmQRqQntbweiJFA9dIZbSOtkDF1cff
# fUMuHJE+2f/bOFWQuI9Tr7BS+Z6fS3ei1PrURrmgm5TxES6lznXqtL4M3IIkvlYM
# aaMxBLLGExy2t62aLZxv3EIa+2gPqVSCod0NA2Q8oboRgko/A01gbfMIcQ1FEqBl
# 3zbGhUIH2Hc2FnczW5L5hc61w62TB8EoocxDxbXg0lS8MvfGPIv7krViLom1/kbe
# kC/FlCB/+99HcPrPG07hDL+ryphbZ7LImdFr2+bWR+NR3ZHQ2ZPo1pSMOmLcRnSu
# IXsVMYICAjCCAf4CAQEwYTBaMQswCQYDVQQGEwJVUzEYMBYGA1UEChMPVS5TLiBH
# b3Zlcm5tZW50MQwwCgYDVQQLEwNEb0QxDDAKBgNVBAsTA1BLSTEVMBMGA1UEAxMM
# RE9EIElEIENBLTYzAgMSNG8wCQYFKw4DAhoFAKB4MBgGCisGAQQBgjcCAQwxCjAI
# oAKAAKECgAAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIB
# CzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFAeuXqt8AUdixJ22lhUO
# EOY29rALMA0GCSqGSIb3DQEBAQUABIIBAEnBllzefUmlSfOe8zjKjX25YQJEu04V
# Ptx+uiHZKTQ4GFNoW1F/N51PM9WNvwJ1G7UYtpzJN8SGDZ9BwfOoAiE5bFyX1+8H
# sGCOqsWVbhM7NJ774J3Jgb79l/jPB9/ymWE2Hyvk1AfKgJTddZa7NuH8UQCwZhPn
# XbITUjZCZK9B0v+28qz6UZoRh2CZzNWe6p/zbSmF03Kwc2eKbUiWMQhdiivORD8D
# X3zeVGRkjlGLCZ38acZkQ5d39FO/zVz/QacBHe8Tc2wahN+svcvt8+VRuMFB0Fkw
# nhHd8qrX2x2BNOw2szPmdADlIbLpYtsobCcPo82xEGbDw+RLblPnKdw=
# SIG # End signature block
